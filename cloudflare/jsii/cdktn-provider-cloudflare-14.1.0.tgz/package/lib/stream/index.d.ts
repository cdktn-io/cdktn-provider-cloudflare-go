/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#account_id Stream#account_id}
    */
    readonly accountId: string;
    /**
    * Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#allowed_origins Stream#allowed_origins}
    */
    readonly allowedOrigins?: string[];
    /**
    * A user-defined identifier for the media creator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#creator Stream#creator}
    */
    readonly creator?: string;
    /**
    * A Cloudflare-generated unique identifier for a media item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#identifier Stream#identifier}
    */
    readonly identifier?: string;
    /**
    * The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#max_duration_seconds Stream#max_duration_seconds}
    */
    readonly maxDurationSeconds?: number;
    /**
    * A user modifiable key-value store used to reference other systems of record for managing videos.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#meta Stream#meta}
    */
    readonly meta?: string;
    /**
    * Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#require_signed_urls Stream#require_signed_urls}
    */
    readonly requireSignedUrls?: boolean | cdktn.IResolvable;
    /**
    * Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#scheduled_deletion Stream#scheduled_deletion}
    */
    readonly scheduledDeletion?: string;
    /**
    * The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video.  If this value is not set, the default thumbnail image is taken from 0s of the video.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#thumbnail_timestamp_pct Stream#thumbnail_timestamp_pct}
    */
    readonly thumbnailTimestampPct?: number;
    /**
    * The date and time when the video upload URL is no longer valid for direct user uploads.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#upload_expiry Stream#upload_expiry}
    */
    readonly uploadExpiry?: string;
}
export interface StreamInput {
}
export declare function streamInputToTerraform(struct?: StreamInput): any;
export declare function streamInputToHclTerraform(struct?: StreamInput): any;
export declare class StreamInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StreamInput | undefined;
    set internalValue(value: StreamInput | undefined);
    get height(): number;
    get width(): number;
}
export interface StreamPlayback {
}
export declare function streamPlaybackToTerraform(struct?: StreamPlayback): any;
export declare function streamPlaybackToHclTerraform(struct?: StreamPlayback): any;
export declare class StreamPlaybackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StreamPlayback | undefined;
    set internalValue(value: StreamPlayback | undefined);
    get dash(): string;
    get hls(): string;
}
export interface StreamStatus {
}
export declare function streamStatusToTerraform(struct?: StreamStatus): any;
export declare function streamStatusToHclTerraform(struct?: StreamStatus): any;
export declare class StreamStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StreamStatus | undefined;
    set internalValue(value: StreamStatus | undefined);
    get errorReasonCode(): string;
    get errorReasonText(): string;
    get pctComplete(): string;
    get state(): string;
}
export interface StreamWatermark {
}
export declare function streamWatermarkToTerraform(struct?: StreamWatermark): any;
export declare function streamWatermarkToHclTerraform(struct?: StreamWatermark): any;
export declare class StreamWatermarkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StreamWatermark | undefined;
    set internalValue(value: StreamWatermark | undefined);
    get created(): string;
    get downloadedFrom(): string;
    get height(): number;
    get name(): string;
    get opacity(): number;
    get padding(): number;
    get position(): string;
    get scale(): number;
    get size(): number;
    get uid(): string;
    get width(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream cloudflare_stream}
*/
export declare class Stream extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_stream";
    /**
    * Generates CDKTN code for importing a Stream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Stream to import
    * @param importFromId The id of the existing Stream that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Stream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream cloudflare_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StreamConfig
    */
    constructor(scope: Construct, id: string, config: StreamConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    resetAllowedOrigins(): void;
    get allowedOriginsInput(): string[] | undefined;
    get created(): string;
    private _creator?;
    get creator(): string;
    set creator(value: string);
    resetCreator(): void;
    get creatorInput(): string | undefined;
    get duration(): number;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    resetIdentifier(): void;
    get identifierInput(): string | undefined;
    private _input;
    get input(): StreamInputOutputReference;
    get liveInput(): string;
    private _maxDurationSeconds?;
    get maxDurationSeconds(): number;
    set maxDurationSeconds(value: number);
    resetMaxDurationSeconds(): void;
    get maxDurationSecondsInput(): number | undefined;
    private _meta?;
    get meta(): string;
    set meta(value: string);
    resetMeta(): void;
    get metaInput(): string | undefined;
    get modified(): string;
    private _playback;
    get playback(): StreamPlaybackOutputReference;
    get preview(): string;
    get readyToStream(): cdktn.IResolvable;
    get readyToStreamAt(): string;
    private _requireSignedUrls?;
    get requireSignedUrls(): boolean | cdktn.IResolvable;
    set requireSignedUrls(value: boolean | cdktn.IResolvable);
    resetRequireSignedUrls(): void;
    get requireSignedUrlsInput(): boolean | cdktn.IResolvable | undefined;
    private _scheduledDeletion?;
    get scheduledDeletion(): string;
    set scheduledDeletion(value: string);
    resetScheduledDeletion(): void;
    get scheduledDeletionInput(): string | undefined;
    get size(): number;
    private _status;
    get status(): StreamStatusOutputReference;
    get thumbnail(): string;
    private _thumbnailTimestampPct?;
    get thumbnailTimestampPct(): number;
    set thumbnailTimestampPct(value: number);
    resetThumbnailTimestampPct(): void;
    get thumbnailTimestampPctInput(): number | undefined;
    get uid(): string;
    private _uploadExpiry?;
    get uploadExpiry(): string;
    set uploadExpiry(value: string);
    resetUploadExpiry(): void;
    get uploadExpiryInput(): string | undefined;
    get uploaded(): string;
    private _watermark;
    get watermark(): StreamWatermarkOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
