/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSecretsStoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_stores#account_id DataCloudflareSecretsStores#account_id}
    */
    readonly accountId: string;
    /**
    * Direction to sort objects.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_stores#direction DataCloudflareSecretsStores#direction}
    */
    readonly direction?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_stores#max_items DataCloudflareSecretsStores#max_items}
    */
    readonly maxItems?: number;
    /**
    * Order stores by values in the given field.
    * Available values: "name", "created", "modified".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_stores#order DataCloudflareSecretsStores#order}
    */
    readonly order?: string;
}
export interface DataCloudflareSecretsStoresResult {
}
export declare function dataCloudflareSecretsStoresResultToTerraform(struct?: DataCloudflareSecretsStoresResult): any;
export declare function dataCloudflareSecretsStoresResultToHclTerraform(struct?: DataCloudflareSecretsStoresResult): any;
export declare class DataCloudflareSecretsStoresResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareSecretsStoresResult | undefined;
    set internalValue(value: DataCloudflareSecretsStoresResult | undefined);
    get accountId(): string;
    get created(): string;
    get id(): string;
    get modified(): string;
    get name(): string;
}
export declare class DataCloudflareSecretsStoresResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareSecretsStoresResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_stores cloudflare_secrets_stores}
*/
export declare class DataCloudflareSecretsStores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_secrets_stores";
    /**
    * Generates CDKTN code for importing a DataCloudflareSecretsStores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSecretsStores to import
    * @param importFromId The id of the existing DataCloudflareSecretsStores that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_stores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSecretsStores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_stores cloudflare_secrets_stores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSecretsStoresConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareSecretsStoresConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _result;
    get result(): DataCloudflareSecretsStoresResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
