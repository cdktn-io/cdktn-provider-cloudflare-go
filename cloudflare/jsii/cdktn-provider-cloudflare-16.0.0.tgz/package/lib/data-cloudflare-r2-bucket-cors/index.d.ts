/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareR2BucketCorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/r2_bucket_cors#account_id DataCloudflareR2BucketCors#account_id}
    */
    readonly accountId: string;
    /**
    * Name of the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/r2_bucket_cors#bucket_name DataCloudflareR2BucketCors#bucket_name}
    */
    readonly bucketName: string;
}
export interface DataCloudflareR2BucketCorsRulesAllowed {
}
export declare function dataCloudflareR2BucketCorsRulesAllowedToTerraform(struct?: DataCloudflareR2BucketCorsRulesAllowed): any;
export declare function dataCloudflareR2BucketCorsRulesAllowedToHclTerraform(struct?: DataCloudflareR2BucketCorsRulesAllowed): any;
export declare class DataCloudflareR2BucketCorsRulesAllowedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareR2BucketCorsRulesAllowed | undefined;
    set internalValue(value: DataCloudflareR2BucketCorsRulesAllowed | undefined);
    get headers(): string[];
    get methods(): string[];
    get origins(): string[];
}
export interface DataCloudflareR2BucketCorsRules {
}
export declare function dataCloudflareR2BucketCorsRulesToTerraform(struct?: DataCloudflareR2BucketCorsRules): any;
export declare function dataCloudflareR2BucketCorsRulesToHclTerraform(struct?: DataCloudflareR2BucketCorsRules): any;
export declare class DataCloudflareR2BucketCorsRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareR2BucketCorsRules | undefined;
    set internalValue(value: DataCloudflareR2BucketCorsRules | undefined);
    private _allowed;
    get allowed(): DataCloudflareR2BucketCorsRulesAllowedOutputReference;
    get exposeHeaders(): string[];
    get id(): string;
    get maxAgeSeconds(): number;
}
export declare class DataCloudflareR2BucketCorsRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareR2BucketCorsRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/r2_bucket_cors cloudflare_r2_bucket_cors}
*/
export declare class DataCloudflareR2BucketCors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_r2_bucket_cors";
    /**
    * Generates CDKTN code for importing a DataCloudflareR2BucketCors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareR2BucketCors to import
    * @param importFromId The id of the existing DataCloudflareR2BucketCors that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/r2_bucket_cors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareR2BucketCors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/r2_bucket_cors cloudflare_r2_bucket_cors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareR2BucketCorsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareR2BucketCorsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _rules;
    get rules(): DataCloudflareR2BucketCorsRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
