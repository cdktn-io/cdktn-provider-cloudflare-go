/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EmailRoutingDnsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Domain of your zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/email_routing_dns#name EmailRoutingDns#name}
    */
    readonly name?: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/email_routing_dns#zone_id EmailRoutingDns#zone_id}
    */
    readonly zoneId: string;
}
export interface EmailRoutingDnsErrorsSource {
}
export declare function emailRoutingDnsErrorsSourceToTerraform(struct?: EmailRoutingDnsErrorsSource): any;
export declare function emailRoutingDnsErrorsSourceToHclTerraform(struct?: EmailRoutingDnsErrorsSource): any;
export declare class EmailRoutingDnsErrorsSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EmailRoutingDnsErrorsSource | undefined;
    set internalValue(value: EmailRoutingDnsErrorsSource | undefined);
    get pointer(): string;
}
export interface EmailRoutingDnsErrors {
}
export declare function emailRoutingDnsErrorsToTerraform(struct?: EmailRoutingDnsErrors): any;
export declare function emailRoutingDnsErrorsToHclTerraform(struct?: EmailRoutingDnsErrors): any;
export declare class EmailRoutingDnsErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailRoutingDnsErrors | undefined;
    set internalValue(value: EmailRoutingDnsErrors | undefined);
    get code(): number;
    get documentationUrl(): string;
    get message(): string;
    private _source;
    get source(): EmailRoutingDnsErrorsSourceOutputReference;
}
export declare class EmailRoutingDnsErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailRoutingDnsErrorsOutputReference;
}
export interface EmailRoutingDnsMessagesSource {
}
export declare function emailRoutingDnsMessagesSourceToTerraform(struct?: EmailRoutingDnsMessagesSource): any;
export declare function emailRoutingDnsMessagesSourceToHclTerraform(struct?: EmailRoutingDnsMessagesSource): any;
export declare class EmailRoutingDnsMessagesSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EmailRoutingDnsMessagesSource | undefined;
    set internalValue(value: EmailRoutingDnsMessagesSource | undefined);
    get pointer(): string;
}
export interface EmailRoutingDnsMessages {
}
export declare function emailRoutingDnsMessagesToTerraform(struct?: EmailRoutingDnsMessages): any;
export declare function emailRoutingDnsMessagesToHclTerraform(struct?: EmailRoutingDnsMessages): any;
export declare class EmailRoutingDnsMessagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailRoutingDnsMessages | undefined;
    set internalValue(value: EmailRoutingDnsMessages | undefined);
    get code(): number;
    get documentationUrl(): string;
    get message(): string;
    private _source;
    get source(): EmailRoutingDnsMessagesSourceOutputReference;
}
export declare class EmailRoutingDnsMessagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailRoutingDnsMessagesOutputReference;
}
export interface EmailRoutingDnsResultErrorsMissing {
}
export declare function emailRoutingDnsResultErrorsMissingToTerraform(struct?: EmailRoutingDnsResultErrorsMissing): any;
export declare function emailRoutingDnsResultErrorsMissingToHclTerraform(struct?: EmailRoutingDnsResultErrorsMissing): any;
export declare class EmailRoutingDnsResultErrorsMissingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EmailRoutingDnsResultErrorsMissing | undefined;
    set internalValue(value: EmailRoutingDnsResultErrorsMissing | undefined);
    get content(): string;
    get name(): string;
    get priority(): number;
    get ttl(): number;
    get type(): string;
}
export interface EmailRoutingDnsResultErrors {
}
export declare function emailRoutingDnsResultErrorsToTerraform(struct?: EmailRoutingDnsResultErrors): any;
export declare function emailRoutingDnsResultErrorsToHclTerraform(struct?: EmailRoutingDnsResultErrors): any;
export declare class EmailRoutingDnsResultErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailRoutingDnsResultErrors | undefined;
    set internalValue(value: EmailRoutingDnsResultErrors | undefined);
    get code(): string;
    private _missing;
    get missing(): EmailRoutingDnsResultErrorsMissingOutputReference;
}
export declare class EmailRoutingDnsResultErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailRoutingDnsResultErrorsOutputReference;
}
export interface EmailRoutingDnsResultRecord {
}
export declare function emailRoutingDnsResultRecordToTerraform(struct?: EmailRoutingDnsResultRecord): any;
export declare function emailRoutingDnsResultRecordToHclTerraform(struct?: EmailRoutingDnsResultRecord): any;
export declare class EmailRoutingDnsResultRecordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailRoutingDnsResultRecord | undefined;
    set internalValue(value: EmailRoutingDnsResultRecord | undefined);
    get content(): string;
    get name(): string;
    get priority(): number;
    get ttl(): number;
    get type(): string;
}
export declare class EmailRoutingDnsResultRecordList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailRoutingDnsResultRecordOutputReference;
}
export interface EmailRoutingDnsResult {
}
export declare function emailRoutingDnsResultToTerraform(struct?: EmailRoutingDnsResult): any;
export declare function emailRoutingDnsResultToHclTerraform(struct?: EmailRoutingDnsResult): any;
export declare class EmailRoutingDnsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EmailRoutingDnsResult | undefined;
    set internalValue(value: EmailRoutingDnsResult | undefined);
    get content(): string;
    private _errors;
    get errors(): EmailRoutingDnsResultErrorsList;
    get name(): string;
    get priority(): number;
    private _record;
    get record(): EmailRoutingDnsResultRecordList;
    get ttl(): number;
    get type(): string;
}
export interface EmailRoutingDnsResultInfo {
}
export declare function emailRoutingDnsResultInfoToTerraform(struct?: EmailRoutingDnsResultInfo): any;
export declare function emailRoutingDnsResultInfoToHclTerraform(struct?: EmailRoutingDnsResultInfo): any;
export declare class EmailRoutingDnsResultInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EmailRoutingDnsResultInfo | undefined;
    set internalValue(value: EmailRoutingDnsResultInfo | undefined);
    get emailRoutingDnsCount(): number;
    get page(): number;
    get perPage(): number;
    get totalCount(): number;
    get totalPages(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/email_routing_dns cloudflare_email_routing_dns}
*/
export declare class EmailRoutingDns extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_email_routing_dns";
    /**
    * Generates CDKTN code for importing a EmailRoutingDns resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailRoutingDns to import
    * @param importFromId The id of the existing EmailRoutingDns that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/email_routing_dns#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailRoutingDns to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/email_routing_dns cloudflare_email_routing_dns} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailRoutingDnsConfig
    */
    constructor(scope: Construct, id: string, config: EmailRoutingDnsConfig);
    get created(): string;
    get enabled(): cdktn.IResolvable;
    private _errors;
    get errors(): EmailRoutingDnsErrorsList;
    get id(): string;
    private _messages;
    get messages(): EmailRoutingDnsMessagesList;
    get modified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _result;
    get result(): EmailRoutingDnsResultOutputReference;
    private _resultInfo;
    get resultInfo(): EmailRoutingDnsResultInfoOutputReference;
    get skipWizard(): cdktn.IResolvable;
    get status(): string;
    get success(): cdktn.IResolvable;
    get tag(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
