/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCertificatePacksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specify the deployment environment for the certificate packs.
    * Available values: "staging", "production".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/certificate_packs#deploy DataCloudflareCertificatePacks#deploy}
    */
    readonly deploy?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/certificate_packs#max_items DataCloudflareCertificatePacks#max_items}
    */
    readonly maxItems?: number;
    /**
    * Include Certificate Packs of all statuses, not just active ones.
    * Available values: "all".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/certificate_packs#status DataCloudflareCertificatePacks#status}
    */
    readonly status?: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/certificate_packs#zone_id DataCloudflareCertificatePacks#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflareCertificatePacksResultCertificatesGeoRestrictions {
}
export declare function dataCloudflareCertificatePacksResultCertificatesGeoRestrictionsToTerraform(struct?: DataCloudflareCertificatePacksResultCertificatesGeoRestrictions): any;
export declare function dataCloudflareCertificatePacksResultCertificatesGeoRestrictionsToHclTerraform(struct?: DataCloudflareCertificatePacksResultCertificatesGeoRestrictions): any;
export declare class DataCloudflareCertificatePacksResultCertificatesGeoRestrictionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCertificatePacksResultCertificatesGeoRestrictions | undefined;
    set internalValue(value: DataCloudflareCertificatePacksResultCertificatesGeoRestrictions | undefined);
    get label(): string;
}
export interface DataCloudflareCertificatePacksResultCertificates {
}
export declare function dataCloudflareCertificatePacksResultCertificatesToTerraform(struct?: DataCloudflareCertificatePacksResultCertificates): any;
export declare function dataCloudflareCertificatePacksResultCertificatesToHclTerraform(struct?: DataCloudflareCertificatePacksResultCertificates): any;
export declare class DataCloudflareCertificatePacksResultCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCertificatePacksResultCertificates | undefined;
    set internalValue(value: DataCloudflareCertificatePacksResultCertificates | undefined);
    get bundleMethod(): string;
    get expiresOn(): string;
    private _geoRestrictions;
    get geoRestrictions(): DataCloudflareCertificatePacksResultCertificatesGeoRestrictionsOutputReference;
    get hosts(): string[];
    get id(): string;
    get issuer(): string;
    get modifiedOn(): string;
    get priority(): number;
    get signature(): string;
    get status(): string;
    get uploadedOn(): string;
    get zoneId(): string;
}
export declare class DataCloudflareCertificatePacksResultCertificatesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCertificatePacksResultCertificatesOutputReference;
}
export interface DataCloudflareCertificatePacksResultDcvDelegationRecords {
}
export declare function dataCloudflareCertificatePacksResultDcvDelegationRecordsToTerraform(struct?: DataCloudflareCertificatePacksResultDcvDelegationRecords): any;
export declare function dataCloudflareCertificatePacksResultDcvDelegationRecordsToHclTerraform(struct?: DataCloudflareCertificatePacksResultDcvDelegationRecords): any;
export declare class DataCloudflareCertificatePacksResultDcvDelegationRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCertificatePacksResultDcvDelegationRecords | undefined;
    set internalValue(value: DataCloudflareCertificatePacksResultDcvDelegationRecords | undefined);
    get cname(): string;
    get cnameTarget(): string;
    get emails(): string[];
    get httpBody(): string;
    get httpUrl(): string;
    get status(): string;
    get txtName(): string;
    get txtValue(): string;
}
export declare class DataCloudflareCertificatePacksResultDcvDelegationRecordsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCertificatePacksResultDcvDelegationRecordsOutputReference;
}
export interface DataCloudflareCertificatePacksResultValidationErrors {
}
export declare function dataCloudflareCertificatePacksResultValidationErrorsToTerraform(struct?: DataCloudflareCertificatePacksResultValidationErrors): any;
export declare function dataCloudflareCertificatePacksResultValidationErrorsToHclTerraform(struct?: DataCloudflareCertificatePacksResultValidationErrors): any;
export declare class DataCloudflareCertificatePacksResultValidationErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCertificatePacksResultValidationErrors | undefined;
    set internalValue(value: DataCloudflareCertificatePacksResultValidationErrors | undefined);
    get message(): string;
}
export declare class DataCloudflareCertificatePacksResultValidationErrorsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCertificatePacksResultValidationErrorsOutputReference;
}
export interface DataCloudflareCertificatePacksResultValidationRecords {
}
export declare function dataCloudflareCertificatePacksResultValidationRecordsToTerraform(struct?: DataCloudflareCertificatePacksResultValidationRecords): any;
export declare function dataCloudflareCertificatePacksResultValidationRecordsToHclTerraform(struct?: DataCloudflareCertificatePacksResultValidationRecords): any;
export declare class DataCloudflareCertificatePacksResultValidationRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCertificatePacksResultValidationRecords | undefined;
    set internalValue(value: DataCloudflareCertificatePacksResultValidationRecords | undefined);
    get cname(): string;
    get cnameTarget(): string;
    get emails(): string[];
    get httpBody(): string;
    get httpUrl(): string;
    get status(): string;
    get txtName(): string;
    get txtValue(): string;
}
export declare class DataCloudflareCertificatePacksResultValidationRecordsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCertificatePacksResultValidationRecordsOutputReference;
}
export interface DataCloudflareCertificatePacksResult {
}
export declare function dataCloudflareCertificatePacksResultToTerraform(struct?: DataCloudflareCertificatePacksResult): any;
export declare function dataCloudflareCertificatePacksResultToHclTerraform(struct?: DataCloudflareCertificatePacksResult): any;
export declare class DataCloudflareCertificatePacksResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCertificatePacksResult | undefined;
    set internalValue(value: DataCloudflareCertificatePacksResult | undefined);
    get certificateAuthority(): string;
    private _certificates;
    get certificates(): DataCloudflareCertificatePacksResultCertificatesList;
    get cloudflareBranding(): cdktn.IResolvable;
    private _dcvDelegationRecords;
    get dcvDelegationRecords(): DataCloudflareCertificatePacksResultDcvDelegationRecordsList;
    get hosts(): string[];
    get id(): string;
    get primaryCertificate(): string;
    get status(): string;
    get type(): string;
    private _validationErrors;
    get validationErrors(): DataCloudflareCertificatePacksResultValidationErrorsList;
    get validationMethod(): string;
    private _validationRecords;
    get validationRecords(): DataCloudflareCertificatePacksResultValidationRecordsList;
    get validityDays(): number;
}
export declare class DataCloudflareCertificatePacksResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCertificatePacksResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/certificate_packs cloudflare_certificate_packs}
*/
export declare class DataCloudflareCertificatePacks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_certificate_packs";
    /**
    * Generates CDKTN code for importing a DataCloudflareCertificatePacks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCertificatePacks to import
    * @param importFromId The id of the existing DataCloudflareCertificatePacks that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/certificate_packs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCertificatePacks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/certificate_packs cloudflare_certificate_packs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCertificatePacksConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareCertificatePacksConfig);
    private _deploy?;
    get deploy(): string;
    set deploy(value: string);
    resetDeploy(): void;
    get deployInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareCertificatePacksResultList;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
