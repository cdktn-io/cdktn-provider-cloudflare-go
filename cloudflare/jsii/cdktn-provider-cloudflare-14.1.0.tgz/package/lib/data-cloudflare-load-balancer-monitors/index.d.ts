/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLoadBalancerMonitorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/load_balancer_monitors#account_id DataCloudflareLoadBalancerMonitors#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/load_balancer_monitors#max_items DataCloudflareLoadBalancerMonitors#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareLoadBalancerMonitorsResult {
}
export declare function dataCloudflareLoadBalancerMonitorsResultToTerraform(struct?: DataCloudflareLoadBalancerMonitorsResult): any;
export declare function dataCloudflareLoadBalancerMonitorsResultToHclTerraform(struct?: DataCloudflareLoadBalancerMonitorsResult): any;
export declare class DataCloudflareLoadBalancerMonitorsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerMonitorsResult | undefined;
    set internalValue(value: DataCloudflareLoadBalancerMonitorsResult | undefined);
    get allowInsecure(): cdktn.IResolvable;
    get consecutiveDown(): number;
    get consecutiveUp(): number;
    get createdOn(): string;
    get description(): string;
    get expectedBody(): string;
    get expectedCodes(): string;
    get followRedirects(): cdktn.IResolvable;
    private _header;
    get header(): cdktn.StringListMap;
    get id(): string;
    get interval(): number;
    get method(): string;
    get modifiedOn(): string;
    get path(): string;
    get port(): number;
    get probeZone(): string;
    get retries(): number;
    get timeout(): number;
    get type(): string;
}
export declare class DataCloudflareLoadBalancerMonitorsResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerMonitorsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/load_balancer_monitors cloudflare_load_balancer_monitors}
*/
export declare class DataCloudflareLoadBalancerMonitors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_load_balancer_monitors";
    /**
    * Generates CDKTN code for importing a DataCloudflareLoadBalancerMonitors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLoadBalancerMonitors to import
    * @param importFromId The id of the existing DataCloudflareLoadBalancerMonitors that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/load_balancer_monitors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLoadBalancerMonitors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/load_balancer_monitors cloudflare_load_balancer_monitors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLoadBalancerMonitorsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareLoadBalancerMonitorsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareLoadBalancerMonitorsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
