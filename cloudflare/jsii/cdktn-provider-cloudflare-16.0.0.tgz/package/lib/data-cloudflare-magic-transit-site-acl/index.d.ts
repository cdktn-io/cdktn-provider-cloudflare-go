/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicTransitSiteAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/magic_transit_site_acl#account_id DataCloudflareMagicTransitSiteAcl#account_id}
    */
    readonly accountId: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/magic_transit_site_acl#acl_id DataCloudflareMagicTransitSiteAcl#acl_id}
    */
    readonly aclId: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/magic_transit_site_acl#site_id DataCloudflareMagicTransitSiteAcl#site_id}
    */
    readonly siteId: string;
}
export interface DataCloudflareMagicTransitSiteAclLan1 {
}
export declare function dataCloudflareMagicTransitSiteAclLan1ToTerraform(struct?: DataCloudflareMagicTransitSiteAclLan1): any;
export declare function dataCloudflareMagicTransitSiteAclLan1ToHclTerraform(struct?: DataCloudflareMagicTransitSiteAclLan1): any;
export declare class DataCloudflareMagicTransitSiteAclLan1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitSiteAclLan1 | undefined;
    set internalValue(value: DataCloudflareMagicTransitSiteAclLan1 | undefined);
    get lanId(): string;
    get lanName(): string;
    get portRanges(): string[];
    get ports(): number[];
    get subnets(): string[];
}
export interface DataCloudflareMagicTransitSiteAclLan2 {
}
export declare function dataCloudflareMagicTransitSiteAclLan2ToTerraform(struct?: DataCloudflareMagicTransitSiteAclLan2): any;
export declare function dataCloudflareMagicTransitSiteAclLan2ToHclTerraform(struct?: DataCloudflareMagicTransitSiteAclLan2): any;
export declare class DataCloudflareMagicTransitSiteAclLan2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitSiteAclLan2 | undefined;
    set internalValue(value: DataCloudflareMagicTransitSiteAclLan2 | undefined);
    get lanId(): string;
    get lanName(): string;
    get portRanges(): string[];
    get ports(): number[];
    get subnets(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/magic_transit_site_acl cloudflare_magic_transit_site_acl}
*/
export declare class DataCloudflareMagicTransitSiteAcl extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_transit_site_acl";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicTransitSiteAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicTransitSiteAcl to import
    * @param importFromId The id of the existing DataCloudflareMagicTransitSiteAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/magic_transit_site_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicTransitSiteAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/magic_transit_site_acl cloudflare_magic_transit_site_acl} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicTransitSiteAclConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicTransitSiteAclConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _aclId?;
    get aclId(): string;
    set aclId(value: string);
    get aclIdInput(): string | undefined;
    get description(): string;
    get forwardLocally(): cdktn.IResolvable;
    get id(): string;
    private _lan1;
    get lan1(): DataCloudflareMagicTransitSiteAclLan1OutputReference;
    private _lan2;
    get lan2(): DataCloudflareMagicTransitSiteAclLan2OutputReference;
    get name(): string;
    get protocols(): string[];
    private _siteId?;
    get siteId(): string;
    set siteId(value: string);
    get siteIdInput(): string | undefined;
    get unidirectional(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
