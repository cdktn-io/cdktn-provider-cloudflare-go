/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogpullRetentionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The log retention flag for Logpull API.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/logpull_retention#flag LogpullRetention#flag}
    */
    readonly flag?: boolean | cdktn.IResolvable;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/logpull_retention#zone_id LogpullRetention#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/logpull_retention cloudflare_logpull_retention}
*/
export declare class LogpullRetention extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_logpull_retention";
    /**
    * Generates CDKTN code for importing a LogpullRetention resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogpullRetention to import
    * @param importFromId The id of the existing LogpullRetention that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/logpull_retention#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogpullRetention to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/logpull_retention cloudflare_logpull_retention} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogpullRetentionConfig
    */
    constructor(scope: Construct, id: string, config: LogpullRetentionConfig);
    private _flag?;
    get flag(): boolean | cdktn.IResolvable;
    set flag(value: boolean | cdktn.IResolvable);
    resetFlag(): void;
    get flagInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
