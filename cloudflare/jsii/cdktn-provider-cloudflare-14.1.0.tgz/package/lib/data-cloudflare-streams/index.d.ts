/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareStreamsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#account_id DataCloudflareStreams#account_id}
    */
    readonly accountId: string;
    /**
    * Lists videos in ascending order of creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#asc DataCloudflareStreams#asc}
    */
    readonly asc?: boolean | cdktn.IResolvable;
    /**
    * A user-defined identifier for the media creator.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#creator DataCloudflareStreams#creator}
    */
    readonly creator?: string;
    /**
    * Lists videos created before the specified date.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#end DataCloudflareStreams#end}
    */
    readonly end?: string;
    /**
    * Includes the total number of videos associated with the submitted query parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#include_counts DataCloudflareStreams#include_counts}
    */
    readonly includeCounts?: boolean | cdktn.IResolvable;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#max_items DataCloudflareStreams#max_items}
    */
    readonly maxItems?: number;
    /**
    * Provides a partial word match of the `name` key in the `meta` field. Slow for medium to large video libraries. May be unavailable for very large libraries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#search DataCloudflareStreams#search}
    */
    readonly search?: string;
    /**
    * Lists videos created after the specified date.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#start DataCloudflareStreams#start}
    */
    readonly start?: string;
    /**
    * Specifies the processing status for all quality levels for a video.
    * Available values: "pendingupload", "downloading", "queued", "inprogress", "ready", "error", "live-inprogress".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#status DataCloudflareStreams#status}
    */
    readonly status?: string;
    /**
    * Specifies whether the video is `vod` or `live`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#type DataCloudflareStreams#type}
    */
    readonly type?: string;
    /**
    * Provides a fast, exact string match on the `name` key in the `meta` field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#video_name DataCloudflareStreams#video_name}
    */
    readonly videoName?: string;
}
export interface DataCloudflareStreamsResultInput {
}
export declare function dataCloudflareStreamsResultInputToTerraform(struct?: DataCloudflareStreamsResultInput): any;
export declare function dataCloudflareStreamsResultInputToHclTerraform(struct?: DataCloudflareStreamsResultInput): any;
export declare class DataCloudflareStreamsResultInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamsResultInput | undefined;
    set internalValue(value: DataCloudflareStreamsResultInput | undefined);
    get height(): number;
    get width(): number;
}
export interface DataCloudflareStreamsResultPlayback {
}
export declare function dataCloudflareStreamsResultPlaybackToTerraform(struct?: DataCloudflareStreamsResultPlayback): any;
export declare function dataCloudflareStreamsResultPlaybackToHclTerraform(struct?: DataCloudflareStreamsResultPlayback): any;
export declare class DataCloudflareStreamsResultPlaybackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamsResultPlayback | undefined;
    set internalValue(value: DataCloudflareStreamsResultPlayback | undefined);
    get dash(): string;
    get hls(): string;
}
export interface DataCloudflareStreamsResultStatus {
}
export declare function dataCloudflareStreamsResultStatusToTerraform(struct?: DataCloudflareStreamsResultStatus): any;
export declare function dataCloudflareStreamsResultStatusToHclTerraform(struct?: DataCloudflareStreamsResultStatus): any;
export declare class DataCloudflareStreamsResultStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamsResultStatus | undefined;
    set internalValue(value: DataCloudflareStreamsResultStatus | undefined);
    get errorReasonCode(): string;
    get errorReasonText(): string;
    get pctComplete(): string;
    get state(): string;
}
export interface DataCloudflareStreamsResultWatermark {
}
export declare function dataCloudflareStreamsResultWatermarkToTerraform(struct?: DataCloudflareStreamsResultWatermark): any;
export declare function dataCloudflareStreamsResultWatermarkToHclTerraform(struct?: DataCloudflareStreamsResultWatermark): any;
export declare class DataCloudflareStreamsResultWatermarkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamsResultWatermark | undefined;
    set internalValue(value: DataCloudflareStreamsResultWatermark | undefined);
    get created(): string;
    get downloadedFrom(): string;
    get height(): number;
    get name(): string;
    get opacity(): number;
    get padding(): number;
    get position(): string;
    get scale(): number;
    get size(): number;
    get uid(): string;
    get width(): number;
}
export interface DataCloudflareStreamsResult {
}
export declare function dataCloudflareStreamsResultToTerraform(struct?: DataCloudflareStreamsResult): any;
export declare function dataCloudflareStreamsResultToHclTerraform(struct?: DataCloudflareStreamsResult): any;
export declare class DataCloudflareStreamsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareStreamsResult | undefined;
    set internalValue(value: DataCloudflareStreamsResult | undefined);
    get allowedOrigins(): string[];
    get created(): string;
    get creator(): string;
    get duration(): number;
    private _input;
    get input(): DataCloudflareStreamsResultInputOutputReference;
    get liveInput(): string;
    get maxDurationSeconds(): number;
    get meta(): string;
    get modified(): string;
    private _playback;
    get playback(): DataCloudflareStreamsResultPlaybackOutputReference;
    get preview(): string;
    get readyToStream(): cdktn.IResolvable;
    get readyToStreamAt(): string;
    get requireSignedUrls(): cdktn.IResolvable;
    get scheduledDeletion(): string;
    get size(): number;
    private _status;
    get status(): DataCloudflareStreamsResultStatusOutputReference;
    get thumbnail(): string;
    get thumbnailTimestampPct(): number;
    get uid(): string;
    get uploadExpiry(): string;
    get uploaded(): string;
    private _watermark;
    get watermark(): DataCloudflareStreamsResultWatermarkOutputReference;
}
export declare class DataCloudflareStreamsResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareStreamsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams cloudflare_streams}
*/
export declare class DataCloudflareStreams extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_streams";
    /**
    * Generates CDKTN code for importing a DataCloudflareStreams resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareStreams to import
    * @param importFromId The id of the existing DataCloudflareStreams that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareStreams to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/streams cloudflare_streams} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareStreamsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareStreamsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _asc?;
    get asc(): boolean | cdktn.IResolvable;
    set asc(value: boolean | cdktn.IResolvable);
    resetAsc(): void;
    get ascInput(): boolean | cdktn.IResolvable | undefined;
    private _creator?;
    get creator(): string;
    set creator(value: string);
    resetCreator(): void;
    get creatorInput(): string | undefined;
    private _end?;
    get end(): string;
    set end(value: string);
    resetEnd(): void;
    get endInput(): string | undefined;
    private _includeCounts?;
    get includeCounts(): boolean | cdktn.IResolvable;
    set includeCounts(value: boolean | cdktn.IResolvable);
    resetIncludeCounts(): void;
    get includeCountsInput(): boolean | cdktn.IResolvable | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareStreamsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    resetStart(): void;
    get startInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _videoName?;
    get videoName(): string;
    set videoName(value: string);
    resetVideoName(): void;
    get videoNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
