/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#account_id DataCloudflareZeroTrustAccessAiControlsMcpServer#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#filter DataCloudflareZeroTrustAccessAiControlsMcpServer#filter}
    */
    readonly filter?: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter;
    /**
    * server id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#id DataCloudflareZeroTrustAccessAiControlsMcpServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerFilter {
    /**
    * Search by id, name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#search DataCloudflareZeroTrustAccessAiControlsMcpServer#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerFilterToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerFilterToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable | undefined);
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server cloudflare_zero_trust_access_ai_controls_mcp_server}
*/
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_access_ai_controls_mcp_server";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustAccessAiControlsMcpServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustAccessAiControlsMcpServer to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustAccessAiControlsMcpServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustAccessAiControlsMcpServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server cloudflare_zero_trust_access_ai_controls_mcp_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustAccessAiControlsMcpServerConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustAccessAiControlsMcpServerConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get authType(): string;
    get createdAt(): string;
    get createdBy(): string;
    get description(): string;
    get error(): string;
    private _filter;
    get filter(): DataCloudflareZeroTrustAccessAiControlsMcpServerFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | undefined;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastSuccessfulSync(): string;
    get lastSynced(): string;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get name(): string;
    private _prompts;
    get prompts(): cdktn.StringMapList;
    get status(): string;
    private _tools;
    get tools(): cdktn.StringMapList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
