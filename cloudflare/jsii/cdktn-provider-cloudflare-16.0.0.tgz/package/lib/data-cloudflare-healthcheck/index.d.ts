/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareHealthcheckConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/healthcheck#healthcheck_id DataCloudflareHealthcheck#healthcheck_id}
    */
    readonly healthcheckId: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/healthcheck#zone_id DataCloudflareHealthcheck#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareHealthcheckHttpConfig {
}
export declare function dataCloudflareHealthcheckHttpConfigToTerraform(struct?: DataCloudflareHealthcheckHttpConfig): any;
export declare function dataCloudflareHealthcheckHttpConfigToHclTerraform(struct?: DataCloudflareHealthcheckHttpConfig): any;
export declare class DataCloudflareHealthcheckHttpConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareHealthcheckHttpConfig | undefined;
    set internalValue(value: DataCloudflareHealthcheckHttpConfig | undefined);
    get allowInsecure(): cdktn.IResolvable;
    get expectedBody(): string;
    get expectedCodes(): string[];
    get followRedirects(): cdktn.IResolvable;
    private _header;
    get header(): cdktn.StringListMap;
    get method(): string;
    get path(): string;
    get port(): number;
}
export interface DataCloudflareHealthcheckTcpConfig {
}
export declare function dataCloudflareHealthcheckTcpConfigToTerraform(struct?: DataCloudflareHealthcheckTcpConfig): any;
export declare function dataCloudflareHealthcheckTcpConfigToHclTerraform(struct?: DataCloudflareHealthcheckTcpConfig): any;
export declare class DataCloudflareHealthcheckTcpConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareHealthcheckTcpConfig | undefined;
    set internalValue(value: DataCloudflareHealthcheckTcpConfig | undefined);
    get method(): string;
    get port(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/healthcheck cloudflare_healthcheck}
*/
export declare class DataCloudflareHealthcheck extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_healthcheck";
    /**
    * Generates CDKTN code for importing a DataCloudflareHealthcheck resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareHealthcheck to import
    * @param importFromId The id of the existing DataCloudflareHealthcheck that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/healthcheck#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareHealthcheck to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/healthcheck cloudflare_healthcheck} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareHealthcheckConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareHealthcheckConfig);
    get address(): string;
    get checkRegions(): string[];
    get consecutiveFails(): number;
    get consecutiveSuccesses(): number;
    get createdOn(): string;
    get description(): string;
    get failureReason(): string;
    private _healthcheckId?;
    get healthcheckId(): string;
    set healthcheckId(value: string);
    get healthcheckIdInput(): string | undefined;
    private _httpConfig;
    get httpConfig(): DataCloudflareHealthcheckHttpConfigOutputReference;
    get id(): string;
    get interval(): number;
    get modifiedOn(): string;
    get name(): string;
    get retries(): number;
    get status(): string;
    get suspended(): cdktn.IResolvable;
    private _tcpConfig;
    get tcpConfig(): DataCloudflareHealthcheckTcpConfigOutputReference;
    get timeout(): number;
    get type(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
