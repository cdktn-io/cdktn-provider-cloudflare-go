/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareFlagshipFlagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_flags#account_id DataCloudflareFlagshipFlags#account_id}
    */
    readonly accountId: string;
    /**
    * App identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_flags#app_id DataCloudflareFlagshipFlags#app_id}
    */
    readonly appId: string;
    /**
    * Max items to return (1–200).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_flags#limit DataCloudflareFlagshipFlags#limit}
    */
    readonly limit?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_flags#max_items DataCloudflareFlagshipFlags#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareFlagshipFlagsResultRulesConditionsClauses {
}
export declare function dataCloudflareFlagshipFlagsResultRulesConditionsClausesToTerraform(struct?: DataCloudflareFlagshipFlagsResultRulesConditionsClauses): any;
export declare function dataCloudflareFlagshipFlagsResultRulesConditionsClausesToHclTerraform(struct?: DataCloudflareFlagshipFlagsResultRulesConditionsClauses): any;
export declare class DataCloudflareFlagshipFlagsResultRulesConditionsClausesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipFlagsResultRulesConditionsClauses | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagsResultRulesConditionsClauses | undefined);
    get attribute(): string;
    private _clauses;
    get clauses(): DataCloudflareFlagshipFlagsResultRulesConditionsClausesList;
    get logicalOperator(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataCloudflareFlagshipFlagsResultRulesConditionsClausesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipFlagsResultRulesConditionsClausesOutputReference;
}
export interface DataCloudflareFlagshipFlagsResultRulesConditions {
}
export declare function dataCloudflareFlagshipFlagsResultRulesConditionsToTerraform(struct?: DataCloudflareFlagshipFlagsResultRulesConditions): any;
export declare function dataCloudflareFlagshipFlagsResultRulesConditionsToHclTerraform(struct?: DataCloudflareFlagshipFlagsResultRulesConditions): any;
export declare class DataCloudflareFlagshipFlagsResultRulesConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipFlagsResultRulesConditions | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagsResultRulesConditions | undefined);
    get attribute(): string;
    private _clauses;
    get clauses(): DataCloudflareFlagshipFlagsResultRulesConditionsClausesList;
    get logicalOperator(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataCloudflareFlagshipFlagsResultRulesConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipFlagsResultRulesConditionsOutputReference;
}
export interface DataCloudflareFlagshipFlagsResultRulesRollout {
}
export declare function dataCloudflareFlagshipFlagsResultRulesRolloutToTerraform(struct?: DataCloudflareFlagshipFlagsResultRulesRollout): any;
export declare function dataCloudflareFlagshipFlagsResultRulesRolloutToHclTerraform(struct?: DataCloudflareFlagshipFlagsResultRulesRollout): any;
export declare class DataCloudflareFlagshipFlagsResultRulesRolloutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareFlagshipFlagsResultRulesRollout | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagsResultRulesRollout | undefined);
    get attribute(): string;
    get percentage(): number;
}
export interface DataCloudflareFlagshipFlagsResultRules {
}
export declare function dataCloudflareFlagshipFlagsResultRulesToTerraform(struct?: DataCloudflareFlagshipFlagsResultRules): any;
export declare function dataCloudflareFlagshipFlagsResultRulesToHclTerraform(struct?: DataCloudflareFlagshipFlagsResultRules): any;
export declare class DataCloudflareFlagshipFlagsResultRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipFlagsResultRules | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagsResultRules | undefined);
    private _conditions;
    get conditions(): DataCloudflareFlagshipFlagsResultRulesConditionsList;
    get priority(): number;
    private _rollout;
    get rollout(): DataCloudflareFlagshipFlagsResultRulesRolloutOutputReference;
    get serveVariation(): string;
}
export declare class DataCloudflareFlagshipFlagsResultRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipFlagsResultRulesOutputReference;
}
export interface DataCloudflareFlagshipFlagsResult {
}
export declare function dataCloudflareFlagshipFlagsResultToTerraform(struct?: DataCloudflareFlagshipFlagsResult): any;
export declare function dataCloudflareFlagshipFlagsResultToHclTerraform(struct?: DataCloudflareFlagshipFlagsResult): any;
export declare class DataCloudflareFlagshipFlagsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipFlagsResult | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagsResult | undefined);
    get defaultVariation(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get key(): string;
    private _rules;
    get rules(): DataCloudflareFlagshipFlagsResultRulesList;
    get type(): string;
    get updatedAt(): string;
    get updatedBy(): string;
    private _variations;
    get variations(): cdktn.StringMap;
}
export declare class DataCloudflareFlagshipFlagsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipFlagsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_flags cloudflare_flagship_flags}
*/
export declare class DataCloudflareFlagshipFlags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_flagship_flags";
    /**
    * Generates CDKTN code for importing a DataCloudflareFlagshipFlags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareFlagshipFlags to import
    * @param importFromId The id of the existing DataCloudflareFlagshipFlags that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_flags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareFlagshipFlags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_flags cloudflare_flagship_flags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareFlagshipFlagsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareFlagshipFlagsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _limit?;
    get limit(): string;
    set limit(value: string);
    resetLimit(): void;
    get limitInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareFlagshipFlagsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
