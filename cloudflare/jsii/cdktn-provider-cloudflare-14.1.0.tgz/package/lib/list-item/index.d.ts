/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ListItemConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#account_id ListItem#account_id}
    */
    readonly accountId: string;
    /**
    * A non-negative 32 bit integer
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#asn ListItem#asn}
    */
    readonly asn?: number;
    /**
    * An informative summary of the list item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#comment ListItem#comment}
    */
    readonly comment?: string;
    /**
    * Valid characters for hostnames are ASCII(7) letters from a to z, the digits from 0 to 9, wildcards (*), and the hyphen (-).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#hostname ListItem#hostname}
    */
    readonly hostname?: ListItemHostname;
    /**
    * An IPv4 address, an IPv4 CIDR, an IPv6 address, or an IPv6 CIDR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#ip ListItem#ip}
    */
    readonly ip?: string;
    /**
    * The unique ID of the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#list_id ListItem#list_id}
    */
    readonly listId: string;
    /**
    * The definition of the redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#redirect ListItem#redirect}
    */
    readonly redirect?: ListItemRedirect;
}
export interface ListItemHostname {
    /**
    * Only applies to wildcard hostnames (e.g., *.example.com). When true (default), only subdomains are blocked. When false, both the root domain and subdomains are blocked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#exclude_exact_hostname ListItem#exclude_exact_hostname}
    */
    readonly excludeExactHostname?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#url_hostname ListItem#url_hostname}
    */
    readonly urlHostname: string;
}
export declare function listItemHostnameToTerraform(struct?: ListItemHostname | cdktn.IResolvable): any;
export declare function listItemHostnameToHclTerraform(struct?: ListItemHostname | cdktn.IResolvable): any;
export declare class ListItemHostnameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ListItemHostname | cdktn.IResolvable | undefined;
    set internalValue(value: ListItemHostname | cdktn.IResolvable | undefined);
    private _excludeExactHostname?;
    get excludeExactHostname(): boolean | cdktn.IResolvable;
    set excludeExactHostname(value: boolean | cdktn.IResolvable);
    resetExcludeExactHostname(): void;
    get excludeExactHostnameInput(): boolean | cdktn.IResolvable | undefined;
    private _urlHostname?;
    get urlHostname(): string;
    set urlHostname(value: string);
    get urlHostnameInput(): string | undefined;
}
export interface ListItemRedirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#include_subdomains ListItem#include_subdomains}
    */
    readonly includeSubdomains?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#preserve_path_suffix ListItem#preserve_path_suffix}
    */
    readonly preservePathSuffix?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#preserve_query_string ListItem#preserve_query_string}
    */
    readonly preserveQueryString?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#source_url ListItem#source_url}
    */
    readonly sourceUrl: string;
    /**
    * Available values: 301, 302, 307, 308.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#status_code ListItem#status_code}
    */
    readonly statusCode?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#subpath_matching ListItem#subpath_matching}
    */
    readonly subpathMatching?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#target_url ListItem#target_url}
    */
    readonly targetUrl: string;
}
export declare function listItemRedirectToTerraform(struct?: ListItemRedirect | cdktn.IResolvable): any;
export declare function listItemRedirectToHclTerraform(struct?: ListItemRedirect | cdktn.IResolvable): any;
export declare class ListItemRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ListItemRedirect | cdktn.IResolvable | undefined;
    set internalValue(value: ListItemRedirect | cdktn.IResolvable | undefined);
    private _includeSubdomains?;
    get includeSubdomains(): boolean | cdktn.IResolvable;
    set includeSubdomains(value: boolean | cdktn.IResolvable);
    resetIncludeSubdomains(): void;
    get includeSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _preservePathSuffix?;
    get preservePathSuffix(): boolean | cdktn.IResolvable;
    set preservePathSuffix(value: boolean | cdktn.IResolvable);
    resetPreservePathSuffix(): void;
    get preservePathSuffixInput(): boolean | cdktn.IResolvable | undefined;
    private _preserveQueryString?;
    get preserveQueryString(): boolean | cdktn.IResolvable;
    set preserveQueryString(value: boolean | cdktn.IResolvable);
    resetPreserveQueryString(): void;
    get preserveQueryStringInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceUrl?;
    get sourceUrl(): string;
    set sourceUrl(value: string);
    get sourceUrlInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _subpathMatching?;
    get subpathMatching(): boolean | cdktn.IResolvable;
    set subpathMatching(value: boolean | cdktn.IResolvable);
    resetSubpathMatching(): void;
    get subpathMatchingInput(): boolean | cdktn.IResolvable | undefined;
    private _targetUrl?;
    get targetUrl(): string;
    set targetUrl(value: string);
    get targetUrlInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item cloudflare_list_item}
*/
export declare class ListItem extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_list_item";
    /**
    * Generates CDKTN code for importing a ListItem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ListItem to import
    * @param importFromId The id of the existing ListItem that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ListItem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/list_item cloudflare_list_item} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ListItemConfig
    */
    constructor(scope: Construct, id: string, config: ListItemConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _asn?;
    get asn(): number;
    set asn(value: number);
    resetAsn(): void;
    get asnInput(): number | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdOn(): string;
    private _hostname;
    get hostname(): ListItemHostnameOutputReference;
    putHostname(value: ListItemHostname): void;
    resetHostname(): void;
    get hostnameInput(): cdktn.IResolvable | ListItemHostname | undefined;
    get id(): string;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    resetIp(): void;
    get ipInput(): string | undefined;
    private _listId?;
    get listId(): string;
    set listId(value: string);
    get listIdInput(): string | undefined;
    get modifiedOn(): string;
    get operationId(): string;
    private _redirect;
    get redirect(): ListItemRedirectOutputReference;
    putRedirect(value: ListItemRedirect): void;
    resetRedirect(): void;
    get redirectInput(): cdktn.IResolvable | ListItemRedirect | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
