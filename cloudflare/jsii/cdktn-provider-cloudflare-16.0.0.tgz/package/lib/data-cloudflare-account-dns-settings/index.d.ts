/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAccountDnsSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_dns_settings#account_id DataCloudflareAccountDnsSettings#account_id}
    */
    readonly accountId?: string;
}
export interface DataCloudflareAccountDnsSettingsZoneDefaultsInternalDns {
}
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsInternalDnsToTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaultsInternalDns): any;
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsInternalDnsToHclTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaultsInternalDns): any;
export declare class DataCloudflareAccountDnsSettingsZoneDefaultsInternalDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountDnsSettingsZoneDefaultsInternalDns | undefined;
    set internalValue(value: DataCloudflareAccountDnsSettingsZoneDefaultsInternalDns | undefined);
    get referenceZoneId(): string;
}
export interface DataCloudflareAccountDnsSettingsZoneDefaultsNameservers {
}
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsNameserversToTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaultsNameservers): any;
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsNameserversToHclTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaultsNameservers): any;
export declare class DataCloudflareAccountDnsSettingsZoneDefaultsNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountDnsSettingsZoneDefaultsNameservers | undefined;
    set internalValue(value: DataCloudflareAccountDnsSettingsZoneDefaultsNameservers | undefined);
    get type(): string;
}
export interface DataCloudflareAccountDnsSettingsZoneDefaultsSoa {
}
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsSoaToTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaultsSoa): any;
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsSoaToHclTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaultsSoa): any;
export declare class DataCloudflareAccountDnsSettingsZoneDefaultsSoaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountDnsSettingsZoneDefaultsSoa | undefined;
    set internalValue(value: DataCloudflareAccountDnsSettingsZoneDefaultsSoa | undefined);
    get expire(): number;
    get minTtl(): number;
    get mname(): string;
    get refresh(): number;
    get retry(): number;
    get rname(): string;
    get ttl(): number;
}
export interface DataCloudflareAccountDnsSettingsZoneDefaults {
}
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsToTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaults): any;
export declare function dataCloudflareAccountDnsSettingsZoneDefaultsToHclTerraform(struct?: DataCloudflareAccountDnsSettingsZoneDefaults): any;
export declare class DataCloudflareAccountDnsSettingsZoneDefaultsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountDnsSettingsZoneDefaults | undefined;
    set internalValue(value: DataCloudflareAccountDnsSettingsZoneDefaults | undefined);
    get flattenAllCnames(): cdktn.IResolvable;
    get foundationDns(): cdktn.IResolvable;
    private _internalDns;
    get internalDns(): DataCloudflareAccountDnsSettingsZoneDefaultsInternalDnsOutputReference;
    get multiProvider(): cdktn.IResolvable;
    private _nameservers;
    get nameservers(): DataCloudflareAccountDnsSettingsZoneDefaultsNameserversOutputReference;
    get nsTtl(): number;
    get secondaryOverrides(): cdktn.IResolvable;
    private _soa;
    get soa(): DataCloudflareAccountDnsSettingsZoneDefaultsSoaOutputReference;
    get zoneMode(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_dns_settings cloudflare_account_dns_settings}
*/
export declare class DataCloudflareAccountDnsSettings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_account_dns_settings";
    /**
    * Generates CDKTN code for importing a DataCloudflareAccountDnsSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAccountDnsSettings to import
    * @param importFromId The id of the existing DataCloudflareAccountDnsSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_dns_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAccountDnsSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_dns_settings cloudflare_account_dns_settings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAccountDnsSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareAccountDnsSettingsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get enforceDnsOnly(): cdktn.IResolvable;
    private _zoneDefaults;
    get zoneDefaults(): DataCloudflareAccountDnsSettingsZoneDefaultsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
