/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareDnsFirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_firewall#account_id DataCloudflareDnsFirewall#account_id}
    */
    readonly accountId?: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_firewall#dns_firewall_id DataCloudflareDnsFirewall#dns_firewall_id}
    */
    readonly dnsFirewallId: string;
}
export interface DataCloudflareDnsFirewallAttackMitigation {
}
export declare function dataCloudflareDnsFirewallAttackMitigationToTerraform(struct?: DataCloudflareDnsFirewallAttackMitigation): any;
export declare function dataCloudflareDnsFirewallAttackMitigationToHclTerraform(struct?: DataCloudflareDnsFirewallAttackMitigation): any;
export declare class DataCloudflareDnsFirewallAttackMitigationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsFirewallAttackMitigation | undefined;
    set internalValue(value: DataCloudflareDnsFirewallAttackMitigation | undefined);
    get enabled(): cdktn.IResolvable;
    get onlyWhenUpstreamUnhealthy(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_firewall cloudflare_dns_firewall}
*/
export declare class DataCloudflareDnsFirewall extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_dns_firewall";
    /**
    * Generates CDKTN code for importing a DataCloudflareDnsFirewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareDnsFirewall to import
    * @param importFromId The id of the existing DataCloudflareDnsFirewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareDnsFirewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_firewall cloudflare_dns_firewall} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareDnsFirewallConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareDnsFirewallConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _attackMitigation;
    get attackMitigation(): DataCloudflareDnsFirewallAttackMitigationOutputReference;
    get deprecateAnyRequests(): cdktn.IResolvable;
    private _dnsFirewallId?;
    get dnsFirewallId(): string;
    set dnsFirewallId(value: string);
    get dnsFirewallIdInput(): string | undefined;
    get dnsFirewallIps(): string[];
    get ecsFallback(): cdktn.IResolvable;
    get id(): string;
    get maximumCacheTtl(): number;
    get minimumCacheTtl(): number;
    get modifiedOn(): string;
    get name(): string;
    get negativeCacheTtl(): number;
    get ratelimit(): number;
    get retries(): number;
    get upstreamIps(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
