/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareUserAgentBlockingRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * A string to search for in the description of existing rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules#description DataCloudflareUserAgentBlockingRules#description}
    */
    readonly description?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules#max_items DataCloudflareUserAgentBlockingRules#max_items}
    */
    readonly maxItems?: number;
    /**
    * When true, indicates that the rule is currently paused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules#paused DataCloudflareUserAgentBlockingRules#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * A string to search for in the user agent values of existing rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules#user_agent DataCloudflareUserAgentBlockingRules#user_agent}
    */
    readonly userAgent?: string;
    /**
    * Defines an identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules#zone_id DataCloudflareUserAgentBlockingRules#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareUserAgentBlockingRulesResultConfiguration {
}
export declare function dataCloudflareUserAgentBlockingRulesResultConfigurationToTerraform(struct?: DataCloudflareUserAgentBlockingRulesResultConfiguration): any;
export declare function dataCloudflareUserAgentBlockingRulesResultConfigurationToHclTerraform(struct?: DataCloudflareUserAgentBlockingRulesResultConfiguration): any;
export declare class DataCloudflareUserAgentBlockingRulesResultConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareUserAgentBlockingRulesResultConfiguration | undefined;
    set internalValue(value: DataCloudflareUserAgentBlockingRulesResultConfiguration | undefined);
    get target(): string;
    get value(): string;
}
export interface DataCloudflareUserAgentBlockingRulesResult {
}
export declare function dataCloudflareUserAgentBlockingRulesResultToTerraform(struct?: DataCloudflareUserAgentBlockingRulesResult): any;
export declare function dataCloudflareUserAgentBlockingRulesResultToHclTerraform(struct?: DataCloudflareUserAgentBlockingRulesResult): any;
export declare class DataCloudflareUserAgentBlockingRulesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareUserAgentBlockingRulesResult | undefined;
    set internalValue(value: DataCloudflareUserAgentBlockingRulesResult | undefined);
    private _configuration;
    get configuration(): DataCloudflareUserAgentBlockingRulesResultConfigurationOutputReference;
    get description(): string;
    get id(): string;
    get mode(): string;
    get paused(): cdktn.IResolvable;
}
export declare class DataCloudflareUserAgentBlockingRulesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareUserAgentBlockingRulesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules cloudflare_user_agent_blocking_rules}
*/
export declare class DataCloudflareUserAgentBlockingRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_user_agent_blocking_rules";
    /**
    * Generates CDKTN code for importing a DataCloudflareUserAgentBlockingRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareUserAgentBlockingRules to import
    * @param importFromId The id of the existing DataCloudflareUserAgentBlockingRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareUserAgentBlockingRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user_agent_blocking_rules cloudflare_user_agent_blocking_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareUserAgentBlockingRulesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareUserAgentBlockingRulesConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _result;
    get result(): DataCloudflareUserAgentBlockingRulesResultList;
    private _userAgent?;
    get userAgent(): string;
    set userAgent(value: string);
    resetUserAgent(): void;
    get userAgentInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
