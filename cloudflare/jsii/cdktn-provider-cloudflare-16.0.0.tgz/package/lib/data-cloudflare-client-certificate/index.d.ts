/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareClientCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate#client_certificate_id DataCloudflareClientCertificate#client_certificate_id}
    */
    readonly clientCertificateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate#filter DataCloudflareClientCertificate#filter}
    */
    readonly filter?: DataCloudflareClientCertificateFilter;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate#zone_id DataCloudflareClientCertificate#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareClientCertificateCertificateAuthority {
}
export declare function dataCloudflareClientCertificateCertificateAuthorityToTerraform(struct?: DataCloudflareClientCertificateCertificateAuthority): any;
export declare function dataCloudflareClientCertificateCertificateAuthorityToHclTerraform(struct?: DataCloudflareClientCertificateCertificateAuthority): any;
export declare class DataCloudflareClientCertificateCertificateAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareClientCertificateCertificateAuthority | undefined;
    set internalValue(value: DataCloudflareClientCertificateCertificateAuthority | undefined);
    get id(): string;
    get name(): string;
}
export interface DataCloudflareClientCertificateFilter {
    /**
    * Limit to the number of records returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate#limit DataCloudflareClientCertificate#limit}
    */
    readonly limit?: number;
    /**
    * Offset the results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate#offset DataCloudflareClientCertificate#offset}
    */
    readonly offset?: number;
    /**
    * Client Certitifcate Status to filter results by.
    * Available values: "all", "active", "pending_reactivation", "pending_revocation", "revoked".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate#status DataCloudflareClientCertificate#status}
    */
    readonly status?: string;
}
export declare function dataCloudflareClientCertificateFilterToTerraform(struct?: DataCloudflareClientCertificateFilter | cdktn.IResolvable): any;
export declare function dataCloudflareClientCertificateFilterToHclTerraform(struct?: DataCloudflareClientCertificateFilter | cdktn.IResolvable): any;
export declare class DataCloudflareClientCertificateFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareClientCertificateFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareClientCertificateFilter | cdktn.IResolvable | undefined);
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _offset?;
    get offset(): number;
    set offset(value: number);
    resetOffset(): void;
    get offsetInput(): number | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate cloudflare_client_certificate}
*/
export declare class DataCloudflareClientCertificate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_client_certificate";
    /**
    * Generates CDKTN code for importing a DataCloudflareClientCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareClientCertificate to import
    * @param importFromId The id of the existing DataCloudflareClientCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareClientCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/client_certificate cloudflare_client_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareClientCertificateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareClientCertificateConfig);
    get certificate(): string;
    private _certificateAuthority;
    get certificateAuthority(): DataCloudflareClientCertificateCertificateAuthorityOutputReference;
    private _clientCertificateId?;
    get clientCertificateId(): string;
    set clientCertificateId(value: string);
    resetClientCertificateId(): void;
    get clientCertificateIdInput(): string | undefined;
    get commonName(): string;
    get country(): string;
    get csr(): string;
    get expiresOn(): string;
    private _filter;
    get filter(): DataCloudflareClientCertificateFilterOutputReference;
    putFilter(value: DataCloudflareClientCertificateFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareClientCertificateFilter | undefined;
    get fingerprintSha256(): string;
    get id(): string;
    get issuedOn(): string;
    get location(): string;
    get organization(): string;
    get organizationalUnit(): string;
    get serialNumber(): string;
    get signature(): string;
    get ski(): string;
    get state(): string;
    get status(): string;
    get validityDays(): number;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
