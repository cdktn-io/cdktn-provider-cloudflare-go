/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDexTestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test#account_id DataCloudflareZeroTrustDexTest#account_id}
    */
    readonly accountId?: string;
    /**
    * The unique identifier for the test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test#dex_test_id DataCloudflareZeroTrustDexTest#dex_test_id}
    */
    readonly dexTestId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test#filter DataCloudflareZeroTrustDexTest#filter}
    */
    readonly filter?: DataCloudflareZeroTrustDexTestFilter;
    /**
    * DEX rules targeted by this test
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test#target_policies DataCloudflareZeroTrustDexTest#target_policies}
    */
    readonly targetPolicies?: DataCloudflareZeroTrustDexTestTargetPolicies[] | cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDexTestData {
}
export declare function dataCloudflareZeroTrustDexTestDataToTerraform(struct?: DataCloudflareZeroTrustDexTestData): any;
export declare function dataCloudflareZeroTrustDexTestDataToHclTerraform(struct?: DataCloudflareZeroTrustDexTestData): any;
export declare class DataCloudflareZeroTrustDexTestDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDexTestData | undefined;
    set internalValue(value: DataCloudflareZeroTrustDexTestData | undefined);
    get host(): string;
    get kind(): string;
    get method(): string;
}
export interface DataCloudflareZeroTrustDexTestFilter {
    /**
    * Filter by test type
    * Available values: "http", "traceroute".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test#kind DataCloudflareZeroTrustDexTest#kind}
    */
    readonly kind?: string;
    /**
    * Filter by test name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test#test_name DataCloudflareZeroTrustDexTest#test_name}
    */
    readonly testName?: string;
}
export declare function dataCloudflareZeroTrustDexTestFilterToTerraform(struct?: DataCloudflareZeroTrustDexTestFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustDexTestFilterToHclTerraform(struct?: DataCloudflareZeroTrustDexTestFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustDexTestFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDexTestFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustDexTestFilter | cdktn.IResolvable | undefined);
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _testName?;
    get testName(): string;
    set testName(value: string);
    resetTestName(): void;
    get testNameInput(): string | undefined;
}
export interface DataCloudflareZeroTrustDexTestTargetPolicies {
}
export declare function dataCloudflareZeroTrustDexTestTargetPoliciesToTerraform(struct?: DataCloudflareZeroTrustDexTestTargetPolicies | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustDexTestTargetPoliciesToHclTerraform(struct?: DataCloudflareZeroTrustDexTestTargetPolicies | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustDexTestTargetPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDexTestTargetPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustDexTestTargetPolicies | cdktn.IResolvable | undefined);
    get default(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZeroTrustDexTestTargetPoliciesList extends cdktn.ComplexList {
    internalValue?: DataCloudflareZeroTrustDexTestTargetPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDexTestTargetPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test cloudflare_zero_trust_dex_test}
*/
export declare class DataCloudflareZeroTrustDexTest extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dex_test";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDexTest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDexTest to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDexTest that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDexTest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dex_test cloudflare_zero_trust_dex_test} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDexTestConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustDexTestConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _data;
    get data(): DataCloudflareZeroTrustDexTestDataOutputReference;
    get description(): string;
    private _dexTestId?;
    get dexTestId(): string;
    set dexTestId(value: string);
    resetDexTestId(): void;
    get dexTestIdInput(): string | undefined;
    get enabled(): cdktn.IResolvable;
    private _filter;
    get filter(): DataCloudflareZeroTrustDexTestFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustDexTestFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustDexTestFilter | undefined;
    get id(): string;
    get interval(): string;
    get name(): string;
    private _targetPolicies;
    get targetPolicies(): DataCloudflareZeroTrustDexTestTargetPoliciesList;
    putTargetPolicies(value: DataCloudflareZeroTrustDexTestTargetPolicies[] | cdktn.IResolvable): void;
    resetTargetPolicies(): void;
    get targetPoliciesInput(): cdktn.IResolvable | DataCloudflareZeroTrustDexTestTargetPolicies[] | undefined;
    get targeted(): cdktn.IResolvable;
    get testId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
