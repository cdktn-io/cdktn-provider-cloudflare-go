/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareFlagshipAppsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_apps#account_id DataCloudflareFlagshipApps#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_apps#max_items DataCloudflareFlagshipApps#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareFlagshipAppsResult {
}
export declare function dataCloudflareFlagshipAppsResultToTerraform(struct?: DataCloudflareFlagshipAppsResult): any;
export declare function dataCloudflareFlagshipAppsResultToHclTerraform(struct?: DataCloudflareFlagshipAppsResult): any;
export declare class DataCloudflareFlagshipAppsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipAppsResult | undefined;
    set internalValue(value: DataCloudflareFlagshipAppsResult | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    get updatedAt(): string;
    get updatedBy(): string;
}
export declare class DataCloudflareFlagshipAppsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipAppsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_apps cloudflare_flagship_apps}
*/
export declare class DataCloudflareFlagshipApps extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_flagship_apps";
    /**
    * Generates CDKTN code for importing a DataCloudflareFlagshipApps resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareFlagshipApps to import
    * @param importFromId The id of the existing DataCloudflareFlagshipApps that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_apps#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareFlagshipApps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/flagship_apps cloudflare_flagship_apps} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareFlagshipAppsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareFlagshipAppsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareFlagshipAppsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
