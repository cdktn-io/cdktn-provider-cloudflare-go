/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicTransitConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/magic_transit_connector#account_id DataCloudflareMagicTransitConnector#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/magic_transit_connector#connector_id DataCloudflareMagicTransitConnector#connector_id}
    */
    readonly connectorId: string;
}
export interface DataCloudflareMagicTransitConnectorDevice {
}
export declare function dataCloudflareMagicTransitConnectorDeviceToTerraform(struct?: DataCloudflareMagicTransitConnectorDevice): any;
export declare function dataCloudflareMagicTransitConnectorDeviceToHclTerraform(struct?: DataCloudflareMagicTransitConnectorDevice): any;
export declare class DataCloudflareMagicTransitConnectorDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitConnectorDevice | undefined;
    set internalValue(value: DataCloudflareMagicTransitConnectorDevice | undefined);
    get id(): string;
    get serialNumber(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/magic_transit_connector cloudflare_magic_transit_connector}
*/
export declare class DataCloudflareMagicTransitConnector extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_transit_connector";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicTransitConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicTransitConnector to import
    * @param importFromId The id of the existing DataCloudflareMagicTransitConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/magic_transit_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicTransitConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/magic_transit_connector cloudflare_magic_transit_connector} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicTransitConnectorConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicTransitConnectorConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get activated(): cdktn.IResolvable;
    private _connectorId?;
    get connectorId(): string;
    set connectorId(value: string);
    get connectorIdInput(): string | undefined;
    private _device;
    get device(): DataCloudflareMagicTransitConnectorDeviceOutputReference;
    get id(): string;
    get interruptWindowDaysOfWeek(): string[];
    get interruptWindowDurationHours(): number;
    get interruptWindowEmbargoDates(): string[];
    get interruptWindowHourOfDay(): number;
    get lastHeartbeat(): string;
    get lastSeenVersion(): string;
    get lastUpdated(): string;
    get licenseKey(): string;
    get notes(): string;
    get timezone(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
