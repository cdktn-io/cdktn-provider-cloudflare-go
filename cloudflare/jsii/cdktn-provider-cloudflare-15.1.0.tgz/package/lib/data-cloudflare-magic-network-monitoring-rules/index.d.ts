/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicNetworkMonitoringRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/magic_network_monitoring_rules#account_id DataCloudflareMagicNetworkMonitoringRules#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/magic_network_monitoring_rules#max_items DataCloudflareMagicNetworkMonitoringRules#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareMagicNetworkMonitoringRulesResult {
}
export declare function dataCloudflareMagicNetworkMonitoringRulesResultToTerraform(struct?: DataCloudflareMagicNetworkMonitoringRulesResult): any;
export declare function dataCloudflareMagicNetworkMonitoringRulesResultToHclTerraform(struct?: DataCloudflareMagicNetworkMonitoringRulesResult): any;
export declare class DataCloudflareMagicNetworkMonitoringRulesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMagicNetworkMonitoringRulesResult | undefined;
    set internalValue(value: DataCloudflareMagicNetworkMonitoringRulesResult | undefined);
    get automaticAdvertisement(): cdktn.IResolvable;
    get bandwidthThreshold(): number;
    get duration(): string;
    get id(): string;
    get name(): string;
    get packetThreshold(): number;
    get prefixMatch(): string;
    get prefixes(): string[];
    get type(): string;
    get zscoreSensitivity(): string;
    get zscoreTarget(): string;
}
export declare class DataCloudflareMagicNetworkMonitoringRulesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMagicNetworkMonitoringRulesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/magic_network_monitoring_rules cloudflare_magic_network_monitoring_rules}
*/
export declare class DataCloudflareMagicNetworkMonitoringRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_network_monitoring_rules";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicNetworkMonitoringRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicNetworkMonitoringRules to import
    * @param importFromId The id of the existing DataCloudflareMagicNetworkMonitoringRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/magic_network_monitoring_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicNetworkMonitoringRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/magic_network_monitoring_rules cloudflare_magic_network_monitoring_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicNetworkMonitoringRulesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareMagicNetworkMonitoringRulesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareMagicNetworkMonitoringRulesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
