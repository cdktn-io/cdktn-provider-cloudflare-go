/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustListsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#account_id DataCloudflareZeroTrustLists#account_id}
    */
    readonly accountId?: string;
    /**
    * Sort direction. Applies to the field named in `order_by`; when `order_by`
    * is omitted it applies to the default `created_at` ordering. When
    * `direction` is omitted the default is field-specific: explicitly choosing
    * `created_at` or `updated_at` defaults to descending (newest first); `name`
    * and `item_count` default to ascending; and the default `created_at`
    * ordering used when `order_by` is omitted is ascending (for backwards
    * compatibility).
    *   * `asc` — ascending.
    *   * `desc` — descending.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#direction DataCloudflareZeroTrustLists#direction}
    */
    readonly direction?: string;
    /**
    * Filter the returned lists by one or more `field:value` pairs.
    * Repeat the parameter to apply multiple filters; they are combined with
    * logical AND (a list must satisfy every filter to be returned).
    *
    * Supported fields and their matching behaviour:
    *   * `name` — case-insensitive substring match on the list name.
    *   * `id` — substring match on the list ID (UUID), with or without dashes.
    *   * `type` — exact match on the list type. Supersedes the legacy `type` query
    *     parameter when both are supplied. Must be one of the valid type values.
    *   * `item_count` — exact integer match on the number of items in the list.
    *
    * Each entry must match one of the per-field patterns below: the field must be
    * one of `name`, `id`, `type`, or `item_count`; `name`/`id` accept any value,
    * `type` is restricted to the valid list type values, and `item_count` must be
    * a non-negative integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#filter DataCloudflareZeroTrustLists#filter}
    */
    readonly filter?: string[];
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#max_items DataCloudflareZeroTrustLists#max_items}
    */
    readonly maxItems?: number;
    /**
    * Field to sort the returned lists by. When omitted, results are ordered by
    * `created_at` in ascending order (i.e. creation order) for backwards
    * compatibility. Supported values:
    *   * `name` — sort alphabetically by list name.
    *   * `created_at` — sort by creation time; defaults to descending unless `direction` is set.
    *   * `updated_at` — sort by last-modified time; defaults to descending unless `direction` is set.
    *   * `item_count` — sort by number of items in the list.
    * Available values: "name", "created_at", "updated_at", "item_count".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#order_by DataCloudflareZeroTrustLists#order_by}
    */
    readonly orderBy?: string;
    /**
    * Case-insensitive substring match on the list name or description. When
    * combined with `filter`, both must match (logical AND).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#search DataCloudflareZeroTrustLists#search}
    */
    readonly search?: string;
    /**
    * Specify the list type.
    * Available values: "SERIAL", "URL", "DOMAIN", "EMAIL", "IP", "CATEGORY", "LOCATION", "DEVICE", "AAGUID".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#type DataCloudflareZeroTrustLists#type}
    */
    readonly type?: string;
}
export interface DataCloudflareZeroTrustListsResultItems {
}
export declare function dataCloudflareZeroTrustListsResultItemsToTerraform(struct?: DataCloudflareZeroTrustListsResultItems): any;
export declare function dataCloudflareZeroTrustListsResultItemsToHclTerraform(struct?: DataCloudflareZeroTrustListsResultItems): any;
export declare class DataCloudflareZeroTrustListsResultItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustListsResultItems | undefined;
    set internalValue(value: DataCloudflareZeroTrustListsResultItems | undefined);
    get createdAt(): string;
    get description(): string;
    get value(): string;
}
export declare class DataCloudflareZeroTrustListsResultItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustListsResultItemsOutputReference;
}
export interface DataCloudflareZeroTrustListsResult {
}
export declare function dataCloudflareZeroTrustListsResultToTerraform(struct?: DataCloudflareZeroTrustListsResult): any;
export declare function dataCloudflareZeroTrustListsResultToHclTerraform(struct?: DataCloudflareZeroTrustListsResult): any;
export declare class DataCloudflareZeroTrustListsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustListsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustListsResult | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    private _items;
    get items(): DataCloudflareZeroTrustListsResultItemsList;
    get listCount(): number;
    get name(): string;
    get type(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustListsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustListsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists cloudflare_zero_trust_lists}
*/
export declare class DataCloudflareZeroTrustLists extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_lists";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustLists resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustLists to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustLists that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustLists to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_lists cloudflare_zero_trust_lists} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustListsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustListsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _filter?;
    get filter(): string[];
    set filter(value: string[]);
    resetFilter(): void;
    get filterInput(): string[] | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustListsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
