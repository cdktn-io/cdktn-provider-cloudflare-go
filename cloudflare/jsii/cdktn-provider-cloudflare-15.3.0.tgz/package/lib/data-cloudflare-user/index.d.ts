/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareUserConfig extends cdktn.TerraformMetaArguments {
}
export interface DataCloudflareUserOrganizations {
}
export declare function dataCloudflareUserOrganizationsToTerraform(struct?: DataCloudflareUserOrganizations): any;
export declare function dataCloudflareUserOrganizationsToHclTerraform(struct?: DataCloudflareUserOrganizations): any;
export declare class DataCloudflareUserOrganizationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareUserOrganizations | undefined;
    set internalValue(value: DataCloudflareUserOrganizations | undefined);
    get id(): string;
    get name(): string;
    get permissions(): string[];
    get roles(): string[];
    get status(): string;
}
export declare class DataCloudflareUserOrganizationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareUserOrganizationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user cloudflare_user}
*/
export declare class DataCloudflareUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_user";
    /**
    * Generates CDKTN code for importing a DataCloudflareUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareUser to import
    * @param importFromId The id of the existing DataCloudflareUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/user cloudflare_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareUserConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareUserConfig);
    get betas(): string[];
    get country(): string;
    get email(): string;
    get firstName(): string;
    get hasBusinessZones(): cdktn.IResolvable;
    get hasEnterpriseZones(): cdktn.IResolvable;
    get hasProZones(): cdktn.IResolvable;
    get id(): string;
    get lastName(): string;
    private _organizations;
    get organizations(): DataCloudflareUserOrganizationsList;
    get suspended(): cdktn.IResolvable;
    get telephone(): string;
    get twoFactorAuthenticationEnabled(): cdktn.IResolvable;
    get twoFactorAuthenticationLocked(): cdktn.IResolvable;
    get zipcode(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
