/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#account_id AccountToken#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#condition AccountToken#condition}
    */
    readonly condition?: AccountTokenCondition;
    /**
    * The expiration time on or after which the JWT MUST NOT be accepted for processing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#expires_on AccountToken#expires_on}
    */
    readonly expiresOn?: string;
    /**
    * Token name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#name AccountToken#name}
    */
    readonly name: string;
    /**
    * The time before which the token MUST NOT be accepted for processing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#not_before AccountToken#not_before}
    */
    readonly notBefore?: string;
    /**
    * Set of access policies assigned to the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#policies AccountToken#policies}
    */
    readonly policies: AccountTokenPolicies[] | cdktn.IResolvable;
    /**
    * Status of the token.
    * Available values: "active", "disabled", "expired".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#status AccountToken#status}
    */
    readonly status?: string;
}
export interface AccountTokenConditionRequestIp {
    /**
    * List of IPv4/IPv6 CIDR addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#in AccountToken#in}
    */
    readonly in?: string[];
    /**
    * List of IPv4/IPv6 CIDR addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#not_in AccountToken#not_in}
    */
    readonly notIn?: string[];
}
export declare function accountTokenConditionRequestIpToTerraform(struct?: AccountTokenConditionRequestIp | cdktn.IResolvable): any;
export declare function accountTokenConditionRequestIpToHclTerraform(struct?: AccountTokenConditionRequestIp | cdktn.IResolvable): any;
export declare class AccountTokenConditionRequestIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountTokenConditionRequestIp | cdktn.IResolvable | undefined;
    set internalValue(value: AccountTokenConditionRequestIp | cdktn.IResolvable | undefined);
    private _in?;
    get in(): string[];
    set in(value: string[]);
    resetIn(): void;
    get inInput(): string[] | undefined;
    private _notIn?;
    get notIn(): string[];
    set notIn(value: string[]);
    resetNotIn(): void;
    get notInInput(): string[] | undefined;
}
export interface AccountTokenCondition {
    /**
    * Client IP restrictions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#request_ip AccountToken#request_ip}
    */
    readonly requestIp?: AccountTokenConditionRequestIp;
}
export declare function accountTokenConditionToTerraform(struct?: AccountTokenCondition | cdktn.IResolvable): any;
export declare function accountTokenConditionToHclTerraform(struct?: AccountTokenCondition | cdktn.IResolvable): any;
export declare class AccountTokenConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountTokenCondition | cdktn.IResolvable | undefined;
    set internalValue(value: AccountTokenCondition | cdktn.IResolvable | undefined);
    private _requestIp;
    get requestIp(): AccountTokenConditionRequestIpOutputReference;
    putRequestIp(value: AccountTokenConditionRequestIp): void;
    resetRequestIp(): void;
    get requestIpInput(): cdktn.IResolvable | AccountTokenConditionRequestIp | undefined;
}
export interface AccountTokenPoliciesPermissionGroups {
    /**
    * Identifier of the permission group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#id AccountToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function accountTokenPoliciesPermissionGroupsToTerraform(struct?: AccountTokenPoliciesPermissionGroups | cdktn.IResolvable): any;
export declare function accountTokenPoliciesPermissionGroupsToHclTerraform(struct?: AccountTokenPoliciesPermissionGroups | cdktn.IResolvable): any;
export declare class AccountTokenPoliciesPermissionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountTokenPoliciesPermissionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: AccountTokenPoliciesPermissionGroups | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class AccountTokenPoliciesPermissionGroupsList extends cdktn.ComplexList {
    internalValue?: AccountTokenPoliciesPermissionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountTokenPoliciesPermissionGroupsOutputReference;
}
export interface AccountTokenPolicies {
    /**
    * Allow or deny operations against the resources.
    * Available values: "allow", "deny".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#effect AccountToken#effect}
    */
    readonly effect: string;
    /**
    * A set of permission groups that are specified to the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#permission_groups AccountToken#permission_groups}
    */
    readonly permissionGroups: AccountTokenPoliciesPermissionGroups[] | cdktn.IResolvable;
    /**
    * A json object representing the resources that are specified to the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#resources AccountToken#resources}
    */
    readonly resources: string;
}
export declare function accountTokenPoliciesToTerraform(struct?: AccountTokenPolicies | cdktn.IResolvable): any;
export declare function accountTokenPoliciesToHclTerraform(struct?: AccountTokenPolicies | cdktn.IResolvable): any;
export declare class AccountTokenPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountTokenPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AccountTokenPolicies | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    get effectInput(): string | undefined;
    private _permissionGroups;
    get permissionGroups(): AccountTokenPoliciesPermissionGroupsList;
    putPermissionGroups(value: AccountTokenPoliciesPermissionGroups[] | cdktn.IResolvable): void;
    get permissionGroupsInput(): cdktn.IResolvable | AccountTokenPoliciesPermissionGroups[] | undefined;
    private _resources?;
    get resources(): string;
    set resources(value: string);
    get resourcesInput(): string | undefined;
}
export declare class AccountTokenPoliciesList extends cdktn.ComplexList {
    internalValue?: AccountTokenPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountTokenPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token cloudflare_account_token}
*/
export declare class AccountToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_account_token";
    /**
    * Generates CDKTN code for importing a AccountToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountToken to import
    * @param importFromId The id of the existing AccountToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/account_token cloudflare_account_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountTokenConfig
    */
    constructor(scope: Construct, id: string, config: AccountTokenConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _condition;
    get condition(): AccountTokenConditionOutputReference;
    putCondition(value: AccountTokenCondition): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | AccountTokenCondition | undefined;
    private _expiresOn?;
    get expiresOn(): string;
    set expiresOn(value: string);
    resetExpiresOn(): void;
    get expiresOnInput(): string | undefined;
    get id(): string;
    get issuedOn(): string;
    get lastUsedOn(): string;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notBefore?;
    get notBefore(): string;
    set notBefore(value: string);
    resetNotBefore(): void;
    get notBeforeInput(): string | undefined;
    private _policies;
    get policies(): AccountTokenPoliciesList;
    putPolicies(value: AccountTokenPolicies[] | cdktn.IResolvable): void;
    get policiesInput(): cdktn.IResolvable | AccountTokenPolicies[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get value(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
