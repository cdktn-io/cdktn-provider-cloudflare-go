/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpEntryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_entry#account_id DataCloudflareZeroTrustDlpEntry#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_entry#entry_id DataCloudflareZeroTrustDlpEntry#entry_id}
    */
    readonly entryId: string;
}
export interface DataCloudflareZeroTrustDlpEntryConfidence {
}
export declare function dataCloudflareZeroTrustDlpEntryConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpEntryConfidence): any;
export declare function dataCloudflareZeroTrustDlpEntryConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntryConfidence): any;
export declare class DataCloudflareZeroTrustDlpEntryConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpEntryConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntryConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpEntryPattern {
}
export declare function dataCloudflareZeroTrustDlpEntryPatternToTerraform(struct?: DataCloudflareZeroTrustDlpEntryPattern): any;
export declare function dataCloudflareZeroTrustDlpEntryPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntryPattern): any;
export declare class DataCloudflareZeroTrustDlpEntryPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpEntryPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntryPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpEntryProfiles {
}
export declare function dataCloudflareZeroTrustDlpEntryProfilesToTerraform(struct?: DataCloudflareZeroTrustDlpEntryProfiles): any;
export declare function dataCloudflareZeroTrustDlpEntryProfilesToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntryProfiles): any;
export declare class DataCloudflareZeroTrustDlpEntryProfilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpEntryProfiles | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntryProfiles | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZeroTrustDlpEntryProfilesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpEntryProfilesOutputReference;
}
export interface DataCloudflareZeroTrustDlpEntryVariant {
}
export declare function dataCloudflareZeroTrustDlpEntryVariantToTerraform(struct?: DataCloudflareZeroTrustDlpEntryVariant): any;
export declare function dataCloudflareZeroTrustDlpEntryVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntryVariant): any;
export declare class DataCloudflareZeroTrustDlpEntryVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpEntryVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntryVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_entry cloudflare_zero_trust_dlp_entry}
*/
export declare class DataCloudflareZeroTrustDlpEntry extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_entry";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpEntry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpEntry to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpEntry that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_entry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpEntry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_entry cloudflare_zero_trust_dlp_entry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpEntryConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpEntryConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpEntryConfidenceOutputReference;
    get createdAt(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _entryId?;
    get entryId(): string;
    set entryId(value: string);
    get entryIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpEntryPatternOutputReference;
    get profileId(): string;
    private _profiles;
    get profiles(): DataCloudflareZeroTrustDlpEntryProfilesList;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    get uploadStatus(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpEntryVariantOutputReference;
    get wordList(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
