/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZoneAutoOriginTlsKexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zone_auto_origin_tls_kex#zone_id DataCloudflareZoneAutoOriginTlsKex#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zone_auto_origin_tls_kex cloudflare_zone_auto_origin_tls_kex}
*/
export declare class DataCloudflareZoneAutoOriginTlsKex extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zone_auto_origin_tls_kex";
    /**
    * Generates CDKTN code for importing a DataCloudflareZoneAutoOriginTlsKex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZoneAutoOriginTlsKex to import
    * @param importFromId The id of the existing DataCloudflareZoneAutoOriginTlsKex that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zone_auto_origin_tls_kex#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZoneAutoOriginTlsKex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zone_auto_origin_tls_kex cloudflare_zone_auto_origin_tls_kex} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZoneAutoOriginTlsKexConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZoneAutoOriginTlsKexConfig);
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get modifiedOn(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
