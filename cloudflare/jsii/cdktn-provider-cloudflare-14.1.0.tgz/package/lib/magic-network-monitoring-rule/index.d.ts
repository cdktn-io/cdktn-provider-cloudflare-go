/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MagicNetworkMonitoringRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#account_id MagicNetworkMonitoringRule#account_id}
    */
    readonly accountId: string;
    /**
    * Toggle on if you would like Cloudflare to automatically advertise the IP Prefixes within the rule via Magic Transit when the rule is triggered. Only available for users of Magic Transit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#automatic_advertisement MagicNetworkMonitoringRule#automatic_advertisement}
    */
    readonly automaticAdvertisement?: boolean | cdktn.IResolvable;
    /**
    * The number of bits per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#bandwidth MagicNetworkMonitoringRule#bandwidth}
    */
    readonly bandwidth?: number;
    /**
    * The amount of time that the rule threshold must be exceeded to send an alert notification. The final value must be equivalent to one of the following 8 values ["1m","5m","10m","15m","20m","30m","45m","60m"].
    * Available values: "1m", "5m", "10m", "15m", "20m", "30m", "45m", "60m".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#duration MagicNetworkMonitoringRule#duration}
    */
    readonly duration?: string;
    /**
    * The name of the rule. Must be unique. Supports characters A-Z, a-z, 0-9, underscore (_), dash (-), period (.), and tilde (~). You can’t have a space in the rule name. Max 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#name MagicNetworkMonitoringRule#name}
    */
    readonly name: string;
    /**
    * The number of packets per second for the rule. When this value is exceeded for the set duration, an alert notification is sent. Minimum of 1 and no maximum.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#packet_threshold MagicNetworkMonitoringRule#packet_threshold}
    */
    readonly packetThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#prefixes MagicNetworkMonitoringRule#prefixes}
    */
    readonly prefixes?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule cloudflare_magic_network_monitoring_rule}
*/
export declare class MagicNetworkMonitoringRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_magic_network_monitoring_rule";
    /**
    * Generates CDKTN code for importing a MagicNetworkMonitoringRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MagicNetworkMonitoringRule to import
    * @param importFromId The id of the existing MagicNetworkMonitoringRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MagicNetworkMonitoringRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_network_monitoring_rule cloudflare_magic_network_monitoring_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MagicNetworkMonitoringRuleConfig
    */
    constructor(scope: Construct, id: string, config: MagicNetworkMonitoringRuleConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _automaticAdvertisement?;
    get automaticAdvertisement(): boolean | cdktn.IResolvable;
    set automaticAdvertisement(value: boolean | cdktn.IResolvable);
    resetAutomaticAdvertisement(): void;
    get automaticAdvertisementInput(): boolean | cdktn.IResolvable | undefined;
    private _bandwidth?;
    get bandwidth(): number;
    set bandwidth(value: number);
    resetBandwidth(): void;
    get bandwidthInput(): number | undefined;
    get bandwidthThreshold(): number;
    private _duration?;
    get duration(): string;
    set duration(value: string);
    resetDuration(): void;
    get durationInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _packetThreshold?;
    get packetThreshold(): number;
    set packetThreshold(value: number);
    resetPacketThreshold(): void;
    get packetThresholdInput(): number | undefined;
    get prefixMatch(): string;
    private _prefixes?;
    get prefixes(): string[];
    set prefixes(value: string[]);
    resetPrefixes(): void;
    get prefixesInput(): string[] | undefined;
    get type(): string;
    get zscoreSensitivity(): string;
    get zscoreTarget(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
