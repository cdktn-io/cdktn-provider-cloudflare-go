/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareClientCertificatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Limit to the number of records returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates#limit DataCloudflareClientCertificates#limit}
    */
    readonly limit?: number;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates#max_items DataCloudflareClientCertificates#max_items}
    */
    readonly maxItems?: number;
    /**
    * Offset the results
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates#offset DataCloudflareClientCertificates#offset}
    */
    readonly offset?: number;
    /**
    * Client Certitifcate Status to filter results by.
    * Available values: "all", "active", "pending_reactivation", "pending_revocation", "revoked".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates#status DataCloudflareClientCertificates#status}
    */
    readonly status?: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates#zone_id DataCloudflareClientCertificates#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflareClientCertificatesResultCertificateAuthority {
}
export declare function dataCloudflareClientCertificatesResultCertificateAuthorityToTerraform(struct?: DataCloudflareClientCertificatesResultCertificateAuthority): any;
export declare function dataCloudflareClientCertificatesResultCertificateAuthorityToHclTerraform(struct?: DataCloudflareClientCertificatesResultCertificateAuthority): any;
export declare class DataCloudflareClientCertificatesResultCertificateAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareClientCertificatesResultCertificateAuthority | undefined;
    set internalValue(value: DataCloudflareClientCertificatesResultCertificateAuthority | undefined);
    get id(): string;
    get name(): string;
}
export interface DataCloudflareClientCertificatesResult {
}
export declare function dataCloudflareClientCertificatesResultToTerraform(struct?: DataCloudflareClientCertificatesResult): any;
export declare function dataCloudflareClientCertificatesResultToHclTerraform(struct?: DataCloudflareClientCertificatesResult): any;
export declare class DataCloudflareClientCertificatesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareClientCertificatesResult | undefined;
    set internalValue(value: DataCloudflareClientCertificatesResult | undefined);
    get certificate(): string;
    private _certificateAuthority;
    get certificateAuthority(): DataCloudflareClientCertificatesResultCertificateAuthorityOutputReference;
    get commonName(): string;
    get country(): string;
    get csr(): string;
    get expiresOn(): string;
    get fingerprintSha256(): string;
    get id(): string;
    get issuedOn(): string;
    get location(): string;
    get organization(): string;
    get organizationalUnit(): string;
    get serialNumber(): string;
    get signature(): string;
    get ski(): string;
    get state(): string;
    get status(): string;
    get validityDays(): number;
}
export declare class DataCloudflareClientCertificatesResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareClientCertificatesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates cloudflare_client_certificates}
*/
export declare class DataCloudflareClientCertificates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_client_certificates";
    /**
    * Generates CDKTN code for importing a DataCloudflareClientCertificates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareClientCertificates to import
    * @param importFromId The id of the existing DataCloudflareClientCertificates that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareClientCertificates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/client_certificates cloudflare_client_certificates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareClientCertificatesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareClientCertificatesConfig);
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _offset?;
    get offset(): number;
    set offset(value: number);
    resetOffset(): void;
    get offsetInput(): number | undefined;
    private _result;
    get result(): DataCloudflareClientCertificatesResultList;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
