/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareByoIpPrefixesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier of a Cloudflare account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/byo_ip_prefixes#account_id DataCloudflareByoIpPrefixes#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/byo_ip_prefixes#max_items DataCloudflareByoIpPrefixes#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareByoIpPrefixesResult {
}
export declare function dataCloudflareByoIpPrefixesResultToTerraform(struct?: DataCloudflareByoIpPrefixesResult): any;
export declare function dataCloudflareByoIpPrefixesResultToHclTerraform(struct?: DataCloudflareByoIpPrefixesResult): any;
export declare class DataCloudflareByoIpPrefixesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareByoIpPrefixesResult | undefined;
    set internalValue(value: DataCloudflareByoIpPrefixesResult | undefined);
    get accountId(): string;
    get advertised(): cdktn.IResolvable;
    get advertisedModifiedAt(): string;
    get approved(): string;
    get asn(): number;
    get cidr(): string;
    get createdAt(): string;
    get delegateLoaCreation(): cdktn.IResolvable;
    get description(): string;
    get id(): string;
    get irrValidationState(): string;
    get loaDocumentId(): string;
    get modifiedAt(): string;
    get onDemandEnabled(): cdktn.IResolvable;
    get onDemandLocked(): cdktn.IResolvable;
    get ownershipValidationState(): string;
    get ownershipValidationToken(): string;
    get rpkiValidationState(): string;
}
export declare class DataCloudflareByoIpPrefixesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareByoIpPrefixesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/byo_ip_prefixes cloudflare_byo_ip_prefixes}
*/
export declare class DataCloudflareByoIpPrefixes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_byo_ip_prefixes";
    /**
    * Generates CDKTN code for importing a DataCloudflareByoIpPrefixes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareByoIpPrefixes to import
    * @param importFromId The id of the existing DataCloudflareByoIpPrefixes that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/byo_ip_prefixes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareByoIpPrefixes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/byo_ip_prefixes cloudflare_byo_ip_prefixes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareByoIpPrefixesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareByoIpPrefixesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareByoIpPrefixesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
