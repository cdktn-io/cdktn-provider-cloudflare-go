/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClientCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Certificate Signing Request (CSR). Must be newline-encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/client_certificate#csr ClientCertificate#csr}
    */
    readonly csr: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/client_certificate#reactivate ClientCertificate#reactivate}
    */
    readonly reactivate?: boolean | cdktn.IResolvable;
    /**
    * The number of days the Client Certificate will be valid after the issued_on date
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/client_certificate#validity_days ClientCertificate#validity_days}
    */
    readonly validityDays: number;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/client_certificate#zone_id ClientCertificate#zone_id}
    */
    readonly zoneId?: string;
}
export interface ClientCertificateCertificateAuthority {
}
export declare function clientCertificateCertificateAuthorityToTerraform(struct?: ClientCertificateCertificateAuthority): any;
export declare function clientCertificateCertificateAuthorityToHclTerraform(struct?: ClientCertificateCertificateAuthority): any;
export declare class ClientCertificateCertificateAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClientCertificateCertificateAuthority | undefined;
    set internalValue(value: ClientCertificateCertificateAuthority | undefined);
    get id(): string;
    get name(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/client_certificate cloudflare_client_certificate}
*/
export declare class ClientCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_client_certificate";
    /**
    * Generates CDKTN code for importing a ClientCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClientCertificate to import
    * @param importFromId The id of the existing ClientCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/client_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClientCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/client_certificate cloudflare_client_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClientCertificateConfig
    */
    constructor(scope: Construct, id: string, config: ClientCertificateConfig);
    get certificate(): string;
    private _certificateAuthority;
    get certificateAuthority(): ClientCertificateCertificateAuthorityOutputReference;
    get commonName(): string;
    get country(): string;
    private _csr?;
    get csr(): string;
    set csr(value: string);
    get csrInput(): string | undefined;
    get expiresOn(): string;
    get fingerprintSha256(): string;
    get id(): string;
    get issuedOn(): string;
    get location(): string;
    get organization(): string;
    get organizationalUnit(): string;
    private _reactivate?;
    get reactivate(): boolean | cdktn.IResolvable;
    set reactivate(value: boolean | cdktn.IResolvable);
    resetReactivate(): void;
    get reactivateInput(): boolean | cdktn.IResolvable | undefined;
    get serialNumber(): string;
    get signature(): string;
    get ski(): string;
    get state(): string;
    get status(): string;
    private _validityDays?;
    get validityDays(): number;
    set validityDays(value: number);
    get validityDaysInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
