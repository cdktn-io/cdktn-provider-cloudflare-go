/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWebAnalyticsSitesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/web_analytics_sites#account_id DataCloudflareWebAnalyticsSites#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/web_analytics_sites#max_items DataCloudflareWebAnalyticsSites#max_items}
    */
    readonly maxItems?: number;
    /**
    * The property used to sort the list of results.
    * Available values: "host", "created".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/web_analytics_sites#order_by DataCloudflareWebAnalyticsSites#order_by}
    */
    readonly orderBy?: string;
}
export interface DataCloudflareWebAnalyticsSitesResultRules {
}
export declare function dataCloudflareWebAnalyticsSitesResultRulesToTerraform(struct?: DataCloudflareWebAnalyticsSitesResultRules): any;
export declare function dataCloudflareWebAnalyticsSitesResultRulesToHclTerraform(struct?: DataCloudflareWebAnalyticsSitesResultRules): any;
export declare class DataCloudflareWebAnalyticsSitesResultRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWebAnalyticsSitesResultRules | undefined;
    set internalValue(value: DataCloudflareWebAnalyticsSitesResultRules | undefined);
    get created(): string;
    get host(): string;
    get id(): string;
    get inclusive(): cdktn.IResolvable;
    get isPaused(): cdktn.IResolvable;
    get paths(): string[];
    get priority(): number;
}
export declare class DataCloudflareWebAnalyticsSitesResultRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWebAnalyticsSitesResultRulesOutputReference;
}
export interface DataCloudflareWebAnalyticsSitesResultRuleset {
}
export declare function dataCloudflareWebAnalyticsSitesResultRulesetToTerraform(struct?: DataCloudflareWebAnalyticsSitesResultRuleset): any;
export declare function dataCloudflareWebAnalyticsSitesResultRulesetToHclTerraform(struct?: DataCloudflareWebAnalyticsSitesResultRuleset): any;
export declare class DataCloudflareWebAnalyticsSitesResultRulesetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWebAnalyticsSitesResultRuleset | undefined;
    set internalValue(value: DataCloudflareWebAnalyticsSitesResultRuleset | undefined);
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get zoneName(): string;
    get zoneTag(): string;
}
export interface DataCloudflareWebAnalyticsSitesResult {
}
export declare function dataCloudflareWebAnalyticsSitesResultToTerraform(struct?: DataCloudflareWebAnalyticsSitesResult): any;
export declare function dataCloudflareWebAnalyticsSitesResultToHclTerraform(struct?: DataCloudflareWebAnalyticsSitesResult): any;
export declare class DataCloudflareWebAnalyticsSitesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWebAnalyticsSitesResult | undefined;
    set internalValue(value: DataCloudflareWebAnalyticsSitesResult | undefined);
    get autoInstall(): cdktn.IResolvable;
    get created(): string;
    get id(): string;
    private _rules;
    get rules(): DataCloudflareWebAnalyticsSitesResultRulesList;
    private _ruleset;
    get ruleset(): DataCloudflareWebAnalyticsSitesResultRulesetOutputReference;
    get siteTag(): string;
    get siteToken(): string;
    get snippet(): string;
}
export declare class DataCloudflareWebAnalyticsSitesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWebAnalyticsSitesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/web_analytics_sites cloudflare_web_analytics_sites}
*/
export declare class DataCloudflareWebAnalyticsSites extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_web_analytics_sites";
    /**
    * Generates CDKTN code for importing a DataCloudflareWebAnalyticsSites resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWebAnalyticsSites to import
    * @param importFromId The id of the existing DataCloudflareWebAnalyticsSites that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/web_analytics_sites#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWebAnalyticsSites to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/web_analytics_sites cloudflare_web_analytics_sites} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWebAnalyticsSitesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWebAnalyticsSitesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _result;
    get result(): DataCloudflareWebAnalyticsSitesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
