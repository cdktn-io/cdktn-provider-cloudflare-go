/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkersForPlatformsDispatchNamespacesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/workers_for_platforms_dispatch_namespaces#account_id DataCloudflareWorkersForPlatformsDispatchNamespaces#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/workers_for_platforms_dispatch_namespaces#max_items DataCloudflareWorkersForPlatformsDispatchNamespaces#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareWorkersForPlatformsDispatchNamespacesResult {
}
export declare function dataCloudflareWorkersForPlatformsDispatchNamespacesResultToTerraform(struct?: DataCloudflareWorkersForPlatformsDispatchNamespacesResult): any;
export declare function dataCloudflareWorkersForPlatformsDispatchNamespacesResultToHclTerraform(struct?: DataCloudflareWorkersForPlatformsDispatchNamespacesResult): any;
export declare class DataCloudflareWorkersForPlatformsDispatchNamespacesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersForPlatformsDispatchNamespacesResult | undefined;
    set internalValue(value: DataCloudflareWorkersForPlatformsDispatchNamespacesResult | undefined);
    get createdBy(): string;
    get createdOn(): string;
    get id(): string;
    get modifiedBy(): string;
    get modifiedOn(): string;
    get namespaceId(): string;
    get namespaceName(): string;
    get scriptCount(): number;
    get trustedWorkers(): cdktn.IResolvable;
}
export declare class DataCloudflareWorkersForPlatformsDispatchNamespacesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersForPlatformsDispatchNamespacesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/workers_for_platforms_dispatch_namespaces cloudflare_workers_for_platforms_dispatch_namespaces}
*/
export declare class DataCloudflareWorkersForPlatformsDispatchNamespaces extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_workers_for_platforms_dispatch_namespaces";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkersForPlatformsDispatchNamespaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkersForPlatformsDispatchNamespaces to import
    * @param importFromId The id of the existing DataCloudflareWorkersForPlatformsDispatchNamespaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/workers_for_platforms_dispatch_namespaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkersForPlatformsDispatchNamespaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/workers_for_platforms_dispatch_namespaces cloudflare_workers_for_platforms_dispatch_namespaces} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkersForPlatformsDispatchNamespacesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWorkersForPlatformsDispatchNamespacesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareWorkersForPlatformsDispatchNamespacesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
