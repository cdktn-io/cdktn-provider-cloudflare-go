/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMonetizationRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique ID of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/monetization_rules#zone_id DataCloudflareMonetizationRules#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflareMonetizationRulesRules {
}
export declare function dataCloudflareMonetizationRulesRulesToTerraform(struct?: DataCloudflareMonetizationRulesRules): any;
export declare function dataCloudflareMonetizationRulesRulesToHclTerraform(struct?: DataCloudflareMonetizationRulesRules): any;
export declare class DataCloudflareMonetizationRulesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMonetizationRulesRules | undefined;
    set internalValue(value: DataCloudflareMonetizationRulesRules | undefined);
    get address(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expression(): string;
    get id(): string;
    get price(): string;
    get scheme(): string;
}
export declare class DataCloudflareMonetizationRulesRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMonetizationRulesRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/monetization_rules cloudflare_monetization_rules}
*/
export declare class DataCloudflareMonetizationRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_monetization_rules";
    /**
    * Generates CDKTN code for importing a DataCloudflareMonetizationRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMonetizationRules to import
    * @param importFromId The id of the existing DataCloudflareMonetizationRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/monetization_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMonetizationRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/monetization_rules cloudflare_monetization_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMonetizationRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMonetizationRulesConfig);
    get id(): string;
    private _rules;
    get rules(): DataCloudflareMonetizationRulesRulesList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
