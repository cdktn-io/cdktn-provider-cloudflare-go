/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLogpushJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/logpush_job#account_id DataCloudflareLogpushJob#account_id}
    */
    readonly accountId?: string;
    /**
    * Unique id of the job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/logpush_job#job_id DataCloudflareLogpushJob#job_id}
    */
    readonly jobId: number;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/logpush_job#zone_id DataCloudflareLogpushJob#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareLogpushJobOutputOptions {
}
export declare function dataCloudflareLogpushJobOutputOptionsToTerraform(struct?: DataCloudflareLogpushJobOutputOptions): any;
export declare function dataCloudflareLogpushJobOutputOptionsToHclTerraform(struct?: DataCloudflareLogpushJobOutputOptions): any;
export declare class DataCloudflareLogpushJobOutputOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLogpushJobOutputOptions | undefined;
    set internalValue(value: DataCloudflareLogpushJobOutputOptions | undefined);
    get batchPrefix(): string;
    get batchSuffix(): string;
    get cve202144228(): cdktn.IResolvable;
    get fieldDelimiter(): string;
    get fieldNames(): string[];
    get mergeSubrequests(): cdktn.IResolvable;
    get outputType(): string;
    get recordDelimiter(): string;
    get recordPrefix(): string;
    get recordSuffix(): string;
    get recordTemplate(): string;
    get sampleRate(): number;
    get timestampFormat(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/logpush_job cloudflare_logpush_job}
*/
export declare class DataCloudflareLogpushJob extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_logpush_job";
    /**
    * Generates CDKTN code for importing a DataCloudflareLogpushJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLogpushJob to import
    * @param importFromId The id of the existing DataCloudflareLogpushJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/logpush_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLogpushJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/logpush_job cloudflare_logpush_job} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLogpushJobConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareLogpushJobConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get dataset(): string;
    get destinationConf(): string;
    get enabled(): cdktn.IResolvable;
    get errorMessage(): string;
    get frequency(): string;
    get id(): number;
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    get kind(): string;
    get lastComplete(): string;
    get lastError(): string;
    get logpullOptions(): string;
    get maxUploadBytes(): number;
    get maxUploadIntervalSeconds(): number;
    get maxUploadRecords(): number;
    get name(): string;
    private _outputOptions;
    get outputOptions(): DataCloudflareLogpushJobOutputOptionsOutputReference;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
