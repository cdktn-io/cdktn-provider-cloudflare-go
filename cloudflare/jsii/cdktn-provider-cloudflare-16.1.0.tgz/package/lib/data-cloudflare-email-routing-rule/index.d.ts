/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailRoutingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/email_routing_rule#filter DataCloudflareEmailRoutingRule#filter}
    */
    readonly filter?: DataCloudflareEmailRoutingRuleFilter;
    /**
    * Routing rule identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/email_routing_rule#rule_identifier DataCloudflareEmailRoutingRule#rule_identifier}
    */
    readonly ruleIdentifier?: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/email_routing_rule#zone_id DataCloudflareEmailRoutingRule#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareEmailRoutingRuleActions {
}
export declare function dataCloudflareEmailRoutingRuleActionsToTerraform(struct?: DataCloudflareEmailRoutingRuleActions): any;
export declare function dataCloudflareEmailRoutingRuleActionsToHclTerraform(struct?: DataCloudflareEmailRoutingRuleActions): any;
export declare class DataCloudflareEmailRoutingRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareEmailRoutingRuleActions | undefined;
    set internalValue(value: DataCloudflareEmailRoutingRuleActions | undefined);
    get type(): string;
    get value(): string[];
}
export declare class DataCloudflareEmailRoutingRuleActionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareEmailRoutingRuleActionsOutputReference;
}
export interface DataCloudflareEmailRoutingRuleFilter {
    /**
    * Filter by enabled routing rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/email_routing_rule#enabled DataCloudflareEmailRoutingRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function dataCloudflareEmailRoutingRuleFilterToTerraform(struct?: DataCloudflareEmailRoutingRuleFilter | cdktn.IResolvable): any;
export declare function dataCloudflareEmailRoutingRuleFilterToHclTerraform(struct?: DataCloudflareEmailRoutingRuleFilter | cdktn.IResolvable): any;
export declare class DataCloudflareEmailRoutingRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailRoutingRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareEmailRoutingRuleFilter | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataCloudflareEmailRoutingRuleMatchers {
}
export declare function dataCloudflareEmailRoutingRuleMatchersToTerraform(struct?: DataCloudflareEmailRoutingRuleMatchers): any;
export declare function dataCloudflareEmailRoutingRuleMatchersToHclTerraform(struct?: DataCloudflareEmailRoutingRuleMatchers): any;
export declare class DataCloudflareEmailRoutingRuleMatchersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareEmailRoutingRuleMatchers | undefined;
    set internalValue(value: DataCloudflareEmailRoutingRuleMatchers | undefined);
    get field(): string;
    get type(): string;
    get value(): string;
}
export declare class DataCloudflareEmailRoutingRuleMatchersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareEmailRoutingRuleMatchersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/email_routing_rule cloudflare_email_routing_rule}
*/
export declare class DataCloudflareEmailRoutingRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_routing_rule";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailRoutingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailRoutingRule to import
    * @param importFromId The id of the existing DataCloudflareEmailRoutingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/email_routing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailRoutingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/email_routing_rule cloudflare_email_routing_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailRoutingRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareEmailRoutingRuleConfig);
    private _actions;
    get actions(): DataCloudflareEmailRoutingRuleActionsList;
    get enabled(): cdktn.IResolvable;
    private _filter;
    get filter(): DataCloudflareEmailRoutingRuleFilterOutputReference;
    putFilter(value: DataCloudflareEmailRoutingRuleFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareEmailRoutingRuleFilter | undefined;
    get id(): string;
    private _matchers;
    get matchers(): DataCloudflareEmailRoutingRuleMatchersList;
    get name(): string;
    get priority(): number;
    private _ruleIdentifier?;
    get ruleIdentifier(): string;
    set ruleIdentifier(value: string);
    resetRuleIdentifier(): void;
    get ruleIdentifierInput(): string | undefined;
    get source(): string;
    get tag(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
