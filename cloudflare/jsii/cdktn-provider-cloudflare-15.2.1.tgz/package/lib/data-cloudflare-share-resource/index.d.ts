/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareShareResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource#account_id DataCloudflareShareResource#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource#filter DataCloudflareShareResource#filter}
    */
    readonly filter?: DataCloudflareShareResourceFilter;
    /**
    * Share identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource#share_id DataCloudflareShareResource#share_id}
    */
    readonly shareId: string;
    /**
    * Share Resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource#share_resource_id DataCloudflareShareResource#share_resource_id}
    */
    readonly shareResourceId?: string;
}
export interface DataCloudflareShareResourceFilter {
    /**
    * Filter share resources by resource_type.
    * Available values: "custom-ruleset", "gateway-policy", "gateway-destination-ip", "gateway-block-page-settings", "gateway-extended-email-matching", "idp-federation-grant".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource#resource_type DataCloudflareShareResource#resource_type}
    */
    readonly resourceType?: string;
    /**
    * Filter share resources by status.
    * Available values: "active", "deleting", "deleted".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource#status DataCloudflareShareResource#status}
    */
    readonly status?: string;
}
export declare function dataCloudflareShareResourceFilterToTerraform(struct?: DataCloudflareShareResourceFilter | cdktn.IResolvable): any;
export declare function dataCloudflareShareResourceFilterToHclTerraform(struct?: DataCloudflareShareResourceFilter | cdktn.IResolvable): any;
export declare class DataCloudflareShareResourceFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareShareResourceFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareShareResourceFilter | cdktn.IResolvable | undefined);
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource cloudflare_share_resource}
*/
export declare class DataCloudflareShareResource extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_share_resource";
    /**
    * Generates CDKTN code for importing a DataCloudflareShareResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareShareResource to import
    * @param importFromId The id of the existing DataCloudflareShareResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareShareResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/share_resource cloudflare_share_resource} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareShareResourceConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareShareResourceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get created(): string;
    private _filter;
    get filter(): DataCloudflareShareResourceFilterOutputReference;
    putFilter(value: DataCloudflareShareResourceFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareShareResourceFilter | undefined;
    get id(): string;
    get meta(): string;
    get modified(): string;
    get resourceAccountId(): string;
    get resourceId(): string;
    get resourceType(): string;
    get resourceVersion(): number;
    private _shareId?;
    get shareId(): string;
    set shareId(value: string);
    get shareIdInput(): string | undefined;
    private _shareResourceId?;
    get shareResourceId(): string;
    set shareResourceId(value: string);
    resetShareResourceId(): void;
    get shareResourceIdInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
