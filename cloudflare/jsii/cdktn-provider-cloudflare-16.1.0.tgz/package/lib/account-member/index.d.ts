/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountMemberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#account_id AccountMember#account_id}
    */
    readonly accountId: string;
    /**
    * The contact email address of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#email AccountMember#email}
    */
    readonly email: string;
    /**
    * Array of policies associated with this member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#policies AccountMember#policies}
    */
    readonly policies?: AccountMemberPolicies[] | cdktn.IResolvable;
    /**
    * Set of roles associated with this member.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#roles AccountMember#roles}
    */
    readonly roles?: string[];
    /**
    * Status of the member invitation. If not provided during creation, defaults to 'pending'.
    * Changing from 'accepted' back to 'pending' will trigger a replacement of the member resource in Terraform.
    * Available values: "accepted", "pending".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#status AccountMember#status}
    */
    readonly status?: string;
}
export interface AccountMemberPoliciesPermissionGroups {
    /**
    * Identifier of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#id AccountMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function accountMemberPoliciesPermissionGroupsToTerraform(struct?: AccountMemberPoliciesPermissionGroups): any;
export declare function accountMemberPoliciesPermissionGroupsToHclTerraform(struct?: AccountMemberPoliciesPermissionGroups): any;
export declare class AccountMemberPoliciesPermissionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountMemberPoliciesPermissionGroups | undefined;
    set internalValue(value: AccountMemberPoliciesPermissionGroups | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class AccountMemberPoliciesPermissionGroupsList extends cdktn.ComplexList {
    internalValue?: AccountMemberPoliciesPermissionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountMemberPoliciesPermissionGroupsOutputReference;
}
export interface AccountMemberPoliciesResourceGroups {
    /**
    * Identifier of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#id AccountMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function accountMemberPoliciesResourceGroupsToTerraform(struct?: AccountMemberPoliciesResourceGroups): any;
export declare function accountMemberPoliciesResourceGroupsToHclTerraform(struct?: AccountMemberPoliciesResourceGroups): any;
export declare class AccountMemberPoliciesResourceGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountMemberPoliciesResourceGroups | undefined;
    set internalValue(value: AccountMemberPoliciesResourceGroups | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class AccountMemberPoliciesResourceGroupsList extends cdktn.ComplexList {
    internalValue?: AccountMemberPoliciesResourceGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountMemberPoliciesResourceGroupsOutputReference;
}
export interface AccountMemberPolicies {
    /**
    * Allow or deny operations against the resources.
    * Available values: "allow", "deny".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#access AccountMember#access}
    */
    readonly access: string;
    /**
    * A set of permission groups that are specified to the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#permission_groups AccountMember#permission_groups}
    */
    readonly permissionGroups: AccountMemberPoliciesPermissionGroups[] | cdktn.IResolvable;
    /**
    * A list of resource groups that the policy applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#resource_groups AccountMember#resource_groups}
    */
    readonly resourceGroups: AccountMemberPoliciesResourceGroups[] | cdktn.IResolvable;
}
export declare function accountMemberPoliciesToTerraform(struct?: AccountMemberPolicies | cdktn.IResolvable): any;
export declare function accountMemberPoliciesToHclTerraform(struct?: AccountMemberPolicies | cdktn.IResolvable): any;
export declare class AccountMemberPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountMemberPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AccountMemberPolicies | cdktn.IResolvable | undefined);
    private _access?;
    get access(): string;
    set access(value: string);
    get accessInput(): string | undefined;
    private _permissionGroups;
    get permissionGroups(): AccountMemberPoliciesPermissionGroupsList;
    putPermissionGroups(value: AccountMemberPoliciesPermissionGroups[] | cdktn.IResolvable): void;
    get permissionGroupsInput(): cdktn.IResolvable | AccountMemberPoliciesPermissionGroups[] | undefined;
    private _resourceGroups;
    get resourceGroups(): AccountMemberPoliciesResourceGroupsList;
    putResourceGroups(value: AccountMemberPoliciesResourceGroups[] | cdktn.IResolvable): void;
    get resourceGroupsInput(): cdktn.IResolvable | AccountMemberPoliciesResourceGroups[] | undefined;
}
export declare class AccountMemberPoliciesList extends cdktn.ComplexList {
    internalValue?: AccountMemberPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountMemberPoliciesOutputReference;
}
export interface AccountMemberUser {
}
export declare function accountMemberUserToTerraform(struct?: AccountMemberUser): any;
export declare function accountMemberUserToHclTerraform(struct?: AccountMemberUser): any;
export declare class AccountMemberUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountMemberUser | undefined;
    set internalValue(value: AccountMemberUser | undefined);
    get email(): string;
    get firstName(): string;
    get id(): string;
    get lastName(): string;
    get twoFactorAuthenticationEnabled(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member cloudflare_account_member}
*/
export declare class AccountMember extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_account_member";
    /**
    * Generates CDKTN code for importing a AccountMember resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountMember to import
    * @param importFromId The id of the existing AccountMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/account_member cloudflare_account_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountMemberConfig
    */
    constructor(scope: Construct, id: string, config: AccountMemberConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    get id(): string;
    private _policies;
    get policies(): AccountMemberPoliciesList;
    putPolicies(value: AccountMemberPolicies[] | cdktn.IResolvable): void;
    resetPolicies(): void;
    get policiesInput(): cdktn.IResolvable | AccountMemberPolicies[] | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _user;
    get user(): AccountMemberUserOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
