/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiSearchInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#account_id AiSearchInstance#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#ai_gateway_id AiSearchInstance#ai_gateway_id}
    */
    readonly aiGatewayId?: string;
    /**
    * A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#aisearch_model AiSearchInstance#aisearch_model}
    */
    readonly aisearchModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#cache AiSearchInstance#cache}
    */
    readonly cache?: boolean | cdktn.IResolvable;
    /**
    * Available values: "super_strict_match", "close_enough", "flexible_friend", "anything_goes".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#cache_threshold AiSearchInstance#cache_threshold}
    */
    readonly cacheThreshold?: string;
    /**
    * Cache entry TTL in seconds. Allowed values: 600 (10min), 1800 (30min), 3600 (1h), 7200 (2h), 21600 (6h), 43200 (12h), 86400 (24h), 172800 (48h), 259200 (72h), 518400 (6d).
    * Available values: 600, 1800, 3600, 7200, 21600, 43200, 86400, 172800, 259200, 518400.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#cache_ttl AiSearchInstance#cache_ttl}
    */
    readonly cacheTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#chunk AiSearchInstance#chunk}
    */
    readonly chunk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#chunk_overlap AiSearchInstance#chunk_overlap}
    */
    readonly chunkOverlap?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#chunk_size AiSearchInstance#chunk_size}
    */
    readonly chunkSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#custom_metadata AiSearchInstance#custom_metadata}
    */
    readonly customMetadata?: AiSearchInstanceCustomMetadata[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#embedding_model AiSearchInstance#embedding_model}
    */
    readonly embeddingModel?: string;
    /**
    * Available values: "max", "rrf".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#fusion_method AiSearchInstance#fusion_method}
    */
    readonly fusionMethod?: string;
    /**
    * Deprecated — use index_method instead. Defaults to true for new instances; set false to create a vector-only instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#hybrid_search_enabled AiSearchInstance#hybrid_search_enabled}
    */
    readonly hybridSearchEnabled?: boolean | cdktn.IResolvable;
    /**
    * AI Search instance ID. Lowercase alphanumeric, hyphens, and underscores.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#id AiSearchInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Controls which storage backends are used during indexing. Defaults to vector and keyword indexing for new instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#index_method AiSearchInstance#index_method}
    */
    readonly indexMethod?: AiSearchInstanceIndexMethod;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#indexing_options AiSearchInstance#indexing_options}
    */
    readonly indexingOptions?: AiSearchInstanceIndexingOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#max_num_results AiSearchInstance#max_num_results}
    */
    readonly maxNumResults?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#metadata AiSearchInstance#metadata}
    */
    readonly metadata?: AiSearchInstanceMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#paused AiSearchInstance#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#public_endpoint_params AiSearchInstance#public_endpoint_params}
    */
    readonly publicEndpointParams?: AiSearchInstancePublicEndpointParams;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#reranking AiSearchInstance#reranking}
    */
    readonly reranking?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#reranking_model AiSearchInstance#reranking_model}
    */
    readonly rerankingModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#retrieval_options AiSearchInstance#retrieval_options}
    */
    readonly retrievalOptions?: AiSearchInstanceRetrievalOptions;
    /**
    * A Workers AI model ID or an AI Gateway model ID compatible with the OpenAI Chat Completions API. An empty string uses the configured or default model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#rewrite_model AiSearchInstance#rewrite_model}
    */
    readonly rewriteModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#rewrite_query AiSearchInstance#rewrite_query}
    */
    readonly rewriteQuery?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#score_threshold AiSearchInstance#score_threshold}
    */
    readonly scoreThreshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#source AiSearchInstance#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#source_params AiSearchInstance#source_params}
    */
    readonly sourceParams?: AiSearchInstanceSourceParams;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#summarization AiSearchInstance#summarization}
    */
    readonly summarization?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#summarization_model AiSearchInstance#summarization_model}
    */
    readonly summarizationModel?: string;
    /**
    * Interval between automatic syncs, in seconds. Allowed values: 900 (15min), 1800 (30min), 3600 (1h), 7200 (2h), 14400 (4h), 21600 (6h), 43200 (12h), 86400 (24h).
    * Available values: 900, 1800, 3600, 7200, 14400, 21600, 43200, 86400.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#sync_interval AiSearchInstance#sync_interval}
    */
    readonly syncInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#system_prompt_aisearch AiSearchInstance#system_prompt_aisearch}
    */
    readonly systemPromptAisearch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#system_prompt_index_summarization AiSearchInstance#system_prompt_index_summarization}
    */
    readonly systemPromptIndexSummarization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#system_prompt_rewrite_query AiSearchInstance#system_prompt_rewrite_query}
    */
    readonly systemPromptRewriteQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#token_id AiSearchInstance#token_id}
    */
    readonly tokenId?: string;
    /**
    * Source type. When omitted or null with a non-blank source, HTTP(S) URLs infer web-crawler and existing R2 bucket names infer r2. A missing or blank source without a type uses managed upload-only storage.
    * Available values: "r2", "web-crawler".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#type AiSearchInstance#type}
    */
    readonly type?: string;
}
export interface AiSearchInstanceCustomMetadata {
    /**
    * Available values: "text", "number", "boolean", "datetime".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#data_type AiSearchInstance#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#field_name AiSearchInstance#field_name}
    */
    readonly fieldName: string;
}
export declare function aiSearchInstanceCustomMetadataToTerraform(struct?: AiSearchInstanceCustomMetadata | cdktn.IResolvable): any;
export declare function aiSearchInstanceCustomMetadataToHclTerraform(struct?: AiSearchInstanceCustomMetadata | cdktn.IResolvable): any;
export declare class AiSearchInstanceCustomMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchInstanceCustomMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceCustomMetadata | cdktn.IResolvable | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _fieldName?;
    get fieldName(): string;
    set fieldName(value: string);
    get fieldNameInput(): string | undefined;
}
export declare class AiSearchInstanceCustomMetadataList extends cdktn.ComplexList {
    internalValue?: AiSearchInstanceCustomMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchInstanceCustomMetadataOutputReference;
}
export interface AiSearchInstanceIndexMethod {
    /**
    * Enable keyword (BM25) storage backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#keyword AiSearchInstance#keyword}
    */
    readonly keyword: boolean | cdktn.IResolvable;
    /**
    * Enable vector (embedding) storage backend.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#vector AiSearchInstance#vector}
    */
    readonly vector: boolean | cdktn.IResolvable;
}
export declare function aiSearchInstanceIndexMethodToTerraform(struct?: AiSearchInstanceIndexMethod | cdktn.IResolvable): any;
export declare function aiSearchInstanceIndexMethodToHclTerraform(struct?: AiSearchInstanceIndexMethod | cdktn.IResolvable): any;
export declare class AiSearchInstanceIndexMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceIndexMethod | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceIndexMethod | cdktn.IResolvable | undefined);
    private _keyword?;
    get keyword(): boolean | cdktn.IResolvable;
    set keyword(value: boolean | cdktn.IResolvable);
    get keywordInput(): boolean | cdktn.IResolvable | undefined;
    private _vector?;
    get vector(): boolean | cdktn.IResolvable;
    set vector(value: boolean | cdktn.IResolvable);
    get vectorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchInstanceIndexingOptions {
    /**
    * Tokenizer used for keyword search indexing. porter provides word-level tokenization with Porter stemming (good for natural language queries). trigram enables character-level substring matching (good for partial matches, code, identifiers). Changing this triggers a full re-index. Defaults to porter.
    * Available values: "porter", "trigram".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#keyword_tokenizer AiSearchInstance#keyword_tokenizer}
    */
    readonly keywordTokenizer?: string;
    /**
    * Enables OCR ingestion for PDFs and images. Changing this triggers a full re-index. Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#use_ocr AiSearchInstance#use_ocr}
    */
    readonly useOcr?: boolean | cdktn.IResolvable;
}
export declare function aiSearchInstanceIndexingOptionsToTerraform(struct?: AiSearchInstanceIndexingOptions | cdktn.IResolvable): any;
export declare function aiSearchInstanceIndexingOptionsToHclTerraform(struct?: AiSearchInstanceIndexingOptions | cdktn.IResolvable): any;
export declare class AiSearchInstanceIndexingOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceIndexingOptions | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceIndexingOptions | cdktn.IResolvable | undefined);
    private _keywordTokenizer?;
    get keywordTokenizer(): string;
    set keywordTokenizer(value: string);
    resetKeywordTokenizer(): void;
    get keywordTokenizerInput(): string | undefined;
    private _useOcr?;
    get useOcr(): boolean | cdktn.IResolvable;
    set useOcr(value: boolean | cdktn.IResolvable);
    resetUseOcr(): void;
    get useOcrInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchInstanceMetadataCreatedFromEmdashPlugin {
    /**
    * Available values: "native", "rest".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#type AiSearchInstance#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#version AiSearchInstance#version}
    */
    readonly version: string;
}
export declare function aiSearchInstanceMetadataCreatedFromEmdashPluginToTerraform(struct?: AiSearchInstanceMetadataCreatedFromEmdashPlugin | cdktn.IResolvable): any;
export declare function aiSearchInstanceMetadataCreatedFromEmdashPluginToHclTerraform(struct?: AiSearchInstanceMetadataCreatedFromEmdashPlugin | cdktn.IResolvable): any;
export declare class AiSearchInstanceMetadataCreatedFromEmdashPluginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceMetadataCreatedFromEmdashPlugin | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceMetadataCreatedFromEmdashPlugin | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export interface AiSearchInstanceMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#created_from_aisearch_wizard AiSearchInstance#created_from_aisearch_wizard}
    */
    readonly createdFromAisearchWizard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#created_from_emdash_plugin AiSearchInstance#created_from_emdash_plugin}
    */
    readonly createdFromEmdashPlugin?: AiSearchInstanceMetadataCreatedFromEmdashPlugin;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#worker_domain AiSearchInstance#worker_domain}
    */
    readonly workerDomain?: string;
}
export declare function aiSearchInstanceMetadataToTerraform(struct?: AiSearchInstanceMetadata | cdktn.IResolvable): any;
export declare function aiSearchInstanceMetadataToHclTerraform(struct?: AiSearchInstanceMetadata | cdktn.IResolvable): any;
export declare class AiSearchInstanceMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceMetadata | cdktn.IResolvable | undefined);
    private _createdFromAisearchWizard?;
    get createdFromAisearchWizard(): boolean | cdktn.IResolvable;
    set createdFromAisearchWizard(value: boolean | cdktn.IResolvable);
    resetCreatedFromAisearchWizard(): void;
    get createdFromAisearchWizardInput(): boolean | cdktn.IResolvable | undefined;
    private _createdFromEmdashPlugin;
    get createdFromEmdashPlugin(): AiSearchInstanceMetadataCreatedFromEmdashPluginOutputReference;
    putCreatedFromEmdashPlugin(value: AiSearchInstanceMetadataCreatedFromEmdashPlugin): void;
    resetCreatedFromEmdashPlugin(): void;
    get createdFromEmdashPluginInput(): cdktn.IResolvable | AiSearchInstanceMetadataCreatedFromEmdashPlugin | undefined;
    private _workerDomain?;
    get workerDomain(): string;
    set workerDomain(value: string);
    resetWorkerDomain(): void;
    get workerDomainInput(): string | undefined;
}
export interface AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint {
    /**
    * Disable chat completions endpoint for this public endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#disabled AiSearchInstance#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
}
export declare function aiSearchInstancePublicEndpointParamsChatCompletionsEndpointToTerraform(struct?: AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable): any;
export declare function aiSearchInstancePublicEndpointParamsChatCompletionsEndpointToHclTerraform(struct?: AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable): any;
export declare class AiSearchInstancePublicEndpointParamsChatCompletionsEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchInstancePublicEndpointParamsMcp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#description AiSearchInstance#description}
    */
    readonly description?: string;
    /**
    * Disable MCP endpoint for this public endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#disabled AiSearchInstance#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
}
export declare function aiSearchInstancePublicEndpointParamsMcpToTerraform(struct?: AiSearchInstancePublicEndpointParamsMcp | cdktn.IResolvable): any;
export declare function aiSearchInstancePublicEndpointParamsMcpToHclTerraform(struct?: AiSearchInstancePublicEndpointParamsMcp | cdktn.IResolvable): any;
export declare class AiSearchInstancePublicEndpointParamsMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstancePublicEndpointParamsMcp | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstancePublicEndpointParamsMcp | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchInstancePublicEndpointParamsRateLimit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#period_ms AiSearchInstance#period_ms}
    */
    readonly periodMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#requests AiSearchInstance#requests}
    */
    readonly requests?: number;
    /**
    * Available values: "fixed", "sliding".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#technique AiSearchInstance#technique}
    */
    readonly technique?: string;
}
export declare function aiSearchInstancePublicEndpointParamsRateLimitToTerraform(struct?: AiSearchInstancePublicEndpointParamsRateLimit | cdktn.IResolvable): any;
export declare function aiSearchInstancePublicEndpointParamsRateLimitToHclTerraform(struct?: AiSearchInstancePublicEndpointParamsRateLimit | cdktn.IResolvable): any;
export declare class AiSearchInstancePublicEndpointParamsRateLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstancePublicEndpointParamsRateLimit | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstancePublicEndpointParamsRateLimit | cdktn.IResolvable | undefined);
    private _periodMs?;
    get periodMs(): number;
    set periodMs(value: number);
    resetPeriodMs(): void;
    get periodMsInput(): number | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _technique?;
    get technique(): string;
    set technique(value: string);
    resetTechnique(): void;
    get techniqueInput(): string | undefined;
}
export interface AiSearchInstancePublicEndpointParamsSearchEndpoint {
    /**
    * Disable search endpoint for this public endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#disabled AiSearchInstance#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
}
export declare function aiSearchInstancePublicEndpointParamsSearchEndpointToTerraform(struct?: AiSearchInstancePublicEndpointParamsSearchEndpoint | cdktn.IResolvable): any;
export declare function aiSearchInstancePublicEndpointParamsSearchEndpointToHclTerraform(struct?: AiSearchInstancePublicEndpointParamsSearchEndpoint | cdktn.IResolvable): any;
export declare class AiSearchInstancePublicEndpointParamsSearchEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstancePublicEndpointParamsSearchEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstancePublicEndpointParamsSearchEndpoint | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchInstancePublicEndpointParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#authorized_hosts AiSearchInstance#authorized_hosts}
    */
    readonly authorizedHosts?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#chat_completions_endpoint AiSearchInstance#chat_completions_endpoint}
    */
    readonly chatCompletionsEndpoint?: AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint;
    /**
    * Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#custom_domains AiSearchInstance#custom_domains}
    */
    readonly customDomains?: string[];
    /**
    * When false, the instance is reachable only via a registered custom domain and the default <public_endpoint_id>.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off — omitting it resets to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#default_domain_enabled AiSearchInstance#default_domain_enabled}
    */
    readonly defaultDomainEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#enabled AiSearchInstance#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#mcp AiSearchInstance#mcp}
    */
    readonly mcp?: AiSearchInstancePublicEndpointParamsMcp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#rate_limit AiSearchInstance#rate_limit}
    */
    readonly rateLimit?: AiSearchInstancePublicEndpointParamsRateLimit;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#search_endpoint AiSearchInstance#search_endpoint}
    */
    readonly searchEndpoint?: AiSearchInstancePublicEndpointParamsSearchEndpoint;
}
export declare function aiSearchInstancePublicEndpointParamsToTerraform(struct?: AiSearchInstancePublicEndpointParams | cdktn.IResolvable): any;
export declare function aiSearchInstancePublicEndpointParamsToHclTerraform(struct?: AiSearchInstancePublicEndpointParams | cdktn.IResolvable): any;
export declare class AiSearchInstancePublicEndpointParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstancePublicEndpointParams | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstancePublicEndpointParams | cdktn.IResolvable | undefined);
    private _authorizedHosts?;
    get authorizedHosts(): string[];
    set authorizedHosts(value: string[]);
    resetAuthorizedHosts(): void;
    get authorizedHostsInput(): string[] | undefined;
    private _chatCompletionsEndpoint;
    get chatCompletionsEndpoint(): AiSearchInstancePublicEndpointParamsChatCompletionsEndpointOutputReference;
    putChatCompletionsEndpoint(value: AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint): void;
    resetChatCompletionsEndpoint(): void;
    get chatCompletionsEndpointInput(): cdktn.IResolvable | AiSearchInstancePublicEndpointParamsChatCompletionsEndpoint | undefined;
    private _customDomains?;
    get customDomains(): string[];
    set customDomains(value: string[]);
    resetCustomDomains(): void;
    get customDomainsInput(): string[] | undefined;
    private _defaultDomainEnabled?;
    get defaultDomainEnabled(): boolean | cdktn.IResolvable;
    set defaultDomainEnabled(value: boolean | cdktn.IResolvable);
    resetDefaultDomainEnabled(): void;
    get defaultDomainEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _mcp;
    get mcp(): AiSearchInstancePublicEndpointParamsMcpOutputReference;
    putMcp(value: AiSearchInstancePublicEndpointParamsMcp): void;
    resetMcp(): void;
    get mcpInput(): cdktn.IResolvable | AiSearchInstancePublicEndpointParamsMcp | undefined;
    private _rateLimit;
    get rateLimit(): AiSearchInstancePublicEndpointParamsRateLimitOutputReference;
    putRateLimit(value: AiSearchInstancePublicEndpointParamsRateLimit): void;
    resetRateLimit(): void;
    get rateLimitInput(): cdktn.IResolvable | AiSearchInstancePublicEndpointParamsRateLimit | undefined;
    private _searchEndpoint;
    get searchEndpoint(): AiSearchInstancePublicEndpointParamsSearchEndpointOutputReference;
    putSearchEndpoint(value: AiSearchInstancePublicEndpointParamsSearchEndpoint): void;
    resetSearchEndpoint(): void;
    get searchEndpointInput(): cdktn.IResolvable | AiSearchInstancePublicEndpointParamsSearchEndpoint | undefined;
}
export interface AiSearchInstanceRetrievalOptionsBoostBy {
    /**
    * Boost direction. 'desc' = higher values rank higher (e.g. newer timestamps). 'asc' = lower values rank higher. 'exists' = boost chunks that have the field. 'not_exists' = boost chunks that lack the field. Optional — defaults to 'asc' for numeric/datetime fields, 'exists' for text/boolean fields.
    * Available values: "asc", "desc", "exists", "not_exists".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#direction AiSearchInstance#direction}
    */
    readonly direction?: string;
    /**
    * Metadata field name to boost by. Use 'timestamp' for document freshness, or any custom_metadata field. Numeric and datetime fields support all four directions (asc, desc, exists, not_exists); text/boolean fields only support exists/not_exists.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#field AiSearchInstance#field}
    */
    readonly field: string;
}
export declare function aiSearchInstanceRetrievalOptionsBoostByToTerraform(struct?: AiSearchInstanceRetrievalOptionsBoostBy | cdktn.IResolvable): any;
export declare function aiSearchInstanceRetrievalOptionsBoostByToHclTerraform(struct?: AiSearchInstanceRetrievalOptionsBoostBy | cdktn.IResolvable): any;
export declare class AiSearchInstanceRetrievalOptionsBoostByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchInstanceRetrievalOptionsBoostBy | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceRetrievalOptionsBoostBy | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
}
export declare class AiSearchInstanceRetrievalOptionsBoostByList extends cdktn.ComplexList {
    internalValue?: AiSearchInstanceRetrievalOptionsBoostBy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchInstanceRetrievalOptionsBoostByOutputReference;
}
export interface AiSearchInstanceRetrievalOptions {
    /**
    * Metadata fields to boost search results by. Each entry specifies a metadata field and an optional direction. Direction defaults to 'asc' for numeric/datetime fields and 'exists' for text/boolean fields. Fields must match 'timestamp' or a defined custom_metadata field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#boost_by AiSearchInstance#boost_by}
    */
    readonly boostBy?: AiSearchInstanceRetrievalOptionsBoostBy[] | cdktn.IResolvable;
    /**
    * Controls which documents are candidates for BM25 scoring. 'and' restricts candidates to documents containing all query terms; 'or' includes any document containing at least one term, ranked by BM25 relevance. When omitted on an update, the existing stored value is preserved; when never set, search falls back to 'and'.
    * Available values: "and", "or".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#keyword_match_mode AiSearchInstance#keyword_match_mode}
    */
    readonly keywordMatchMode?: string;
}
export declare function aiSearchInstanceRetrievalOptionsToTerraform(struct?: AiSearchInstanceRetrievalOptions | cdktn.IResolvable): any;
export declare function aiSearchInstanceRetrievalOptionsToHclTerraform(struct?: AiSearchInstanceRetrievalOptions | cdktn.IResolvable): any;
export declare class AiSearchInstanceRetrievalOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceRetrievalOptions | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceRetrievalOptions | cdktn.IResolvable | undefined);
    private _boostBy;
    get boostBy(): AiSearchInstanceRetrievalOptionsBoostByList;
    putBoostBy(value: AiSearchInstanceRetrievalOptionsBoostBy[] | cdktn.IResolvable): void;
    resetBoostBy(): void;
    get boostByInput(): cdktn.IResolvable | AiSearchInstanceRetrievalOptionsBoostBy[] | undefined;
    private _keywordMatchMode?;
    get keywordMatchMode(): string;
    set keywordMatchMode(value: string);
    resetKeywordMatchMode(): void;
    get keywordMatchModeInput(): string | undefined;
}
export interface AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions {
    /**
    * Maximum link-follow depth from the seed URL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#depth AiSearchInstance#depth}
    */
    readonly depth?: number;
    /**
    * Follow links that point outside the source domain. Must stay `false` — discover crawls are restricted to the zone you own.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#include_external_links AiSearchInstance#include_external_links}
    */
    readonly includeExternalLinks?: boolean | cdktn.IResolvable;
    /**
    * Follow links to subdomains of the source host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#include_subdomains AiSearchInstance#include_subdomains}
    */
    readonly includeSubdomains?: boolean | cdktn.IResolvable;
    /**
    * Maximum number of pages to crawl (1-100000).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#limit AiSearchInstance#limit}
    */
    readonly limit?: number;
    /**
    * Maximum content age in seconds to accept (0–604800).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#max_age AiSearchInstance#max_age}
    */
    readonly maxAge?: number;
    /**
    * Where the crawler looks for URLs: 'sitemaps' reads sitemap XML only, 'links' follows page links only, 'all' does both.
    * Available values: "all", "sitemaps", "links".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#source AiSearchInstance#source}
    */
    readonly source?: string;
}
export declare function aiSearchInstanceSourceParamsWebCrawlerDiscoverOptionsToTerraform(struct?: AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions | cdktn.IResolvable): any;
export declare function aiSearchInstanceSourceParamsWebCrawlerDiscoverOptionsToHclTerraform(struct?: AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions | cdktn.IResolvable): any;
export declare class AiSearchInstanceSourceParamsWebCrawlerDiscoverOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions | cdktn.IResolvable | undefined);
    private _depth?;
    get depth(): number;
    set depth(value: number);
    resetDepth(): void;
    get depthInput(): number | undefined;
    private _includeExternalLinks?;
    get includeExternalLinks(): boolean | cdktn.IResolvable;
    set includeExternalLinks(value: boolean | cdktn.IResolvable);
    resetIncludeExternalLinks(): void;
    get includeExternalLinksInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSubdomains?;
    get includeSubdomains(): boolean | cdktn.IResolvable;
    set includeSubdomains(value: boolean | cdktn.IResolvable);
    resetIncludeSubdomains(): void;
    get includeSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _maxAge?;
    get maxAge(): number;
    set maxAge(value: number);
    resetMaxAge(): void;
    get maxAgeInput(): number | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector {
    /**
    * Glob pattern to match against the page URL path. Uses standard glob syntax: * matches within a segment, ** crosses directories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#path AiSearchInstance#path}
    */
    readonly path: string;
    /**
    * CSS selector to extract content from pages matching the path pattern. Must not contain disallowed characters (;, `, $, {, }, \). Must target a single element; if multiple elements match, the selector is ignored and the full page is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#selector AiSearchInstance#selector}
    */
    readonly selector: string;
}
export declare function aiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelectorToTerraform(struct?: AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector | cdktn.IResolvable): any;
export declare function aiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelectorToHclTerraform(struct?: AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector | cdktn.IResolvable): any;
export declare class AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _selector?;
    get selector(): string;
    set selector(value: string);
    get selectorInput(): string | undefined;
}
export declare class AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelectorList extends cdktn.ComplexList {
    internalValue?: AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelectorOutputReference;
}
export interface AiSearchInstanceSourceParamsWebCrawlerParseOptions {
    /**
    * List of path-to-selector mappings for extracting specific content from crawled pages. Each entry pairs a URL glob pattern with a CSS selector. The first matching path wins. Only the matched HTML fragment is stored and indexed. Omit the field to disable content selection — empty arrays are rejected.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#content_selector AiSearchInstance#content_selector}
    */
    readonly contentSelector?: AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector[] | cdktn.IResolvable;
    /**
    * Up to 5 custom HTTP headers sent with each crawl request. Names must be RFC-7230 token characters (no spaces, colons, or control characters); values must be HTAB + printable ASCII (no CR/LF).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#include_headers AiSearchInstance#include_headers}
    */
    readonly includeHeaders?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#include_images AiSearchInstance#include_images}
    */
    readonly includeImages?: boolean | cdktn.IResolvable;
    /**
    * List of specific sitemap URLs to use for crawling. Only valid when parse_type is 'sitemap'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#specific_sitemaps AiSearchInstance#specific_sitemaps}
    */
    readonly specificSitemaps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#use_browser_rendering AiSearchInstance#use_browser_rendering}
    */
    readonly useBrowserRendering?: boolean | cdktn.IResolvable;
}
export declare function aiSearchInstanceSourceParamsWebCrawlerParseOptionsToTerraform(struct?: AiSearchInstanceSourceParamsWebCrawlerParseOptions | cdktn.IResolvable): any;
export declare function aiSearchInstanceSourceParamsWebCrawlerParseOptionsToHclTerraform(struct?: AiSearchInstanceSourceParamsWebCrawlerParseOptions | cdktn.IResolvable): any;
export declare class AiSearchInstanceSourceParamsWebCrawlerParseOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceSourceParamsWebCrawlerParseOptions | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceSourceParamsWebCrawlerParseOptions | cdktn.IResolvable | undefined);
    private _contentSelector;
    get contentSelector(): AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelectorList;
    putContentSelector(value: AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector[] | cdktn.IResolvable): void;
    resetContentSelector(): void;
    get contentSelectorInput(): cdktn.IResolvable | AiSearchInstanceSourceParamsWebCrawlerParseOptionsContentSelector[] | undefined;
    private _includeHeaders?;
    get includeHeaders(): {
        [key: string]: string;
    };
    set includeHeaders(value: {
        [key: string]: string;
    });
    resetIncludeHeaders(): void;
    get includeHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _includeImages?;
    get includeImages(): boolean | cdktn.IResolvable;
    set includeImages(value: boolean | cdktn.IResolvable);
    resetIncludeImages(): void;
    get includeImagesInput(): boolean | cdktn.IResolvable | undefined;
    private _specificSitemaps?;
    get specificSitemaps(): string[];
    set specificSitemaps(value: string[]);
    resetSpecificSitemaps(): void;
    get specificSitemapsInput(): string[] | undefined;
    private _useBrowserRendering?;
    get useBrowserRendering(): boolean | cdktn.IResolvable;
    set useBrowserRendering(value: boolean | cdktn.IResolvable);
    resetUseBrowserRendering(): void;
    get useBrowserRenderingInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchInstanceSourceParamsWebCrawler {
    /**
    * Options for parse_type 'discover', where Browser Run discovers URLs by link following and sitemaps. Ignored for 'sitemap'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#discover_options AiSearchInstance#discover_options}
    */
    readonly discoverOptions?: AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#parse_options AiSearchInstance#parse_options}
    */
    readonly parseOptions?: AiSearchInstanceSourceParamsWebCrawlerParseOptions;
    /**
    * How URLs are discovered. 'sitemap' reads XML sitemaps; 'discover' follows links recursively and requires the source to be a Verified zone on this account.
    * Available values: "sitemap", "discover".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#parse_type AiSearchInstance#parse_type}
    */
    readonly parseType?: string;
}
export declare function aiSearchInstanceSourceParamsWebCrawlerToTerraform(struct?: AiSearchInstanceSourceParamsWebCrawler | cdktn.IResolvable): any;
export declare function aiSearchInstanceSourceParamsWebCrawlerToHclTerraform(struct?: AiSearchInstanceSourceParamsWebCrawler | cdktn.IResolvable): any;
export declare class AiSearchInstanceSourceParamsWebCrawlerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceSourceParamsWebCrawler | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceSourceParamsWebCrawler | cdktn.IResolvable | undefined);
    private _discoverOptions;
    get discoverOptions(): AiSearchInstanceSourceParamsWebCrawlerDiscoverOptionsOutputReference;
    putDiscoverOptions(value: AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions): void;
    resetDiscoverOptions(): void;
    get discoverOptionsInput(): cdktn.IResolvable | AiSearchInstanceSourceParamsWebCrawlerDiscoverOptions | undefined;
    private _parseOptions;
    get parseOptions(): AiSearchInstanceSourceParamsWebCrawlerParseOptionsOutputReference;
    putParseOptions(value: AiSearchInstanceSourceParamsWebCrawlerParseOptions): void;
    resetParseOptions(): void;
    get parseOptionsInput(): cdktn.IResolvable | AiSearchInstanceSourceParamsWebCrawlerParseOptions | undefined;
    private _parseType?;
    get parseType(): string;
    set parseType(value: string);
    resetParseType(): void;
    get parseTypeInput(): string | undefined;
}
export interface AiSearchInstanceSourceParams {
    /**
    * List of path patterns to exclude. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /admin/** matches /admin/users and /admin/settings/advanced). Most accounts are limited to 10 rules; contact support to raise it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#exclude_items AiSearchInstance#exclude_items}
    */
    readonly excludeItems?: string[];
    /**
    * List of path patterns to include. Uses micromatch glob syntax: * matches within a path segment, ** matches across path segments (e.g., /blog/** matches /blog/post and /blog/2024/post). Most accounts are limited to 10 rules; contact support to raise it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#include_items AiSearchInstance#include_items}
    */
    readonly includeItems?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#prefix AiSearchInstance#prefix}
    */
    readonly prefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#r2_jurisdiction AiSearchInstance#r2_jurisdiction}
    */
    readonly r2Jurisdiction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#web_crawler AiSearchInstance#web_crawler}
    */
    readonly webCrawler?: AiSearchInstanceSourceParamsWebCrawler;
}
export declare function aiSearchInstanceSourceParamsToTerraform(struct?: AiSearchInstanceSourceParams | cdktn.IResolvable): any;
export declare function aiSearchInstanceSourceParamsToHclTerraform(struct?: AiSearchInstanceSourceParams | cdktn.IResolvable): any;
export declare class AiSearchInstanceSourceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchInstanceSourceParams | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchInstanceSourceParams | cdktn.IResolvable | undefined);
    private _excludeItems?;
    get excludeItems(): string[];
    set excludeItems(value: string[]);
    resetExcludeItems(): void;
    get excludeItemsInput(): string[] | undefined;
    private _includeItems?;
    get includeItems(): string[];
    set includeItems(value: string[]);
    resetIncludeItems(): void;
    get includeItemsInput(): string[] | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    private _r2Jurisdiction?;
    get r2Jurisdiction(): string;
    set r2Jurisdiction(value: string);
    resetR2Jurisdiction(): void;
    get r2JurisdictionInput(): string | undefined;
    private _webCrawler;
    get webCrawler(): AiSearchInstanceSourceParamsWebCrawlerOutputReference;
    putWebCrawler(value: AiSearchInstanceSourceParamsWebCrawler): void;
    resetWebCrawler(): void;
    get webCrawlerInput(): cdktn.IResolvable | AiSearchInstanceSourceParamsWebCrawler | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance cloudflare_ai_search_instance}
*/
export declare class AiSearchInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ai_search_instance";
    /**
    * Generates CDKTN code for importing a AiSearchInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiSearchInstance to import
    * @param importFromId The id of the existing AiSearchInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiSearchInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.0/docs/resources/ai_search_instance cloudflare_ai_search_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiSearchInstanceConfig
    */
    constructor(scope: Construct, id: string, config: AiSearchInstanceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _aiGatewayId?;
    get aiGatewayId(): string;
    set aiGatewayId(value: string);
    resetAiGatewayId(): void;
    get aiGatewayIdInput(): string | undefined;
    private _aisearchModel?;
    get aisearchModel(): string;
    set aisearchModel(value: string);
    resetAisearchModel(): void;
    get aisearchModelInput(): string | undefined;
    private _cache?;
    get cache(): boolean | cdktn.IResolvable;
    set cache(value: boolean | cdktn.IResolvable);
    resetCache(): void;
    get cacheInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheThreshold?;
    get cacheThreshold(): string;
    set cacheThreshold(value: string);
    resetCacheThreshold(): void;
    get cacheThresholdInput(): string | undefined;
    private _cacheTtl?;
    get cacheTtl(): number;
    set cacheTtl(value: number);
    resetCacheTtl(): void;
    get cacheTtlInput(): number | undefined;
    private _chunk?;
    get chunk(): boolean | cdktn.IResolvable;
    set chunk(value: boolean | cdktn.IResolvable);
    resetChunk(): void;
    get chunkInput(): boolean | cdktn.IResolvable | undefined;
    private _chunkOverlap?;
    get chunkOverlap(): number;
    set chunkOverlap(value: number);
    resetChunkOverlap(): void;
    get chunkOverlapInput(): number | undefined;
    private _chunkSize?;
    get chunkSize(): number;
    set chunkSize(value: number);
    resetChunkSize(): void;
    get chunkSizeInput(): number | undefined;
    get createdAt(): string;
    get createdBy(): string;
    private _customMetadata;
    get customMetadata(): AiSearchInstanceCustomMetadataList;
    putCustomMetadata(value: AiSearchInstanceCustomMetadata[] | cdktn.IResolvable): void;
    resetCustomMetadata(): void;
    get customMetadataInput(): cdktn.IResolvable | AiSearchInstanceCustomMetadata[] | undefined;
    private _embeddingModel?;
    get embeddingModel(): string;
    set embeddingModel(value: string);
    resetEmbeddingModel(): void;
    get embeddingModelInput(): string | undefined;
    get enable(): cdktn.IResolvable;
    get engineVersion(): number;
    private _fusionMethod?;
    get fusionMethod(): string;
    set fusionMethod(value: string);
    resetFusionMethod(): void;
    get fusionMethodInput(): string | undefined;
    private _hybridSearchEnabled?;
    get hybridSearchEnabled(): boolean | cdktn.IResolvable;
    set hybridSearchEnabled(value: boolean | cdktn.IResolvable);
    resetHybridSearchEnabled(): void;
    get hybridSearchEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _indexMethod;
    get indexMethod(): AiSearchInstanceIndexMethodOutputReference;
    putIndexMethod(value: AiSearchInstanceIndexMethod): void;
    resetIndexMethod(): void;
    get indexMethodInput(): cdktn.IResolvable | AiSearchInstanceIndexMethod | undefined;
    private _indexingOptions;
    get indexingOptions(): AiSearchInstanceIndexingOptionsOutputReference;
    putIndexingOptions(value: AiSearchInstanceIndexingOptions): void;
    resetIndexingOptions(): void;
    get indexingOptionsInput(): cdktn.IResolvable | AiSearchInstanceIndexingOptions | undefined;
    get lastActivity(): string;
    private _maxNumResults?;
    get maxNumResults(): number;
    set maxNumResults(value: number);
    resetMaxNumResults(): void;
    get maxNumResultsInput(): number | undefined;
    private _metadata;
    get metadata(): AiSearchInstanceMetadataOutputReference;
    putMetadata(value: AiSearchInstanceMetadata): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | AiSearchInstanceMetadata | undefined;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get namespace(): string;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    get publicEndpointId(): string;
    private _publicEndpointParams;
    get publicEndpointParams(): AiSearchInstancePublicEndpointParamsOutputReference;
    putPublicEndpointParams(value: AiSearchInstancePublicEndpointParams): void;
    resetPublicEndpointParams(): void;
    get publicEndpointParamsInput(): cdktn.IResolvable | AiSearchInstancePublicEndpointParams | undefined;
    private _reranking?;
    get reranking(): boolean | cdktn.IResolvable;
    set reranking(value: boolean | cdktn.IResolvable);
    resetReranking(): void;
    get rerankingInput(): boolean | cdktn.IResolvable | undefined;
    private _rerankingModel?;
    get rerankingModel(): string;
    set rerankingModel(value: string);
    resetRerankingModel(): void;
    get rerankingModelInput(): string | undefined;
    private _retrievalOptions;
    get retrievalOptions(): AiSearchInstanceRetrievalOptionsOutputReference;
    putRetrievalOptions(value: AiSearchInstanceRetrievalOptions): void;
    resetRetrievalOptions(): void;
    get retrievalOptionsInput(): cdktn.IResolvable | AiSearchInstanceRetrievalOptions | undefined;
    private _rewriteModel?;
    get rewriteModel(): string;
    set rewriteModel(value: string);
    resetRewriteModel(): void;
    get rewriteModelInput(): string | undefined;
    private _rewriteQuery?;
    get rewriteQuery(): boolean | cdktn.IResolvable;
    set rewriteQuery(value: boolean | cdktn.IResolvable);
    resetRewriteQuery(): void;
    get rewriteQueryInput(): boolean | cdktn.IResolvable | undefined;
    private _scoreThreshold?;
    get scoreThreshold(): number;
    set scoreThreshold(value: number);
    resetScoreThreshold(): void;
    get scoreThresholdInput(): number | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _sourceParams;
    get sourceParams(): AiSearchInstanceSourceParamsOutputReference;
    putSourceParams(value: AiSearchInstanceSourceParams): void;
    resetSourceParams(): void;
    get sourceParamsInput(): cdktn.IResolvable | AiSearchInstanceSourceParams | undefined;
    get status(): string;
    private _summarization?;
    get summarization(): boolean | cdktn.IResolvable;
    set summarization(value: boolean | cdktn.IResolvable);
    resetSummarization(): void;
    get summarizationInput(): boolean | cdktn.IResolvable | undefined;
    private _summarizationModel?;
    get summarizationModel(): string;
    set summarizationModel(value: string);
    resetSummarizationModel(): void;
    get summarizationModelInput(): string | undefined;
    private _syncInterval?;
    get syncInterval(): number;
    set syncInterval(value: number);
    resetSyncInterval(): void;
    get syncIntervalInput(): number | undefined;
    private _systemPromptAisearch?;
    get systemPromptAisearch(): string;
    set systemPromptAisearch(value: string);
    resetSystemPromptAisearch(): void;
    get systemPromptAisearchInput(): string | undefined;
    private _systemPromptIndexSummarization?;
    get systemPromptIndexSummarization(): string;
    set systemPromptIndexSummarization(value: string);
    resetSystemPromptIndexSummarization(): void;
    get systemPromptIndexSummarizationInput(): string | undefined;
    private _systemPromptRewriteQuery?;
    get systemPromptRewriteQuery(): string;
    set systemPromptRewriteQuery(value: string);
    resetSystemPromptRewriteQuery(): void;
    get systemPromptRewriteQueryInput(): string | undefined;
    private _tokenId?;
    get tokenId(): string;
    set tokenId(value: string);
    resetTokenId(): void;
    get tokenIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
