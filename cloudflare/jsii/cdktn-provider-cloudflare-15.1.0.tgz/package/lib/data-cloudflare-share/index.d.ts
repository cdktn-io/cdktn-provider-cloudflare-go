/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#account_id DataCloudflareShare#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#filter DataCloudflareShare#filter}
    */
    readonly filter?: DataCloudflareShareFilter;
    /**
    * Include recipient counts in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#include_recipient_counts DataCloudflareShare#include_recipient_counts}
    */
    readonly includeRecipientCounts?: boolean | cdktn.IResolvable;
    /**
    * Include resources in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#include_resources DataCloudflareShare#include_resources}
    */
    readonly includeResources?: boolean | cdktn.IResolvable;
    /**
    * Share identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#share_id DataCloudflareShare#share_id}
    */
    readonly shareId?: string;
}
export interface DataCloudflareShareFilter {
    /**
    * Direction to sort objects.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#direction DataCloudflareShare#direction}
    */
    readonly direction?: string;
    /**
    * Filter shares by kind.
    * Available values: "sent", "received".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#kind DataCloudflareShare#kind}
    */
    readonly kind?: string;
    /**
    * Order shares by values in the given field.
    * Available values: "name", "created".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#order DataCloudflareShare#order}
    */
    readonly order?: string;
    /**
    * Filter share resources by resource_types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#resource_types DataCloudflareShare#resource_types}
    */
    readonly resourceTypes?: string[];
    /**
    * Filter shares by status.
    * Available values: "active", "deleting", "deleted".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#status DataCloudflareShare#status}
    */
    readonly status?: string;
    /**
    * Filter shares by tag. Each value is either `key=value` (matches shares whose tags contain that key/value pair) or `key` alone (matches shares that have any value for that key). May be repeated; multiple `tag` parameters are ANDed together. Maximum 20 `tag` parameters per request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#tag DataCloudflareShare#tag}
    */
    readonly tag?: string[];
    /**
    * Filter shares by target_type.
    * Available values: "account", "organization".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#target_type DataCloudflareShare#target_type}
    */
    readonly targetType?: string;
}
export declare function dataCloudflareShareFilterToTerraform(struct?: DataCloudflareShareFilter | cdktn.IResolvable): any;
export declare function dataCloudflareShareFilterToHclTerraform(struct?: DataCloudflareShareFilter | cdktn.IResolvable): any;
export declare class DataCloudflareShareFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareShareFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareShareFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tag?;
    get tag(): string[];
    set tag(value: string[]);
    resetTag(): void;
    get tagInput(): string[] | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
}
export interface DataCloudflareShareResources {
}
export declare function dataCloudflareShareResourcesToTerraform(struct?: DataCloudflareShareResources): any;
export declare function dataCloudflareShareResourcesToHclTerraform(struct?: DataCloudflareShareResources): any;
export declare class DataCloudflareShareResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareShareResources | undefined;
    set internalValue(value: DataCloudflareShareResources | undefined);
    get created(): string;
    get id(): string;
    get meta(): string;
    get modified(): string;
    get resourceAccountId(): string;
    get resourceId(): string;
    get resourceType(): string;
    get resourceVersion(): number;
    get status(): string;
}
export declare class DataCloudflareShareResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareShareResourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share cloudflare_share}
*/
export declare class DataCloudflareShare extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_share";
    /**
    * Generates CDKTN code for importing a DataCloudflareShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareShare to import
    * @param importFromId The id of the existing DataCloudflareShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share cloudflare_share} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareShareConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareShareConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get accountName(): string;
    get associatedRecipientCount(): number;
    get associatingRecipientCount(): number;
    get created(): string;
    get disassociatedRecipientCount(): number;
    get disassociatingRecipientCount(): number;
    private _filter;
    get filter(): DataCloudflareShareFilterOutputReference;
    putFilter(value: DataCloudflareShareFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareShareFilter | undefined;
    get id(): string;
    private _includeRecipientCounts?;
    get includeRecipientCounts(): boolean | cdktn.IResolvable;
    set includeRecipientCounts(value: boolean | cdktn.IResolvable);
    resetIncludeRecipientCounts(): void;
    get includeRecipientCountsInput(): boolean | cdktn.IResolvable | undefined;
    private _includeResources?;
    get includeResources(): boolean | cdktn.IResolvable;
    set includeResources(value: boolean | cdktn.IResolvable);
    resetIncludeResources(): void;
    get includeResourcesInput(): boolean | cdktn.IResolvable | undefined;
    get kind(): string;
    get modified(): string;
    get name(): string;
    get organizationId(): string;
    private _resources;
    get resources(): DataCloudflareShareResourcesList;
    private _shareId?;
    get shareId(): string;
    set shareId(value: string);
    resetShareId(): void;
    get shareIdInput(): string | undefined;
    get status(): string;
    get targetType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
