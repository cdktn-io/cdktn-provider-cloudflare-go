/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLogpushDatasetJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/logpush_dataset_job#account_id DataCloudflareLogpushDatasetJob#account_id}
    */
    readonly accountId?: string;
    /**
    * Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/).
    * Available values: "access_requests", "account_abuse_protection_events", "ai_gateway_events", "audit_logs", "audit_logs_v2", "biso_user_actions", "casb_findings", "device_posture_results", "dex_application_tests", "dex_device_state_events", "dlp_forensic_copies", "dns_firewall_logs", "dns_logs", "email_security_alerts", "email_security_post_delivery_events", "firewall_events", "gateway_dns", "gateway_http", "gateway_network", "http_requests", "ipsec_logs", "magic_bgp_logs", "magic_ids_detections", "mcp_portal_logs", "mnm_flow_logs", "nel_reports", "network_analytics_logs", "page_shield_events", "sinkhole_http_logs", "spectrum_events", "ssh_logs", "turnstile_events", "warp_config_changes", "warp_toggle_changes", "websocket_analytics", "workers_trace_events", "zaraz_events", "zero_trust_network_sessions".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/logpush_dataset_job#dataset_id DataCloudflareLogpushDatasetJob#dataset_id}
    */
    readonly datasetId?: string;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/logpush_dataset_job#zone_id DataCloudflareLogpushDatasetJob#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareLogpushDatasetJobOutputOptions {
}
export declare function dataCloudflareLogpushDatasetJobOutputOptionsToTerraform(struct?: DataCloudflareLogpushDatasetJobOutputOptions): any;
export declare function dataCloudflareLogpushDatasetJobOutputOptionsToHclTerraform(struct?: DataCloudflareLogpushDatasetJobOutputOptions): any;
export declare class DataCloudflareLogpushDatasetJobOutputOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLogpushDatasetJobOutputOptions | undefined;
    set internalValue(value: DataCloudflareLogpushDatasetJobOutputOptions | undefined);
    get batchPrefix(): string;
    get batchSuffix(): string;
    get cve202144228(): cdktn.IResolvable;
    get fieldDelimiter(): string;
    get fieldNames(): string[];
    get mergeSubrequests(): cdktn.IResolvable;
    get outputType(): string;
    get recordDelimiter(): string;
    get recordPrefix(): string;
    get recordSuffix(): string;
    get recordTemplate(): string;
    get sampleRate(): number;
    get timestampFormat(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/logpush_dataset_job cloudflare_logpush_dataset_job}
*/
export declare class DataCloudflareLogpushDatasetJob extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_logpush_dataset_job";
    /**
    * Generates CDKTN code for importing a DataCloudflareLogpushDatasetJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLogpushDatasetJob to import
    * @param importFromId The id of the existing DataCloudflareLogpushDatasetJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/logpush_dataset_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLogpushDatasetJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/logpush_dataset_job cloudflare_logpush_dataset_job} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLogpushDatasetJobConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareLogpushDatasetJobConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get dataset(): string;
    private _datasetId?;
    get datasetId(): string;
    set datasetId(value: string);
    resetDatasetId(): void;
    get datasetIdInput(): string | undefined;
    get destinationConf(): string;
    get enabled(): cdktn.IResolvable;
    get errorMessage(): string;
    get filterAttackTraffic(): cdktn.IResolvable;
    get frequency(): string;
    get id(): number;
    get kind(): string;
    get lastComplete(): string;
    get lastError(): string;
    get logpullOptions(): string;
    get maxUploadBytes(): number;
    get maxUploadIntervalSeconds(): number;
    get maxUploadRecords(): number;
    get name(): string;
    private _outputOptions;
    get outputOptions(): DataCloudflareLogpushDatasetJobOutputOptionsOutputReference;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
