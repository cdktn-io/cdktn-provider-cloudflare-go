/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DlsPrefixBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier of a Cloudflare account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/dls_prefix_binding#account_id DlsPrefixBinding#account_id}
    */
    readonly accountId: string;
    /**
    * IP prefix in CIDR notation to bind.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/dls_prefix_binding#cidr DlsPrefixBinding#cidr}
    */
    readonly cidr: string;
    /**
    * The ID of the parent IP prefix that contains the CIDR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/dls_prefix_binding#prefix_id DlsPrefixBinding#prefix_id}
    */
    readonly prefixId: string;
    /**
    * Region key from managed regions (e.g., "us", "eu").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/dls_prefix_binding#region_key DlsPrefixBinding#region_key}
    */
    readonly regionKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/dls_prefix_binding cloudflare_dls_prefix_binding}
*/
export declare class DlsPrefixBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_dls_prefix_binding";
    /**
    * Generates CDKTN code for importing a DlsPrefixBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DlsPrefixBinding to import
    * @param importFromId The id of the existing DlsPrefixBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/dls_prefix_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DlsPrefixBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/dls_prefix_binding cloudflare_dls_prefix_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DlsPrefixBindingConfig
    */
    constructor(scope: Construct, id: string, config: DlsPrefixBindingConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    get cidrInput(): string | undefined;
    get id(): string;
    private _prefixId?;
    get prefixId(): string;
    set prefixId(value: string);
    get prefixIdInput(): string | undefined;
    private _regionKey?;
    get regionKey(): string;
    set regionKey(value: string);
    get regionKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
