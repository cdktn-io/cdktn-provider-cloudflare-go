/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpCustomProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_dlp_custom_profile#account_id DataCloudflareZeroTrustDlpCustomProfile#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_dlp_custom_profile#profile_id DataCloudflareZeroTrustDlpCustomProfile#profile_id}
    */
    readonly profileId: string;
}
export interface DataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkip {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkipToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkip): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkipToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkip): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkip | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkip | undefined);
    get files(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpCustomProfileContextAwareness {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileContextAwarenessToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileContextAwareness): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileContextAwarenessToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileContextAwareness): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileContextAwarenessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileContextAwareness | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileContextAwareness | undefined);
    get enabled(): cdktn.IResolvable;
    private _skip;
    get skip(): DataCloudflareZeroTrustDlpCustomProfileContextAwarenessSkipOutputReference;
}
export interface DataCloudflareZeroTrustDlpCustomProfileEntriesConfidence {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntriesConfidence): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntriesConfidence): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileEntriesConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileEntriesConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileEntriesConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpCustomProfileEntriesPattern {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesPatternToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntriesPattern): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntriesPattern): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileEntriesPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileEntriesPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileEntriesPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpCustomProfileEntriesVariant {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesVariantToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntriesVariant): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntriesVariant): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileEntriesVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileEntriesVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileEntriesVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
export interface DataCloudflareZeroTrustDlpCustomProfileEntries {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntries): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileEntriesToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileEntries): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileEntries | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileEntries | undefined);
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpCustomProfileEntriesConfidenceOutputReference;
    get createdAt(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpCustomProfileEntriesPatternOutputReference;
    get profileId(): string;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpCustomProfileEntriesVariantOutputReference;
    get wordList(): string;
}
export declare class DataCloudflareZeroTrustDlpCustomProfileEntriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpCustomProfileEntriesOutputReference;
}
export interface DataCloudflareZeroTrustDlpCustomProfileSensitivityLevels {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileSensitivityLevelsToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSensitivityLevels): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileSensitivityLevelsToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSensitivityLevels): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileSensitivityLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileSensitivityLevels | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileSensitivityLevels | undefined);
    get groupId(): string;
    get levelId(): string;
}
export declare class DataCloudflareZeroTrustDlpCustomProfileSensitivityLevelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpCustomProfileSensitivityLevelsOutputReference;
}
export interface DataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidence {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidence): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidence): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpCustomProfileSharedEntriesPattern {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesPatternToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesPattern): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesPattern): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileSharedEntriesPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariant {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariantToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariant): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariant): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
export interface DataCloudflareZeroTrustDlpCustomProfileSharedEntries {
}
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesToTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntries): any;
export declare function dataCloudflareZeroTrustDlpCustomProfileSharedEntriesToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomProfileSharedEntries): any;
export declare class DataCloudflareZeroTrustDlpCustomProfileSharedEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpCustomProfileSharedEntries | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomProfileSharedEntries | undefined);
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesConfidenceOutputReference;
    get createdAt(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesPatternOutputReference;
    get profileId(): string;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesVariantOutputReference;
    get wordList(): string;
}
export declare class DataCloudflareZeroTrustDlpCustomProfileSharedEntriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_dlp_custom_profile cloudflare_zero_trust_dlp_custom_profile}
*/
export declare class DataCloudflareZeroTrustDlpCustomProfile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_custom_profile";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpCustomProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpCustomProfile to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpCustomProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_dlp_custom_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpCustomProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_dlp_custom_profile cloudflare_zero_trust_dlp_custom_profile} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpCustomProfileConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpCustomProfileConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get aiContextEnabled(): cdktn.IResolvable;
    get allowedMatchCount(): number;
    get confidenceThreshold(): string;
    private _contextAwareness;
    get contextAwareness(): DataCloudflareZeroTrustDlpCustomProfileContextAwarenessOutputReference;
    get createdAt(): string;
    get dataClasses(): string[];
    get dataTags(): string[];
    get description(): string;
    private _entries;
    get entries(): DataCloudflareZeroTrustDlpCustomProfileEntriesList;
    get id(): string;
    get name(): string;
    get ocrEnabled(): cdktn.IResolvable;
    get openAccess(): cdktn.IResolvable;
    private _profileId?;
    get profileId(): string;
    set profileId(value: string);
    get profileIdInput(): string | undefined;
    private _sensitivityLevels;
    get sensitivityLevels(): DataCloudflareZeroTrustDlpCustomProfileSensitivityLevelsList;
    private _sharedEntries;
    get sharedEntries(): DataCloudflareZeroTrustDlpCustomProfileSharedEntriesList;
    get type(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
