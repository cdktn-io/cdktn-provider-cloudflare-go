/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MagicTransitSiteAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#account_id MagicTransitSiteAcl#account_id}
    */
    readonly accountId: string;
    /**
    * Description for the ACL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#description MagicTransitSiteAcl#description}
    */
    readonly description?: string;
    /**
    * The desired forwarding action for this ACL policy. If set to "false", the policy will forward traffic to Cloudflare. If set to "true", the policy will forward traffic locally on the Magic Connector. If not included in request, will default to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#forward_locally MagicTransitSiteAcl#forward_locally}
    */
    readonly forwardLocally?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#lan_1 MagicTransitSiteAcl#lan_1}
    */
    readonly lan1: MagicTransitSiteAclLan1;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#lan_2 MagicTransitSiteAcl#lan_2}
    */
    readonly lan2: MagicTransitSiteAclLan2;
    /**
    * The name of the ACL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#name MagicTransitSiteAcl#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#protocols MagicTransitSiteAcl#protocols}
    */
    readonly protocols?: string[];
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#site_id MagicTransitSiteAcl#site_id}
    */
    readonly siteId: string;
    /**
    * The desired traffic direction for this ACL policy. If set to "false", the policy will allow bidirectional traffic. If set to "true", the policy will only allow traffic in one direction. If not included in request, will default to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#unidirectional MagicTransitSiteAcl#unidirectional}
    */
    readonly unidirectional?: boolean | cdktn.IResolvable;
}
export interface MagicTransitSiteAclLan1 {
    /**
    * The identifier for the LAN you want to create an ACL policy with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#lan_id MagicTransitSiteAcl#lan_id}
    */
    readonly lanId: string;
    /**
    * The name of the LAN based on the provided lan_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#lan_name MagicTransitSiteAcl#lan_name}
    */
    readonly lanName?: string;
    /**
    * Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#port_ranges MagicTransitSiteAcl#port_ranges}
    */
    readonly portRanges?: string[];
    /**
    * Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#ports MagicTransitSiteAcl#ports}
    */
    readonly ports?: number[];
    /**
    * Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#subnets MagicTransitSiteAcl#subnets}
    */
    readonly subnets?: string[];
}
export declare function magicTransitSiteAclLan1ToTerraform(struct?: MagicTransitSiteAclLan1 | cdktn.IResolvable): any;
export declare function magicTransitSiteAclLan1ToHclTerraform(struct?: MagicTransitSiteAclLan1 | cdktn.IResolvable): any;
export declare class MagicTransitSiteAclLan1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteAclLan1 | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteAclLan1 | cdktn.IResolvable | undefined);
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
    private _lanName?;
    get lanName(): string;
    set lanName(value: string);
    resetLanName(): void;
    get lanNameInput(): string | undefined;
    private _portRanges?;
    get portRanges(): string[];
    set portRanges(value: string[]);
    resetPortRanges(): void;
    get portRangesInput(): string[] | undefined;
    private _ports?;
    get ports(): number[];
    set ports(value: number[]);
    resetPorts(): void;
    get portsInput(): number[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
export interface MagicTransitSiteAclLan2 {
    /**
    * The identifier for the LAN you want to create an ACL policy with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#lan_id MagicTransitSiteAcl#lan_id}
    */
    readonly lanId: string;
    /**
    * The name of the LAN based on the provided lan_id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#lan_name MagicTransitSiteAcl#lan_name}
    */
    readonly lanName?: string;
    /**
    * Array of port ranges on the provided LAN that will be included in the ACL. If no ports or port rangess are provided, communication on any port on this LAN is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#port_ranges MagicTransitSiteAcl#port_ranges}
    */
    readonly portRanges?: string[];
    /**
    * Array of ports on the provided LAN that will be included in the ACL. If no ports or port ranges are provided, communication on any port on this LAN is allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#ports MagicTransitSiteAcl#ports}
    */
    readonly ports?: number[];
    /**
    * Array of subnet IPs within the LAN that will be included in the ACL. If no subnets are provided, communication on any subnets on this LAN are allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#subnets MagicTransitSiteAcl#subnets}
    */
    readonly subnets?: string[];
}
export declare function magicTransitSiteAclLan2ToTerraform(struct?: MagicTransitSiteAclLan2 | cdktn.IResolvable): any;
export declare function magicTransitSiteAclLan2ToHclTerraform(struct?: MagicTransitSiteAclLan2 | cdktn.IResolvable): any;
export declare class MagicTransitSiteAclLan2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteAclLan2 | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteAclLan2 | cdktn.IResolvable | undefined);
    private _lanId?;
    get lanId(): string;
    set lanId(value: string);
    get lanIdInput(): string | undefined;
    private _lanName?;
    get lanName(): string;
    set lanName(value: string);
    resetLanName(): void;
    get lanNameInput(): string | undefined;
    private _portRanges?;
    get portRanges(): string[];
    set portRanges(value: string[]);
    resetPortRanges(): void;
    get portRangesInput(): string[] | undefined;
    private _ports?;
    get ports(): number[];
    set ports(value: number[]);
    resetPorts(): void;
    get portsInput(): number[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl cloudflare_magic_transit_site_acl}
*/
export declare class MagicTransitSiteAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_magic_transit_site_acl";
    /**
    * Generates CDKTN code for importing a MagicTransitSiteAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MagicTransitSiteAcl to import
    * @param importFromId The id of the existing MagicTransitSiteAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MagicTransitSiteAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site_acl cloudflare_magic_transit_site_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MagicTransitSiteAclConfig
    */
    constructor(scope: Construct, id: string, config: MagicTransitSiteAclConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forwardLocally?;
    get forwardLocally(): boolean | cdktn.IResolvable;
    set forwardLocally(value: boolean | cdktn.IResolvable);
    resetForwardLocally(): void;
    get forwardLocallyInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _lan1;
    get lan1(): MagicTransitSiteAclLan1OutputReference;
    putLan1(value: MagicTransitSiteAclLan1): void;
    get lan1Input(): cdktn.IResolvable | MagicTransitSiteAclLan1 | undefined;
    private _lan2;
    get lan2(): MagicTransitSiteAclLan2OutputReference;
    putLan2(value: MagicTransitSiteAclLan2): void;
    get lan2Input(): cdktn.IResolvable | MagicTransitSiteAclLan2 | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protocols?;
    get protocols(): string[];
    set protocols(value: string[]);
    resetProtocols(): void;
    get protocolsInput(): string[] | undefined;
    private _siteId?;
    get siteId(): string;
    set siteId(value: string);
    get siteIdInput(): string | undefined;
    private _unidirectional?;
    get unidirectional(): boolean | cdktn.IResolvable;
    set unidirectional(value: boolean | cdktn.IResolvable);
    resetUnidirectional(): void;
    get unidirectionalInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
