/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDeviceDeploymentGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups#account_id DataCloudflareZeroTrustDeviceDeploymentGroups#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups#group_id DataCloudflareZeroTrustDeviceDeploymentGroups#group_id}
    */
    readonly groupId: string;
}
export interface DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfig {
}
export declare function dataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfigToTerraform(struct?: DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfig): any;
export declare function dataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfigToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfig): any;
export declare class DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfig | undefined);
    get targetEnvironment(): string;
    get version(): string;
}
export declare class DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups cloudflare_zero_trust_device_deployment_groups}
*/
export declare class DataCloudflareZeroTrustDeviceDeploymentGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_deployment_groups";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDeviceDeploymentGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDeviceDeploymentGroups to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDeviceDeploymentGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDeviceDeploymentGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups cloudflare_zero_trust_device_deployment_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDeviceDeploymentGroupsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDeviceDeploymentGroupsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    get policyIds(): string[];
    get updatedAt(): string;
    private _versionConfig;
    get versionConfig(): DataCloudflareZeroTrustDeviceDeploymentGroupsVersionConfigList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
