/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCloudConnectorRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/cloud_connector_rules#zone_id DataCloudflareCloudConnectorRules#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflareCloudConnectorRulesParameters {
}
export declare function dataCloudflareCloudConnectorRulesParametersToTerraform(struct?: DataCloudflareCloudConnectorRulesParameters): any;
export declare function dataCloudflareCloudConnectorRulesParametersToHclTerraform(struct?: DataCloudflareCloudConnectorRulesParameters): any;
export declare class DataCloudflareCloudConnectorRulesParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCloudConnectorRulesParameters | undefined;
    set internalValue(value: DataCloudflareCloudConnectorRulesParameters | undefined);
    get host(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/cloud_connector_rules cloudflare_cloud_connector_rules}
*/
export declare class DataCloudflareCloudConnectorRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_cloud_connector_rules";
    /**
    * Generates CDKTN code for importing a DataCloudflareCloudConnectorRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCloudConnectorRules to import
    * @param importFromId The id of the existing DataCloudflareCloudConnectorRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/cloud_connector_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCloudConnectorRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/cloud_connector_rules cloudflare_cloud_connector_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCloudConnectorRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareCloudConnectorRulesConfig);
    get cloudConnectorRulesProvider(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expression(): string;
    get id(): string;
    private _parameters;
    get parameters(): DataCloudflareCloudConnectorRulesParametersOutputReference;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
