/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkersCustomDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#account_id DataCloudflareWorkersCustomDomain#account_id}
    */
    readonly accountId?: string;
    /**
    * ID of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#domain_id DataCloudflareWorkersCustomDomain#domain_id}
    */
    readonly domainId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#filter DataCloudflareWorkersCustomDomain#filter}
    */
    readonly filter?: DataCloudflareWorkersCustomDomainFilter;
}
export interface DataCloudflareWorkersCustomDomainFilter {
    /**
    * Worker environment associated with the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#environment DataCloudflareWorkersCustomDomain#environment}
    */
    readonly environment?: string;
    /**
    * Hostname of the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#hostname DataCloudflareWorkersCustomDomain#hostname}
    */
    readonly hostname?: string;
    /**
    * Name of the Worker associated with the domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#service DataCloudflareWorkersCustomDomain#service}
    */
    readonly service?: string;
    /**
    * ID of the zone containing the domain hostname.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#zone_id DataCloudflareWorkersCustomDomain#zone_id}
    */
    readonly zoneId?: string;
    /**
    * Name of the zone containing the domain hostname.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#zone_name DataCloudflareWorkersCustomDomain#zone_name}
    */
    readonly zoneName?: string;
}
export declare function dataCloudflareWorkersCustomDomainFilterToTerraform(struct?: DataCloudflareWorkersCustomDomainFilter | cdktn.IResolvable): any;
export declare function dataCloudflareWorkersCustomDomainFilterToHclTerraform(struct?: DataCloudflareWorkersCustomDomainFilter | cdktn.IResolvable): any;
export declare class DataCloudflareWorkersCustomDomainFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersCustomDomainFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareWorkersCustomDomainFilter | cdktn.IResolvable | undefined);
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    private _zoneName?;
    get zoneName(): string;
    set zoneName(value: string);
    resetZoneName(): void;
    get zoneNameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain cloudflare_workers_custom_domain}
*/
export declare class DataCloudflareWorkersCustomDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_workers_custom_domain";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkersCustomDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkersCustomDomain to import
    * @param importFromId The id of the existing DataCloudflareWorkersCustomDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkersCustomDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/workers_custom_domain cloudflare_workers_custom_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkersCustomDomainConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWorkersCustomDomainConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get certId(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    resetDomainId(): void;
    get domainIdInput(): string | undefined;
    get environment(): string;
    private _filter;
    get filter(): DataCloudflareWorkersCustomDomainFilterOutputReference;
    putFilter(value: DataCloudflareWorkersCustomDomainFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareWorkersCustomDomainFilter | undefined;
    get hostname(): string;
    get id(): string;
    get service(): string;
    get zoneId(): string;
    get zoneName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
