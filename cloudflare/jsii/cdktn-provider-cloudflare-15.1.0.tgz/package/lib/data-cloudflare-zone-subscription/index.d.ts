/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZoneSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zone_subscription#zone_id DataCloudflareZoneSubscription#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareZoneSubscriptionRatePlan {
}
export declare function dataCloudflareZoneSubscriptionRatePlanToTerraform(struct?: DataCloudflareZoneSubscriptionRatePlan): any;
export declare function dataCloudflareZoneSubscriptionRatePlanToHclTerraform(struct?: DataCloudflareZoneSubscriptionRatePlan): any;
export declare class DataCloudflareZoneSubscriptionRatePlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneSubscriptionRatePlan | undefined;
    set internalValue(value: DataCloudflareZoneSubscriptionRatePlan | undefined);
    get currency(): string;
    get externallyManaged(): cdktn.IResolvable;
    get id(): string;
    get isContract(): cdktn.IResolvable;
    get publicName(): string;
    get scope(): string;
    get sets(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zone_subscription cloudflare_zone_subscription}
*/
export declare class DataCloudflareZoneSubscription extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zone_subscription";
    /**
    * Generates CDKTN code for importing a DataCloudflareZoneSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZoneSubscription to import
    * @param importFromId The id of the existing DataCloudflareZoneSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zone_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZoneSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zone_subscription cloudflare_zone_subscription} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZoneSubscriptionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZoneSubscriptionConfig);
    get currency(): string;
    get currentPeriodEnd(): string;
    get currentPeriodStart(): string;
    get frequency(): string;
    get id(): string;
    get price(): number;
    private _ratePlan;
    get ratePlan(): DataCloudflareZoneSubscriptionRatePlanOutputReference;
    get state(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
