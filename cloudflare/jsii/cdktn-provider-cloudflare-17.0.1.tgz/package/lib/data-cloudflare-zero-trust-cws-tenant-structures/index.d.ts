/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsTenantStructuresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures#account_id DataCloudflareZeroTrustCwsTenantStructures#account_id}
    */
    readonly accountId: string;
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures#direction DataCloudflareZeroTrustCwsTenantStructures#direction}
    */
    readonly direction?: string;
    /**
    * Filter by import path (case-sensitive literal substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures#import_path DataCloudflareZeroTrustCwsTenantStructures#import_path}
    */
    readonly importPath?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures#max_items DataCloudflareZeroTrustCwsTenantStructures#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter by tenant structure name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures#name DataCloudflareZeroTrustCwsTenantStructures#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures#order DataCloudflareZeroTrustCwsTenantStructures#order}
    */
    readonly order?: string;
}
export interface DataCloudflareZeroTrustCwsTenantStructuresResult {
}
export declare function dataCloudflareZeroTrustCwsTenantStructuresResultToTerraform(struct?: DataCloudflareZeroTrustCwsTenantStructuresResult): any;
export declare function dataCloudflareZeroTrustCwsTenantStructuresResultToHclTerraform(struct?: DataCloudflareZeroTrustCwsTenantStructuresResult): any;
export declare class DataCloudflareZeroTrustCwsTenantStructuresResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCwsTenantStructuresResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsTenantStructuresResult | undefined);
    get application(): string;
    get createdAt(): string;
    get id(): string;
    get importPath(): string;
    get name(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustCwsTenantStructuresResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCwsTenantStructuresResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures cloudflare_zero_trust_cws_tenant_structures}
*/
export declare class DataCloudflareZeroTrustCwsTenantStructures extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_tenant_structures";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsTenantStructures resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsTenantStructures to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsTenantStructures that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsTenantStructures to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_tenant_structures cloudflare_zero_trust_cws_tenant_structures} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsTenantStructuresConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsTenantStructuresConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _importPath?;
    get importPath(): string;
    set importPath(value: string);
    resetImportPath(): void;
    get importPathInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCwsTenantStructuresResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
