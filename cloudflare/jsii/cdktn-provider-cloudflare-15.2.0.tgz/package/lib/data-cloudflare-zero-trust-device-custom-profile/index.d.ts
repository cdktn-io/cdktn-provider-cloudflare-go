/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDeviceCustomProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_custom_profile#account_id DataCloudflareZeroTrustDeviceCustomProfile#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_custom_profile#policy_id DataCloudflareZeroTrustDeviceCustomProfile#policy_id}
    */
    readonly policyId: string;
}
export interface DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixes {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixesToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixes): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixesToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixes): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixes | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixes | undefined);
    get description(): string;
    get suffix(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixesOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfileExclude {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfileExcludeToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileExclude): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfileExcludeToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileExclude): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfileExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfileExclude | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfileExclude | undefined);
    get address(): string;
    get description(): string;
    get host(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfileExcludeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfileExcludeOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfileFallbackDomains {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfileFallbackDomainsToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileFallbackDomains): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfileFallbackDomainsToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileFallbackDomains): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfileFallbackDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfileFallbackDomains | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfileFallbackDomains | undefined);
    get description(): string;
    get dnsServer(): string[];
    get suffix(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfileFallbackDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfileFallbackDomainsOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfileInclude {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfileIncludeToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileInclude): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfileIncludeToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileInclude): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfileIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfileInclude | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfileInclude | undefined);
    get address(): string;
    get description(): string;
    get host(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfileIncludeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfileIncludeOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfileServiceModeV2 {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfileServiceModeV2ToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileServiceModeV2): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfileServiceModeV2ToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileServiceModeV2): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfileServiceModeV2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfileServiceModeV2 | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfileServiceModeV2 | undefined);
    get mode(): string;
    get port(): number;
}
export interface DataCloudflareZeroTrustDeviceCustomProfileTargetTests {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfileTargetTestsToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileTargetTests): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfileTargetTestsToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileTargetTests): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfileTargetTestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfileTargetTests | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfileTargetTests | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfileTargetTestsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfileTargetTestsOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfileVirtualNetworks {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfileVirtualNetworksToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileVirtualNetworks): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfileVirtualNetworksToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfileVirtualNetworks): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfileVirtualNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfileVirtualNetworks | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfileVirtualNetworks | undefined);
    get allowed(): string[];
    get default(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_custom_profile cloudflare_zero_trust_device_custom_profile}
*/
export declare class DataCloudflareZeroTrustDeviceCustomProfile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_custom_profile";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDeviceCustomProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDeviceCustomProfile to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDeviceCustomProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_custom_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDeviceCustomProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_custom_profile cloudflare_zero_trust_device_custom_profile} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDeviceCustomProfileConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDeviceCustomProfileConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get allowModeSwitch(): cdktn.IResolvable;
    get allowUpdates(): cdktn.IResolvable;
    get allowedToLeave(): cdktn.IResolvable;
    get autoConnect(): number;
    get captivePortal(): number;
    get default(): cdktn.IResolvable;
    get description(): string;
    get disableAutoFallback(): cdktn.IResolvable;
    private _dnsSearchSuffixes;
    get dnsSearchSuffixes(): DataCloudflareZeroTrustDeviceCustomProfileDnsSearchSuffixesList;
    get enabled(): cdktn.IResolvable;
    private _exclude;
    get exclude(): DataCloudflareZeroTrustDeviceCustomProfileExcludeList;
    get excludeOfficeIps(): cdktn.IResolvable;
    private _fallbackDomains;
    get fallbackDomains(): DataCloudflareZeroTrustDeviceCustomProfileFallbackDomainsList;
    get gatewayUniqueId(): string;
    get id(): string;
    private _include;
    get include(): DataCloudflareZeroTrustDeviceCustomProfileIncludeList;
    get lanAllowMinutes(): number;
    get lanAllowSubnetSize(): number;
    get match(): string;
    get name(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    get precedence(): number;
    get registerInterfaceIpWithDns(): cdktn.IResolvable;
    get sccmVpnBoundarySupport(): cdktn.IResolvable;
    private _serviceModeV2;
    get serviceModeV2(): DataCloudflareZeroTrustDeviceCustomProfileServiceModeV2OutputReference;
    get supportUrl(): string;
    get switchLocked(): cdktn.IResolvable;
    private _targetTests;
    get targetTests(): DataCloudflareZeroTrustDeviceCustomProfileTargetTestsList;
    get tunnelProtocol(): string;
    private _virtualNetworks;
    get virtualNetworks(): DataCloudflareZeroTrustDeviceCustomProfileVirtualNetworksOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
