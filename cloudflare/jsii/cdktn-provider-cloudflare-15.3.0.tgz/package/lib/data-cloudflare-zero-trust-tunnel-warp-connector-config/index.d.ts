/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustTunnelWarpConnectorConfigAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_tunnel_warp_connector_config#account_id DataCloudflareZeroTrustTunnelWarpConnectorConfigA#account_id}
    */
    readonly accountId: string;
    /**
    * UUID of the tunnel.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_tunnel_warp_connector_config#tunnel_id DataCloudflareZeroTrustTunnelWarpConnectorConfigA#tunnel_id}
    */
    readonly tunnelId: string;
}
export interface DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVips {
}
export declare function dataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsToTerraform(struct?: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVips): any;
export declare function dataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsToHclTerraform(struct?: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVips): any;
export declare class DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVips | undefined;
    set internalValue(value: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVips | undefined);
    get address(): string;
}
export declare class DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsOutputReference;
}
export interface DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPrevious {
}
export declare function dataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPreviousToTerraform(struct?: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPrevious): any;
export declare function dataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPreviousToHclTerraform(struct?: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPrevious): any;
export declare class DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPreviousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPrevious | undefined;
    set internalValue(value: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPrevious | undefined);
    get address(): string;
}
export declare class DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPreviousList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPreviousOutputReference;
}
export interface DataCloudflareZeroTrustTunnelWarpConnectorConfigConfig {
}
export declare function dataCloudflareZeroTrustTunnelWarpConnectorConfigConfigToTerraform(struct?: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfig): any;
export declare function dataCloudflareZeroTrustTunnelWarpConnectorConfigConfigToHclTerraform(struct?: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfig): any;
export declare class DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustTunnelWarpConnectorConfigConfig | undefined);
    get fnrId(): string;
    private _vips;
    get vips(): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsList;
    private _vipsPrevious;
    get vipsPrevious(): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigVipsPreviousList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_tunnel_warp_connector_config cloudflare_zero_trust_tunnel_warp_connector_config}
*/
export declare class DataCloudflareZeroTrustTunnelWarpConnectorConfigA extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_tunnel_warp_connector_config";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustTunnelWarpConnectorConfigA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustTunnelWarpConnectorConfigA to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustTunnelWarpConnectorConfigA that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_tunnel_warp_connector_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustTunnelWarpConnectorConfigA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_tunnel_warp_connector_config cloudflare_zero_trust_tunnel_warp_connector_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustTunnelWarpConnectorConfigAConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustTunnelWarpConnectorConfigAConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _config;
    get config(): DataCloudflareZeroTrustTunnelWarpConnectorConfigConfigOutputReference;
    get configurationVersion(): number;
    get createdAt(): string;
    get haMode(): string;
    private _tunnelId?;
    get tunnelId(): string;
    set tunnelId(value: string);
    get tunnelIdInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
