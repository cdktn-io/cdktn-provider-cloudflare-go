/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustGatewayProxyEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specify the Cloudflare account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#account_id DataCloudflareZeroTrustGatewayProxyEndpoint#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#filter DataCloudflareZeroTrustGatewayProxyEndpoint#filter}
    */
    readonly filter?: DataCloudflareZeroTrustGatewayProxyEndpointFilter;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#proxy_endpoint_id DataCloudflareZeroTrustGatewayProxyEndpoint#proxy_endpoint_id}
    */
    readonly proxyEndpointId?: string;
}
export interface DataCloudflareZeroTrustGatewayProxyEndpointFilter {
    /**
    * Sort direction. Only takes effect when `order_by` is also provided; it
    * is ignored otherwise. When `direction` is omitted the effective
    * direction is field-specific: `created_at` and `updated_at` default to
    * descending (newest first); `name` defaults to ascending.
    *   * `asc` — ascending.
    *   * `desc` — descending.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#direction DataCloudflareZeroTrustGatewayProxyEndpoint#direction}
    */
    readonly direction?: string;
    /**
    * Filter the returned proxy endpoints by one or more `field:value` pairs.
    * Repeat the parameter to apply multiple filters; they are combined with
    * logical AND (an endpoint must satisfy every filter to be returned).
    *
    * Supported fields and their matching behaviour:
    *   * `name` — case-insensitive substring match on the endpoint name.
    *   * `id` — substring match on the endpoint ID (UUID), with or without dashes.
    *   * `kind` — exact match on the endpoint kind. The value must be `ip` or `identity`; any other value returns `400`.
    *
    * Each entry must match one of the per-field patterns below: the field
    * must be one of `name`, `id`, or `kind`; `name`/`id` accept any value,
    * while `kind` only accepts `ip` or `identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#filter DataCloudflareZeroTrustGatewayProxyEndpoint#filter}
    */
    readonly filter?: string[];
    /**
    * Field to sort the returned endpoints by. When omitted, the order of
    * results is unspecified. Supported values:
    *   * `name` — sort alphabetically by endpoint name.
    *   * `created_at` — sort by creation time; defaults to descending unless `direction` is set.
    *   * `updated_at` — sort by last-modified time; defaults to descending unless `direction` is set.
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#order_by DataCloudflareZeroTrustGatewayProxyEndpoint#order_by}
    */
    readonly orderBy?: string;
    /**
    * Case-insensitive substring match on the endpoint name. When combined
    * with `filter`, both must match (logical AND).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#search DataCloudflareZeroTrustGatewayProxyEndpoint#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareZeroTrustGatewayProxyEndpointFilterToTerraform(struct?: DataCloudflareZeroTrustGatewayProxyEndpointFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustGatewayProxyEndpointFilterToHclTerraform(struct?: DataCloudflareZeroTrustGatewayProxyEndpointFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustGatewayProxyEndpointFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayProxyEndpointFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayProxyEndpointFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _filter?;
    get filter(): string[];
    set filter(value: string[]);
    resetFilter(): void;
    get filterInput(): string[] | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint cloudflare_zero_trust_gateway_proxy_endpoint}
*/
export declare class DataCloudflareZeroTrustGatewayProxyEndpoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_gateway_proxy_endpoint";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustGatewayProxyEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustGatewayProxyEndpoint to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustGatewayProxyEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustGatewayProxyEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_gateway_proxy_endpoint cloudflare_zero_trust_gateway_proxy_endpoint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustGatewayProxyEndpointConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustGatewayProxyEndpointConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    private _filter;
    get filter(): DataCloudflareZeroTrustGatewayProxyEndpointFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustGatewayProxyEndpointFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustGatewayProxyEndpointFilter | undefined;
    get id(): string;
    get ips(): string[];
    get kind(): string;
    get name(): string;
    private _proxyEndpointId?;
    get proxyEndpointId(): string;
    set proxyEndpointId(value: string);
    resetProxyEndpointId(): void;
    get proxyEndpointIdInput(): string | undefined;
    get subdomain(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
