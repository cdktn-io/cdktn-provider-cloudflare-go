/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkflowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/workflow#account_id DataCloudflareWorkflow#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/workflow#filter DataCloudflareWorkflow#filter}
    */
    readonly filter?: DataCloudflareWorkflowFilter;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/workflow#workflow_name DataCloudflareWorkflow#workflow_name}
    */
    readonly workflowName?: string;
}
export interface DataCloudflareWorkflowFilter {
    /**
    * Allows filtering workflows` name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/workflow#search DataCloudflareWorkflow#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareWorkflowFilterToTerraform(struct?: DataCloudflareWorkflowFilter | cdktn.IResolvable): any;
export declare function dataCloudflareWorkflowFilterToHclTerraform(struct?: DataCloudflareWorkflowFilter | cdktn.IResolvable): any;
export declare class DataCloudflareWorkflowFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkflowFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareWorkflowFilter | cdktn.IResolvable | undefined);
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
export interface DataCloudflareWorkflowInstances {
}
export declare function dataCloudflareWorkflowInstancesToTerraform(struct?: DataCloudflareWorkflowInstances): any;
export declare function dataCloudflareWorkflowInstancesToHclTerraform(struct?: DataCloudflareWorkflowInstances): any;
export declare class DataCloudflareWorkflowInstancesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkflowInstances | undefined;
    set internalValue(value: DataCloudflareWorkflowInstances | undefined);
    get complete(): number;
    get errored(): number;
    get paused(): number;
    get queued(): number;
    get rollingBack(): number;
    get running(): number;
    get terminated(): number;
    get waiting(): number;
    get waitingForPause(): number;
}
export interface DataCloudflareWorkflowSchedules {
}
export declare function dataCloudflareWorkflowSchedulesToTerraform(struct?: DataCloudflareWorkflowSchedules): any;
export declare function dataCloudflareWorkflowSchedulesToHclTerraform(struct?: DataCloudflareWorkflowSchedules): any;
export declare class DataCloudflareWorkflowSchedulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkflowSchedules | undefined;
    set internalValue(value: DataCloudflareWorkflowSchedules | undefined);
    get cron(): string;
    get nextInstance(): string;
}
export declare class DataCloudflareWorkflowSchedulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkflowSchedulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/workflow cloudflare_workflow}
*/
export declare class DataCloudflareWorkflow extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_workflow";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkflow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkflow to import
    * @param importFromId The id of the existing DataCloudflareWorkflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/workflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/workflow cloudflare_workflow} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkflowConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWorkflowConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get className(): string;
    get createdOn(): string;
    private _filter;
    get filter(): DataCloudflareWorkflowFilterOutputReference;
    putFilter(value: DataCloudflareWorkflowFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareWorkflowFilter | undefined;
    get id(): string;
    private _instances;
    get instances(): DataCloudflareWorkflowInstancesOutputReference;
    get modifiedOn(): string;
    get name(): string;
    private _schedules;
    get schedules(): DataCloudflareWorkflowSchedulesList;
    get scriptName(): string;
    get triggeredOn(): string;
    private _workflowName?;
    get workflowName(): string;
    set workflowName(value: string);
    resetWorkflowName(): void;
    get workflowNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
