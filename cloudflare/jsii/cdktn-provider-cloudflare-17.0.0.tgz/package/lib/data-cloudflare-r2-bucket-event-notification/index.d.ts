/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareR2BucketEventNotificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID that owns the R2 resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/r2_bucket_event_notification#account_id DataCloudflareR2BucketEventNotification#account_id}
    */
    readonly accountId: string;
    /**
    * Name of the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/r2_bucket_event_notification#bucket_name DataCloudflareR2BucketEventNotification#bucket_name}
    */
    readonly bucketName: string;
    /**
    * ID of the Cloudflare Queue that receives notifications for matching R2 object events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/r2_bucket_event_notification#queue_id DataCloudflareR2BucketEventNotification#queue_id}
    */
    readonly queueId: string;
}
export interface DataCloudflareR2BucketEventNotificationRules {
}
export declare function dataCloudflareR2BucketEventNotificationRulesToTerraform(struct?: DataCloudflareR2BucketEventNotificationRules): any;
export declare function dataCloudflareR2BucketEventNotificationRulesToHclTerraform(struct?: DataCloudflareR2BucketEventNotificationRules): any;
export declare class DataCloudflareR2BucketEventNotificationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareR2BucketEventNotificationRules | undefined;
    set internalValue(value: DataCloudflareR2BucketEventNotificationRules | undefined);
    get actions(): string[];
    get createdAt(): string;
    get description(): string;
    get prefix(): string;
    get ruleId(): string;
    get suffix(): string;
}
export declare class DataCloudflareR2BucketEventNotificationRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareR2BucketEventNotificationRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/r2_bucket_event_notification cloudflare_r2_bucket_event_notification}
*/
export declare class DataCloudflareR2BucketEventNotification extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_r2_bucket_event_notification";
    /**
    * Generates CDKTN code for importing a DataCloudflareR2BucketEventNotification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareR2BucketEventNotification to import
    * @param importFromId The id of the existing DataCloudflareR2BucketEventNotification that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/r2_bucket_event_notification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareR2BucketEventNotification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/r2_bucket_event_notification cloudflare_r2_bucket_event_notification} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareR2BucketEventNotificationConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareR2BucketEventNotificationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _queueId?;
    get queueId(): string;
    set queueId(value: string);
    get queueIdInput(): string | undefined;
    get queueName(): string;
    private _rules;
    get rules(): DataCloudflareR2BucketEventNotificationRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
