/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareShareRecipientConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/share_recipient#account_id DataCloudflareShareRecipient#account_id}
    */
    readonly accountId: string;
    /**
    * Include resources in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/share_recipient#include_resources DataCloudflareShareRecipient#include_resources}
    */
    readonly includeResources?: boolean | cdktn.IResolvable;
    /**
    * Share Recipient identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/share_recipient#recipient_id DataCloudflareShareRecipient#recipient_id}
    */
    readonly recipientId: string;
    /**
    * Share identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/share_recipient#share_id DataCloudflareShareRecipient#share_id}
    */
    readonly shareId: string;
}
export interface DataCloudflareShareRecipientResources {
}
export declare function dataCloudflareShareRecipientResourcesToTerraform(struct?: DataCloudflareShareRecipientResources): any;
export declare function dataCloudflareShareRecipientResourcesToHclTerraform(struct?: DataCloudflareShareRecipientResources): any;
export declare class DataCloudflareShareRecipientResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareShareRecipientResources | undefined;
    set internalValue(value: DataCloudflareShareRecipientResources | undefined);
    get error(): string;
    get resourceId(): string;
    get resourceVersion(): number;
    get terminal(): cdktn.IResolvable;
}
export declare class DataCloudflareShareRecipientResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareShareRecipientResourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/share_recipient cloudflare_share_recipient}
*/
export declare class DataCloudflareShareRecipient extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_share_recipient";
    /**
    * Generates CDKTN code for importing a DataCloudflareShareRecipient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareShareRecipient to import
    * @param importFromId The id of the existing DataCloudflareShareRecipient that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/share_recipient#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareShareRecipient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/share_recipient cloudflare_share_recipient} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareShareRecipientConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareShareRecipientConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get associationStatus(): string;
    get created(): string;
    get id(): string;
    private _includeResources?;
    get includeResources(): boolean | cdktn.IResolvable;
    set includeResources(value: boolean | cdktn.IResolvable);
    resetIncludeResources(): void;
    get includeResourcesInput(): boolean | cdktn.IResolvable | undefined;
    get modified(): string;
    private _recipientId?;
    get recipientId(): string;
    set recipientId(value: string);
    get recipientIdInput(): string | undefined;
    private _resources;
    get resources(): DataCloudflareShareRecipientResourcesList;
    private _shareId?;
    get shareId(): string;
    set shareId(value: string);
    get shareIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
