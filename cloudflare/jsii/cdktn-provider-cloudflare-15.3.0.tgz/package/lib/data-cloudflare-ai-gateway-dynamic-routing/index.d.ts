/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAiGatewayDynamicRoutingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/ai_gateway_dynamic_routing#account_id DataCloudflareAiGatewayDynamicRouting#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/ai_gateway_dynamic_routing#gateway_id DataCloudflareAiGatewayDynamicRouting#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/ai_gateway_dynamic_routing#id DataCloudflareAiGatewayDynamicRouting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export interface DataCloudflareAiGatewayDynamicRoutingDeployment {
}
export declare function dataCloudflareAiGatewayDynamicRoutingDeploymentToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingDeployment): any;
export declare function dataCloudflareAiGatewayDynamicRoutingDeploymentToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingDeployment): any;
export declare class DataCloudflareAiGatewayDynamicRoutingDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingDeployment | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingDeployment | undefined);
    get createdAt(): string;
    get deploymentId(): string;
    get versionId(): string;
}
export interface DataCloudflareAiGatewayDynamicRoutingElementsOutputsFallback {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsFallbackToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsFallback): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsFallbackToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsFallback): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsOutputsFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsFallback | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElementsOutputsFallback | undefined);
    get elementId(): string;
}
export interface DataCloudflareAiGatewayDynamicRoutingElementsOutputsFalse {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsFalseToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsFalse): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsFalseToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsFalse): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsOutputsFalseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsFalse | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElementsOutputsFalse | undefined);
    get elementId(): string;
}
export interface DataCloudflareAiGatewayDynamicRoutingElementsOutputsNext {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsNextToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsNext): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsNextToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsNext): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsOutputsNextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsNext | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElementsOutputsNext | undefined);
    get elementId(): string;
}
export interface DataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccess {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccessToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccess): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccessToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccess): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccess | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccess | undefined);
    get elementId(): string;
}
export interface DataCloudflareAiGatewayDynamicRoutingElementsOutputsTrue {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsTrueToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsTrue): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsTrueToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputsTrue): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsOutputsTrueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsTrue | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElementsOutputsTrue | undefined);
    get elementId(): string;
}
export interface DataCloudflareAiGatewayDynamicRoutingElementsOutputs {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputs): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsOutputsToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsOutputs): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsOutputsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElementsOutputs | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElementsOutputs | undefined);
    get elementId(): string;
    private _fallback;
    get fallback(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsFallbackOutputReference;
    private _false;
    get false(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsFalseOutputReference;
    private _next;
    get next(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsNextOutputReference;
    private _success;
    get success(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsSuccessOutputReference;
    private _true;
    get true(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsTrueOutputReference;
}
export interface DataCloudflareAiGatewayDynamicRoutingElementsProperties {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsPropertiesToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsProperties): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsPropertiesToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElementsProperties): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElementsProperties | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElementsProperties | undefined);
    get aiGatewayDynamicRoutingProvider(): string;
    get conditions(): string;
    get key(): string;
    get limit(): number;
    get limitType(): string;
    get model(): string;
    get retries(): number;
    get timeout(): number;
    get window(): number;
}
export interface DataCloudflareAiGatewayDynamicRoutingElements {
}
export declare function dataCloudflareAiGatewayDynamicRoutingElementsToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElements): any;
export declare function dataCloudflareAiGatewayDynamicRoutingElementsToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingElements): any;
export declare class DataCloudflareAiGatewayDynamicRoutingElementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingElements | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingElements | undefined);
    get id(): string;
    private _outputs;
    get outputs(): DataCloudflareAiGatewayDynamicRoutingElementsOutputsOutputReference;
    private _properties;
    get properties(): DataCloudflareAiGatewayDynamicRoutingElementsPropertiesOutputReference;
    get type(): string;
}
export declare class DataCloudflareAiGatewayDynamicRoutingElementsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewayDynamicRoutingElementsOutputReference;
}
export interface DataCloudflareAiGatewayDynamicRoutingVersion {
}
export declare function dataCloudflareAiGatewayDynamicRoutingVersionToTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingVersion): any;
export declare function dataCloudflareAiGatewayDynamicRoutingVersionToHclTerraform(struct?: DataCloudflareAiGatewayDynamicRoutingVersion): any;
export declare class DataCloudflareAiGatewayDynamicRoutingVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDynamicRoutingVersion | undefined;
    set internalValue(value: DataCloudflareAiGatewayDynamicRoutingVersion | undefined);
    get active(): string;
    get createdAt(): string;
    get data(): string;
    get isValid(): cdktn.IResolvable;
    get versionId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/ai_gateway_dynamic_routing cloudflare_ai_gateway_dynamic_routing}
*/
export declare class DataCloudflareAiGatewayDynamicRouting extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ai_gateway_dynamic_routing";
    /**
    * Generates CDKTN code for importing a DataCloudflareAiGatewayDynamicRouting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAiGatewayDynamicRouting to import
    * @param importFromId The id of the existing DataCloudflareAiGatewayDynamicRouting that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/ai_gateway_dynamic_routing#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAiGatewayDynamicRouting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/ai_gateway_dynamic_routing cloudflare_ai_gateway_dynamic_routing} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAiGatewayDynamicRoutingConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareAiGatewayDynamicRoutingConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    private _deployment;
    get deployment(): DataCloudflareAiGatewayDynamicRoutingDeploymentOutputReference;
    private _elements;
    get elements(): DataCloudflareAiGatewayDynamicRoutingElementsList;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get modifiedAt(): string;
    get name(): string;
    private _version;
    get version(): DataCloudflareAiGatewayDynamicRoutingVersionOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
