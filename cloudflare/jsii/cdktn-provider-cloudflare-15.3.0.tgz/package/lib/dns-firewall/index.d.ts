/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsFirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#account_id DnsFirewall#account_id}
    */
    readonly accountId: string;
    /**
    * Attack mitigation settings
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#attack_mitigation DnsFirewall#attack_mitigation}
    */
    readonly attackMitigation?: DnsFirewallAttackMitigation;
    /**
    * Whether to refuse to answer queries for the ANY type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#deprecate_any_requests DnsFirewall#deprecate_any_requests}
    */
    readonly deprecateAnyRequests?: boolean | cdktn.IResolvable;
    /**
    * Number of IPv4 addresses to assign to the DNS Firewall cluster. Only used during cluster creation and cannot be changed later.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#dns_firewall_ip_count DnsFirewall#dns_firewall_ip_count}
    */
    readonly dnsFirewallIpCount?: number;
    /**
    * Whether to forward client IP (resolver) subnet if no EDNS Client Subnet is sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#ecs_fallback DnsFirewall#ecs_fallback}
    */
    readonly ecsFallback?: boolean | cdktn.IResolvable;
    /**
    * By default, Cloudflare attempts to cache responses for as long as
    * indicated by the TTL received from upstream nameservers. This setting
    * sets an upper bound on this duration. For caching purposes, higher TTLs
    * will be decreased to the maximum value defined by this setting.
    *
    * This setting does not affect the TTL value in the DNS response
    * Cloudflare returns to clients. Cloudflare will always forward the TTL
    * value received from upstream nameservers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#maximum_cache_ttl DnsFirewall#maximum_cache_ttl}
    */
    readonly maximumCacheTtl?: number;
    /**
    * By default, Cloudflare attempts to cache responses for as long as
    * indicated by the TTL received from upstream nameservers. This setting
    * sets a lower bound on this duration. For caching purposes, lower TTLs
    * will be increased to the minimum value defined by this setting.
    *
    * This setting does not affect the TTL value in the DNS response
    * Cloudflare returns to clients. Cloudflare will always forward the TTL
    * value received from upstream nameservers.
    *
    * Note that, even with this setting, there is no guarantee that a
    * response will be cached for at least the specified duration. Cached
    * responses may be removed earlier for capacity or other operational
    * reasons.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#minimum_cache_ttl DnsFirewall#minimum_cache_ttl}
    */
    readonly minimumCacheTtl?: number;
    /**
    * DNS Firewall cluster name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#name DnsFirewall#name}
    */
    readonly name: string;
    /**
    * This setting controls how long DNS Firewall should cache negative
    * responses (e.g., NXDOMAIN) from the upstream servers.
    *
    * This setting does not affect the TTL value in the DNS response
    * Cloudflare returns to clients. Cloudflare will always forward the TTL
    * value received from upstream nameservers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#negative_cache_ttl DnsFirewall#negative_cache_ttl}
    */
    readonly negativeCacheTtl?: number;
    /**
    * Maximum number of DNS queries per second that will be forwarded to your upstream nameservers. The limit is enforced per server, where each server receives a fraction of the configured value. The actual aggregate rate for a data center may vary depending on how many servers are present. Responses served from cache do not count toward this limit. Set to null to disable rate limiting.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#ratelimit DnsFirewall#ratelimit}
    */
    readonly ratelimit?: number;
    /**
    * Number of retries for fetching DNS responses from upstream nameservers (not counting the initial attempt)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#retries DnsFirewall#retries}
    */
    readonly retries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#upstream_ips DnsFirewall#upstream_ips}
    */
    readonly upstreamIps: string[];
}
export interface DnsFirewallAttackMitigation {
    /**
    * When enabled, automatically mitigate random-prefix attacks to protect upstream DNS servers
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#enabled DnsFirewall#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Only mitigate attacks when upstream servers seem unhealthy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#only_when_upstream_unhealthy DnsFirewall#only_when_upstream_unhealthy}
    */
    readonly onlyWhenUpstreamUnhealthy?: boolean | cdktn.IResolvable;
}
export declare function dnsFirewallAttackMitigationToTerraform(struct?: DnsFirewallAttackMitigation | cdktn.IResolvable): any;
export declare function dnsFirewallAttackMitigationToHclTerraform(struct?: DnsFirewallAttackMitigation | cdktn.IResolvable): any;
export declare class DnsFirewallAttackMitigationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DnsFirewallAttackMitigation | cdktn.IResolvable | undefined;
    set internalValue(value: DnsFirewallAttackMitigation | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _onlyWhenUpstreamUnhealthy?;
    get onlyWhenUpstreamUnhealthy(): boolean | cdktn.IResolvable;
    set onlyWhenUpstreamUnhealthy(value: boolean | cdktn.IResolvable);
    resetOnlyWhenUpstreamUnhealthy(): void;
    get onlyWhenUpstreamUnhealthyInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall cloudflare_dns_firewall}
*/
export declare class DnsFirewall extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_dns_firewall";
    /**
    * Generates CDKTN code for importing a DnsFirewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsFirewall to import
    * @param importFromId The id of the existing DnsFirewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsFirewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/dns_firewall cloudflare_dns_firewall} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsFirewallConfig
    */
    constructor(scope: Construct, id: string, config: DnsFirewallConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _attackMitigation;
    get attackMitigation(): DnsFirewallAttackMitigationOutputReference;
    putAttackMitigation(value: DnsFirewallAttackMitigation): void;
    resetAttackMitigation(): void;
    get attackMitigationInput(): cdktn.IResolvable | DnsFirewallAttackMitigation | undefined;
    private _deprecateAnyRequests?;
    get deprecateAnyRequests(): boolean | cdktn.IResolvable;
    set deprecateAnyRequests(value: boolean | cdktn.IResolvable);
    resetDeprecateAnyRequests(): void;
    get deprecateAnyRequestsInput(): boolean | cdktn.IResolvable | undefined;
    private _dnsFirewallIpCount?;
    get dnsFirewallIpCount(): number;
    set dnsFirewallIpCount(value: number);
    resetDnsFirewallIpCount(): void;
    get dnsFirewallIpCountInput(): number | undefined;
    get dnsFirewallIps(): string[];
    private _ecsFallback?;
    get ecsFallback(): boolean | cdktn.IResolvable;
    set ecsFallback(value: boolean | cdktn.IResolvable);
    resetEcsFallback(): void;
    get ecsFallbackInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _maximumCacheTtl?;
    get maximumCacheTtl(): number;
    set maximumCacheTtl(value: number);
    resetMaximumCacheTtl(): void;
    get maximumCacheTtlInput(): number | undefined;
    private _minimumCacheTtl?;
    get minimumCacheTtl(): number;
    set minimumCacheTtl(value: number);
    resetMinimumCacheTtl(): void;
    get minimumCacheTtlInput(): number | undefined;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _negativeCacheTtl?;
    get negativeCacheTtl(): number;
    set negativeCacheTtl(value: number);
    resetNegativeCacheTtl(): void;
    get negativeCacheTtlInput(): number | undefined;
    private _ratelimit?;
    get ratelimit(): number;
    set ratelimit(value: number);
    resetRatelimit(): void;
    get ratelimitInput(): number | undefined;
    private _retries?;
    get retries(): number;
    set retries(value: number);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _upstreamIps?;
    get upstreamIps(): string[];
    set upstreamIps(value: string[]);
    get upstreamIpsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
