/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TokenValidationRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Action to take on requests that match operations included in `selector` and fail `expression`.
    * Available values: "log", "block".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#action TokenValidationRules#action}
    */
    readonly action: string;
    /**
    * A human-readable description that gives more details than `title`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#description TokenValidationRules#description}
    */
    readonly description: string;
    /**
    * Toggle rule on or off.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#enabled TokenValidationRules#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Rule expression. Requests that fail to match this expression will be subject to `action`.
    *
    * For details on expressions, see the [Cloudflare Docs](https://developers.cloudflare.com/api-shield/security/jwt-validation/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#expression TokenValidationRules#expression}
    */
    readonly expression: string;
    /**
    * Update rule order among zone rules.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#position TokenValidationRules#position}
    */
    readonly position?: TokenValidationRulesPosition;
    /**
    * Select operations covered by this rule.
    *
    * For details on selectors, see the [Cloudflare Docs](https://developers.cloudflare.com/api-shield/security/jwt-validation/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#selector TokenValidationRules#selector}
    */
    readonly selector: TokenValidationRulesSelector;
    /**
    * A human-readable name for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#title TokenValidationRules#title}
    */
    readonly title: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#zone_id TokenValidationRules#zone_id}
    */
    readonly zoneId: string;
}
export interface TokenValidationRulesPosition {
    /**
    * Move rule to after rule with this ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#after TokenValidationRules#after}
    */
    readonly after?: string;
    /**
    * Move rule to before rule with this ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#before TokenValidationRules#before}
    */
    readonly before?: string;
    /**
    * Move rule to this position
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#index TokenValidationRules#index}
    */
    readonly index?: number;
}
export declare function tokenValidationRulesPositionToTerraform(struct?: TokenValidationRulesPosition | cdktn.IResolvable): any;
export declare function tokenValidationRulesPositionToHclTerraform(struct?: TokenValidationRulesPosition | cdktn.IResolvable): any;
export declare class TokenValidationRulesPositionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TokenValidationRulesPosition | cdktn.IResolvable | undefined;
    set internalValue(value: TokenValidationRulesPosition | cdktn.IResolvable | undefined);
    private _after?;
    get after(): string;
    set after(value: string);
    resetAfter(): void;
    get afterInput(): string | undefined;
    private _before?;
    get before(): string;
    set before(value: string);
    resetBefore(): void;
    get beforeInput(): string | undefined;
    private _index?;
    get index(): number;
    set index(value: number);
    resetIndex(): void;
    get indexInput(): number | undefined;
}
export interface TokenValidationRulesSelectorExclude {
    /**
    * Excluded operation IDs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#operation_ids TokenValidationRules#operation_ids}
    */
    readonly operationIds?: string[];
}
export declare function tokenValidationRulesSelectorExcludeToTerraform(struct?: TokenValidationRulesSelectorExclude | cdktn.IResolvable): any;
export declare function tokenValidationRulesSelectorExcludeToHclTerraform(struct?: TokenValidationRulesSelectorExclude | cdktn.IResolvable): any;
export declare class TokenValidationRulesSelectorExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TokenValidationRulesSelectorExclude | cdktn.IResolvable | undefined;
    set internalValue(value: TokenValidationRulesSelectorExclude | cdktn.IResolvable | undefined);
    private _operationIds?;
    get operationIds(): string[];
    set operationIds(value: string[]);
    resetOperationIds(): void;
    get operationIdsInput(): string[] | undefined;
}
export declare class TokenValidationRulesSelectorExcludeList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TokenValidationRulesSelectorExclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TokenValidationRulesSelectorExcludeOutputReference;
}
export interface TokenValidationRulesSelectorInclude {
    /**
    * Included hostnames.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#host TokenValidationRules#host}
    */
    readonly host?: string[];
}
export declare function tokenValidationRulesSelectorIncludeToTerraform(struct?: TokenValidationRulesSelectorInclude | cdktn.IResolvable): any;
export declare function tokenValidationRulesSelectorIncludeToHclTerraform(struct?: TokenValidationRulesSelectorInclude | cdktn.IResolvable): any;
export declare class TokenValidationRulesSelectorIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TokenValidationRulesSelectorInclude | cdktn.IResolvable | undefined;
    set internalValue(value: TokenValidationRulesSelectorInclude | cdktn.IResolvable | undefined);
    private _host?;
    get host(): string[];
    set host(value: string[]);
    resetHost(): void;
    get hostInput(): string[] | undefined;
}
export declare class TokenValidationRulesSelectorIncludeList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: TokenValidationRulesSelectorInclude[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TokenValidationRulesSelectorIncludeOutputReference;
}
export interface TokenValidationRulesSelector {
    /**
    * Ignore operations that were otherwise included by `include`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#exclude TokenValidationRules#exclude}
    */
    readonly exclude?: TokenValidationRulesSelectorExclude[] | cdktn.IResolvable;
    /**
    * Select all matching operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#include TokenValidationRules#include}
    */
    readonly include?: TokenValidationRulesSelectorInclude[] | cdktn.IResolvable;
}
export declare function tokenValidationRulesSelectorToTerraform(struct?: TokenValidationRulesSelector | cdktn.IResolvable): any;
export declare function tokenValidationRulesSelectorToHclTerraform(struct?: TokenValidationRulesSelector | cdktn.IResolvable): any;
export declare class TokenValidationRulesSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TokenValidationRulesSelector | cdktn.IResolvable | undefined;
    set internalValue(value: TokenValidationRulesSelector | cdktn.IResolvable | undefined);
    private _exclude;
    get exclude(): TokenValidationRulesSelectorExcludeList;
    putExclude(value: TokenValidationRulesSelectorExclude[] | cdktn.IResolvable): void;
    resetExclude(): void;
    get excludeInput(): cdktn.IResolvable | TokenValidationRulesSelectorExclude[] | undefined;
    private _include;
    get include(): TokenValidationRulesSelectorIncludeList;
    putInclude(value: TokenValidationRulesSelectorInclude[] | cdktn.IResolvable): void;
    resetInclude(): void;
    get includeInput(): cdktn.IResolvable | TokenValidationRulesSelectorInclude[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules cloudflare_token_validation_rules}
*/
export declare class TokenValidationRules extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_token_validation_rules";
    /**
    * Generates CDKTN code for importing a TokenValidationRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TokenValidationRules to import
    * @param importFromId The id of the existing TokenValidationRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TokenValidationRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/token_validation_rules cloudflare_token_validation_rules} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TokenValidationRulesConfig
    */
    constructor(scope: Construct, id: string, config: TokenValidationRulesConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    get id(): string;
    get lastUpdated(): string;
    private _position;
    get position(): TokenValidationRulesPositionOutputReference;
    putPosition(value: TokenValidationRulesPosition): void;
    resetPosition(): void;
    get positionInput(): cdktn.IResolvable | TokenValidationRulesPosition | undefined;
    private _selector;
    get selector(): TokenValidationRulesSelectorOutputReference;
    putSelector(value: TokenValidationRulesSelector): void;
    get selectorInput(): cdktn.IResolvable | TokenValidationRulesSelector | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    get titleInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
