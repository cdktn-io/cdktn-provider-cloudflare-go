/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsRegoMetadataConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#account_id DataCloudflareZeroTrustCwsRegoMetadata#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#filter DataCloudflareZeroTrustCwsRegoMetadata#filter}
    */
    readonly filter?: DataCloudflareZeroTrustCwsRegoMetadataFilter;
    /**
    * ID of the rego metadata document to retrieve
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#rego_metadata_id DataCloudflareZeroTrustCwsRegoMetadata#rego_metadata_id}
    */
    readonly regoMetadataId?: string;
}
export interface DataCloudflareZeroTrustCwsRegoMetadataFilter {
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#direction DataCloudflareZeroTrustCwsRegoMetadata#direction}
    */
    readonly direction?: string;
    /**
    * Filter by import path (case-sensitive literal substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#import_path DataCloudflareZeroTrustCwsRegoMetadata#import_path}
    */
    readonly importPath?: string;
    /**
    * Filter by rego metadata name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#name DataCloudflareZeroTrustCwsRegoMetadata#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#order DataCloudflareZeroTrustCwsRegoMetadata#order}
    */
    readonly order?: string;
}
export declare function dataCloudflareZeroTrustCwsRegoMetadataFilterToTerraform(struct?: DataCloudflareZeroTrustCwsRegoMetadataFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustCwsRegoMetadataFilterToHclTerraform(struct?: DataCloudflareZeroTrustCwsRegoMetadataFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustCwsRegoMetadataFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCwsRegoMetadataFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsRegoMetadataFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _importPath?;
    get importPath(): string;
    set importPath(value: string);
    resetImportPath(): void;
    get importPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata cloudflare_zero_trust_cws_rego_metadata}
*/
export declare class DataCloudflareZeroTrustCwsRegoMetadata extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_rego_metadata";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsRegoMetadata resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsRegoMetadata to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsRegoMetadata that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsRegoMetadata to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata cloudflare_zero_trust_cws_rego_metadata} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsRegoMetadataConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsRegoMetadataConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get data(): string;
    private _filter;
    get filter(): DataCloudflareZeroTrustCwsRegoMetadataFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustCwsRegoMetadataFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustCwsRegoMetadataFilter | undefined;
    get id(): string;
    get importPath(): string;
    get name(): string;
    private _regoMetadataId?;
    get regoMetadataId(): string;
    set regoMetadataId(value: string);
    resetRegoMetadataId(): void;
    get regoMetadataIdInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
