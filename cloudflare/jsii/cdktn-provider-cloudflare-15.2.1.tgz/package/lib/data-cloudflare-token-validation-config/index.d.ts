/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareTokenValidationConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/token_validation_config#config_id DataCloudflareTokenValidationConfig#config_id}
    */
    readonly configId: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/token_validation_config#zone_id DataCloudflareTokenValidationConfig#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareTokenValidationConfigCredentialsKeys {
}
export declare function dataCloudflareTokenValidationConfigCredentialsKeysToTerraform(struct?: DataCloudflareTokenValidationConfigCredentialsKeys): any;
export declare function dataCloudflareTokenValidationConfigCredentialsKeysToHclTerraform(struct?: DataCloudflareTokenValidationConfigCredentialsKeys): any;
export declare class DataCloudflareTokenValidationConfigCredentialsKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareTokenValidationConfigCredentialsKeys | undefined;
    set internalValue(value: DataCloudflareTokenValidationConfigCredentialsKeys | undefined);
    get alg(): string;
    get crv(): string;
    get e(): string;
    get kid(): string;
    get kty(): string;
    get n(): string;
    get x(): string;
    get y(): string;
}
export declare class DataCloudflareTokenValidationConfigCredentialsKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareTokenValidationConfigCredentialsKeysOutputReference;
}
export interface DataCloudflareTokenValidationConfigCredentials {
}
export declare function dataCloudflareTokenValidationConfigCredentialsToTerraform(struct?: DataCloudflareTokenValidationConfigCredentials): any;
export declare function dataCloudflareTokenValidationConfigCredentialsToHclTerraform(struct?: DataCloudflareTokenValidationConfigCredentials): any;
export declare class DataCloudflareTokenValidationConfigCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareTokenValidationConfigCredentials | undefined;
    set internalValue(value: DataCloudflareTokenValidationConfigCredentials | undefined);
    private _keys;
    get keys(): DataCloudflareTokenValidationConfigCredentialsKeysList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/token_validation_config cloudflare_token_validation_config}
*/
export declare class DataCloudflareTokenValidationConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_token_validation_config";
    /**
    * Generates CDKTN code for importing a DataCloudflareTokenValidationConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareTokenValidationConfig to import
    * @param importFromId The id of the existing DataCloudflareTokenValidationConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/token_validation_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareTokenValidationConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/token_validation_config cloudflare_token_validation_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareTokenValidationConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareTokenValidationConfigConfig);
    private _configId?;
    get configId(): string;
    set configId(value: string);
    get configIdInput(): string | undefined;
    get createdAt(): string;
    private _credentials;
    get credentials(): DataCloudflareTokenValidationConfigCredentialsOutputReference;
    get description(): string;
    get id(): string;
    get lastUpdated(): string;
    get title(): string;
    get tokenSources(): string[];
    get tokenType(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
