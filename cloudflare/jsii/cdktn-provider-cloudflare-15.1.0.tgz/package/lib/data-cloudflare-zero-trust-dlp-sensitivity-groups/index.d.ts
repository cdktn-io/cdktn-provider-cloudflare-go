/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpSensitivityGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_sensitivity_groups#account_id DataCloudflareZeroTrustDlpSensitivityGroups#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_sensitivity_groups#max_items DataCloudflareZeroTrustDlpSensitivityGroups#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDlpSensitivityGroupsResultLevels {
}
export declare function dataCloudflareZeroTrustDlpSensitivityGroupsResultLevelsToTerraform(struct?: DataCloudflareZeroTrustDlpSensitivityGroupsResultLevels): any;
export declare function dataCloudflareZeroTrustDlpSensitivityGroupsResultLevelsToHclTerraform(struct?: DataCloudflareZeroTrustDlpSensitivityGroupsResultLevels): any;
export declare class DataCloudflareZeroTrustDlpSensitivityGroupsResultLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpSensitivityGroupsResultLevels | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpSensitivityGroupsResultLevels | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustDlpSensitivityGroupsResultLevelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpSensitivityGroupsResultLevelsOutputReference;
}
export interface DataCloudflareZeroTrustDlpSensitivityGroupsResult {
}
export declare function dataCloudflareZeroTrustDlpSensitivityGroupsResultToTerraform(struct?: DataCloudflareZeroTrustDlpSensitivityGroupsResult): any;
export declare function dataCloudflareZeroTrustDlpSensitivityGroupsResultToHclTerraform(struct?: DataCloudflareZeroTrustDlpSensitivityGroupsResult): any;
export declare class DataCloudflareZeroTrustDlpSensitivityGroupsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpSensitivityGroupsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpSensitivityGroupsResult | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    private _levels;
    get levels(): DataCloudflareZeroTrustDlpSensitivityGroupsResultLevelsList;
    get name(): string;
    get templateId(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustDlpSensitivityGroupsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpSensitivityGroupsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_sensitivity_groups cloudflare_zero_trust_dlp_sensitivity_groups}
*/
export declare class DataCloudflareZeroTrustDlpSensitivityGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_sensitivity_groups";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpSensitivityGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpSensitivityGroups to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpSensitivityGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_sensitivity_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpSensitivityGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_sensitivity_groups cloudflare_zero_trust_dlp_sensitivity_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpSensitivityGroupsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpSensitivityGroupsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDlpSensitivityGroupsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
