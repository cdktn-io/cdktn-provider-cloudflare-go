/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWebAnalyticsSiteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/web_analytics_site#account_id DataCloudflareWebAnalyticsSite#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/web_analytics_site#filter DataCloudflareWebAnalyticsSite#filter}
    */
    readonly filter?: DataCloudflareWebAnalyticsSiteFilter;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/web_analytics_site#site_id DataCloudflareWebAnalyticsSite#site_id}
    */
    readonly siteId?: string;
}
export interface DataCloudflareWebAnalyticsSiteFilter {
    /**
    * The property used to sort the list of results.
    * Available values: "host", "created".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/web_analytics_site#order_by DataCloudflareWebAnalyticsSite#order_by}
    */
    readonly orderBy?: string;
}
export declare function dataCloudflareWebAnalyticsSiteFilterToTerraform(struct?: DataCloudflareWebAnalyticsSiteFilter | cdktn.IResolvable): any;
export declare function dataCloudflareWebAnalyticsSiteFilterToHclTerraform(struct?: DataCloudflareWebAnalyticsSiteFilter | cdktn.IResolvable): any;
export declare class DataCloudflareWebAnalyticsSiteFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWebAnalyticsSiteFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareWebAnalyticsSiteFilter | cdktn.IResolvable | undefined);
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
}
export interface DataCloudflareWebAnalyticsSiteRules {
}
export declare function dataCloudflareWebAnalyticsSiteRulesToTerraform(struct?: DataCloudflareWebAnalyticsSiteRules): any;
export declare function dataCloudflareWebAnalyticsSiteRulesToHclTerraform(struct?: DataCloudflareWebAnalyticsSiteRules): any;
export declare class DataCloudflareWebAnalyticsSiteRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWebAnalyticsSiteRules | undefined;
    set internalValue(value: DataCloudflareWebAnalyticsSiteRules | undefined);
    get created(): string;
    get host(): string;
    get id(): string;
    get inclusive(): cdktn.IResolvable;
    get isPaused(): cdktn.IResolvable;
    get paths(): string[];
    get priority(): number;
}
export declare class DataCloudflareWebAnalyticsSiteRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWebAnalyticsSiteRulesOutputReference;
}
export interface DataCloudflareWebAnalyticsSiteRuleset {
}
export declare function dataCloudflareWebAnalyticsSiteRulesetToTerraform(struct?: DataCloudflareWebAnalyticsSiteRuleset): any;
export declare function dataCloudflareWebAnalyticsSiteRulesetToHclTerraform(struct?: DataCloudflareWebAnalyticsSiteRuleset): any;
export declare class DataCloudflareWebAnalyticsSiteRulesetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWebAnalyticsSiteRuleset | undefined;
    set internalValue(value: DataCloudflareWebAnalyticsSiteRuleset | undefined);
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get zoneName(): string;
    get zoneTag(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/web_analytics_site cloudflare_web_analytics_site}
*/
export declare class DataCloudflareWebAnalyticsSite extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_web_analytics_site";
    /**
    * Generates CDKTN code for importing a DataCloudflareWebAnalyticsSite resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWebAnalyticsSite to import
    * @param importFromId The id of the existing DataCloudflareWebAnalyticsSite that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/web_analytics_site#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWebAnalyticsSite to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/web_analytics_site cloudflare_web_analytics_site} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWebAnalyticsSiteConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWebAnalyticsSiteConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get autoInstall(): cdktn.IResolvable;
    get created(): string;
    private _filter;
    get filter(): DataCloudflareWebAnalyticsSiteFilterOutputReference;
    putFilter(value: DataCloudflareWebAnalyticsSiteFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareWebAnalyticsSiteFilter | undefined;
    get id(): string;
    private _rules;
    get rules(): DataCloudflareWebAnalyticsSiteRulesList;
    private _ruleset;
    get ruleset(): DataCloudflareWebAnalyticsSiteRulesetOutputReference;
    private _siteId?;
    get siteId(): string;
    set siteId(value: string);
    resetSiteId(): void;
    get siteIdInput(): string | undefined;
    get siteTag(): string;
    get siteToken(): string;
    get snippet(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
