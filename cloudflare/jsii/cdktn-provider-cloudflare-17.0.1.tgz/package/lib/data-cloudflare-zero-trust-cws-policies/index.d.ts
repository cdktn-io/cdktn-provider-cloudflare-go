/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#account_id DataCloudflareZeroTrustCwsPolicies#account_id}
    */
    readonly accountId: string;
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#direction DataCloudflareZeroTrustCwsPolicies#direction}
    */
    readonly direction?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#max_items DataCloudflareZeroTrustCwsPolicies#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter by policy name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#name DataCloudflareZeroTrustCwsPolicies#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#order DataCloudflareZeroTrustCwsPolicies#order}
    */
    readonly order?: string;
    /**
    * Filter by package path (case-sensitive literal substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#package_path DataCloudflareZeroTrustCwsPolicies#package_path}
    */
    readonly packagePath?: string;
    /**
    * Filter to policies attached to (members of) this policy set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#policy_set_id DataCloudflareZeroTrustCwsPolicies#policy_set_id}
    */
    readonly policySetId?: string;
}
export interface DataCloudflareZeroTrustCwsPoliciesResult {
}
export declare function dataCloudflareZeroTrustCwsPoliciesResultToTerraform(struct?: DataCloudflareZeroTrustCwsPoliciesResult): any;
export declare function dataCloudflareZeroTrustCwsPoliciesResultToHclTerraform(struct?: DataCloudflareZeroTrustCwsPoliciesResult): any;
export declare class DataCloudflareZeroTrustCwsPoliciesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCwsPoliciesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsPoliciesResult | undefined);
    get createdAt(): string;
    get description(): string;
    get entrypoint(): string;
    get filter(): string;
    get id(): string;
    get name(): string;
    get packagePath(): string;
    get regoSource(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustCwsPoliciesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCwsPoliciesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies cloudflare_zero_trust_cws_policies}
*/
export declare class DataCloudflareZeroTrustCwsPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_policies";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsPolicies to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policies cloudflare_zero_trust_cws_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsPoliciesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsPoliciesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _packagePath?;
    get packagePath(): string;
    set packagePath(value: string);
    resetPackagePath(): void;
    get packagePathInput(): string | undefined;
    private _policySetId?;
    get policySetId(): string;
    set policySetId(value: string);
    resetPolicySetId(): void;
    get policySetIdInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCwsPoliciesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
