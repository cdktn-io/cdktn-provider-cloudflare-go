/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSecretsStoreSecretsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#account_id DataCloudflareSecretsStoreSecrets#account_id}
    */
    readonly accountId: string;
    /**
    * Direction to sort objects
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#direction DataCloudflareSecretsStoreSecrets#direction}
    */
    readonly direction?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#max_items DataCloudflareSecretsStoreSecrets#max_items}
    */
    readonly maxItems?: number;
    /**
    * Order secrets by values in the given field
    * Available values: "name", "comment", "created", "modified", "status".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#order DataCloudflareSecretsStoreSecrets#order}
    */
    readonly order?: string;
    /**
    * Only secrets with the given scopes will be returned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#scopes DataCloudflareSecretsStoreSecrets#scopes}
    */
    readonly scopes?: string[][] | cdktn.IResolvable;
    /**
    * Search secrets using a filter string, filtering across name and comment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#search DataCloudflareSecretsStoreSecrets#search}
    */
    readonly search?: string;
    /**
    * Store Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#store_id DataCloudflareSecretsStoreSecrets#store_id}
    */
    readonly storeId: string;
}
export interface DataCloudflareSecretsStoreSecretsResult {
}
export declare function dataCloudflareSecretsStoreSecretsResultToTerraform(struct?: DataCloudflareSecretsStoreSecretsResult): any;
export declare function dataCloudflareSecretsStoreSecretsResultToHclTerraform(struct?: DataCloudflareSecretsStoreSecretsResult): any;
export declare class DataCloudflareSecretsStoreSecretsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareSecretsStoreSecretsResult | undefined;
    set internalValue(value: DataCloudflareSecretsStoreSecretsResult | undefined);
    get comment(): string;
    get created(): string;
    get id(): string;
    get modified(): string;
    get name(): string;
    get scopes(): string[];
    get status(): string;
    get storeId(): string;
}
export declare class DataCloudflareSecretsStoreSecretsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareSecretsStoreSecretsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets cloudflare_secrets_store_secrets}
*/
export declare class DataCloudflareSecretsStoreSecrets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_secrets_store_secrets";
    /**
    * Generates CDKTN code for importing a DataCloudflareSecretsStoreSecrets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSecretsStoreSecrets to import
    * @param importFromId The id of the existing DataCloudflareSecretsStoreSecrets that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSecretsStoreSecrets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/secrets_store_secrets cloudflare_secrets_store_secrets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSecretsStoreSecretsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareSecretsStoreSecretsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _result;
    get result(): DataCloudflareSecretsStoreSecretsResultList;
    private _scopes?;
    get scopes(): string[][] | cdktn.IResolvable;
    set scopes(value: string[][] | cdktn.IResolvable);
    resetScopes(): void;
    get scopesInput(): cdktn.IResolvable | string[][] | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _storeId?;
    get storeId(): string;
    set storeId(value: string);
    get storeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
