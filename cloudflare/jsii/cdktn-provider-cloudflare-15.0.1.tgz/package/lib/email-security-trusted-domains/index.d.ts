/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EmailSecurityTrustedDomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#account_id EmailSecurityTrustedDomains#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#body EmailSecurityTrustedDomains#body}
    */
    readonly body?: EmailSecurityTrustedDomainsBody[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#comments EmailSecurityTrustedDomains#comments}
    */
    readonly comments?: string;
    /**
    * Select to prevent recently registered domains from triggering a
    * Suspicious or Malicious disposition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#is_recent EmailSecurityTrustedDomains#is_recent}
    */
    readonly isRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#is_regex EmailSecurityTrustedDomains#is_regex}
    */
    readonly isRegex?: boolean | cdktn.IResolvable;
    /**
    * Select for partner or other approved domains that have similar
    * spelling to your connected domains. Prevents listed domains from
    * triggering a Spoof disposition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#is_similarity EmailSecurityTrustedDomains#is_similarity}
    */
    readonly isSimilarity?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#pattern EmailSecurityTrustedDomains#pattern}
    */
    readonly pattern?: string;
}
export interface EmailSecurityTrustedDomainsBody {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#comments EmailSecurityTrustedDomains#comments}
    */
    readonly comments?: string;
    /**
    * Select to prevent recently registered domains from triggering a
    * Suspicious or Malicious disposition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#is_recent EmailSecurityTrustedDomains#is_recent}
    */
    readonly isRecent: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#is_regex EmailSecurityTrustedDomains#is_regex}
    */
    readonly isRegex: boolean | cdktn.IResolvable;
    /**
    * Select for partner or other approved domains that have similar
    * spelling to your connected domains. Prevents listed domains from
    * triggering a Spoof disposition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#is_similarity EmailSecurityTrustedDomains#is_similarity}
    */
    readonly isSimilarity: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#pattern EmailSecurityTrustedDomains#pattern}
    */
    readonly pattern: string;
}
export declare function emailSecurityTrustedDomainsBodyToTerraform(struct?: EmailSecurityTrustedDomainsBody | cdktn.IResolvable): any;
export declare function emailSecurityTrustedDomainsBodyToHclTerraform(struct?: EmailSecurityTrustedDomainsBody | cdktn.IResolvable): any;
export declare class EmailSecurityTrustedDomainsBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailSecurityTrustedDomainsBody | cdktn.IResolvable | undefined;
    set internalValue(value: EmailSecurityTrustedDomainsBody | cdktn.IResolvable | undefined);
    private _comments?;
    get comments(): string;
    set comments(value: string);
    resetComments(): void;
    get commentsInput(): string | undefined;
    private _isRecent?;
    get isRecent(): boolean | cdktn.IResolvable;
    set isRecent(value: boolean | cdktn.IResolvable);
    get isRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _isRegex?;
    get isRegex(): boolean | cdktn.IResolvable;
    set isRegex(value: boolean | cdktn.IResolvable);
    get isRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _isSimilarity?;
    get isSimilarity(): boolean | cdktn.IResolvable;
    set isSimilarity(value: boolean | cdktn.IResolvable);
    get isSimilarityInput(): boolean | cdktn.IResolvable | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    get patternInput(): string | undefined;
}
export declare class EmailSecurityTrustedDomainsBodyList extends cdktn.ComplexList {
    internalValue?: EmailSecurityTrustedDomainsBody[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailSecurityTrustedDomainsBodyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains cloudflare_email_security_trusted_domains}
*/
export declare class EmailSecurityTrustedDomains extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_email_security_trusted_domains";
    /**
    * Generates CDKTN code for importing a EmailSecurityTrustedDomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailSecurityTrustedDomains to import
    * @param importFromId The id of the existing EmailSecurityTrustedDomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailSecurityTrustedDomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/email_security_trusted_domains cloudflare_email_security_trusted_domains} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailSecurityTrustedDomainsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: EmailSecurityTrustedDomainsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _body;
    get body(): EmailSecurityTrustedDomainsBodyList;
    putBody(value: EmailSecurityTrustedDomainsBody[] | cdktn.IResolvable): void;
    resetBody(): void;
    get bodyInput(): cdktn.IResolvable | EmailSecurityTrustedDomainsBody[] | undefined;
    private _comments?;
    get comments(): string;
    set comments(value: string);
    resetComments(): void;
    get commentsInput(): string | undefined;
    get createdAt(): string;
    get id(): number;
    private _isRecent?;
    get isRecent(): boolean | cdktn.IResolvable;
    set isRecent(value: boolean | cdktn.IResolvable);
    resetIsRecent(): void;
    get isRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _isRegex?;
    get isRegex(): boolean | cdktn.IResolvable;
    set isRegex(value: boolean | cdktn.IResolvable);
    resetIsRegex(): void;
    get isRegexInput(): boolean | cdktn.IResolvable | undefined;
    private _isSimilarity?;
    get isSimilarity(): boolean | cdktn.IResolvable;
    set isSimilarity(value: boolean | cdktn.IResolvable);
    resetIsSimilarity(): void;
    get isSimilarityInput(): boolean | cdktn.IResolvable | undefined;
    get lastModified(): string;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
