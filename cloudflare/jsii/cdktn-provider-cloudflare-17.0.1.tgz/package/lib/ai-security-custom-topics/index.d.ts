/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiSecurityCustomTopicsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Custom topic categories for AI Security for Apps content detection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/ai_security_custom_topics#topics AiSecurityCustomTopics#topics}
    */
    readonly topics?: AiSecurityCustomTopicsTopics[] | cdktn.IResolvable;
    /**
    * Defines the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/ai_security_custom_topics#zone_id AiSecurityCustomTopics#zone_id}
    */
    readonly zoneId: string;
}
export interface AiSecurityCustomTopicsTopics {
    /**
    * Unique label identifier. Must contain only lowercase letters (a–z), digits (0–9), and hyphens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/ai_security_custom_topics#label AiSecurityCustomTopics#label}
    */
    readonly label: string;
    /**
    * Description of the topic category. Must contain 2–50 UTF-8 bytes. Text in any language is supported, including spaces, numbers, punctuation, and symbols. Tabs, line breaks, invalid text, and invisible formatting characters are not allowed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/ai_security_custom_topics#topic AiSecurityCustomTopics#topic}
    */
    readonly topic: string;
}
export declare function aiSecurityCustomTopicsTopicsToTerraform(struct?: AiSecurityCustomTopicsTopics | cdktn.IResolvable): any;
export declare function aiSecurityCustomTopicsTopicsToHclTerraform(struct?: AiSecurityCustomTopicsTopics | cdktn.IResolvable): any;
export declare class AiSecurityCustomTopicsTopicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSecurityCustomTopicsTopics | cdktn.IResolvable | undefined;
    set internalValue(value: AiSecurityCustomTopicsTopics | cdktn.IResolvable | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _topic?;
    get topic(): string;
    set topic(value: string);
    get topicInput(): string | undefined;
}
export declare class AiSecurityCustomTopicsTopicsList extends cdktn.ComplexList {
    internalValue?: AiSecurityCustomTopicsTopics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSecurityCustomTopicsTopicsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/ai_security_custom_topics cloudflare_ai_security_custom_topics}
*/
export declare class AiSecurityCustomTopics extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ai_security_custom_topics";
    /**
    * Generates CDKTN code for importing a AiSecurityCustomTopics resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiSecurityCustomTopics to import
    * @param importFromId The id of the existing AiSecurityCustomTopics that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/ai_security_custom_topics#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiSecurityCustomTopics to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/ai_security_custom_topics cloudflare_ai_security_custom_topics} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiSecurityCustomTopicsConfig
    */
    constructor(scope: Construct, id: string, config: AiSecurityCustomTopicsConfig);
    get id(): string;
    private _topics;
    get topics(): AiSecurityCustomTopicsTopicsList;
    putTopics(value: AiSecurityCustomTopicsTopics[] | cdktn.IResolvable): void;
    resetTopics(): void;
    get topicsInput(): cdktn.IResolvable | AiSecurityCustomTopicsTopics[] | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
