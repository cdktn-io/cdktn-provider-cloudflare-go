/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSharesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#account_id DataCloudflareShares#account_id}
    */
    readonly accountId: string;
    /**
    * Direction to sort objects.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#direction DataCloudflareShares#direction}
    */
    readonly direction?: string;
    /**
    * Include recipient counts in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#include_recipient_counts DataCloudflareShares#include_recipient_counts}
    */
    readonly includeRecipientCounts?: boolean | cdktn.IResolvable;
    /**
    * Include resources in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#include_resources DataCloudflareShares#include_resources}
    */
    readonly includeResources?: boolean | cdktn.IResolvable;
    /**
    * Filter shares by kind.
    * Available values: "sent", "received".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#kind DataCloudflareShares#kind}
    */
    readonly kind?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#max_items DataCloudflareShares#max_items}
    */
    readonly maxItems?: number;
    /**
    * Order shares by values in the given field.
    * Available values: "name", "created".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#order DataCloudflareShares#order}
    */
    readonly order?: string;
    /**
    * Filter share resources by resource_types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#resource_types DataCloudflareShares#resource_types}
    */
    readonly resourceTypes?: string[];
    /**
    * Filter shares by status.
    * Available values: "active", "deleting", "deleted".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#status DataCloudflareShares#status}
    */
    readonly status?: string;
    /**
    * Filter shares by tag. Each value is either `key=value` (matches shares whose tags contain that key/value pair) or `key` alone (matches shares that have any value for that key). May be repeated; multiple `tag` parameters are ANDed together. Maximum 20 `tag` parameters per request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#tag DataCloudflareShares#tag}
    */
    readonly tag?: string[];
    /**
    * Filter shares by target_type.
    * Available values: "account", "organization".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#target_type DataCloudflareShares#target_type}
    */
    readonly targetType?: string;
}
export interface DataCloudflareSharesResultResources {
}
export declare function dataCloudflareSharesResultResourcesToTerraform(struct?: DataCloudflareSharesResultResources): any;
export declare function dataCloudflareSharesResultResourcesToHclTerraform(struct?: DataCloudflareSharesResultResources): any;
export declare class DataCloudflareSharesResultResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareSharesResultResources | undefined;
    set internalValue(value: DataCloudflareSharesResultResources | undefined);
    get created(): string;
    get id(): string;
    get meta(): string;
    get modified(): string;
    get resourceAccountId(): string;
    get resourceId(): string;
    get resourceType(): string;
    get resourceVersion(): number;
    get status(): string;
}
export declare class DataCloudflareSharesResultResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareSharesResultResourcesOutputReference;
}
export interface DataCloudflareSharesResult {
}
export declare function dataCloudflareSharesResultToTerraform(struct?: DataCloudflareSharesResult): any;
export declare function dataCloudflareSharesResultToHclTerraform(struct?: DataCloudflareSharesResult): any;
export declare class DataCloudflareSharesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareSharesResult | undefined;
    set internalValue(value: DataCloudflareSharesResult | undefined);
    get accountId(): string;
    get accountName(): string;
    get associatedRecipientCount(): number;
    get associatingRecipientCount(): number;
    get created(): string;
    get disassociatedRecipientCount(): number;
    get disassociatingRecipientCount(): number;
    get id(): string;
    get kind(): string;
    get modified(): string;
    get name(): string;
    get organizationId(): string;
    private _resources;
    get resources(): DataCloudflareSharesResultResourcesList;
    get status(): string;
    get targetType(): string;
}
export declare class DataCloudflareSharesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareSharesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares cloudflare_shares}
*/
export declare class DataCloudflareShares extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_shares";
    /**
    * Generates CDKTN code for importing a DataCloudflareShares resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareShares to import
    * @param importFromId The id of the existing DataCloudflareShares that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareShares to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/shares cloudflare_shares} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSharesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareSharesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _includeRecipientCounts?;
    get includeRecipientCounts(): boolean | cdktn.IResolvable;
    set includeRecipientCounts(value: boolean | cdktn.IResolvable);
    resetIncludeRecipientCounts(): void;
    get includeRecipientCountsInput(): boolean | cdktn.IResolvable | undefined;
    private _includeResources?;
    get includeResources(): boolean | cdktn.IResolvable;
    set includeResources(value: boolean | cdktn.IResolvable);
    resetIncludeResources(): void;
    get includeResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
    private _result;
    get result(): DataCloudflareSharesResultList;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tag?;
    get tag(): string[];
    set tag(value: string[]);
    resetTag(): void;
    get tagInput(): string[] | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
