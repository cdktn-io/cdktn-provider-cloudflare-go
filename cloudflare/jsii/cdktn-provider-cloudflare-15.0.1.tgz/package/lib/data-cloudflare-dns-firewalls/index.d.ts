/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareDnsFirewallsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/dns_firewalls#account_id DataCloudflareDnsFirewalls#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/dns_firewalls#max_items DataCloudflareDnsFirewalls#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareDnsFirewallsResultAttackMitigation {
}
export declare function dataCloudflareDnsFirewallsResultAttackMitigationToTerraform(struct?: DataCloudflareDnsFirewallsResultAttackMitigation): any;
export declare function dataCloudflareDnsFirewallsResultAttackMitigationToHclTerraform(struct?: DataCloudflareDnsFirewallsResultAttackMitigation): any;
export declare class DataCloudflareDnsFirewallsResultAttackMitigationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsFirewallsResultAttackMitigation | undefined;
    set internalValue(value: DataCloudflareDnsFirewallsResultAttackMitigation | undefined);
    get enabled(): cdktn.IResolvable;
    get onlyWhenUpstreamUnhealthy(): cdktn.IResolvable;
}
export interface DataCloudflareDnsFirewallsResult {
}
export declare function dataCloudflareDnsFirewallsResultToTerraform(struct?: DataCloudflareDnsFirewallsResult): any;
export declare function dataCloudflareDnsFirewallsResultToHclTerraform(struct?: DataCloudflareDnsFirewallsResult): any;
export declare class DataCloudflareDnsFirewallsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareDnsFirewallsResult | undefined;
    set internalValue(value: DataCloudflareDnsFirewallsResult | undefined);
    private _attackMitigation;
    get attackMitigation(): DataCloudflareDnsFirewallsResultAttackMitigationOutputReference;
    get deprecateAnyRequests(): cdktn.IResolvable;
    get dnsFirewallIps(): string[];
    get ecsFallback(): cdktn.IResolvable;
    get id(): string;
    get maximumCacheTtl(): number;
    get minimumCacheTtl(): number;
    get modifiedOn(): string;
    get name(): string;
    get negativeCacheTtl(): number;
    get ratelimit(): number;
    get retries(): number;
    get upstreamIps(): string[];
}
export declare class DataCloudflareDnsFirewallsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareDnsFirewallsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/dns_firewalls cloudflare_dns_firewalls}
*/
export declare class DataCloudflareDnsFirewalls extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_dns_firewalls";
    /**
    * Generates CDKTN code for importing a DataCloudflareDnsFirewalls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareDnsFirewalls to import
    * @param importFromId The id of the existing DataCloudflareDnsFirewalls that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/dns_firewalls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareDnsFirewalls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/dns_firewalls cloudflare_dns_firewalls} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareDnsFirewallsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareDnsFirewallsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareDnsFirewallsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
