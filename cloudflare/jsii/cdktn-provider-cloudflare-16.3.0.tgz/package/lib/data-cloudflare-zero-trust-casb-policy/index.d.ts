/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCasbPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policy#account_id DataCloudflareZeroTrustCasbPolicy#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policy#policy_id DataCloudflareZeroTrustCasbPolicy#policy_id}
    */
    readonly policyId: string;
}
export interface DataCloudflareZeroTrustCasbPolicyActionsRemediationTypes {
}
export declare function dataCloudflareZeroTrustCasbPolicyActionsRemediationTypesToTerraform(struct?: DataCloudflareZeroTrustCasbPolicyActionsRemediationTypes): any;
export declare function dataCloudflareZeroTrustCasbPolicyActionsRemediationTypesToHclTerraform(struct?: DataCloudflareZeroTrustCasbPolicyActionsRemediationTypes): any;
export declare class DataCloudflareZeroTrustCasbPolicyActionsRemediationTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbPolicyActionsRemediationTypes | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbPolicyActionsRemediationTypes | undefined);
    get displayName(): string;
    get remediationType(): string;
    get remediationTypeId(): string;
}
export declare class DataCloudflareZeroTrustCasbPolicyActionsRemediationTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbPolicyActionsRemediationTypesOutputReference;
}
export interface DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigs {
}
export declare function dataCloudflareZeroTrustCasbPolicyActionsWebhookConfigsToTerraform(struct?: DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigs): any;
export declare function dataCloudflareZeroTrustCasbPolicyActionsWebhookConfigsToHclTerraform(struct?: DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigs): any;
export declare class DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigs | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigs | undefined);
    get displayName(): string;
    get webhookConfigId(): string;
}
export declare class DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigsOutputReference;
}
export interface DataCloudflareZeroTrustCasbPolicyActions {
}
export declare function dataCloudflareZeroTrustCasbPolicyActionsToTerraform(struct?: DataCloudflareZeroTrustCasbPolicyActions): any;
export declare function dataCloudflareZeroTrustCasbPolicyActionsToHclTerraform(struct?: DataCloudflareZeroTrustCasbPolicyActions): any;
export declare class DataCloudflareZeroTrustCasbPolicyActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCasbPolicyActions | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbPolicyActions | undefined);
    private _remediationTypes;
    get remediationTypes(): DataCloudflareZeroTrustCasbPolicyActionsRemediationTypesList;
    private _webhookConfigs;
    get webhookConfigs(): DataCloudflareZeroTrustCasbPolicyActionsWebhookConfigsList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policy cloudflare_zero_trust_casb_policy}
*/
export declare class DataCloudflareZeroTrustCasbPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_casb_policy";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCasbPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCasbPolicy to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCasbPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCasbPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policy cloudflare_zero_trust_casb_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCasbPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCasbPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _actions;
    get actions(): DataCloudflareZeroTrustCasbPolicyActionsOutputReference;
    get appliesToAllIntegrations(): cdktn.IResolvable;
    get createdAt(): string;
    get description(): string;
    get disabledAt(): string;
    get displayName(): string;
    get enabled(): cdktn.IResolvable;
    get findingTypeId(): string;
    get id(): string;
    get integrationIds(): string[];
    get lastTriggeredAt(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
