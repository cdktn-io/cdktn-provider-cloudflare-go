/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWaitingRoomConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room#waiting_room_id DataCloudflareWaitingRoom#waiting_room_id}
    */
    readonly waitingRoomId: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room#zone_id DataCloudflareWaitingRoom#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareWaitingRoomAdditionalRoutes {
}
export declare function dataCloudflareWaitingRoomAdditionalRoutesToTerraform(struct?: DataCloudflareWaitingRoomAdditionalRoutes): any;
export declare function dataCloudflareWaitingRoomAdditionalRoutesToHclTerraform(struct?: DataCloudflareWaitingRoomAdditionalRoutes): any;
export declare class DataCloudflareWaitingRoomAdditionalRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWaitingRoomAdditionalRoutes | undefined;
    set internalValue(value: DataCloudflareWaitingRoomAdditionalRoutes | undefined);
    get host(): string;
    get path(): string;
}
export declare class DataCloudflareWaitingRoomAdditionalRoutesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWaitingRoomAdditionalRoutesOutputReference;
}
export interface DataCloudflareWaitingRoomCookieAttributes {
}
export declare function dataCloudflareWaitingRoomCookieAttributesToTerraform(struct?: DataCloudflareWaitingRoomCookieAttributes): any;
export declare function dataCloudflareWaitingRoomCookieAttributesToHclTerraform(struct?: DataCloudflareWaitingRoomCookieAttributes): any;
export declare class DataCloudflareWaitingRoomCookieAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWaitingRoomCookieAttributes | undefined;
    set internalValue(value: DataCloudflareWaitingRoomCookieAttributes | undefined);
    get samesite(): string;
    get secure(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room cloudflare_waiting_room}
*/
export declare class DataCloudflareWaitingRoom extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_waiting_room";
    /**
    * Generates CDKTN code for importing a DataCloudflareWaitingRoom resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWaitingRoom to import
    * @param importFromId The id of the existing DataCloudflareWaitingRoom that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWaitingRoom to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room cloudflare_waiting_room} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWaitingRoomConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareWaitingRoomConfig);
    private _additionalRoutes;
    get additionalRoutes(): DataCloudflareWaitingRoomAdditionalRoutesList;
    private _cookieAttributes;
    get cookieAttributes(): DataCloudflareWaitingRoomCookieAttributesOutputReference;
    get cookieSuffix(): string;
    get createdOn(): string;
    get customPageHtml(): string;
    get defaultTemplateLanguage(): string;
    get description(): string;
    get disableSessionRenewal(): cdktn.IResolvable;
    get enabledOriginCommands(): string[];
    get host(): string;
    get id(): string;
    get jsonResponseEnabled(): cdktn.IResolvable;
    get modifiedOn(): string;
    get name(): string;
    get newUsersPerMinute(): number;
    get nextEventPrequeueStartTime(): string;
    get nextEventStartTime(): string;
    get path(): string;
    get queueAll(): cdktn.IResolvable;
    get queueingMethod(): string;
    get queueingStatusCode(): number;
    get sessionDuration(): number;
    get suspended(): cdktn.IResolvable;
    get totalActiveUsers(): number;
    get turnstileAction(): string;
    get turnstileMode(): string;
    private _waitingRoomId?;
    get waitingRoomId(): string;
    set waitingRoomId(value: string);
    get waitingRoomIdInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
