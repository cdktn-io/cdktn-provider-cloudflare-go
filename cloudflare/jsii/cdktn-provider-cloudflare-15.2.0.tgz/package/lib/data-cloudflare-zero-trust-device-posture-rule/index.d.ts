/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDevicePostureRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_rule#account_id DataCloudflareZeroTrustDevicePostureRule#account_id}
    */
    readonly accountId?: string;
    /**
    * API UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_rule#rule_id DataCloudflareZeroTrustDevicePostureRule#rule_id}
    */
    readonly ruleId: string;
}
export interface DataCloudflareZeroTrustDevicePostureRuleInputLocations {
}
export declare function dataCloudflareZeroTrustDevicePostureRuleInputLocationsToTerraform(struct?: DataCloudflareZeroTrustDevicePostureRuleInputLocations): any;
export declare function dataCloudflareZeroTrustDevicePostureRuleInputLocationsToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureRuleInputLocations): any;
export declare class DataCloudflareZeroTrustDevicePostureRuleInputLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDevicePostureRuleInputLocations | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureRuleInputLocations | undefined);
    get paths(): string[];
    get trustStores(): string[];
}
export interface DataCloudflareZeroTrustDevicePostureRuleInput {
}
export declare function dataCloudflareZeroTrustDevicePostureRuleInputToTerraform(struct?: DataCloudflareZeroTrustDevicePostureRuleInput): any;
export declare function dataCloudflareZeroTrustDevicePostureRuleInputToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureRuleInput): any;
export declare class DataCloudflareZeroTrustDevicePostureRuleInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDevicePostureRuleInput | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureRuleInput | undefined);
    get activeThreats(): number;
    get authState(): string[];
    get certificateId(): string;
    get checkDisks(): string[];
    get checkPrivateKey(): cdktn.IResolvable;
    get cn(): string;
    get complianceStatus(): string;
    get connectionId(): string;
    get countOperator(): string;
    get domain(): string;
    get eidLastSeen(): string;
    get enabled(): cdktn.IResolvable;
    get exists(): cdktn.IResolvable;
    get extendedKeyUsage(): string[];
    get id(): string;
    get infected(): cdktn.IResolvable;
    get isActive(): cdktn.IResolvable;
    get issueCount(): string;
    get lastSeen(): string;
    private _locations;
    get locations(): DataCloudflareZeroTrustDevicePostureRuleInputLocationsOutputReference;
    get networkStatus(): string;
    get operatingSystem(): string;
    get operationalState(): string;
    get operator(): string;
    get os(): string;
    get osDistroName(): string;
    get osDistroRevision(): string;
    get osVersionExtra(): string;
    get overall(): string;
    get path(): string;
    get requireAll(): cdktn.IResolvable;
    get riskLevel(): string;
    get score(): number;
    get scoreOperator(): string;
    get sensorConfig(): string;
    get sha256(): string;
    get state(): string;
    get subjectAlternativeNames(): string[];
    get thumbprint(): string;
    get totalScore(): number;
    get updateWindowDays(): number;
    get version(): string;
    get versionOperator(): string;
}
export interface DataCloudflareZeroTrustDevicePostureRuleMatch {
}
export declare function dataCloudflareZeroTrustDevicePostureRuleMatchToTerraform(struct?: DataCloudflareZeroTrustDevicePostureRuleMatch): any;
export declare function dataCloudflareZeroTrustDevicePostureRuleMatchToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureRuleMatch): any;
export declare class DataCloudflareZeroTrustDevicePostureRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDevicePostureRuleMatch | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureRuleMatch | undefined);
    get platform(): string;
}
export declare class DataCloudflareZeroTrustDevicePostureRuleMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDevicePostureRuleMatchOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_rule cloudflare_zero_trust_device_posture_rule}
*/
export declare class DataCloudflareZeroTrustDevicePostureRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_posture_rule";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDevicePostureRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDevicePostureRule to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDevicePostureRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDevicePostureRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_rule cloudflare_zero_trust_device_posture_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDevicePostureRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDevicePostureRuleConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get description(): string;
    get expiration(): string;
    get id(): string;
    private _input;
    get input(): DataCloudflareZeroTrustDevicePostureRuleInputOutputReference;
    private _match;
    get match(): DataCloudflareZeroTrustDevicePostureRuleMatchList;
    get name(): string;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
    get schedule(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
