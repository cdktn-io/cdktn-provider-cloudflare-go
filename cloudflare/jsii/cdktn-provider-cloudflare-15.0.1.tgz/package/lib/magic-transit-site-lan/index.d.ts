/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MagicTransitSiteLanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#account_id MagicTransitSiteLan#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#bond_id MagicTransitSiteLan#bond_id}
    */
    readonly bondId?: number;
    /**
    * mark true to use this LAN for HA probing. only works for site with HA turned on. only one LAN can be set as the ha_link.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#ha_link MagicTransitSiteLan#ha_link}
    */
    readonly haLink?: boolean | cdktn.IResolvable;
    /**
    * mark true to use this LAN for source-based breakout traffic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#is_breakout MagicTransitSiteLan#is_breakout}
    */
    readonly isBreakout?: boolean | cdktn.IResolvable;
    /**
    * mark true to use this LAN for source-based prioritized traffic
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#is_prioritized MagicTransitSiteLan#is_prioritized}
    */
    readonly isPrioritized?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#name MagicTransitSiteLan#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#nat MagicTransitSiteLan#nat}
    */
    readonly nat?: MagicTransitSiteLanNat;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#physport MagicTransitSiteLan#physport}
    */
    readonly physport?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#routed_subnets MagicTransitSiteLan#routed_subnets}
    */
    readonly routedSubnets?: MagicTransitSiteLanRoutedSubnets[] | cdktn.IResolvable;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#site_id MagicTransitSiteLan#site_id}
    */
    readonly siteId: string;
    /**
    * If the site is not configured in high availability mode, this configuration is optional (if omitted, use DHCP). However, if in high availability mode, static_address is required along with secondary and virtual address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#static_addressing MagicTransitSiteLan#static_addressing}
    */
    readonly staticAddressing?: MagicTransitSiteLanStaticAddressing;
    /**
    * VLAN ID. Use zero for untagged.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#vlan_tag MagicTransitSiteLan#vlan_tag}
    */
    readonly vlanTag?: number;
}
export interface MagicTransitSiteLanNat {
    /**
    * A valid CIDR notation representing an IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#static_prefix MagicTransitSiteLan#static_prefix}
    */
    readonly staticPrefix?: string;
}
export declare function magicTransitSiteLanNatToTerraform(struct?: MagicTransitSiteLanNat | cdktn.IResolvable): any;
export declare function magicTransitSiteLanNatToHclTerraform(struct?: MagicTransitSiteLanNat | cdktn.IResolvable): any;
export declare class MagicTransitSiteLanNatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteLanNat | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteLanNat | cdktn.IResolvable | undefined);
    private _staticPrefix?;
    get staticPrefix(): string;
    set staticPrefix(value: string);
    resetStaticPrefix(): void;
    get staticPrefixInput(): string | undefined;
}
export interface MagicTransitSiteLanRoutedSubnetsNat {
    /**
    * A valid CIDR notation representing an IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#static_prefix MagicTransitSiteLan#static_prefix}
    */
    readonly staticPrefix?: string;
}
export declare function magicTransitSiteLanRoutedSubnetsNatToTerraform(struct?: MagicTransitSiteLanRoutedSubnetsNat | cdktn.IResolvable): any;
export declare function magicTransitSiteLanRoutedSubnetsNatToHclTerraform(struct?: MagicTransitSiteLanRoutedSubnetsNat | cdktn.IResolvable): any;
export declare class MagicTransitSiteLanRoutedSubnetsNatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteLanRoutedSubnetsNat | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteLanRoutedSubnetsNat | cdktn.IResolvable | undefined);
    private _staticPrefix?;
    get staticPrefix(): string;
    set staticPrefix(value: string);
    resetStaticPrefix(): void;
    get staticPrefixInput(): string | undefined;
}
export interface MagicTransitSiteLanRoutedSubnets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#nat MagicTransitSiteLan#nat}
    */
    readonly nat?: MagicTransitSiteLanRoutedSubnetsNat;
    /**
    * A valid IPv4 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#next_hop MagicTransitSiteLan#next_hop}
    */
    readonly nextHop: string;
    /**
    * A valid CIDR notation representing an IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#prefix MagicTransitSiteLan#prefix}
    */
    readonly prefix: string;
}
export declare function magicTransitSiteLanRoutedSubnetsToTerraform(struct?: MagicTransitSiteLanRoutedSubnets | cdktn.IResolvable): any;
export declare function magicTransitSiteLanRoutedSubnetsToHclTerraform(struct?: MagicTransitSiteLanRoutedSubnets | cdktn.IResolvable): any;
export declare class MagicTransitSiteLanRoutedSubnetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MagicTransitSiteLanRoutedSubnets | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteLanRoutedSubnets | cdktn.IResolvable | undefined);
    private _nat;
    get nat(): MagicTransitSiteLanRoutedSubnetsNatOutputReference;
    putNat(value: MagicTransitSiteLanRoutedSubnetsNat): void;
    resetNat(): void;
    get natInput(): cdktn.IResolvable | MagicTransitSiteLanRoutedSubnetsNat | undefined;
    private _nextHop?;
    get nextHop(): string;
    set nextHop(value: string);
    get nextHopInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
}
export declare class MagicTransitSiteLanRoutedSubnetsList extends cdktn.ComplexList {
    internalValue?: MagicTransitSiteLanRoutedSubnets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MagicTransitSiteLanRoutedSubnetsOutputReference;
}
export interface MagicTransitSiteLanStaticAddressingDhcpRelay {
    /**
    * List of DHCP server IPs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#server_addresses MagicTransitSiteLan#server_addresses}
    */
    readonly serverAddresses?: string[];
}
export declare function magicTransitSiteLanStaticAddressingDhcpRelayToTerraform(struct?: MagicTransitSiteLanStaticAddressingDhcpRelay | cdktn.IResolvable): any;
export declare function magicTransitSiteLanStaticAddressingDhcpRelayToHclTerraform(struct?: MagicTransitSiteLanStaticAddressingDhcpRelay | cdktn.IResolvable): any;
export declare class MagicTransitSiteLanStaticAddressingDhcpRelayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteLanStaticAddressingDhcpRelay | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteLanStaticAddressingDhcpRelay | cdktn.IResolvable | undefined);
    private _serverAddresses?;
    get serverAddresses(): string[];
    set serverAddresses(value: string[]);
    resetServerAddresses(): void;
    get serverAddressesInput(): string[] | undefined;
}
export interface MagicTransitSiteLanStaticAddressingDhcpServer {
    /**
    * A valid IPv4 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#dhcp_pool_end MagicTransitSiteLan#dhcp_pool_end}
    */
    readonly dhcpPoolEnd?: string;
    /**
    * A valid IPv4 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#dhcp_pool_start MagicTransitSiteLan#dhcp_pool_start}
    */
    readonly dhcpPoolStart?: string;
    /**
    * A valid IPv4 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#dns_server MagicTransitSiteLan#dns_server}
    */
    readonly dnsServer?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#dns_servers MagicTransitSiteLan#dns_servers}
    */
    readonly dnsServers?: string[];
    /**
    * Mapping of MAC addresses to IP addresses
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#reservations MagicTransitSiteLan#reservations}
    */
    readonly reservations?: {
        [key: string]: string;
    };
}
export declare function magicTransitSiteLanStaticAddressingDhcpServerToTerraform(struct?: MagicTransitSiteLanStaticAddressingDhcpServer | cdktn.IResolvable): any;
export declare function magicTransitSiteLanStaticAddressingDhcpServerToHclTerraform(struct?: MagicTransitSiteLanStaticAddressingDhcpServer | cdktn.IResolvable): any;
export declare class MagicTransitSiteLanStaticAddressingDhcpServerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteLanStaticAddressingDhcpServer | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteLanStaticAddressingDhcpServer | cdktn.IResolvable | undefined);
    private _dhcpPoolEnd?;
    get dhcpPoolEnd(): string;
    set dhcpPoolEnd(value: string);
    resetDhcpPoolEnd(): void;
    get dhcpPoolEndInput(): string | undefined;
    private _dhcpPoolStart?;
    get dhcpPoolStart(): string;
    set dhcpPoolStart(value: string);
    resetDhcpPoolStart(): void;
    get dhcpPoolStartInput(): string | undefined;
    private _dnsServer?;
    get dnsServer(): string;
    set dnsServer(value: string);
    resetDnsServer(): void;
    get dnsServerInput(): string | undefined;
    private _dnsServers?;
    get dnsServers(): string[];
    set dnsServers(value: string[]);
    resetDnsServers(): void;
    get dnsServersInput(): string[] | undefined;
    private _reservations?;
    get reservations(): {
        [key: string]: string;
    };
    set reservations(value: {
        [key: string]: string;
    });
    resetReservations(): void;
    get reservationsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface MagicTransitSiteLanStaticAddressing {
    /**
    * A valid CIDR notation representing an IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#address MagicTransitSiteLan#address}
    */
    readonly address: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#dhcp_relay MagicTransitSiteLan#dhcp_relay}
    */
    readonly dhcpRelay?: MagicTransitSiteLanStaticAddressingDhcpRelay;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#dhcp_server MagicTransitSiteLan#dhcp_server}
    */
    readonly dhcpServer?: MagicTransitSiteLanStaticAddressingDhcpServer;
    /**
    * A valid CIDR notation representing an IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#secondary_address MagicTransitSiteLan#secondary_address}
    */
    readonly secondaryAddress?: string;
    /**
    * A valid CIDR notation representing an IP range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#virtual_address MagicTransitSiteLan#virtual_address}
    */
    readonly virtualAddress?: string;
}
export declare function magicTransitSiteLanStaticAddressingToTerraform(struct?: MagicTransitSiteLanStaticAddressing | cdktn.IResolvable): any;
export declare function magicTransitSiteLanStaticAddressingToHclTerraform(struct?: MagicTransitSiteLanStaticAddressing | cdktn.IResolvable): any;
export declare class MagicTransitSiteLanStaticAddressingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteLanStaticAddressing | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteLanStaticAddressing | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _dhcpRelay;
    get dhcpRelay(): MagicTransitSiteLanStaticAddressingDhcpRelayOutputReference;
    putDhcpRelay(value: MagicTransitSiteLanStaticAddressingDhcpRelay): void;
    resetDhcpRelay(): void;
    get dhcpRelayInput(): cdktn.IResolvable | MagicTransitSiteLanStaticAddressingDhcpRelay | undefined;
    private _dhcpServer;
    get dhcpServer(): MagicTransitSiteLanStaticAddressingDhcpServerOutputReference;
    putDhcpServer(value: MagicTransitSiteLanStaticAddressingDhcpServer): void;
    resetDhcpServer(): void;
    get dhcpServerInput(): cdktn.IResolvable | MagicTransitSiteLanStaticAddressingDhcpServer | undefined;
    private _secondaryAddress?;
    get secondaryAddress(): string;
    set secondaryAddress(value: string);
    resetSecondaryAddress(): void;
    get secondaryAddressInput(): string | undefined;
    private _virtualAddress?;
    get virtualAddress(): string;
    set virtualAddress(value: string);
    resetVirtualAddress(): void;
    get virtualAddressInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan cloudflare_magic_transit_site_lan}
*/
export declare class MagicTransitSiteLan extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_magic_transit_site_lan";
    /**
    * Generates CDKTN code for importing a MagicTransitSiteLan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MagicTransitSiteLan to import
    * @param importFromId The id of the existing MagicTransitSiteLan that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MagicTransitSiteLan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/magic_transit_site_lan cloudflare_magic_transit_site_lan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MagicTransitSiteLanConfig
    */
    constructor(scope: Construct, id: string, config: MagicTransitSiteLanConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _bondId?;
    get bondId(): number;
    set bondId(value: number);
    resetBondId(): void;
    get bondIdInput(): number | undefined;
    private _haLink?;
    get haLink(): boolean | cdktn.IResolvable;
    set haLink(value: boolean | cdktn.IResolvable);
    resetHaLink(): void;
    get haLinkInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _isBreakout?;
    get isBreakout(): boolean | cdktn.IResolvable;
    set isBreakout(value: boolean | cdktn.IResolvable);
    resetIsBreakout(): void;
    get isBreakoutInput(): boolean | cdktn.IResolvable | undefined;
    private _isPrioritized?;
    get isPrioritized(): boolean | cdktn.IResolvable;
    set isPrioritized(value: boolean | cdktn.IResolvable);
    resetIsPrioritized(): void;
    get isPrioritizedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nat;
    get nat(): MagicTransitSiteLanNatOutputReference;
    putNat(value: MagicTransitSiteLanNat): void;
    resetNat(): void;
    get natInput(): cdktn.IResolvable | MagicTransitSiteLanNat | undefined;
    private _physport?;
    get physport(): number;
    set physport(value: number);
    resetPhysport(): void;
    get physportInput(): number | undefined;
    private _routedSubnets;
    get routedSubnets(): MagicTransitSiteLanRoutedSubnetsList;
    putRoutedSubnets(value: MagicTransitSiteLanRoutedSubnets[] | cdktn.IResolvable): void;
    resetRoutedSubnets(): void;
    get routedSubnetsInput(): cdktn.IResolvable | MagicTransitSiteLanRoutedSubnets[] | undefined;
    private _siteId?;
    get siteId(): string;
    set siteId(value: string);
    get siteIdInput(): string | undefined;
    private _staticAddressing;
    get staticAddressing(): MagicTransitSiteLanStaticAddressingOutputReference;
    putStaticAddressing(value: MagicTransitSiteLanStaticAddressing): void;
    resetStaticAddressing(): void;
    get staticAddressingInput(): cdktn.IResolvable | MagicTransitSiteLanStaticAddressing | undefined;
    private _vlanTag?;
    get vlanTag(): number;
    set vlanTag(value: number);
    resetVlanTag(): void;
    get vlanTagInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
