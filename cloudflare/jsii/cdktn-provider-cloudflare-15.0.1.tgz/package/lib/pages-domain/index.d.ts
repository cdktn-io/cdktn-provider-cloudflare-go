/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PagesDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/pages_domain#account_id PagesDomain#account_id}
    */
    readonly accountId?: string;
    /**
    * The domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/pages_domain#name PagesDomain#name}
    */
    readonly name: string;
    /**
    * Name of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/pages_domain#project_name PagesDomain#project_name}
    */
    readonly projectName: string;
}
export interface PagesDomainValidationData {
}
export declare function pagesDomainValidationDataToTerraform(struct?: PagesDomainValidationData): any;
export declare function pagesDomainValidationDataToHclTerraform(struct?: PagesDomainValidationData): any;
export declare class PagesDomainValidationDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesDomainValidationData | undefined;
    set internalValue(value: PagesDomainValidationData | undefined);
    get errorMessage(): string;
    get method(): string;
    get status(): string;
    get txtName(): string;
    get txtValue(): string;
}
export interface PagesDomainVerificationData {
}
export declare function pagesDomainVerificationDataToTerraform(struct?: PagesDomainVerificationData): any;
export declare function pagesDomainVerificationDataToHclTerraform(struct?: PagesDomainVerificationData): any;
export declare class PagesDomainVerificationDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesDomainVerificationData | undefined;
    set internalValue(value: PagesDomainVerificationData | undefined);
    get errorMessage(): string;
    get status(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/pages_domain cloudflare_pages_domain}
*/
export declare class PagesDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_pages_domain";
    /**
    * Generates CDKTN code for importing a PagesDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PagesDomain to import
    * @param importFromId The id of the existing PagesDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/pages_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PagesDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/pages_domain cloudflare_pages_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PagesDomainConfig
    */
    constructor(scope: Construct, id: string, config: PagesDomainConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get certificateAuthority(): string;
    get createdOn(): string;
    get domainId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    get status(): string;
    private _validationData;
    get validationData(): PagesDomainValidationDataOutputReference;
    private _verificationData;
    get verificationData(): PagesDomainVerificationDataOutputReference;
    get zoneTag(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
