/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustGatewayPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_gateway_policies#account_id DataCloudflareZeroTrustGatewayPolicies#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_gateway_policies#max_items DataCloudflareZeroTrustGatewayPolicies#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultExpiration {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultExpirationToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultExpiration): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultExpirationToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultExpiration): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultExpirationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultExpiration | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultExpiration | undefined);
    get duration(): number;
    get expired(): cdktn.IResolvable;
    get expiresAt(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSsh {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSshToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSsh): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSshToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSsh): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSshOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSsh | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSsh | undefined);
    get commandLogging(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControls {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControlsToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControls): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControlsToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControls): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControls | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControls | undefined);
    get copy(): string;
    get dcp(): cdktn.IResolvable;
    get dd(): cdktn.IResolvable;
    get dk(): cdktn.IResolvable;
    get download(): string;
    get dp(): cdktn.IResolvable;
    get du(): cdktn.IResolvable;
    get keyboard(): string;
    get paste(): string;
    get printing(): string;
    get upload(): string;
    get version(): string;
    get wmId(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPage {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPageToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPage): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPageToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPage): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPage | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPage | undefined);
    get includeContext(): cdktn.IResolvable;
    get targetUri(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSession {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSessionToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSession): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSessionToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSession): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSessionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSession | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSession | undefined);
    get duration(): string;
    get enforce(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4 {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4ToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4ToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4 | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4 | undefined);
    get ip(): string;
    get port(): number;
    get routeThroughPrivateNetwork(): cdktn.IResolvable;
    get vnetId(): string;
}
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4List extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4OutputReference;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6 {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6ToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6ToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6 | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6 | undefined);
    get ip(): string;
    get port(): number;
    get routeThroughPrivateNetwork(): cdktn.IResolvable;
    get vnetId(): string;
}
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6List extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6OutputReference;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolvers {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolvers): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolvers): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolvers | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolvers | undefined);
    private _ipv4;
    get ipv4(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv4List;
    private _ipv6;
    get ipv6(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversIpv6List;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgress {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgressToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgress): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgressToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgress): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgress | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgress | undefined);
    get ipv4(): string;
    get ipv4Fallback(): string;
    get ipv6(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopy {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopyToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopy): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopyToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopy): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopy | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopy | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4Override {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4OverrideToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4Override): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4OverrideToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4Override): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4OverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4Override | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4Override | undefined);
    get ip(): string;
    get port(): number;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettings {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettingsToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettings): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettingsToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettings): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettings | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettings | undefined);
    get enabled(): cdktn.IResolvable;
    get includeContext(): cdktn.IResolvable;
    get msg(): string;
    get supportUrl(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLog {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLogToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLog): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLogToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLog): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLog | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLog | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantine {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantineToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantine): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantineToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantine): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantine | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantine | undefined);
    get fileTypes(): string[];
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirect {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirectToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirect): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirectToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirect): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirect | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirect | undefined);
    get includeContext(): cdktn.IResolvable;
    get preservePathAndQuery(): cdktn.IResolvable;
    get targetUri(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternally {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternallyToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternally): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternallyToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternally): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternallyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternally | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternally | undefined);
    get fallback(): string;
    get viewId(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCert {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCertToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCert): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCertToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCert): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCert | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCert | undefined);
    get action(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultRuleSettings {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettings): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettings): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettings | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultRuleSettings | undefined);
    private _addHeaders;
    get addHeaders(): cdktn.StringListMap;
    get allowChildBypass(): cdktn.IResolvable;
    private _auditSsh;
    get auditSsh(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsAuditSshOutputReference;
    private _bisoAdminControls;
    get bisoAdminControls(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBisoAdminControlsOutputReference;
    private _blockPage;
    get blockPage(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsBlockPageOutputReference;
    get blockPageEnabled(): cdktn.IResolvable;
    get blockReason(): string;
    get bypassParentRule(): cdktn.IResolvable;
    private _checkSession;
    get checkSession(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsCheckSessionOutputReference;
    get deleteHeaders(): string[];
    private _dnsResolvers;
    get dnsResolvers(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsDnsResolversOutputReference;
    private _egress;
    get egress(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsEgressOutputReference;
    private _forensicCopy;
    get forensicCopy(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsForensicCopyOutputReference;
    get ignoreCnameCategoryMatches(): cdktn.IResolvable;
    get insecureDisableDnssecValidation(): cdktn.IResolvable;
    get ipCategories(): cdktn.IResolvable;
    get ipIndicatorFeeds(): cdktn.IResolvable;
    private _l4Override;
    get l4Override(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsL4OverrideOutputReference;
    private _notificationSettings;
    get notificationSettings(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsNotificationSettingsOutputReference;
    get overrideHost(): string;
    get overrideIps(): string[];
    private _payloadLog;
    get payloadLog(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsPayloadLogOutputReference;
    private _quarantine;
    get quarantine(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsQuarantineOutputReference;
    private _redirect;
    get redirect(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsRedirectOutputReference;
    private _resolveDnsInternally;
    get resolveDnsInternally(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsResolveDnsInternallyOutputReference;
    get resolveDnsThroughCloudflare(): cdktn.IResolvable;
    private _setHeaders;
    get setHeaders(): cdktn.StringListMap;
    private _untrustedCert;
    get untrustedCert(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsUntrustedCertOutputReference;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResultSchedule {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultScheduleToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultSchedule): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultScheduleToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResultSchedule): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResultSchedule | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResultSchedule | undefined);
    get fri(): string;
    get mon(): string;
    get sat(): string;
    get sun(): string;
    get thu(): string;
    get timeZone(): string;
    get tue(): string;
    get wed(): string;
}
export interface DataCloudflareZeroTrustGatewayPoliciesResult {
}
export declare function dataCloudflareZeroTrustGatewayPoliciesResultToTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResult): any;
export declare function dataCloudflareZeroTrustGatewayPoliciesResultToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPoliciesResult): any;
export declare class DataCloudflareZeroTrustGatewayPoliciesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustGatewayPoliciesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPoliciesResult | undefined);
    get action(): string;
    get createdAt(): string;
    get deletedAt(): string;
    get description(): string;
    get devicePosture(): string;
    get enabled(): cdktn.IResolvable;
    private _expiration;
    get expiration(): DataCloudflareZeroTrustGatewayPoliciesResultExpirationOutputReference;
    get filters(): string[];
    get id(): string;
    get identity(): string;
    get name(): string;
    get precedence(): number;
    get readOnly(): cdktn.IResolvable;
    private _ruleSettings;
    get ruleSettings(): DataCloudflareZeroTrustGatewayPoliciesResultRuleSettingsOutputReference;
    private _schedule;
    get schedule(): DataCloudflareZeroTrustGatewayPoliciesResultScheduleOutputReference;
    get sharable(): cdktn.IResolvable;
    get sourceAccount(): string;
    get traffic(): string;
    get updatedAt(): string;
    get version(): number;
    get warningStatus(): string;
}
export declare class DataCloudflareZeroTrustGatewayPoliciesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustGatewayPoliciesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_gateway_policies cloudflare_zero_trust_gateway_policies}
*/
export declare class DataCloudflareZeroTrustGatewayPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_gateway_policies";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustGatewayPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustGatewayPolicies to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustGatewayPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_gateway_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustGatewayPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_gateway_policies cloudflare_zero_trust_gateway_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustGatewayPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustGatewayPoliciesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustGatewayPoliciesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
