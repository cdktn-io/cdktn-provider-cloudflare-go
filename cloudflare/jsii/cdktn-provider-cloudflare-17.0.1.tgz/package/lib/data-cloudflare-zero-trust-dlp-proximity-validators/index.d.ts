/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpProximityValidatorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validators#account_id DataCloudflareZeroTrustDlpProximityValidators#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validators#max_items DataCloudflareZeroTrustDlpProximityValidators#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntries {
}
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntriesToTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntries): any;
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntriesToHclTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntries): any;
export declare class DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntries | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntries | undefined);
    get id(): string;
    get name(): string;
    get type(): string;
}
export declare class DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntriesOutputReference;
}
export interface DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedBy {
}
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByToTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedBy): any;
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByToHclTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedBy): any;
export declare class DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedBy | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedBy | undefined);
    private _entries;
    get entries(): DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByEntriesList;
    get entryCount(): number;
}
export interface DataCloudflareZeroTrustDlpProximityValidatorsResultWords {
}
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultWordsToTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResultWords): any;
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultWordsToHclTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResultWords): any;
export declare class DataCloudflareZeroTrustDlpProximityValidatorsResultWordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpProximityValidatorsResultWords | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpProximityValidatorsResultWords | undefined);
    get weight(): string;
    get word(): string;
}
export declare class DataCloudflareZeroTrustDlpProximityValidatorsResultWordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpProximityValidatorsResultWordsOutputReference;
}
export interface DataCloudflareZeroTrustDlpProximityValidatorsResult {
}
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultToTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResult): any;
export declare function dataCloudflareZeroTrustDlpProximityValidatorsResultToHclTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorsResult): any;
export declare class DataCloudflareZeroTrustDlpProximityValidatorsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpProximityValidatorsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpProximityValidatorsResult | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    private _referencedBy;
    get referencedBy(): DataCloudflareZeroTrustDlpProximityValidatorsResultReferencedByOutputReference;
    get updatedAt(): string;
    private _words;
    get words(): DataCloudflareZeroTrustDlpProximityValidatorsResultWordsList;
}
export declare class DataCloudflareZeroTrustDlpProximityValidatorsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpProximityValidatorsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validators cloudflare_zero_trust_dlp_proximity_validators}
*/
export declare class DataCloudflareZeroTrustDlpProximityValidators extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_proximity_validators";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpProximityValidators resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpProximityValidators to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpProximityValidators that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validators#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpProximityValidators to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validators cloudflare_zero_trust_dlp_proximity_validators} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpProximityValidatorsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpProximityValidatorsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDlpProximityValidatorsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
