/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareHyperdriveConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Define configurations using a unique string identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/hyperdrive_config#account_id DataCloudflareHyperdriveConfig#account_id}
    */
    readonly accountId?: string;
    /**
    * Define configurations using a unique string identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/hyperdrive_config#hyperdrive_id DataCloudflareHyperdriveConfig#hyperdrive_id}
    */
    readonly hyperdriveId: string;
}
export interface DataCloudflareHyperdriveConfigCaching {
}
export declare function dataCloudflareHyperdriveConfigCachingToTerraform(struct?: DataCloudflareHyperdriveConfigCaching): any;
export declare function dataCloudflareHyperdriveConfigCachingToHclTerraform(struct?: DataCloudflareHyperdriveConfigCaching): any;
export declare class DataCloudflareHyperdriveConfigCachingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareHyperdriveConfigCaching | undefined;
    set internalValue(value: DataCloudflareHyperdriveConfigCaching | undefined);
    get disabled(): cdktn.IResolvable;
    get maxAge(): number;
    get staleWhileRevalidate(): number;
}
export interface DataCloudflareHyperdriveConfigMtls {
}
export declare function dataCloudflareHyperdriveConfigMtlsToTerraform(struct?: DataCloudflareHyperdriveConfigMtls): any;
export declare function dataCloudflareHyperdriveConfigMtlsToHclTerraform(struct?: DataCloudflareHyperdriveConfigMtls): any;
export declare class DataCloudflareHyperdriveConfigMtlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareHyperdriveConfigMtls | undefined;
    set internalValue(value: DataCloudflareHyperdriveConfigMtls | undefined);
    get caCertificateId(): string;
    get mtlsCertificateId(): string;
    get sslmode(): string;
}
export interface DataCloudflareHyperdriveConfigOrigin {
}
export declare function dataCloudflareHyperdriveConfigOriginToTerraform(struct?: DataCloudflareHyperdriveConfigOrigin): any;
export declare function dataCloudflareHyperdriveConfigOriginToHclTerraform(struct?: DataCloudflareHyperdriveConfigOrigin): any;
export declare class DataCloudflareHyperdriveConfigOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareHyperdriveConfigOrigin | undefined;
    set internalValue(value: DataCloudflareHyperdriveConfigOrigin | undefined);
    get accessClientId(): string;
    get accessClientSecret(): string;
    get database(): string;
    get host(): string;
    get password(): string;
    get port(): number;
    get scheme(): string;
    get serviceId(): string;
    get user(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/hyperdrive_config cloudflare_hyperdrive_config}
*/
export declare class DataCloudflareHyperdriveConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_hyperdrive_config";
    /**
    * Generates CDKTN code for importing a DataCloudflareHyperdriveConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareHyperdriveConfig to import
    * @param importFromId The id of the existing DataCloudflareHyperdriveConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/hyperdrive_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareHyperdriveConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/hyperdrive_config cloudflare_hyperdrive_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareHyperdriveConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareHyperdriveConfigConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _caching;
    get caching(): DataCloudflareHyperdriveConfigCachingOutputReference;
    get createdOn(): string;
    private _hyperdriveId?;
    get hyperdriveId(): string;
    set hyperdriveId(value: string);
    get hyperdriveIdInput(): string | undefined;
    get id(): string;
    get modifiedOn(): string;
    private _mtls;
    get mtls(): DataCloudflareHyperdriveConfigMtlsOutputReference;
    get name(): string;
    private _origin;
    get origin(): DataCloudflareHyperdriveConfigOriginOutputReference;
    get originConnectionLimit(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
