/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotificationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#account_id NotificationPolicy#account_id}
    */
    readonly accountId: string;
    /**
    * Optional specification of how often to re-alert from the same incident, not support on all alert types.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#alert_interval NotificationPolicy#alert_interval}
    */
    readonly alertInterval?: string;
    /**
    * Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values.
    * Available values: "abuse_report_alert", "access_custom_certificate_expiration_type", "advanced_ddos_attack_l4_alert", "advanced_ddos_attack_l7_alert", "advanced_http_alert_error", "bgp_hijack_notification", "billing_usage_alert", "block_notification_block_removed", "block_notification_new_block", "block_notification_review_rejected", "bot_traffic_basic_alert", "brand_protection_alert", "brand_protection_digest", "clickhouse_alert_fw_anomaly", "clickhouse_alert_fw_ent_anomaly", "cloudforce_one_request_notification", "custom_analytics", "custom_bot_detection_alert", "custom_ssl_certificate_event_type", "dedicated_ssl_certificate_event_type", "device_connectivity_anomaly_alert", "dos_attack_l4", "dos_attack_l7", "expiring_service_token_alert", "failing_logpush_job_disabled_alert", "fbm_auto_advertisement", "fbm_dosd_attack", "fbm_volumetric_attack", "health_check_status_notification", "hostname_aop_custom_certificate_expiration_type", "http_alert_edge_error", "http_alert_origin_error", "image_notification", "image_resizing_notification", "incident_alert", "load_balancing_health_alert", "load_balancing_pool_enablement_alert", "logo_match_alert", "magic_tunnel_health_check_event", "magic_wan_tunnel_health", "maintenance_event_notification", "mtls_certificate_store_certificate_expiration_type", "pages_event_alert", "radar_notification", "real_origin_monitoring", "scriptmonitor_alert_new_code_change_detections", "scriptmonitor_alert_new_hosts", "scriptmonitor_alert_new_malicious_hosts", "scriptmonitor_alert_new_malicious_scripts", "scriptmonitor_alert_new_malicious_url", "scriptmonitor_alert_new_max_length_resource_url", "scriptmonitor_alert_new_resources", "secondary_dns_all_primaries_failing", "secondary_dns_primaries_failing", "secondary_dns_warning", "secondary_dns_zone_successfully_updated", "secondary_dns_zone_validation_warning", "security_insights_alert", "sentinel_alert", "stream_live_notifications", "synthetic_test_latency_alert", "synthetic_test_low_availability_alert", "traffic_anomalies_alert", "tunnel_health_event", "tunnel_update_event", "universal_ssl_event_type", "web_analytics_metrics_update", "zone_aop_custom_certificate_expiration_type".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#alert_type NotificationPolicy#alert_type}
    */
    readonly alertType: string;
    /**
    * Optional description for the Notification policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#description NotificationPolicy#description}
    */
    readonly description?: string;
    /**
    * Whether or not the Notification policy is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#enabled NotificationPolicy#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#filters NotificationPolicy#filters}
    */
    readonly filters?: NotificationPolicyFilters;
    /**
    * List of IDs that will be used when dispatching a notification. IDs for email type will be the email address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#mechanisms NotificationPolicy#mechanisms}
    */
    readonly mechanisms: NotificationPolicyMechanisms;
    /**
    * Name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#name NotificationPolicy#name}
    */
    readonly name: string;
}
export interface NotificationPolicyFilters {
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#actions NotificationPolicy#actions}
    */
    readonly actions?: string[];
    /**
    * Used for configuring radar_notification
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#affected_asns NotificationPolicy#affected_asns}
    */
    readonly affectedAsns?: string[];
    /**
    * Used for configuring incident_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#affected_components NotificationPolicy#affected_components}
    */
    readonly affectedComponents?: string[];
    /**
    * Used for configuring radar_notification
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#affected_locations NotificationPolicy#affected_locations}
    */
    readonly affectedLocations?: string[];
    /**
    * Used for configuring maintenance_event_notification
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#airport_code NotificationPolicy#airport_code}
    */
    readonly airportCode?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#alert_trigger_preferences NotificationPolicy#alert_trigger_preferences}
    */
    readonly alertTriggerPreferences?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#alert_trigger_preferences_value NotificationPolicy#alert_trigger_preferences_value}
    */
    readonly alertTriggerPreferencesValue?: string[];
    /**
    * Used for configuring load_balancing_pool_enablement_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#enabled NotificationPolicy#enabled}
    */
    readonly enabled?: string[];
    /**
    * Used for configuring pages_event_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#environment NotificationPolicy#environment}
    */
    readonly environment?: string[];
    /**
    * Used for configuring pages_event_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#event NotificationPolicy#event}
    */
    readonly event?: string[];
    /**
    * Used for configuring load_balancing_health_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#event_source NotificationPolicy#event_source}
    */
    readonly eventSource?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#event_type NotificationPolicy#event_type}
    */
    readonly eventType?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#group_by NotificationPolicy#group_by}
    */
    readonly groupBy?: string[];
    /**
    * Used for configuring health_check_status_notification
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#health_check_id NotificationPolicy#health_check_id}
    */
    readonly healthCheckId?: string[];
    /**
    * Used for configuring incident_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#incident_impact NotificationPolicy#incident_impact}
    */
    readonly incidentImpact?: string[];
    /**
    * Used for configuring stream_live_notifications
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#input_id NotificationPolicy#input_id}
    */
    readonly inputId?: string[];
    /**
    * Used for configuring security_insights_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#insight_class NotificationPolicy#insight_class}
    */
    readonly insightClass?: string[];
    /**
    * Used for configuring billing_usage_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#limit NotificationPolicy#limit}
    */
    readonly limit?: string[];
    /**
    * Used for configuring logo_match_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#logo_tag NotificationPolicy#logo_tag}
    */
    readonly logoTag?: string[];
    /**
    * Used for configuring advanced_ddos_attack_l4_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#megabits_per_second NotificationPolicy#megabits_per_second}
    */
    readonly megabitsPerSecond?: string[];
    /**
    * Used for configuring load_balancing_health_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#new_health NotificationPolicy#new_health}
    */
    readonly newHealth?: string[];
    /**
    * Used for configuring tunnel_health_event
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#new_status NotificationPolicy#new_status}
    */
    readonly newStatus?: string[];
    /**
    * Used for configuring advanced_ddos_attack_l4_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#packets_per_second NotificationPolicy#packets_per_second}
    */
    readonly packetsPerSecond?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#pool_id NotificationPolicy#pool_id}
    */
    readonly poolId?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#pop_names NotificationPolicy#pop_names}
    */
    readonly popNames?: string[];
    /**
    * Used for configuring billing_usage_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#product NotificationPolicy#product}
    */
    readonly product?: string[];
    /**
    * Used for configuring pages_event_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#project_id NotificationPolicy#project_id}
    */
    readonly projectId?: string[];
    /**
    * Used for configuring advanced_ddos_attack_l4_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#protocol NotificationPolicy#protocol}
    */
    readonly protocol?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#query_tag NotificationPolicy#query_tag}
    */
    readonly queryTag?: string[];
    /**
    * Used for configuring advanced_ddos_attack_l7_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#requests_per_second NotificationPolicy#requests_per_second}
    */
    readonly requestsPerSecond?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#selectors NotificationPolicy#selectors}
    */
    readonly selectors?: string[];
    /**
    * Used for configuring clickhouse_alert_fw_ent_anomaly
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#services NotificationPolicy#services}
    */
    readonly services?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#slo NotificationPolicy#slo}
    */
    readonly slo?: string[];
    /**
    * Used for configuring health_check_status_notification
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#status NotificationPolicy#status}
    */
    readonly status?: string[];
    /**
    * Used for configuring advanced_ddos_attack_l7_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#target_hostname NotificationPolicy#target_hostname}
    */
    readonly targetHostname?: string[];
    /**
    * Used for configuring advanced_ddos_attack_l4_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#target_ip NotificationPolicy#target_ip}
    */
    readonly targetIp?: string[];
    /**
    * Used for configuring advanced_ddos_attack_l7_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#target_zone_name NotificationPolicy#target_zone_name}
    */
    readonly targetZoneName?: string[];
    /**
    * Used for configuring traffic_anomalies_alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#traffic_exclusions NotificationPolicy#traffic_exclusions}
    */
    readonly trafficExclusions?: string[];
    /**
    * Used for configuring tunnel_health_event
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#tunnel_id NotificationPolicy#tunnel_id}
    */
    readonly tunnelId?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#tunnel_name NotificationPolicy#tunnel_name}
    */
    readonly tunnelName?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#type NotificationPolicy#type}
    */
    readonly type?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#where NotificationPolicy#where}
    */
    readonly where?: string[];
    /**
    * Usage depends on specific alert type
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#zones NotificationPolicy#zones}
    */
    readonly zones?: string[];
}
export declare function notificationPolicyFiltersToTerraform(struct?: NotificationPolicyFilters | cdktn.IResolvable): any;
export declare function notificationPolicyFiltersToHclTerraform(struct?: NotificationPolicyFilters | cdktn.IResolvable): any;
export declare class NotificationPolicyFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationPolicyFilters | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyFilters | cdktn.IResolvable | undefined);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    resetActions(): void;
    get actionsInput(): string[] | undefined;
    private _affectedAsns?;
    get affectedAsns(): string[];
    set affectedAsns(value: string[]);
    resetAffectedAsns(): void;
    get affectedAsnsInput(): string[] | undefined;
    private _affectedComponents?;
    get affectedComponents(): string[];
    set affectedComponents(value: string[]);
    resetAffectedComponents(): void;
    get affectedComponentsInput(): string[] | undefined;
    private _affectedLocations?;
    get affectedLocations(): string[];
    set affectedLocations(value: string[]);
    resetAffectedLocations(): void;
    get affectedLocationsInput(): string[] | undefined;
    private _airportCode?;
    get airportCode(): string[];
    set airportCode(value: string[]);
    resetAirportCode(): void;
    get airportCodeInput(): string[] | undefined;
    private _alertTriggerPreferences?;
    get alertTriggerPreferences(): string[];
    set alertTriggerPreferences(value: string[]);
    resetAlertTriggerPreferences(): void;
    get alertTriggerPreferencesInput(): string[] | undefined;
    private _alertTriggerPreferencesValue?;
    get alertTriggerPreferencesValue(): string[];
    set alertTriggerPreferencesValue(value: string[]);
    resetAlertTriggerPreferencesValue(): void;
    get alertTriggerPreferencesValueInput(): string[] | undefined;
    private _enabled?;
    get enabled(): string[];
    set enabled(value: string[]);
    resetEnabled(): void;
    get enabledInput(): string[] | undefined;
    private _environment?;
    get environment(): string[];
    set environment(value: string[]);
    resetEnvironment(): void;
    get environmentInput(): string[] | undefined;
    private _event?;
    get event(): string[];
    set event(value: string[]);
    resetEvent(): void;
    get eventInput(): string[] | undefined;
    private _eventSource?;
    get eventSource(): string[];
    set eventSource(value: string[]);
    resetEventSource(): void;
    get eventSourceInput(): string[] | undefined;
    private _eventType?;
    get eventType(): string[];
    set eventType(value: string[]);
    resetEventType(): void;
    get eventTypeInput(): string[] | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _healthCheckId?;
    get healthCheckId(): string[];
    set healthCheckId(value: string[]);
    resetHealthCheckId(): void;
    get healthCheckIdInput(): string[] | undefined;
    private _incidentImpact?;
    get incidentImpact(): string[];
    set incidentImpact(value: string[]);
    resetIncidentImpact(): void;
    get incidentImpactInput(): string[] | undefined;
    private _inputId?;
    get inputId(): string[];
    set inputId(value: string[]);
    resetInputId(): void;
    get inputIdInput(): string[] | undefined;
    private _insightClass?;
    get insightClass(): string[];
    set insightClass(value: string[]);
    resetInsightClass(): void;
    get insightClassInput(): string[] | undefined;
    private _limit?;
    get limit(): string[];
    set limit(value: string[]);
    resetLimit(): void;
    get limitInput(): string[] | undefined;
    private _logoTag?;
    get logoTag(): string[];
    set logoTag(value: string[]);
    resetLogoTag(): void;
    get logoTagInput(): string[] | undefined;
    private _megabitsPerSecond?;
    get megabitsPerSecond(): string[];
    set megabitsPerSecond(value: string[]);
    resetMegabitsPerSecond(): void;
    get megabitsPerSecondInput(): string[] | undefined;
    private _newHealth?;
    get newHealth(): string[];
    set newHealth(value: string[]);
    resetNewHealth(): void;
    get newHealthInput(): string[] | undefined;
    private _newStatus?;
    get newStatus(): string[];
    set newStatus(value: string[]);
    resetNewStatus(): void;
    get newStatusInput(): string[] | undefined;
    private _packetsPerSecond?;
    get packetsPerSecond(): string[];
    set packetsPerSecond(value: string[]);
    resetPacketsPerSecond(): void;
    get packetsPerSecondInput(): string[] | undefined;
    private _poolId?;
    get poolId(): string[];
    set poolId(value: string[]);
    resetPoolId(): void;
    get poolIdInput(): string[] | undefined;
    private _popNames?;
    get popNames(): string[];
    set popNames(value: string[]);
    resetPopNames(): void;
    get popNamesInput(): string[] | undefined;
    private _product?;
    get product(): string[];
    set product(value: string[]);
    resetProduct(): void;
    get productInput(): string[] | undefined;
    private _projectId?;
    get projectId(): string[];
    set projectId(value: string[]);
    resetProjectId(): void;
    get projectIdInput(): string[] | undefined;
    private _protocol?;
    get protocol(): string[];
    set protocol(value: string[]);
    resetProtocol(): void;
    get protocolInput(): string[] | undefined;
    private _queryTag?;
    get queryTag(): string[];
    set queryTag(value: string[]);
    resetQueryTag(): void;
    get queryTagInput(): string[] | undefined;
    private _requestsPerSecond?;
    get requestsPerSecond(): string[];
    set requestsPerSecond(value: string[]);
    resetRequestsPerSecond(): void;
    get requestsPerSecondInput(): string[] | undefined;
    private _selectors?;
    get selectors(): string[];
    set selectors(value: string[]);
    resetSelectors(): void;
    get selectorsInput(): string[] | undefined;
    private _services?;
    get services(): string[];
    set services(value: string[]);
    resetServices(): void;
    get servicesInput(): string[] | undefined;
    private _slo?;
    get slo(): string[];
    set slo(value: string[]);
    resetSlo(): void;
    get sloInput(): string[] | undefined;
    private _status?;
    get status(): string[];
    set status(value: string[]);
    resetStatus(): void;
    get statusInput(): string[] | undefined;
    private _targetHostname?;
    get targetHostname(): string[];
    set targetHostname(value: string[]);
    resetTargetHostname(): void;
    get targetHostnameInput(): string[] | undefined;
    private _targetIp?;
    get targetIp(): string[];
    set targetIp(value: string[]);
    resetTargetIp(): void;
    get targetIpInput(): string[] | undefined;
    private _targetZoneName?;
    get targetZoneName(): string[];
    set targetZoneName(value: string[]);
    resetTargetZoneName(): void;
    get targetZoneNameInput(): string[] | undefined;
    private _trafficExclusions?;
    get trafficExclusions(): string[];
    set trafficExclusions(value: string[]);
    resetTrafficExclusions(): void;
    get trafficExclusionsInput(): string[] | undefined;
    private _tunnelId?;
    get tunnelId(): string[];
    set tunnelId(value: string[]);
    resetTunnelId(): void;
    get tunnelIdInput(): string[] | undefined;
    private _tunnelName?;
    get tunnelName(): string[];
    set tunnelName(value: string[]);
    resetTunnelName(): void;
    get tunnelNameInput(): string[] | undefined;
    private _type?;
    get type(): string[];
    set type(value: string[]);
    resetType(): void;
    get typeInput(): string[] | undefined;
    private _where?;
    get where(): string[];
    set where(value: string[]);
    resetWhere(): void;
    get whereInput(): string[] | undefined;
    private _zones?;
    get zones(): string[];
    set zones(value: string[]);
    resetZones(): void;
    get zonesInput(): string[] | undefined;
}
export interface NotificationPolicyMechanismsEmail {
    /**
    * The email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#id NotificationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function notificationPolicyMechanismsEmailToTerraform(struct?: NotificationPolicyMechanismsEmail | cdktn.IResolvable): any;
export declare function notificationPolicyMechanismsEmailToHclTerraform(struct?: NotificationPolicyMechanismsEmail | cdktn.IResolvable): any;
export declare class NotificationPolicyMechanismsEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationPolicyMechanismsEmail | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyMechanismsEmail | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class NotificationPolicyMechanismsEmailList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NotificationPolicyMechanismsEmail[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationPolicyMechanismsEmailOutputReference;
}
export interface NotificationPolicyMechanismsPagerduty {
    /**
    * UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#id NotificationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function notificationPolicyMechanismsPagerdutyToTerraform(struct?: NotificationPolicyMechanismsPagerduty | cdktn.IResolvable): any;
export declare function notificationPolicyMechanismsPagerdutyToHclTerraform(struct?: NotificationPolicyMechanismsPagerduty | cdktn.IResolvable): any;
export declare class NotificationPolicyMechanismsPagerdutyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationPolicyMechanismsPagerduty | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyMechanismsPagerduty | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class NotificationPolicyMechanismsPagerdutyList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NotificationPolicyMechanismsPagerduty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationPolicyMechanismsPagerdutyOutputReference;
}
export interface NotificationPolicyMechanismsWebhooks {
    /**
    * UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#id NotificationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function notificationPolicyMechanismsWebhooksToTerraform(struct?: NotificationPolicyMechanismsWebhooks | cdktn.IResolvable): any;
export declare function notificationPolicyMechanismsWebhooksToHclTerraform(struct?: NotificationPolicyMechanismsWebhooks | cdktn.IResolvable): any;
export declare class NotificationPolicyMechanismsWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NotificationPolicyMechanismsWebhooks | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyMechanismsWebhooks | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class NotificationPolicyMechanismsWebhooksList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NotificationPolicyMechanismsWebhooks[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NotificationPolicyMechanismsWebhooksOutputReference;
}
export interface NotificationPolicyMechanisms {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#email NotificationPolicy#email}
    */
    readonly email?: NotificationPolicyMechanismsEmail[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#pagerduty NotificationPolicy#pagerduty}
    */
    readonly pagerduty?: NotificationPolicyMechanismsPagerduty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#webhooks NotificationPolicy#webhooks}
    */
    readonly webhooks?: NotificationPolicyMechanismsWebhooks[] | cdktn.IResolvable;
}
export declare function notificationPolicyMechanismsToTerraform(struct?: NotificationPolicyMechanisms | cdktn.IResolvable): any;
export declare function notificationPolicyMechanismsToHclTerraform(struct?: NotificationPolicyMechanisms | cdktn.IResolvable): any;
export declare class NotificationPolicyMechanismsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationPolicyMechanisms | cdktn.IResolvable | undefined;
    set internalValue(value: NotificationPolicyMechanisms | cdktn.IResolvable | undefined);
    private _email;
    get email(): NotificationPolicyMechanismsEmailList;
    putEmail(value: NotificationPolicyMechanismsEmail[] | cdktn.IResolvable): void;
    resetEmail(): void;
    get emailInput(): cdktn.IResolvable | NotificationPolicyMechanismsEmail[] | undefined;
    private _pagerduty;
    get pagerduty(): NotificationPolicyMechanismsPagerdutyList;
    putPagerduty(value: NotificationPolicyMechanismsPagerduty[] | cdktn.IResolvable): void;
    resetPagerduty(): void;
    get pagerdutyInput(): cdktn.IResolvable | NotificationPolicyMechanismsPagerduty[] | undefined;
    private _webhooks;
    get webhooks(): NotificationPolicyMechanismsWebhooksList;
    putWebhooks(value: NotificationPolicyMechanismsWebhooks[] | cdktn.IResolvable): void;
    resetWebhooks(): void;
    get webhooksInput(): cdktn.IResolvable | NotificationPolicyMechanismsWebhooks[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy cloudflare_notification_policy}
*/
export declare class NotificationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_notification_policy";
    /**
    * Generates CDKTN code for importing a NotificationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationPolicy to import
    * @param importFromId The id of the existing NotificationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/notification_policy cloudflare_notification_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: NotificationPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _alertInterval?;
    get alertInterval(): string;
    set alertInterval(value: string);
    resetAlertInterval(): void;
    get alertIntervalInput(): string | undefined;
    private _alertType?;
    get alertType(): string;
    set alertType(value: string);
    get alertTypeInput(): string | undefined;
    get created(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _filters;
    get filters(): NotificationPolicyFiltersOutputReference;
    putFilters(value: NotificationPolicyFilters): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | NotificationPolicyFilters | undefined;
    get id(): string;
    private _mechanisms;
    get mechanisms(): NotificationPolicyMechanismsOutputReference;
    putMechanisms(value: NotificationPolicyMechanisms): void;
    get mechanismsInput(): cdktn.IResolvable | NotificationPolicyMechanisms | undefined;
    get modified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
