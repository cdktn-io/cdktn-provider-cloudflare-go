/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDeviceManagedNetworksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_device_managed_networks#account_id DataCloudflareZeroTrustDeviceManagedNetworks#account_id}
    */
    readonly accountId?: string;
    /**
    * API UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_device_managed_networks#network_id DataCloudflareZeroTrustDeviceManagedNetworks#network_id}
    */
    readonly networkId: string;
}
export interface DataCloudflareZeroTrustDeviceManagedNetworksConfigA {
}
export declare function dataCloudflareZeroTrustDeviceManagedNetworksConfigAToTerraform(struct?: DataCloudflareZeroTrustDeviceManagedNetworksConfigA): any;
export declare function dataCloudflareZeroTrustDeviceManagedNetworksConfigAToHclTerraform(struct?: DataCloudflareZeroTrustDeviceManagedNetworksConfigA): any;
export declare class DataCloudflareZeroTrustDeviceManagedNetworksConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceManagedNetworksConfigA | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceManagedNetworksConfigA | undefined);
    get sha256(): string;
    get tlsSockaddr(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_device_managed_networks cloudflare_zero_trust_device_managed_networks}
*/
export declare class DataCloudflareZeroTrustDeviceManagedNetworks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_managed_networks";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDeviceManagedNetworks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDeviceManagedNetworks to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDeviceManagedNetworks that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_device_managed_networks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDeviceManagedNetworks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_device_managed_networks cloudflare_zero_trust_device_managed_networks} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDeviceManagedNetworksConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDeviceManagedNetworksConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _config;
    get config(): DataCloudflareZeroTrustDeviceManagedNetworksConfigAOutputReference;
    get id(): string;
    get name(): string;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
