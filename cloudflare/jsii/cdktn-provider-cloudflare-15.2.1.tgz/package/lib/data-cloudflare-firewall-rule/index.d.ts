/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareFirewallRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the firewall rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/firewall_rule#rule_id DataCloudflareFirewallRule#rule_id}
    */
    readonly ruleId?: string;
    /**
    * Defines an identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/firewall_rule#zone_id DataCloudflareFirewallRule#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/firewall_rule cloudflare_firewall_rule}
*/
export declare class DataCloudflareFirewallRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_firewall_rule";
    /**
    * Generates CDKTN code for importing a DataCloudflareFirewallRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareFirewallRule to import
    * @param importFromId The id of the existing DataCloudflareFirewallRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/firewall_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareFirewallRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/firewall_rule cloudflare_firewall_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareFirewallRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareFirewallRuleConfig);
    get action(): string;
    get description(): string;
    get id(): string;
    get paused(): cdktn.IResolvable;
    get priority(): number;
    get products(): string[];
    get ref(): string;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    resetRuleId(): void;
    get ruleIdInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
