/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCasbFindingTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#account_id DataCloudflareZeroTrustCasbFindingType#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#filter DataCloudflareZeroTrustCasbFindingType#filter}
    */
    readonly filter?: DataCloudflareZeroTrustCasbFindingTypeFilter;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#finding_type_id DataCloudflareZeroTrustCasbFindingType#finding_type_id}
    */
    readonly findingTypeId?: string;
}
export interface DataCloudflareZeroTrustCasbFindingTypeCategory {
}
export declare function dataCloudflareZeroTrustCasbFindingTypeCategoryToTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypeCategory): any;
export declare function dataCloudflareZeroTrustCasbFindingTypeCategoryToHclTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypeCategory): any;
export declare class DataCloudflareZeroTrustCasbFindingTypeCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCasbFindingTypeCategory | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbFindingTypeCategory | undefined);
    get observation(): string;
    get product(): string;
    get type(): string;
}
export interface DataCloudflareZeroTrustCasbFindingTypeFilter {
    /**
    * Sort direction for the primary field. Defaults to 'desc'.
    * Ties are resolved by case-insensitive name, then ID, both ascending regardless of direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#direction DataCloudflareZeroTrustCasbFindingType#direction}
    */
    readonly direction?: string;
    /**
    * Return only finding types updated at or before this RFC 3339 timestamp (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#max_updated_at DataCloudflareZeroTrustCasbFindingType#max_updated_at}
    */
    readonly maxUpdatedAt?: string;
    /**
    * Return only finding types updated at or after this RFC 3339 timestamp (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#min_updated_at DataCloudflareZeroTrustCasbFindingType#min_updated_at}
    */
    readonly minUpdatedAt?: string;
    /**
    * Field to sort by (case-insensitive). Defaults to 'created'.
    * Name and vendor sorting is case-insensitive; vendor uses friendly provider names.
    * Ascending order: type Content then Posture; origin custom then system;
    * severity Low, Medium, High, Critical.
    * Available values: "created", "updated", "match_count", "name", "vendor", "type", "origin", "severity".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#order DataCloudflareZeroTrustCasbFindingType#order}
    */
    readonly order?: string;
    /**
    * Filter finding types by origin. Supports multiple comma-separated, case-insensitive values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#origins DataCloudflareZeroTrustCasbFindingType#origins}
    */
    readonly origins?: string[];
    /**
    * When true, return only quarantined finding types; when false, return only non-quarantined finding types. Omit to return both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#quarantined DataCloudflareZeroTrustCasbFindingType#quarantined}
    */
    readonly quarantined?: boolean | cdktn.IResolvable;
    /**
    * Filter finding types by name or ID (case-insensitive substring match).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#search DataCloudflareZeroTrustCasbFindingType#search}
    */
    readonly search?: string;
    /**
    * Filter finding types by severity. Supports multiple comma-separated, case-insensitive values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#severities DataCloudflareZeroTrustCasbFindingType#severities}
    */
    readonly severities?: string[];
    /**
    * Filter finding types by category type. Supports multiple comma-separated, case-insensitive values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#types DataCloudflareZeroTrustCasbFindingType#types}
    */
    readonly types?: string[];
    /**
    * Filter finding types by vendor. Supports multiple comma-separated values. Each value may be either the vendor enum (GOOGLE_WORKSPACE) or the friendly name returned by the read routes (Google Workspace).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#vendors DataCloudflareZeroTrustCasbFindingType#vendors}
    */
    readonly vendors?: string[];
}
export declare function dataCloudflareZeroTrustCasbFindingTypeFilterToTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypeFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustCasbFindingTypeFilterToHclTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypeFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustCasbFindingTypeFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCasbFindingTypeFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbFindingTypeFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxUpdatedAt?;
    get maxUpdatedAt(): string;
    set maxUpdatedAt(value: string);
    resetMaxUpdatedAt(): void;
    get maxUpdatedAtInput(): string | undefined;
    private _minUpdatedAt?;
    get minUpdatedAt(): string;
    set minUpdatedAt(value: string);
    resetMinUpdatedAt(): void;
    get minUpdatedAtInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _origins?;
    get origins(): string[];
    set origins(value: string[]);
    resetOrigins(): void;
    get originsInput(): string[] | undefined;
    private _quarantined?;
    get quarantined(): boolean | cdktn.IResolvable;
    set quarantined(value: boolean | cdktn.IResolvable);
    resetQuarantined(): void;
    get quarantinedInput(): boolean | cdktn.IResolvable | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _severities?;
    get severities(): string[];
    set severities(value: string[]);
    resetSeverities(): void;
    get severitiesInput(): string[] | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
    private _vendors?;
    get vendors(): string[];
    set vendors(value: string[]);
    resetVendors(): void;
    get vendorsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type cloudflare_zero_trust_casb_finding_type}
*/
export declare class DataCloudflareZeroTrustCasbFindingType extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_casb_finding_type";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCasbFindingType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCasbFindingType to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCasbFindingType that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCasbFindingType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_type cloudflare_zero_trust_casb_finding_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCasbFindingTypeConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCasbFindingTypeConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get appliesToAllIntegrations(): cdktn.IResolvable;
    get assetClass(): string;
    get assetVendor(): string;
    private _category;
    get category(): DataCloudflareZeroTrustCasbFindingTypeCategoryOutputReference;
    get createdAt(): string;
    get description(): string;
    get expression(): string;
    private _filter;
    get filter(): DataCloudflareZeroTrustCasbFindingTypeFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustCasbFindingTypeFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustCasbFindingTypeFilter | undefined;
    private _findingTypeId?;
    get findingTypeId(): string;
    set findingTypeId(value: string);
    resetFindingTypeId(): void;
    get findingTypeIdInput(): string | undefined;
    get id(): string;
    get integrationIds(): string[];
    get matchCount(): number;
    get name(): string;
    get origin(): string;
    get quarantined(): cdktn.IResolvable;
    get severity(): string;
    get updatedAt(): string;
    get vendor(): string;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
