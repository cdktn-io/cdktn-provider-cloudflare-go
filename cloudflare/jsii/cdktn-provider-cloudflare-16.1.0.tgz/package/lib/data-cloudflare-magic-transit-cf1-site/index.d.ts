/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicTransitCf1SiteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_cf1_site#account_id DataCloudflareMagicTransitCf1Site#account_id}
    */
    readonly accountId: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_cf1_site#cf1_site_id DataCloudflareMagicTransitCf1Site#cf1_site_id}
    */
    readonly cf1SiteId: string;
}
export interface DataCloudflareMagicTransitCf1SiteLocation {
}
export declare function dataCloudflareMagicTransitCf1SiteLocationToTerraform(struct?: DataCloudflareMagicTransitCf1SiteLocation): any;
export declare function dataCloudflareMagicTransitCf1SiteLocationToHclTerraform(struct?: DataCloudflareMagicTransitCf1SiteLocation): any;
export declare class DataCloudflareMagicTransitCf1SiteLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitCf1SiteLocation | undefined;
    set internalValue(value: DataCloudflareMagicTransitCf1SiteLocation | undefined);
    get lat(): number;
    get long(): number;
    get name(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_cf1_site cloudflare_magic_transit_cf1_site}
*/
export declare class DataCloudflareMagicTransitCf1Site extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_transit_cf1_site";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicTransitCf1Site resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicTransitCf1Site to import
    * @param importFromId The id of the existing DataCloudflareMagicTransitCf1Site that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_cf1_site#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicTransitCf1Site to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_cf1_site cloudflare_magic_transit_cf1_site} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicTransitCf1SiteConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicTransitCf1SiteConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _cf1SiteId?;
    get cf1SiteId(): string;
    set cf1SiteId(value: string);
    get cf1SiteIdInput(): string | undefined;
    get createdOn(): string;
    get description(): string;
    get id(): string;
    private _location;
    get location(): DataCloudflareMagicTransitCf1SiteLocationOutputReference;
    get modifiedOn(): string;
    get name(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
