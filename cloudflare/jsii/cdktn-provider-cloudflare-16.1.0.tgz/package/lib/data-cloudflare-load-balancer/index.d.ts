/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLoadBalancerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#load_balancer_id DataCloudflareLoadBalancer#load_balancer_id}
    */
    readonly loadBalancerId: string;
    /**
    * Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#pop_pools DataCloudflareLoadBalancer#pop_pools}
    */
    readonly popPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#region_pools DataCloudflareLoadBalancer#region_pools}
    */
    readonly regionPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#zone_id DataCloudflareLoadBalancer#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareLoadBalancerAdaptiveRouting {
}
export declare function dataCloudflareLoadBalancerAdaptiveRoutingToTerraform(struct?: DataCloudflareLoadBalancerAdaptiveRouting): any;
export declare function dataCloudflareLoadBalancerAdaptiveRoutingToHclTerraform(struct?: DataCloudflareLoadBalancerAdaptiveRouting): any;
export declare class DataCloudflareLoadBalancerAdaptiveRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerAdaptiveRouting | undefined;
    set internalValue(value: DataCloudflareLoadBalancerAdaptiveRouting | undefined);
    get failoverAcrossPools(): cdktn.IResolvable;
}
export interface DataCloudflareLoadBalancerLocationStrategy {
}
export declare function dataCloudflareLoadBalancerLocationStrategyToTerraform(struct?: DataCloudflareLoadBalancerLocationStrategy): any;
export declare function dataCloudflareLoadBalancerLocationStrategyToHclTerraform(struct?: DataCloudflareLoadBalancerLocationStrategy): any;
export declare class DataCloudflareLoadBalancerLocationStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerLocationStrategy | undefined;
    set internalValue(value: DataCloudflareLoadBalancerLocationStrategy | undefined);
    get mode(): string;
    get preferEcs(): string;
}
export interface DataCloudflareLoadBalancerRandomSteering {
}
export declare function dataCloudflareLoadBalancerRandomSteeringToTerraform(struct?: DataCloudflareLoadBalancerRandomSteering): any;
export declare function dataCloudflareLoadBalancerRandomSteeringToHclTerraform(struct?: DataCloudflareLoadBalancerRandomSteering): any;
export declare class DataCloudflareLoadBalancerRandomSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerRandomSteering | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRandomSteering | undefined);
    get defaultWeight(): number;
    private _poolWeights;
    get poolWeights(): cdktn.NumberMap;
}
export interface DataCloudflareLoadBalancerRulesFixedResponse {
}
export declare function dataCloudflareLoadBalancerRulesFixedResponseToTerraform(struct?: DataCloudflareLoadBalancerRulesFixedResponse): any;
export declare function dataCloudflareLoadBalancerRulesFixedResponseToHclTerraform(struct?: DataCloudflareLoadBalancerRulesFixedResponse): any;
export declare class DataCloudflareLoadBalancerRulesFixedResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerRulesFixedResponse | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRulesFixedResponse | undefined);
    get contentType(): string;
    get location(): string;
    get messageBody(): string;
    get statusCode(): number;
}
export interface DataCloudflareLoadBalancerRulesOverridesAdaptiveRouting {
}
export declare function dataCloudflareLoadBalancerRulesOverridesAdaptiveRoutingToTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesAdaptiveRouting): any;
export declare function dataCloudflareLoadBalancerRulesOverridesAdaptiveRoutingToHclTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesAdaptiveRouting): any;
export declare class DataCloudflareLoadBalancerRulesOverridesAdaptiveRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerRulesOverridesAdaptiveRouting | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRulesOverridesAdaptiveRouting | undefined);
    get failoverAcrossPools(): cdktn.IResolvable;
}
export interface DataCloudflareLoadBalancerRulesOverridesLocationStrategy {
}
export declare function dataCloudflareLoadBalancerRulesOverridesLocationStrategyToTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesLocationStrategy): any;
export declare function dataCloudflareLoadBalancerRulesOverridesLocationStrategyToHclTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesLocationStrategy): any;
export declare class DataCloudflareLoadBalancerRulesOverridesLocationStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerRulesOverridesLocationStrategy | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRulesOverridesLocationStrategy | undefined);
    get mode(): string;
    get preferEcs(): string;
}
export interface DataCloudflareLoadBalancerRulesOverridesRandomSteering {
}
export declare function dataCloudflareLoadBalancerRulesOverridesRandomSteeringToTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesRandomSteering): any;
export declare function dataCloudflareLoadBalancerRulesOverridesRandomSteeringToHclTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesRandomSteering): any;
export declare class DataCloudflareLoadBalancerRulesOverridesRandomSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerRulesOverridesRandomSteering | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRulesOverridesRandomSteering | undefined);
    get defaultWeight(): number;
    private _poolWeights;
    get poolWeights(): cdktn.NumberMap;
}
export interface DataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributes {
    /**
    * Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#drain_duration DataCloudflareLoadBalancer#drain_duration}
    */
    readonly drainDuration?: number;
}
export declare function dataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributesToTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributes): any;
export declare function dataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributesToHclTerraform(struct?: DataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributes): any;
export declare class DataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributes | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributes | undefined);
    private _drainDuration?;
    get drainDuration(): number;
    set drainDuration(value: number);
    resetDrainDuration(): void;
    get drainDurationInput(): number | undefined;
    get headers(): string[];
    get requireAllHeaders(): cdktn.IResolvable;
    get samesite(): string;
    get secure(): string;
    get zeroDowntimeFailover(): string;
}
export interface DataCloudflareLoadBalancerRulesOverrides {
    /**
    * Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#pop_pools DataCloudflareLoadBalancer#pop_pools}
    */
    readonly popPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
}
export declare function dataCloudflareLoadBalancerRulesOverridesToTerraform(struct?: DataCloudflareLoadBalancerRulesOverrides): any;
export declare function dataCloudflareLoadBalancerRulesOverridesToHclTerraform(struct?: DataCloudflareLoadBalancerRulesOverrides): any;
export declare class DataCloudflareLoadBalancerRulesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerRulesOverrides | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRulesOverrides | undefined);
    private _adaptiveRouting;
    get adaptiveRouting(): DataCloudflareLoadBalancerRulesOverridesAdaptiveRoutingOutputReference;
    private _countryPools;
    get countryPools(): cdktn.StringListMap;
    get defaultPools(): string[];
    get fallbackPool(): string;
    private _locationStrategy;
    get locationStrategy(): DataCloudflareLoadBalancerRulesOverridesLocationStrategyOutputReference;
    private _popPools?;
    get popPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set popPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetPopPools(): void;
    get popPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _randomSteering;
    get randomSteering(): DataCloudflareLoadBalancerRulesOverridesRandomSteeringOutputReference;
    private _regionPools;
    get regionPools(): cdktn.StringListMap;
    get sessionAffinity(): string;
    private _sessionAffinityAttributes;
    get sessionAffinityAttributes(): DataCloudflareLoadBalancerRulesOverridesSessionAffinityAttributesOutputReference;
    get sessionAffinityTtl(): number;
    get steeringPolicy(): string;
    get ttl(): number;
}
export interface DataCloudflareLoadBalancerRules {
}
export declare function dataCloudflareLoadBalancerRulesToTerraform(struct?: DataCloudflareLoadBalancerRules): any;
export declare function dataCloudflareLoadBalancerRulesToHclTerraform(struct?: DataCloudflareLoadBalancerRules): any;
export declare class DataCloudflareLoadBalancerRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerRules | undefined;
    set internalValue(value: DataCloudflareLoadBalancerRules | undefined);
    get condition(): string;
    get disabled(): cdktn.IResolvable;
    private _fixedResponse;
    get fixedResponse(): DataCloudflareLoadBalancerRulesFixedResponseOutputReference;
    get name(): string;
    private _overrides;
    get overrides(): DataCloudflareLoadBalancerRulesOverridesOutputReference;
    get priority(): number;
    get terminates(): cdktn.IResolvable;
}
export declare class DataCloudflareLoadBalancerRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerRulesOutputReference;
}
export interface DataCloudflareLoadBalancerSessionAffinityAttributes {
    /**
    * Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#drain_duration DataCloudflareLoadBalancer#drain_duration}
    */
    readonly drainDuration?: number;
}
export declare function dataCloudflareLoadBalancerSessionAffinityAttributesToTerraform(struct?: DataCloudflareLoadBalancerSessionAffinityAttributes): any;
export declare function dataCloudflareLoadBalancerSessionAffinityAttributesToHclTerraform(struct?: DataCloudflareLoadBalancerSessionAffinityAttributes): any;
export declare class DataCloudflareLoadBalancerSessionAffinityAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerSessionAffinityAttributes | undefined;
    set internalValue(value: DataCloudflareLoadBalancerSessionAffinityAttributes | undefined);
    private _drainDuration?;
    get drainDuration(): number;
    set drainDuration(value: number);
    resetDrainDuration(): void;
    get drainDurationInput(): number | undefined;
    get headers(): string[];
    get requireAllHeaders(): cdktn.IResolvable;
    get samesite(): string;
    get secure(): string;
    get zeroDowntimeFailover(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer cloudflare_load_balancer}
*/
export declare class DataCloudflareLoadBalancer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_load_balancer";
    /**
    * Generates CDKTN code for importing a DataCloudflareLoadBalancer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLoadBalancer to import
    * @param importFromId The id of the existing DataCloudflareLoadBalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLoadBalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/load_balancer cloudflare_load_balancer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLoadBalancerConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareLoadBalancerConfig);
    private _adaptiveRouting;
    get adaptiveRouting(): DataCloudflareLoadBalancerAdaptiveRoutingOutputReference;
    private _countryPools;
    get countryPools(): cdktn.StringListMap;
    get createdOn(): string;
    get defaultPools(): string[];
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get fallbackPool(): string;
    get id(): string;
    private _loadBalancerId?;
    get loadBalancerId(): string;
    set loadBalancerId(value: string);
    get loadBalancerIdInput(): string | undefined;
    private _locationStrategy;
    get locationStrategy(): DataCloudflareLoadBalancerLocationStrategyOutputReference;
    get modifiedOn(): string;
    get name(): string;
    get networks(): string[];
    private _popPools?;
    get popPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set popPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetPopPools(): void;
    get popPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get proxied(): cdktn.IResolvable;
    private _randomSteering;
    get randomSteering(): DataCloudflareLoadBalancerRandomSteeringOutputReference;
    private _regionPools?;
    get regionPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set regionPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetRegionPools(): void;
    get regionPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _rules;
    get rules(): DataCloudflareLoadBalancerRulesList;
    get sessionAffinity(): string;
    private _sessionAffinityAttributes;
    get sessionAffinityAttributes(): DataCloudflareLoadBalancerSessionAffinityAttributesOutputReference;
    get sessionAffinityTtl(): number;
    get steeringPolicy(): string;
    get ttl(): number;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
