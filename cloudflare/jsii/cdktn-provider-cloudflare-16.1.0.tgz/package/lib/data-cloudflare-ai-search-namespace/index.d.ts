/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAiSearchNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/ai_search_namespace#account_id DataCloudflareAiSearchNamespace#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/ai_search_namespace#name DataCloudflareAiSearchNamespace#name}
    */
    readonly name: string;
}
export interface DataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint {
}
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpointToTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint): any;
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpointToHclTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint): any;
export declare class DataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint | undefined;
    set internalValue(value: DataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint | undefined);
    get disabled(): cdktn.IResolvable;
}
export interface DataCloudflareAiSearchNamespacePublicEndpointParamsMcp {
}
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsMcpToTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsMcp): any;
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsMcpToHclTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsMcp): any;
export declare class DataCloudflareAiSearchNamespacePublicEndpointParamsMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchNamespacePublicEndpointParamsMcp | undefined;
    set internalValue(value: DataCloudflareAiSearchNamespacePublicEndpointParamsMcp | undefined);
    get description(): string;
    get disabled(): cdktn.IResolvable;
}
export interface DataCloudflareAiSearchNamespacePublicEndpointParamsRateLimit {
}
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsRateLimitToTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsRateLimit): any;
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsRateLimitToHclTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsRateLimit): any;
export declare class DataCloudflareAiSearchNamespacePublicEndpointParamsRateLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchNamespacePublicEndpointParamsRateLimit | undefined;
    set internalValue(value: DataCloudflareAiSearchNamespacePublicEndpointParamsRateLimit | undefined);
    get periodMs(): number;
    get requests(): number;
    get technique(): string;
}
export interface DataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpoint {
}
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpointToTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpoint): any;
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpointToHclTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpoint): any;
export declare class DataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpoint | undefined;
    set internalValue(value: DataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpoint | undefined);
    get disabled(): cdktn.IResolvable;
}
export interface DataCloudflareAiSearchNamespacePublicEndpointParams {
}
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsToTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParams): any;
export declare function dataCloudflareAiSearchNamespacePublicEndpointParamsToHclTerraform(struct?: DataCloudflareAiSearchNamespacePublicEndpointParams): any;
export declare class DataCloudflareAiSearchNamespacePublicEndpointParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchNamespacePublicEndpointParams | undefined;
    set internalValue(value: DataCloudflareAiSearchNamespacePublicEndpointParams | undefined);
    get authorizedHosts(): string[];
    private _chatCompletionsEndpoint;
    get chatCompletionsEndpoint(): DataCloudflareAiSearchNamespacePublicEndpointParamsChatCompletionsEndpointOutputReference;
    get customDomains(): string[];
    get defaultDomainEnabled(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get instancesAllowed(): string[];
    private _mcp;
    get mcp(): DataCloudflareAiSearchNamespacePublicEndpointParamsMcpOutputReference;
    private _rateLimit;
    get rateLimit(): DataCloudflareAiSearchNamespacePublicEndpointParamsRateLimitOutputReference;
    private _searchEndpoint;
    get searchEndpoint(): DataCloudflareAiSearchNamespacePublicEndpointParamsSearchEndpointOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/ai_search_namespace cloudflare_ai_search_namespace}
*/
export declare class DataCloudflareAiSearchNamespace extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ai_search_namespace";
    /**
    * Generates CDKTN code for importing a DataCloudflareAiSearchNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAiSearchNamespace to import
    * @param importFromId The id of the existing DataCloudflareAiSearchNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/ai_search_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAiSearchNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/ai_search_namespace cloudflare_ai_search_namespace} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAiSearchNamespaceConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareAiSearchNamespaceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicEndpointId(): string;
    private _publicEndpointParams;
    get publicEndpointParams(): DataCloudflareAiSearchNamespacePublicEndpointParamsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
