/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EmailSecurityBlockSenderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender#account_id EmailSecurityBlockSender#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender#comments EmailSecurityBlockSender#comments}
    */
    readonly comments?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender#is_regex EmailSecurityBlockSender#is_regex}
    */
    readonly isRegex: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender#pattern EmailSecurityBlockSender#pattern}
    */
    readonly pattern: string;
    /**
    * Available values: "EMAIL", "DOMAIN", "IP", "UNKNOWN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender#pattern_type EmailSecurityBlockSender#pattern_type}
    */
    readonly patternType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender cloudflare_email_security_block_sender}
*/
export declare class EmailSecurityBlockSender extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_email_security_block_sender";
    /**
    * Generates CDKTN code for importing a EmailSecurityBlockSender resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailSecurityBlockSender to import
    * @param importFromId The id of the existing EmailSecurityBlockSender that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailSecurityBlockSender to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_security_block_sender cloudflare_email_security_block_sender} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailSecurityBlockSenderConfig
    */
    constructor(scope: Construct, id: string, config: EmailSecurityBlockSenderConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _comments?;
    get comments(): string;
    set comments(value: string);
    resetComments(): void;
    get commentsInput(): string | undefined;
    get createdAt(): string;
    get id(): number;
    private _isRegex?;
    get isRegex(): boolean | cdktn.IResolvable;
    set isRegex(value: boolean | cdktn.IResolvable);
    get isRegexInput(): boolean | cdktn.IResolvable | undefined;
    get lastModified(): string;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    get patternInput(): string | undefined;
    private _patternType?;
    get patternType(): string;
    set patternType(value: string);
    get patternTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
