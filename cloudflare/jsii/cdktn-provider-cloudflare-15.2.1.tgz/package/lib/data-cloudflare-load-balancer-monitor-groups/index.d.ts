/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLoadBalancerMonitorGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/load_balancer_monitor_groups#account_id DataCloudflareLoadBalancerMonitorGroups#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/load_balancer_monitor_groups#max_items DataCloudflareLoadBalancerMonitorGroups#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareLoadBalancerMonitorGroupsResultMembers {
}
export declare function dataCloudflareLoadBalancerMonitorGroupsResultMembersToTerraform(struct?: DataCloudflareLoadBalancerMonitorGroupsResultMembers): any;
export declare function dataCloudflareLoadBalancerMonitorGroupsResultMembersToHclTerraform(struct?: DataCloudflareLoadBalancerMonitorGroupsResultMembers): any;
export declare class DataCloudflareLoadBalancerMonitorGroupsResultMembersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerMonitorGroupsResultMembers | undefined;
    set internalValue(value: DataCloudflareLoadBalancerMonitorGroupsResultMembers | undefined);
    get createdAt(): string;
    get enabled(): cdktn.IResolvable;
    get monitorId(): string;
    get monitoringOnly(): cdktn.IResolvable;
    get mustBeHealthy(): cdktn.IResolvable;
    get updatedAt(): string;
}
export declare class DataCloudflareLoadBalancerMonitorGroupsResultMembersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerMonitorGroupsResultMembersOutputReference;
}
export interface DataCloudflareLoadBalancerMonitorGroupsResult {
}
export declare function dataCloudflareLoadBalancerMonitorGroupsResultToTerraform(struct?: DataCloudflareLoadBalancerMonitorGroupsResult): any;
export declare function dataCloudflareLoadBalancerMonitorGroupsResultToHclTerraform(struct?: DataCloudflareLoadBalancerMonitorGroupsResult): any;
export declare class DataCloudflareLoadBalancerMonitorGroupsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerMonitorGroupsResult | undefined;
    set internalValue(value: DataCloudflareLoadBalancerMonitorGroupsResult | undefined);
    get createdOn(): string;
    get description(): string;
    get id(): string;
    private _members;
    get members(): DataCloudflareLoadBalancerMonitorGroupsResultMembersList;
    get modifiedOn(): string;
}
export declare class DataCloudflareLoadBalancerMonitorGroupsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerMonitorGroupsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/load_balancer_monitor_groups cloudflare_load_balancer_monitor_groups}
*/
export declare class DataCloudflareLoadBalancerMonitorGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_load_balancer_monitor_groups";
    /**
    * Generates CDKTN code for importing a DataCloudflareLoadBalancerMonitorGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLoadBalancerMonitorGroups to import
    * @param importFromId The id of the existing DataCloudflareLoadBalancerMonitorGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/load_balancer_monitor_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLoadBalancerMonitorGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/load_balancer_monitor_groups cloudflare_load_balancer_monitor_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLoadBalancerMonitorGroupsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareLoadBalancerMonitorGroupsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareLoadBalancerMonitorGroupsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
