/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCasbFindingTypesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#account_id DataCloudflareZeroTrustCasbFindingTypes#account_id}
    */
    readonly accountId: string;
    /**
    * Sort direction for the primary field. Defaults to 'desc'.
    * Ties are resolved by case-insensitive name, then ID, both ascending regardless of direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#direction DataCloudflareZeroTrustCasbFindingTypes#direction}
    */
    readonly direction?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#max_items DataCloudflareZeroTrustCasbFindingTypes#max_items}
    */
    readonly maxItems?: number;
    /**
    * Return only finding types updated at or before this RFC 3339 timestamp (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#max_updated_at DataCloudflareZeroTrustCasbFindingTypes#max_updated_at}
    */
    readonly maxUpdatedAt?: string;
    /**
    * Return only finding types updated at or after this RFC 3339 timestamp (inclusive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#min_updated_at DataCloudflareZeroTrustCasbFindingTypes#min_updated_at}
    */
    readonly minUpdatedAt?: string;
    /**
    * Field to sort by (case-insensitive). Defaults to 'created'.
    * Name and vendor sorting is case-insensitive; vendor uses friendly provider names.
    * Ascending order: type Content then Posture; origin custom then system;
    * severity Low, Medium, High, Critical.
    * Available values: "created", "updated", "match_count", "name", "vendor", "type", "origin", "severity".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#order DataCloudflareZeroTrustCasbFindingTypes#order}
    */
    readonly order?: string;
    /**
    * Filter finding types by origin. Supports multiple comma-separated, case-insensitive values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#origins DataCloudflareZeroTrustCasbFindingTypes#origins}
    */
    readonly origins?: string[];
    /**
    * When true, return only quarantined finding types; when false, return only non-quarantined finding types. Omit to return both.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#quarantined DataCloudflareZeroTrustCasbFindingTypes#quarantined}
    */
    readonly quarantined?: boolean | cdktn.IResolvable;
    /**
    * Filter finding types by name or ID (case-insensitive substring match).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#search DataCloudflareZeroTrustCasbFindingTypes#search}
    */
    readonly search?: string;
    /**
    * Filter finding types by severity. Supports multiple comma-separated, case-insensitive values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#severities DataCloudflareZeroTrustCasbFindingTypes#severities}
    */
    readonly severities?: string[];
    /**
    * Filter finding types by category type. Supports multiple comma-separated, case-insensitive values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#types DataCloudflareZeroTrustCasbFindingTypes#types}
    */
    readonly types?: string[];
    /**
    * Filter finding types by vendor. Supports multiple comma-separated values. Each value may be either the vendor enum (GOOGLE_WORKSPACE) or the friendly name returned by the read routes (Google Workspace).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#vendors DataCloudflareZeroTrustCasbFindingTypes#vendors}
    */
    readonly vendors?: string[];
}
export interface DataCloudflareZeroTrustCasbFindingTypesResultCategory {
}
export declare function dataCloudflareZeroTrustCasbFindingTypesResultCategoryToTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypesResultCategory): any;
export declare function dataCloudflareZeroTrustCasbFindingTypesResultCategoryToHclTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypesResultCategory): any;
export declare class DataCloudflareZeroTrustCasbFindingTypesResultCategoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCasbFindingTypesResultCategory | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbFindingTypesResultCategory | undefined);
    get observation(): string;
    get product(): string;
    get type(): string;
}
export interface DataCloudflareZeroTrustCasbFindingTypesResult {
}
export declare function dataCloudflareZeroTrustCasbFindingTypesResultToTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypesResult): any;
export declare function dataCloudflareZeroTrustCasbFindingTypesResultToHclTerraform(struct?: DataCloudflareZeroTrustCasbFindingTypesResult): any;
export declare class DataCloudflareZeroTrustCasbFindingTypesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbFindingTypesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbFindingTypesResult | undefined);
    get appliesToAllIntegrations(): cdktn.IResolvable;
    get assetClass(): string;
    get assetVendor(): string;
    private _category;
    get category(): DataCloudflareZeroTrustCasbFindingTypesResultCategoryOutputReference;
    get createdAt(): string;
    get description(): string;
    get expression(): string;
    get id(): string;
    get integrationIds(): string[];
    get matchCount(): number;
    get name(): string;
    get origin(): string;
    get quarantined(): cdktn.IResolvable;
    get severity(): string;
    get updatedAt(): string;
    get vendor(): string;
    get version(): number;
}
export declare class DataCloudflareZeroTrustCasbFindingTypesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbFindingTypesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types cloudflare_zero_trust_casb_finding_types}
*/
export declare class DataCloudflareZeroTrustCasbFindingTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_casb_finding_types";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCasbFindingTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCasbFindingTypes to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCasbFindingTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCasbFindingTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_casb_finding_types cloudflare_zero_trust_casb_finding_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCasbFindingTypesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCasbFindingTypesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _maxUpdatedAt?;
    get maxUpdatedAt(): string;
    set maxUpdatedAt(value: string);
    resetMaxUpdatedAt(): void;
    get maxUpdatedAtInput(): string | undefined;
    private _minUpdatedAt?;
    get minUpdatedAt(): string;
    set minUpdatedAt(value: string);
    resetMinUpdatedAt(): void;
    get minUpdatedAtInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _origins?;
    get origins(): string[];
    set origins(value: string[]);
    resetOrigins(): void;
    get originsInput(): string[] | undefined;
    private _quarantined?;
    get quarantined(): boolean | cdktn.IResolvable;
    set quarantined(value: boolean | cdktn.IResolvable);
    resetQuarantined(): void;
    get quarantinedInput(): boolean | cdktn.IResolvable | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCasbFindingTypesResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _severities?;
    get severities(): string[];
    set severities(value: string[]);
    resetSeverities(): void;
    get severitiesInput(): string[] | undefined;
    private _types?;
    get types(): string[];
    set types(value: string[]);
    resetTypes(): void;
    get typesInput(): string[] | undefined;
    private _vendors?;
    get vendors(): string[];
    set vendors(value: string[]);
    resetVendors(): void;
    get vendorsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
