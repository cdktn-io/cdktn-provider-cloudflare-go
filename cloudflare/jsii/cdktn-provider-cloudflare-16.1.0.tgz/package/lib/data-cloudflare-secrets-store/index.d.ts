/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSecretsStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store#account_id DataCloudflareSecretsStore#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store#filter DataCloudflareSecretsStore#filter}
    */
    readonly filter?: DataCloudflareSecretsStoreFilter;
    /**
    * Store Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store#store_id DataCloudflareSecretsStore#store_id}
    */
    readonly storeId?: string;
}
export interface DataCloudflareSecretsStoreFilter {
    /**
    * Direction to sort objects.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store#direction DataCloudflareSecretsStore#direction}
    */
    readonly direction?: string;
    /**
    * Order stores by values in the given field.
    * Available values: "name", "created", "modified".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store#order DataCloudflareSecretsStore#order}
    */
    readonly order?: string;
}
export declare function dataCloudflareSecretsStoreFilterToTerraform(struct?: DataCloudflareSecretsStoreFilter | cdktn.IResolvable): any;
export declare function dataCloudflareSecretsStoreFilterToHclTerraform(struct?: DataCloudflareSecretsStoreFilter | cdktn.IResolvable): any;
export declare class DataCloudflareSecretsStoreFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSecretsStoreFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareSecretsStoreFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store cloudflare_secrets_store}
*/
export declare class DataCloudflareSecretsStore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_secrets_store";
    /**
    * Generates CDKTN code for importing a DataCloudflareSecretsStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSecretsStore to import
    * @param importFromId The id of the existing DataCloudflareSecretsStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSecretsStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/secrets_store cloudflare_secrets_store} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSecretsStoreConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareSecretsStoreConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get created(): string;
    private _filter;
    get filter(): DataCloudflareSecretsStoreFilterOutputReference;
    putFilter(value: DataCloudflareSecretsStoreFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareSecretsStoreFilter | undefined;
    get id(): string;
    get modified(): string;
    get name(): string;
    private _storeId?;
    get storeId(): string;
    set storeId(value: string);
    resetStoreId(): void;
    get storeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
