/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLoadBalancersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#max_items DataCloudflareLoadBalancers#max_items}
    */
    readonly maxItems?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#zone_id DataCloudflareLoadBalancers#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareLoadBalancersResultAdaptiveRouting {
}
export declare function dataCloudflareLoadBalancersResultAdaptiveRoutingToTerraform(struct?: DataCloudflareLoadBalancersResultAdaptiveRouting): any;
export declare function dataCloudflareLoadBalancersResultAdaptiveRoutingToHclTerraform(struct?: DataCloudflareLoadBalancersResultAdaptiveRouting): any;
export declare class DataCloudflareLoadBalancersResultAdaptiveRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultAdaptiveRouting | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultAdaptiveRouting | undefined);
    get failoverAcrossPools(): cdktn.IResolvable;
}
export interface DataCloudflareLoadBalancersResultLocationStrategy {
}
export declare function dataCloudflareLoadBalancersResultLocationStrategyToTerraform(struct?: DataCloudflareLoadBalancersResultLocationStrategy): any;
export declare function dataCloudflareLoadBalancersResultLocationStrategyToHclTerraform(struct?: DataCloudflareLoadBalancersResultLocationStrategy): any;
export declare class DataCloudflareLoadBalancersResultLocationStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultLocationStrategy | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultLocationStrategy | undefined);
    get mode(): string;
    get preferEcs(): string;
}
export interface DataCloudflareLoadBalancersResultRandomSteering {
}
export declare function dataCloudflareLoadBalancersResultRandomSteeringToTerraform(struct?: DataCloudflareLoadBalancersResultRandomSteering): any;
export declare function dataCloudflareLoadBalancersResultRandomSteeringToHclTerraform(struct?: DataCloudflareLoadBalancersResultRandomSteering): any;
export declare class DataCloudflareLoadBalancersResultRandomSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultRandomSteering | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRandomSteering | undefined);
    get defaultWeight(): number;
    private _poolWeights;
    get poolWeights(): cdktn.NumberMap;
}
export interface DataCloudflareLoadBalancersResultRulesFixedResponse {
}
export declare function dataCloudflareLoadBalancersResultRulesFixedResponseToTerraform(struct?: DataCloudflareLoadBalancersResultRulesFixedResponse): any;
export declare function dataCloudflareLoadBalancersResultRulesFixedResponseToHclTerraform(struct?: DataCloudflareLoadBalancersResultRulesFixedResponse): any;
export declare class DataCloudflareLoadBalancersResultRulesFixedResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultRulesFixedResponse | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRulesFixedResponse | undefined);
    get contentType(): string;
    get location(): string;
    get messageBody(): string;
    get statusCode(): number;
}
export interface DataCloudflareLoadBalancersResultRulesOverridesAdaptiveRouting {
}
export declare function dataCloudflareLoadBalancersResultRulesOverridesAdaptiveRoutingToTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesAdaptiveRouting): any;
export declare function dataCloudflareLoadBalancersResultRulesOverridesAdaptiveRoutingToHclTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesAdaptiveRouting): any;
export declare class DataCloudflareLoadBalancersResultRulesOverridesAdaptiveRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultRulesOverridesAdaptiveRouting | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRulesOverridesAdaptiveRouting | undefined);
    get failoverAcrossPools(): cdktn.IResolvable;
}
export interface DataCloudflareLoadBalancersResultRulesOverridesLocationStrategy {
}
export declare function dataCloudflareLoadBalancersResultRulesOverridesLocationStrategyToTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesLocationStrategy): any;
export declare function dataCloudflareLoadBalancersResultRulesOverridesLocationStrategyToHclTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesLocationStrategy): any;
export declare class DataCloudflareLoadBalancersResultRulesOverridesLocationStrategyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultRulesOverridesLocationStrategy | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRulesOverridesLocationStrategy | undefined);
    get mode(): string;
    get preferEcs(): string;
}
export interface DataCloudflareLoadBalancersResultRulesOverridesRandomSteering {
}
export declare function dataCloudflareLoadBalancersResultRulesOverridesRandomSteeringToTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesRandomSteering): any;
export declare function dataCloudflareLoadBalancersResultRulesOverridesRandomSteeringToHclTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesRandomSteering): any;
export declare class DataCloudflareLoadBalancersResultRulesOverridesRandomSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultRulesOverridesRandomSteering | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRulesOverridesRandomSteering | undefined);
    get defaultWeight(): number;
    private _poolWeights;
    get poolWeights(): cdktn.NumberMap;
}
export interface DataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributes {
    /**
    * Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#drain_duration DataCloudflareLoadBalancers#drain_duration}
    */
    readonly drainDuration?: number;
}
export declare function dataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributesToTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributes): any;
export declare function dataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributesToHclTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributes): any;
export declare class DataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributes | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributes | undefined);
    private _drainDuration?;
    get drainDuration(): number;
    set drainDuration(value: number);
    resetDrainDuration(): void;
    get drainDurationInput(): number | undefined;
    get headers(): string[];
    get requireAllHeaders(): cdktn.IResolvable;
    get samesite(): string;
    get secure(): string;
    get zeroDowntimeFailover(): string;
}
export interface DataCloudflareLoadBalancersResultRulesOverrides {
    /**
    * A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#country_pools DataCloudflareLoadBalancers#country_pools}
    */
    readonly countryPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#pop_pools DataCloudflareLoadBalancers#pop_pools}
    */
    readonly popPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#region_pools DataCloudflareLoadBalancers#region_pools}
    */
    readonly regionPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
}
export declare function dataCloudflareLoadBalancersResultRulesOverridesToTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverrides): any;
export declare function dataCloudflareLoadBalancersResultRulesOverridesToHclTerraform(struct?: DataCloudflareLoadBalancersResultRulesOverrides): any;
export declare class DataCloudflareLoadBalancersResultRulesOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultRulesOverrides | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRulesOverrides | undefined);
    private _adaptiveRouting;
    get adaptiveRouting(): DataCloudflareLoadBalancersResultRulesOverridesAdaptiveRoutingOutputReference;
    private _countryPools?;
    get countryPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set countryPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetCountryPools(): void;
    get countryPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get defaultPools(): string[];
    get fallbackPool(): string;
    private _locationStrategy;
    get locationStrategy(): DataCloudflareLoadBalancersResultRulesOverridesLocationStrategyOutputReference;
    private _popPools?;
    get popPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set popPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetPopPools(): void;
    get popPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _randomSteering;
    get randomSteering(): DataCloudflareLoadBalancersResultRulesOverridesRandomSteeringOutputReference;
    private _regionPools?;
    get regionPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set regionPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetRegionPools(): void;
    get regionPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get sessionAffinity(): string;
    private _sessionAffinityAttributes;
    get sessionAffinityAttributes(): DataCloudflareLoadBalancersResultRulesOverridesSessionAffinityAttributesOutputReference;
    get sessionAffinityTtl(): number;
    get steeringPolicy(): string;
    get ttl(): number;
}
export interface DataCloudflareLoadBalancersResultRules {
}
export declare function dataCloudflareLoadBalancersResultRulesToTerraform(struct?: DataCloudflareLoadBalancersResultRules): any;
export declare function dataCloudflareLoadBalancersResultRulesToHclTerraform(struct?: DataCloudflareLoadBalancersResultRules): any;
export declare class DataCloudflareLoadBalancersResultRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancersResultRules | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultRules | undefined);
    get condition(): string;
    get disabled(): cdktn.IResolvable;
    private _fixedResponse;
    get fixedResponse(): DataCloudflareLoadBalancersResultRulesFixedResponseOutputReference;
    get name(): string;
    private _overrides;
    get overrides(): DataCloudflareLoadBalancersResultRulesOverridesOutputReference;
    get priority(): number;
    get terminates(): cdktn.IResolvable;
}
export declare class DataCloudflareLoadBalancersResultRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancersResultRulesOutputReference;
}
export interface DataCloudflareLoadBalancersResultSessionAffinityAttributes {
    /**
    * Configures the drain duration in seconds. This field is only used when session affinity is enabled on the load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#drain_duration DataCloudflareLoadBalancers#drain_duration}
    */
    readonly drainDuration?: number;
}
export declare function dataCloudflareLoadBalancersResultSessionAffinityAttributesToTerraform(struct?: DataCloudflareLoadBalancersResultSessionAffinityAttributes): any;
export declare function dataCloudflareLoadBalancersResultSessionAffinityAttributesToHclTerraform(struct?: DataCloudflareLoadBalancersResultSessionAffinityAttributes): any;
export declare class DataCloudflareLoadBalancersResultSessionAffinityAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancersResultSessionAffinityAttributes | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResultSessionAffinityAttributes | undefined);
    private _drainDuration?;
    get drainDuration(): number;
    set drainDuration(value: number);
    resetDrainDuration(): void;
    get drainDurationInput(): number | undefined;
    get headers(): string[];
    get requireAllHeaders(): cdktn.IResolvable;
    get samesite(): string;
    get secure(): string;
    get zeroDowntimeFailover(): string;
}
export interface DataCloudflareLoadBalancersResult {
    /**
    * A mapping of country codes to a list of pool IDs (ordered by their failover priority) for the given country. Any country not explicitly defined will fall back to using the corresponding region_pool mapping if it exists else to default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#country_pools DataCloudflareLoadBalancers#country_pools}
    */
    readonly countryPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Enterprise only: A mapping of Cloudflare PoP identifiers to a list of pool IDs (ordered by their failover priority) for the PoP (datacenter). Any PoPs not explicitly defined will fall back to using the corresponding country_pool, then region_pool mapping if it exists else to default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#pop_pools DataCloudflareLoadBalancers#pop_pools}
    */
    readonly popPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A mapping of region codes to a list of pool IDs (ordered by their failover priority) for the given region. Any regions not explicitly defined will fall back to using default_pools.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#region_pools DataCloudflareLoadBalancers#region_pools}
    */
    readonly regionPools?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
}
export declare function dataCloudflareLoadBalancersResultToTerraform(struct?: DataCloudflareLoadBalancersResult): any;
export declare function dataCloudflareLoadBalancersResultToHclTerraform(struct?: DataCloudflareLoadBalancersResult): any;
export declare class DataCloudflareLoadBalancersResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancersResult | undefined;
    set internalValue(value: DataCloudflareLoadBalancersResult | undefined);
    private _adaptiveRouting;
    get adaptiveRouting(): DataCloudflareLoadBalancersResultAdaptiveRoutingOutputReference;
    private _countryPools?;
    get countryPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set countryPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetCountryPools(): void;
    get countryPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get createdOn(): string;
    get defaultPools(): string[];
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get fallbackPool(): string;
    get id(): string;
    private _locationStrategy;
    get locationStrategy(): DataCloudflareLoadBalancersResultLocationStrategyOutputReference;
    get modifiedOn(): string;
    get name(): string;
    get networks(): string[];
    private _popPools?;
    get popPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set popPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetPopPools(): void;
    get popPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get proxied(): cdktn.IResolvable;
    private _randomSteering;
    get randomSteering(): DataCloudflareLoadBalancersResultRandomSteeringOutputReference;
    private _regionPools?;
    get regionPools(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set regionPools(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetRegionPools(): void;
    get regionPoolsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _rules;
    get rules(): DataCloudflareLoadBalancersResultRulesList;
    get sessionAffinity(): string;
    private _sessionAffinityAttributes;
    get sessionAffinityAttributes(): DataCloudflareLoadBalancersResultSessionAffinityAttributesOutputReference;
    get sessionAffinityTtl(): number;
    get steeringPolicy(): string;
    get ttl(): number;
    get zoneName(): string;
}
export declare class DataCloudflareLoadBalancersResultList extends cdktn.ComplexList {
    internalValue?: DataCloudflareLoadBalancersResult[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancersResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers cloudflare_load_balancers}
*/
export declare class DataCloudflareLoadBalancers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_load_balancers";
    /**
    * Generates CDKTN code for importing a DataCloudflareLoadBalancers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLoadBalancers to import
    * @param importFromId The id of the existing DataCloudflareLoadBalancers that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLoadBalancers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/load_balancers cloudflare_load_balancers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLoadBalancersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareLoadBalancersConfig);
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareLoadBalancersResultList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
