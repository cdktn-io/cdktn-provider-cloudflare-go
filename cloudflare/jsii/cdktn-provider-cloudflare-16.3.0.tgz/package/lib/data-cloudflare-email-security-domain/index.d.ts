/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSecurityDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#account_id DataCloudflareEmailSecurityDomain#account_id}
    */
    readonly accountId: string;
    /**
    * Domain identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#domain_id DataCloudflareEmailSecurityDomain#domain_id}
    */
    readonly domainId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#filter DataCloudflareEmailSecurityDomain#filter}
    */
    readonly filter?: DataCloudflareEmailSecurityDomainFilter;
}
export interface DataCloudflareEmailSecurityDomainAuthorization {
}
export declare function dataCloudflareEmailSecurityDomainAuthorizationToTerraform(struct?: DataCloudflareEmailSecurityDomainAuthorization): any;
export declare function dataCloudflareEmailSecurityDomainAuthorizationToHclTerraform(struct?: DataCloudflareEmailSecurityDomainAuthorization): any;
export declare class DataCloudflareEmailSecurityDomainAuthorizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityDomainAuthorization | undefined;
    set internalValue(value: DataCloudflareEmailSecurityDomainAuthorization | undefined);
    get authorized(): cdktn.IResolvable;
    get statusMessage(): string;
    get timestamp(): string;
}
export interface DataCloudflareEmailSecurityDomainEmailsProcessed {
}
export declare function dataCloudflareEmailSecurityDomainEmailsProcessedToTerraform(struct?: DataCloudflareEmailSecurityDomainEmailsProcessed): any;
export declare function dataCloudflareEmailSecurityDomainEmailsProcessedToHclTerraform(struct?: DataCloudflareEmailSecurityDomainEmailsProcessed): any;
export declare class DataCloudflareEmailSecurityDomainEmailsProcessedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityDomainEmailsProcessed | undefined;
    set internalValue(value: DataCloudflareEmailSecurityDomainEmailsProcessed | undefined);
    get timestamp(): string;
    get totalEmailsProcessed(): number;
    get totalEmailsProcessedPrevious(): number;
}
export interface DataCloudflareEmailSecurityDomainFilter {
    /**
    * Currently active delivery mode to filter by.
    * Available values: "DIRECT", "BCC", "JOURNAL", "API", "RETRO_SCAN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#active_delivery_mode DataCloudflareEmailSecurityDomain#active_delivery_mode}
    */
    readonly activeDeliveryMode?: string;
    /**
    * Delivery mode to filter by.
    * Available values: "DIRECT", "BCC", "JOURNAL", "API", "RETRO_SCAN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#allowed_delivery_mode DataCloudflareEmailSecurityDomain#allowed_delivery_mode}
    */
    readonly allowedDeliveryMode?: string;
    /**
    * The sorting direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#direction DataCloudflareEmailSecurityDomain#direction}
    */
    readonly direction?: string;
    /**
    * Domain names to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#domain DataCloudflareEmailSecurityDomain#domain}
    */
    readonly domain?: string[];
    /**
    * Integration ID to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#integration_id DataCloudflareEmailSecurityDomain#integration_id}
    */
    readonly integrationId?: string;
    /**
    * Field to sort by.
    * Available values: "domain", "created_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#order DataCloudflareEmailSecurityDomain#order}
    */
    readonly order?: string;
    /**
    * Search term for filtering records. Behavior may change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#search DataCloudflareEmailSecurityDomain#search}
    */
    readonly search?: string;
    /**
    * Filters response to domains with the provided status.
    * Available values: "PENDING", "ACTIVE", "FAILED", "TIMEOUT".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#status DataCloudflareEmailSecurityDomain#status}
    */
    readonly status?: string;
}
export declare function dataCloudflareEmailSecurityDomainFilterToTerraform(struct?: DataCloudflareEmailSecurityDomainFilter | cdktn.IResolvable): any;
export declare function dataCloudflareEmailSecurityDomainFilterToHclTerraform(struct?: DataCloudflareEmailSecurityDomainFilter | cdktn.IResolvable): any;
export declare class DataCloudflareEmailSecurityDomainFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityDomainFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareEmailSecurityDomainFilter | cdktn.IResolvable | undefined);
    private _activeDeliveryMode?;
    get activeDeliveryMode(): string;
    set activeDeliveryMode(value: string);
    resetActiveDeliveryMode(): void;
    get activeDeliveryModeInput(): string | undefined;
    private _allowedDeliveryMode?;
    get allowedDeliveryMode(): string;
    set allowedDeliveryMode(value: string);
    resetAllowedDeliveryMode(): void;
    get allowedDeliveryModeInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _domain?;
    get domain(): string[];
    set domain(value: string[]);
    resetDomain(): void;
    get domainInput(): string[] | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    resetIntegrationId(): void;
    get integrationIdInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain cloudflare_email_security_domain}
*/
export declare class DataCloudflareEmailSecurityDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_security_domain";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSecurityDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSecurityDomain to import
    * @param importFromId The id of the existing DataCloudflareEmailSecurityDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSecurityDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domain cloudflare_email_security_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSecurityDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareEmailSecurityDomainConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get allowedDeliveryModes(): string[];
    private _authorization;
    get authorization(): DataCloudflareEmailSecurityDomainAuthorizationOutputReference;
    get createdAt(): string;
    get dmarcStatus(): string;
    get domain(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    resetDomainId(): void;
    get domainIdInput(): string | undefined;
    get dropDispositions(): string[];
    private _emailsProcessed;
    get emailsProcessed(): DataCloudflareEmailSecurityDomainEmailsProcessedOutputReference;
    private _filter;
    get filter(): DataCloudflareEmailSecurityDomainFilterOutputReference;
    putFilter(value: DataCloudflareEmailSecurityDomainFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareEmailSecurityDomainFilter | undefined;
    get folder(): string;
    get id(): string;
    get inboxProvider(): string;
    get integrationId(): string;
    get ipRestrictions(): string[];
    get lastModified(): string;
    get lookbackHops(): number;
    get modifiedAt(): string;
    get o365TenantId(): string;
    get regions(): string[];
    get requireTlsInbound(): cdktn.IResolvable;
    get requireTlsOutbound(): cdktn.IResolvable;
    get spfStatus(): string;
    get status(): string;
    get transport(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
