/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDevicePostureIntegrationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_integrations#account_id DataCloudflareZeroTrustDevicePostureIntegrations#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_integrations#max_items DataCloudflareZeroTrustDevicePostureIntegrations#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDevicePostureIntegrationsResultConfig {
}
export declare function dataCloudflareZeroTrustDevicePostureIntegrationsResultConfigToTerraform(struct?: DataCloudflareZeroTrustDevicePostureIntegrationsResultConfig): any;
export declare function dataCloudflareZeroTrustDevicePostureIntegrationsResultConfigToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureIntegrationsResultConfig): any;
export declare class DataCloudflareZeroTrustDevicePostureIntegrationsResultConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDevicePostureIntegrationsResultConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureIntegrationsResultConfig | undefined);
    get apiUrl(): string;
    get authUrl(): string;
    get clientId(): string;
}
export interface DataCloudflareZeroTrustDevicePostureIntegrationsResult {
}
export declare function dataCloudflareZeroTrustDevicePostureIntegrationsResultToTerraform(struct?: DataCloudflareZeroTrustDevicePostureIntegrationsResult): any;
export declare function dataCloudflareZeroTrustDevicePostureIntegrationsResultToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureIntegrationsResult): any;
export declare class DataCloudflareZeroTrustDevicePostureIntegrationsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDevicePostureIntegrationsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureIntegrationsResult | undefined);
    private _config;
    get config(): DataCloudflareZeroTrustDevicePostureIntegrationsResultConfigOutputReference;
    get id(): string;
    get interval(): string;
    get name(): string;
    get type(): string;
}
export declare class DataCloudflareZeroTrustDevicePostureIntegrationsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDevicePostureIntegrationsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_integrations cloudflare_zero_trust_device_posture_integrations}
*/
export declare class DataCloudflareZeroTrustDevicePostureIntegrations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_posture_integrations";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDevicePostureIntegrations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDevicePostureIntegrations to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDevicePostureIntegrations that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_integrations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDevicePostureIntegrations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_device_posture_integrations cloudflare_zero_trust_device_posture_integrations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDevicePostureIntegrationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustDevicePostureIntegrationsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDevicePostureIntegrationsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
