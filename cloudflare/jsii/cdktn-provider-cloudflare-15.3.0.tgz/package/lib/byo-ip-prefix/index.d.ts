/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ByoIpPrefixConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier of a Cloudflare account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix#account_id ByoIpPrefix#account_id}
    */
    readonly accountId: string;
    /**
    * Autonomous System Number (ASN) the prefix will be advertised under.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix#asn ByoIpPrefix#asn}
    */
    readonly asn: number;
    /**
    * IP Prefix in Classless Inter-Domain Routing format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix#cidr ByoIpPrefix#cidr}
    */
    readonly cidr: string;
    /**
    * Whether Cloudflare is allowed to generate the LOA document on behalf of the prefix owner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix#delegate_loa_creation ByoIpPrefix#delegate_loa_creation}
    */
    readonly delegateLoaCreation?: boolean | cdktn.IResolvable;
    /**
    * Description of the prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix#description ByoIpPrefix#description}
    */
    readonly description?: string;
    /**
    * Identifier for the uploaded LOA document.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix#loa_document_id ByoIpPrefix#loa_document_id}
    */
    readonly loaDocumentId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix cloudflare_byo_ip_prefix}
*/
export declare class ByoIpPrefix extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_byo_ip_prefix";
    /**
    * Generates CDKTN code for importing a ByoIpPrefix resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ByoIpPrefix to import
    * @param importFromId The id of the existing ByoIpPrefix that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ByoIpPrefix to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/resources/byo_ip_prefix cloudflare_byo_ip_prefix} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ByoIpPrefixConfig
    */
    constructor(scope: Construct, id: string, config: ByoIpPrefixConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get advertised(): cdktn.IResolvable;
    get advertisedModifiedAt(): string;
    get approved(): string;
    private _asn?;
    get asn(): number;
    set asn(value: number);
    get asnInput(): number | undefined;
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    get cidrInput(): string | undefined;
    get createdAt(): string;
    private _delegateLoaCreation?;
    get delegateLoaCreation(): boolean | cdktn.IResolvable;
    set delegateLoaCreation(value: boolean | cdktn.IResolvable);
    resetDelegateLoaCreation(): void;
    get delegateLoaCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get irrValidationState(): string;
    private _loaDocumentId?;
    get loaDocumentId(): string;
    set loaDocumentId(value: string);
    resetLoaDocumentId(): void;
    get loaDocumentIdInput(): string | undefined;
    get modifiedAt(): string;
    get onDemandEnabled(): cdktn.IResolvable;
    get onDemandLocked(): cdktn.IResolvable;
    get ownershipValidationState(): string;
    get ownershipValidationToken(): string;
    get rpkiValidationState(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
