/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCloudConnectorRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/cloud_connector_rules#zone_id DataCloudflareCloudConnectorRules#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareCloudConnectorRulesRulesParameters {
}
export declare function dataCloudflareCloudConnectorRulesRulesParametersToTerraform(struct?: DataCloudflareCloudConnectorRulesRulesParameters): any;
export declare function dataCloudflareCloudConnectorRulesRulesParametersToHclTerraform(struct?: DataCloudflareCloudConnectorRulesRulesParameters): any;
export declare class DataCloudflareCloudConnectorRulesRulesParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCloudConnectorRulesRulesParameters | undefined;
    set internalValue(value: DataCloudflareCloudConnectorRulesRulesParameters | undefined);
    get host(): string;
}
export interface DataCloudflareCloudConnectorRulesRules {
}
export declare function dataCloudflareCloudConnectorRulesRulesToTerraform(struct?: DataCloudflareCloudConnectorRulesRules): any;
export declare function dataCloudflareCloudConnectorRulesRulesToHclTerraform(struct?: DataCloudflareCloudConnectorRulesRules): any;
export declare class DataCloudflareCloudConnectorRulesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCloudConnectorRulesRules | undefined;
    set internalValue(value: DataCloudflareCloudConnectorRulesRules | undefined);
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expression(): string;
    get id(): string;
    private _parameters;
    get parameters(): DataCloudflareCloudConnectorRulesRulesParametersOutputReference;
    get provider(): string;
}
export declare class DataCloudflareCloudConnectorRulesRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCloudConnectorRulesRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/cloud_connector_rules cloudflare_cloud_connector_rules}
*/
export declare class DataCloudflareCloudConnectorRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_cloud_connector_rules";
    /**
    * Generates CDKTN code for importing a DataCloudflareCloudConnectorRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCloudConnectorRules to import
    * @param importFromId The id of the existing DataCloudflareCloudConnectorRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/cloud_connector_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCloudConnectorRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/cloud_connector_rules cloudflare_cloud_connector_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCloudConnectorRulesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareCloudConnectorRulesConfig);
    get id(): string;
    private _rules;
    get rules(): DataCloudflareCloudConnectorRulesRulesList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
