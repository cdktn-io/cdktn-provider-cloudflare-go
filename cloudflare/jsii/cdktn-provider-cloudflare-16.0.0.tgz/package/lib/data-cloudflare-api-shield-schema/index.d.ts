/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareApiShieldSchemaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Omit the source-files of schemas and only retrieve their meta-data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/api_shield_schema#omit_source DataCloudflareApiShieldSchema#omit_source}
    */
    readonly omitSource?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/api_shield_schema#schema_id DataCloudflareApiShieldSchema#schema_id}
    */
    readonly schemaId: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/api_shield_schema#zone_id DataCloudflareApiShieldSchema#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/api_shield_schema cloudflare_api_shield_schema}
*/
export declare class DataCloudflareApiShieldSchema extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_api_shield_schema";
    /**
    * Generates CDKTN code for importing a DataCloudflareApiShieldSchema resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareApiShieldSchema to import
    * @param importFromId The id of the existing DataCloudflareApiShieldSchema that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/api_shield_schema#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareApiShieldSchema to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/api_shield_schema cloudflare_api_shield_schema} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareApiShieldSchemaConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareApiShieldSchemaConfig);
    get createdAt(): string;
    get kind(): string;
    get name(): string;
    private _omitSource?;
    get omitSource(): boolean | cdktn.IResolvable;
    set omitSource(value: boolean | cdktn.IResolvable);
    resetOmitSource(): void;
    get omitSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _schemaId?;
    get schemaId(): string;
    set schemaId(value: string);
    get schemaIdInput(): string | undefined;
    get source(): string;
    get validationEnabled(): cdktn.IResolvable;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
