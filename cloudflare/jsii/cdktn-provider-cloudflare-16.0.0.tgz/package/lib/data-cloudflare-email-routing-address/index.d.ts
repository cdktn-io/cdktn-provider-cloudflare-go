/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailRoutingAddressConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address#account_id DataCloudflareEmailRoutingAddress#account_id}
    */
    readonly accountId?: string;
    /**
    * Destination address identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address#destination_address_identifier DataCloudflareEmailRoutingAddress#destination_address_identifier}
    */
    readonly destinationAddressIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address#filter DataCloudflareEmailRoutingAddress#filter}
    */
    readonly filter?: DataCloudflareEmailRoutingAddressFilter;
}
export interface DataCloudflareEmailRoutingAddressFilter {
    /**
    * Sorts results in an ascending or descending order.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address#direction DataCloudflareEmailRoutingAddress#direction}
    */
    readonly direction?: string;
    /**
    * Filter by verified destination addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address#verified DataCloudflareEmailRoutingAddress#verified}
    */
    readonly verified?: boolean | cdktn.IResolvable;
}
export declare function dataCloudflareEmailRoutingAddressFilterToTerraform(struct?: DataCloudflareEmailRoutingAddressFilter | cdktn.IResolvable): any;
export declare function dataCloudflareEmailRoutingAddressFilterToHclTerraform(struct?: DataCloudflareEmailRoutingAddressFilter | cdktn.IResolvable): any;
export declare class DataCloudflareEmailRoutingAddressFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailRoutingAddressFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareEmailRoutingAddressFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _verified?;
    get verified(): boolean | cdktn.IResolvable;
    set verified(value: boolean | cdktn.IResolvable);
    resetVerified(): void;
    get verifiedInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address cloudflare_email_routing_address}
*/
export declare class DataCloudflareEmailRoutingAddress extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_routing_address";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailRoutingAddress resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailRoutingAddress to import
    * @param importFromId The id of the existing DataCloudflareEmailRoutingAddress that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailRoutingAddress to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_routing_address cloudflare_email_routing_address} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailRoutingAddressConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareEmailRoutingAddressConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get created(): string;
    private _destinationAddressIdentifier?;
    get destinationAddressIdentifier(): string;
    set destinationAddressIdentifier(value: string);
    resetDestinationAddressIdentifier(): void;
    get destinationAddressIdentifierInput(): string | undefined;
    get email(): string;
    private _filter;
    get filter(): DataCloudflareEmailRoutingAddressFilterOutputReference;
    putFilter(value: DataCloudflareEmailRoutingAddressFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareEmailRoutingAddressFilter | undefined;
    get id(): string;
    get modified(): string;
    get tag(): string;
    get verified(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
