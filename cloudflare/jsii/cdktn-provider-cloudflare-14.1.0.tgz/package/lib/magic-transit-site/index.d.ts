/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MagicTransitSiteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#account_id MagicTransitSite#account_id}
    */
    readonly accountId: string;
    /**
    * Magic Connector identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#connector_id MagicTransitSite#connector_id}
    */
    readonly connectorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#description MagicTransitSite#description}
    */
    readonly description?: string;
    /**
    * Site high availability mode. If set to true, the site can have two connectors and runs in high availability mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#ha_mode MagicTransitSite#ha_mode}
    */
    readonly haMode?: boolean | cdktn.IResolvable;
    /**
    * Location of site in latitude and longitude.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#location MagicTransitSite#location}
    */
    readonly location?: MagicTransitSiteLocation;
    /**
    * The name of the site.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#name MagicTransitSite#name}
    */
    readonly name: string;
    /**
    * Magic Connector identifier tag. Used when high availability mode is on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#secondary_connector_id MagicTransitSite#secondary_connector_id}
    */
    readonly secondaryConnectorId?: string;
}
export interface MagicTransitSiteLocation {
    /**
    * Latitude
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#lat MagicTransitSite#lat}
    */
    readonly lat?: string;
    /**
    * Longitude
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#lon MagicTransitSite#lon}
    */
    readonly lon?: string;
}
export declare function magicTransitSiteLocationToTerraform(struct?: MagicTransitSiteLocation | cdktn.IResolvable): any;
export declare function magicTransitSiteLocationToHclTerraform(struct?: MagicTransitSiteLocation | cdktn.IResolvable): any;
export declare class MagicTransitSiteLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MagicTransitSiteLocation | cdktn.IResolvable | undefined;
    set internalValue(value: MagicTransitSiteLocation | cdktn.IResolvable | undefined);
    private _lat?;
    get lat(): string;
    set lat(value: string);
    resetLat(): void;
    get latInput(): string | undefined;
    private _lon?;
    get lon(): string;
    set lon(value: string);
    resetLon(): void;
    get lonInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site cloudflare_magic_transit_site}
*/
export declare class MagicTransitSite extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_magic_transit_site";
    /**
    * Generates CDKTN code for importing a MagicTransitSite resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MagicTransitSite to import
    * @param importFromId The id of the existing MagicTransitSite that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MagicTransitSite to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/magic_transit_site cloudflare_magic_transit_site} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MagicTransitSiteConfig
    */
    constructor(scope: Construct, id: string, config: MagicTransitSiteConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _connectorId?;
    get connectorId(): string;
    set connectorId(value: string);
    resetConnectorId(): void;
    get connectorIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _haMode?;
    get haMode(): boolean | cdktn.IResolvable;
    set haMode(value: boolean | cdktn.IResolvable);
    resetHaMode(): void;
    get haModeInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _location;
    get location(): MagicTransitSiteLocationOutputReference;
    putLocation(value: MagicTransitSiteLocation): void;
    resetLocation(): void;
    get locationInput(): cdktn.IResolvable | MagicTransitSiteLocation | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secondaryConnectorId?;
    get secondaryConnectorId(): string;
    set secondaryConnectorId(value: string);
    resetSecondaryConnectorId(): void;
    get secondaryConnectorIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
