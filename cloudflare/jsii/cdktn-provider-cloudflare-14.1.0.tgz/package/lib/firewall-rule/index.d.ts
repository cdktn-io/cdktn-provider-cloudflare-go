/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FirewallRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The action to perform when the threshold of matched traffic within the configured period is exceeded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#action FirewallRule#action}
    */
    readonly action: FirewallRuleAction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#filter FirewallRule#filter}
    */
    readonly filter: FirewallRuleFilter;
    /**
    * Defines an identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#zone_id FirewallRule#zone_id}
    */
    readonly zoneId: string;
}
export interface FirewallRuleActionResponse {
    /**
    * The response body to return. The value must conform to the configured content type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#body FirewallRule#body}
    */
    readonly body?: string;
    /**
    * The content type of the body. Must be one of the following: `text/plain`, `text/xml`, or `application/json`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#content_type FirewallRule#content_type}
    */
    readonly contentType?: string;
}
export declare function firewallRuleActionResponseToTerraform(struct?: FirewallRuleActionResponse | cdktn.IResolvable): any;
export declare function firewallRuleActionResponseToHclTerraform(struct?: FirewallRuleActionResponse | cdktn.IResolvable): any;
export declare class FirewallRuleActionResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FirewallRuleActionResponse | cdktn.IResolvable | undefined;
    set internalValue(value: FirewallRuleActionResponse | cdktn.IResolvable | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
}
export interface FirewallRuleAction {
    /**
    * The action to perform.
    * Available values: "simulate", "ban", "challenge", "js_challenge", "managed_challenge".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#mode FirewallRule#mode}
    */
    readonly mode?: string;
    /**
    * A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional.
    * Notes: If you omit this object, Cloudflare will use the default HTML error page. If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone challenge pages and you should not provide the "response" object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#response FirewallRule#response}
    */
    readonly response?: FirewallRuleActionResponse;
    /**
    * The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period.
    * Notes: If "mode" is "challenge", "managed_challenge", or "js_challenge", Cloudflare will use the zone's Challenge Passage time and you should not provide this value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#timeout FirewallRule#timeout}
    */
    readonly timeout?: number;
}
export declare function firewallRuleActionToTerraform(struct?: FirewallRuleAction | cdktn.IResolvable): any;
export declare function firewallRuleActionToHclTerraform(struct?: FirewallRuleAction | cdktn.IResolvable): any;
export declare class FirewallRuleActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FirewallRuleAction | cdktn.IResolvable | undefined;
    set internalValue(value: FirewallRuleAction | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _response;
    get response(): FirewallRuleActionResponseOutputReference;
    putResponse(value: FirewallRuleActionResponse): void;
    resetResponse(): void;
    get responseInput(): cdktn.IResolvable | FirewallRuleActionResponse | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
}
export interface FirewallRuleFilter {
    /**
    * An informative summary of the filter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#description FirewallRule#description}
    */
    readonly description?: string;
    /**
    * The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#expression FirewallRule#expression}
    */
    readonly expression?: string;
    /**
    * When true, indicates that the filter is currently paused.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#paused FirewallRule#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * A short reference tag. Allows you to select related filters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#ref FirewallRule#ref}
    */
    readonly ref?: string;
}
export declare function firewallRuleFilterToTerraform(struct?: FirewallRuleFilter | cdktn.IResolvable): any;
export declare function firewallRuleFilterToHclTerraform(struct?: FirewallRuleFilter | cdktn.IResolvable): any;
export declare class FirewallRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FirewallRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: FirewallRuleFilter | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    get id(): string;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule cloudflare_firewall_rule}
*/
export declare class FirewallRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_firewall_rule";
    /**
    * Generates CDKTN code for importing a FirewallRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FirewallRule to import
    * @param importFromId The id of the existing FirewallRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FirewallRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/firewall_rule cloudflare_firewall_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FirewallRuleConfig
    */
    constructor(scope: Construct, id: string, config: FirewallRuleConfig);
    private _action;
    get action(): FirewallRuleActionOutputReference;
    putAction(value: FirewallRuleAction): void;
    get actionInput(): cdktn.IResolvable | FirewallRuleAction | undefined;
    get description(): string;
    private _filter;
    get filter(): FirewallRuleFilterOutputReference;
    putFilter(value: FirewallRuleFilter): void;
    get filterInput(): cdktn.IResolvable | FirewallRuleFilter | undefined;
    get id(): string;
    get paused(): cdktn.IResolvable;
    get priority(): number;
    get products(): string[];
    get ref(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
