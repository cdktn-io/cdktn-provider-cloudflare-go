/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiSearchTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token#account_id AiSearchToken#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token#cf_api_id AiSearchToken#cf_api_id}
    */
    readonly cfApiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token#cf_api_key AiSearchToken#cf_api_key}
    */
    readonly cfApiKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token#legacy AiSearchToken#legacy}
    */
    readonly legacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token#name AiSearchToken#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token cloudflare_ai_search_token}
*/
export declare class AiSearchToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ai_search_token";
    /**
    * Generates CDKTN code for importing a AiSearchToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiSearchToken to import
    * @param importFromId The id of the existing AiSearchToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiSearchToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/ai_search_token cloudflare_ai_search_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiSearchTokenConfig
    */
    constructor(scope: Construct, id: string, config: AiSearchTokenConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _cfApiId?;
    get cfApiId(): string;
    set cfApiId(value: string);
    get cfApiIdInput(): string | undefined;
    private _cfApiKey?;
    get cfApiKey(): string;
    set cfApiKey(value: string);
    get cfApiKeyInput(): string | undefined;
    get createdAt(): string;
    get createdBy(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    private _legacy?;
    get legacy(): boolean | cdktn.IResolvable;
    set legacy(value: boolean | cdktn.IResolvable);
    resetLegacy(): void;
    get legacyInput(): boolean | cdktn.IResolvable | undefined;
    get modifiedAt(): string;
    get modifiedBy(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
