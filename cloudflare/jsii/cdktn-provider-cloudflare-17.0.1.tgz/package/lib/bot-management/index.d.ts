/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BotManagementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Configure blocking behavior for supported personal AI agents.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#ai_agents BotManagement#ai_agents}
    */
    readonly aiAgents?: BotManagementAiAgents;
    /**
    * Temporary migration flag tracking zones opted out of AI bots managed-rule updates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#ai_bots_migration_opt_out BotManagement#ai_bots_migration_opt_out}
    */
    readonly aiBotsMigrationOptOut?: boolean | cdktn.IResolvable;
    /**
    * Enable rule to block AI Scrapers and Crawlers.
    * Available values: "block", "disabled", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#ai_bots_protection BotManagement#ai_bots_protection}
    */
    readonly aiBotsProtection?: string;
    /**
    * Configure robots.txt policy for AI model training bots.
    * Available values: "disabled", "disallow", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#ai_training BotManagement#ai_training}
    */
    readonly aiTraining?: string;
    /**
    * Configure robots.txt policy for AI assistant and agent bots.
    * Available values: "disabled", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#ai_user BotManagement#ai_user}
    */
    readonly aiUser?: string;
    /**
    * Configure robots.txt policy for AI search bots.
    * Available values: "disabled", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#aisearch BotManagement#aisearch}
    */
    readonly aisearch?: string;
    /**
    * Automatically update to the newest bot detection models created by Cloudflare as they are released. [Learn more.](https://developers.cloudflare.com/bots/reference/machine-learning-models#model-versions-and-release-notes)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#auto_update_model BotManagement#auto_update_model}
    */
    readonly autoUpdateModel?: boolean | cdktn.IResolvable;
    /**
    * Indicates that the bot management cookie can be placed on end user devices accessing the site. Defaults to true
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#bm_cookie_enabled BotManagement#bm_cookie_enabled}
    */
    readonly bmCookieEnabled?: boolean | cdktn.IResolvable;
    /**
    * Enable Bot Preference Sync for this zone. When enabled, Cloudflare can serve robots.txt content derived from the zone's AI Search, AI User, and AI Training preferences.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#bot_preference_sync_enabled BotManagement#bot_preference_sync_enabled}
    */
    readonly botPreferenceSyncEnabled?: boolean | cdktn.IResolvable;
    /**
    * Specifies the Robots Access Control License variant to use.
    * Available values: "off", "policy_only".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#cf_robots_variant BotManagement#cf_robots_variant}
    */
    readonly cfRobotsVariant?: string;
    /**
    * Enable rule to block content bots. When enabled, blocks automated traffic with low bot scores, excluding safe verified bot categories. Exceptions should be managed via skip rules.
    * Available values: "block", "disabled".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#content_bots_protection BotManagement#content_bots_protection}
    */
    readonly contentBotsProtection?: string;
    /**
    * Enable rule to punish AI Scrapers and Crawlers via a link maze.
    * Available values: "enabled", "disabled".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#crawler_protection BotManagement#crawler_protection}
    */
    readonly crawlerProtection?: string;
    /**
    * Use lightweight, invisible JavaScript detections to improve Bot Management. [Learn more about JavaScript Detections](https://developers.cloudflare.com/bots/reference/javascript-detections/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#enable_js BotManagement#enable_js}
    */
    readonly enableJs?: boolean | cdktn.IResolvable;
    /**
    * Whether to enable Bot Fight Mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#fight_mode BotManagement#fight_mode}
    */
    readonly fightMode?: boolean | cdktn.IResolvable;
    /**
    * Enable cloudflare managed robots.txt. If an existing robots.txt is detected, then managed robots.txt will be prepended to the existing robots.txt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#is_robots_txt_managed BotManagement#is_robots_txt_managed}
    */
    readonly isRobotsTxtManaged?: boolean | cdktn.IResolvable;
    /**
    * Whether to use JavaScript Detection results submitted through the API for this zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#jsd_api_results_enabled BotManagement#jsd_api_results_enabled}
    */
    readonly jsdApiResultsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether to optimize Super Bot Fight Mode protections for Wordpress.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#optimize_wordpress BotManagement#optimize_wordpress}
    */
    readonly optimizeWordpress?: boolean | cdktn.IResolvable;
    /**
    * Super Bot Fight Mode (SBFM) action to take on definitely automated requests.
    * Available values: "allow", "block", "managed_challenge".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#sbfm_definitely_automated BotManagement#sbfm_definitely_automated}
    */
    readonly sbfmDefinitelyAutomated?: string;
    /**
    * Super Bot Fight Mode (SBFM) action to take on likely automated requests.
    * Available values: "allow", "block", "managed_challenge".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#sbfm_likely_automated BotManagement#sbfm_likely_automated}
    */
    readonly sbfmLikelyAutomated?: string;
    /**
    * Super Bot Fight Mode (SBFM) to enable static resource protection.
    * Enable if static resources on your application need bot protection.
    * Note: Static resource protection can also result in legitimate traffic being blocked.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#sbfm_static_resource_protection BotManagement#sbfm_static_resource_protection}
    */
    readonly sbfmStaticResourceProtection?: boolean | cdktn.IResolvable;
    /**
    * Super Bot Fight Mode (SBFM) action to take on verified bots requests.
    * Available values: "allow", "block".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#sbfm_verified_bots BotManagement#sbfm_verified_bots}
    */
    readonly sbfmVerifiedBots?: string;
    /**
    * Whether to disable tracking the highest bot score for a session in the Bot Management cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#suppress_session_score BotManagement#suppress_session_score}
    */
    readonly suppressSessionScore?: boolean | cdktn.IResolvable;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#zone_id BotManagement#zone_id}
    */
    readonly zoneId: string;
}
export interface BotManagementAiAgents {
    /**
    * Action to apply to one supported personal AI agent.
    * Available values: "disabled", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#anthropic_agent BotManagement#anthropic_agent}
    */
    readonly anthropicAgent?: string;
    /**
    * Action to apply to one supported personal AI agent.
    * Available values: "disabled", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#google_agent BotManagement#google_agent}
    */
    readonly googleAgent?: string;
    /**
    * Action to apply to one supported personal AI agent.
    * Available values: "disabled", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#instinct BotManagement#instinct}
    */
    readonly instinct?: string;
    /**
    * Action to apply to one supported personal AI agent.
    * Available values: "disabled", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#muse BotManagement#muse}
    */
    readonly muse?: string;
    /**
    * Action to apply to one supported personal AI agent.
    * Available values: "disabled", "block", "only_on_ad_pages".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#openai_agent BotManagement#openai_agent}
    */
    readonly openaiAgent?: string;
}
export declare function botManagementAiAgentsToTerraform(struct?: BotManagementAiAgents | cdktn.IResolvable): any;
export declare function botManagementAiAgentsToHclTerraform(struct?: BotManagementAiAgents | cdktn.IResolvable): any;
export declare class BotManagementAiAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BotManagementAiAgents | cdktn.IResolvable | undefined;
    set internalValue(value: BotManagementAiAgents | cdktn.IResolvable | undefined);
    private _anthropicAgent?;
    get anthropicAgent(): string;
    set anthropicAgent(value: string);
    resetAnthropicAgent(): void;
    get anthropicAgentInput(): string | undefined;
    private _googleAgent?;
    get googleAgent(): string;
    set googleAgent(value: string);
    resetGoogleAgent(): void;
    get googleAgentInput(): string | undefined;
    private _instinct?;
    get instinct(): string;
    set instinct(value: string);
    resetInstinct(): void;
    get instinctInput(): string | undefined;
    private _muse?;
    get muse(): string;
    set muse(value: string);
    resetMuse(): void;
    get museInput(): string | undefined;
    private _openaiAgent?;
    get openaiAgent(): string;
    set openaiAgent(value: string);
    resetOpenaiAgent(): void;
    get openaiAgentInput(): string | undefined;
}
export interface BotManagementStaleZoneConfiguration {
}
export declare function botManagementStaleZoneConfigurationToTerraform(struct?: BotManagementStaleZoneConfiguration): any;
export declare function botManagementStaleZoneConfigurationToHclTerraform(struct?: BotManagementStaleZoneConfiguration): any;
export declare class BotManagementStaleZoneConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BotManagementStaleZoneConfiguration | undefined;
    set internalValue(value: BotManagementStaleZoneConfiguration | undefined);
    get fightMode(): cdktn.IResolvable;
    get optimizeWordpress(): cdktn.IResolvable;
    get sbfmDefinitelyAutomated(): string;
    get sbfmLikelyAutomated(): string;
    get sbfmStaticResourceProtection(): string;
    get sbfmVerifiedBots(): string;
    get suppressSessionScore(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management cloudflare_bot_management}
*/
export declare class BotManagement extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_bot_management";
    /**
    * Generates CDKTN code for importing a BotManagement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BotManagement to import
    * @param importFromId The id of the existing BotManagement that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BotManagement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/resources/bot_management cloudflare_bot_management} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BotManagementConfig
    */
    constructor(scope: Construct, id: string, config: BotManagementConfig);
    private _aiAgents;
    get aiAgents(): BotManagementAiAgentsOutputReference;
    putAiAgents(value: BotManagementAiAgents): void;
    resetAiAgents(): void;
    get aiAgentsInput(): cdktn.IResolvable | BotManagementAiAgents | undefined;
    private _aiBotsMigrationOptOut?;
    get aiBotsMigrationOptOut(): boolean | cdktn.IResolvable;
    set aiBotsMigrationOptOut(value: boolean | cdktn.IResolvable);
    resetAiBotsMigrationOptOut(): void;
    get aiBotsMigrationOptOutInput(): boolean | cdktn.IResolvable | undefined;
    private _aiBotsProtection?;
    get aiBotsProtection(): string;
    set aiBotsProtection(value: string);
    resetAiBotsProtection(): void;
    get aiBotsProtectionInput(): string | undefined;
    private _aiTraining?;
    get aiTraining(): string;
    set aiTraining(value: string);
    resetAiTraining(): void;
    get aiTrainingInput(): string | undefined;
    private _aiUser?;
    get aiUser(): string;
    set aiUser(value: string);
    resetAiUser(): void;
    get aiUserInput(): string | undefined;
    private _aisearch?;
    get aisearch(): string;
    set aisearch(value: string);
    resetAisearch(): void;
    get aisearchInput(): string | undefined;
    private _autoUpdateModel?;
    get autoUpdateModel(): boolean | cdktn.IResolvable;
    set autoUpdateModel(value: boolean | cdktn.IResolvable);
    resetAutoUpdateModel(): void;
    get autoUpdateModelInput(): boolean | cdktn.IResolvable | undefined;
    private _bmCookieEnabled?;
    get bmCookieEnabled(): boolean | cdktn.IResolvable;
    set bmCookieEnabled(value: boolean | cdktn.IResolvable);
    resetBmCookieEnabled(): void;
    get bmCookieEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _botPreferenceSyncEnabled?;
    get botPreferenceSyncEnabled(): boolean | cdktn.IResolvable;
    set botPreferenceSyncEnabled(value: boolean | cdktn.IResolvable);
    resetBotPreferenceSyncEnabled(): void;
    get botPreferenceSyncEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _cfRobotsVariant?;
    get cfRobotsVariant(): string;
    set cfRobotsVariant(value: string);
    resetCfRobotsVariant(): void;
    get cfRobotsVariantInput(): string | undefined;
    private _contentBotsProtection?;
    get contentBotsProtection(): string;
    set contentBotsProtection(value: string);
    resetContentBotsProtection(): void;
    get contentBotsProtectionInput(): string | undefined;
    private _crawlerProtection?;
    get crawlerProtection(): string;
    set crawlerProtection(value: string);
    resetCrawlerProtection(): void;
    get crawlerProtectionInput(): string | undefined;
    private _enableJs?;
    get enableJs(): boolean | cdktn.IResolvable;
    set enableJs(value: boolean | cdktn.IResolvable);
    resetEnableJs(): void;
    get enableJsInput(): boolean | cdktn.IResolvable | undefined;
    private _fightMode?;
    get fightMode(): boolean | cdktn.IResolvable;
    set fightMode(value: boolean | cdktn.IResolvable);
    resetFightMode(): void;
    get fightModeInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _isRobotsTxtManaged?;
    get isRobotsTxtManaged(): boolean | cdktn.IResolvable;
    set isRobotsTxtManaged(value: boolean | cdktn.IResolvable);
    resetIsRobotsTxtManaged(): void;
    get isRobotsTxtManagedInput(): boolean | cdktn.IResolvable | undefined;
    private _jsdApiResultsEnabled?;
    get jsdApiResultsEnabled(): boolean | cdktn.IResolvable;
    set jsdApiResultsEnabled(value: boolean | cdktn.IResolvable);
    resetJsdApiResultsEnabled(): void;
    get jsdApiResultsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _optimizeWordpress?;
    get optimizeWordpress(): boolean | cdktn.IResolvable;
    set optimizeWordpress(value: boolean | cdktn.IResolvable);
    resetOptimizeWordpress(): void;
    get optimizeWordpressInput(): boolean | cdktn.IResolvable | undefined;
    private _sbfmDefinitelyAutomated?;
    get sbfmDefinitelyAutomated(): string;
    set sbfmDefinitelyAutomated(value: string);
    resetSbfmDefinitelyAutomated(): void;
    get sbfmDefinitelyAutomatedInput(): string | undefined;
    private _sbfmLikelyAutomated?;
    get sbfmLikelyAutomated(): string;
    set sbfmLikelyAutomated(value: string);
    resetSbfmLikelyAutomated(): void;
    get sbfmLikelyAutomatedInput(): string | undefined;
    private _sbfmStaticResourceProtection?;
    get sbfmStaticResourceProtection(): boolean | cdktn.IResolvable;
    set sbfmStaticResourceProtection(value: boolean | cdktn.IResolvable);
    resetSbfmStaticResourceProtection(): void;
    get sbfmStaticResourceProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _sbfmVerifiedBots?;
    get sbfmVerifiedBots(): string;
    set sbfmVerifiedBots(value: string);
    resetSbfmVerifiedBots(): void;
    get sbfmVerifiedBotsInput(): string | undefined;
    private _staleZoneConfiguration;
    get staleZoneConfiguration(): BotManagementStaleZoneConfigurationOutputReference;
    private _suppressSessionScore?;
    get suppressSessionScore(): boolean | cdktn.IResolvable;
    set suppressSessionScore(value: boolean | cdktn.IResolvable);
    resetSuppressSessionScore(): void;
    get suppressSessionScoreInput(): boolean | cdktn.IResolvable | undefined;
    get usingLatestModel(): cdktn.IResolvable;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
