/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAccountTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token#account_id DataCloudflareAccountToken#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token#filter DataCloudflareAccountToken#filter}
    */
    readonly filter?: DataCloudflareAccountTokenFilter;
    /**
    * Token identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token#token_id DataCloudflareAccountToken#token_id}
    */
    readonly tokenId?: string;
}
export interface DataCloudflareAccountTokenConditionRequestIp {
}
export declare function dataCloudflareAccountTokenConditionRequestIpToTerraform(struct?: DataCloudflareAccountTokenConditionRequestIp): any;
export declare function dataCloudflareAccountTokenConditionRequestIpToHclTerraform(struct?: DataCloudflareAccountTokenConditionRequestIp): any;
export declare class DataCloudflareAccountTokenConditionRequestIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountTokenConditionRequestIp | undefined;
    set internalValue(value: DataCloudflareAccountTokenConditionRequestIp | undefined);
    get in(): string[];
    get notIn(): string[];
}
export interface DataCloudflareAccountTokenCondition {
}
export declare function dataCloudflareAccountTokenConditionToTerraform(struct?: DataCloudflareAccountTokenCondition): any;
export declare function dataCloudflareAccountTokenConditionToHclTerraform(struct?: DataCloudflareAccountTokenCondition): any;
export declare class DataCloudflareAccountTokenConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountTokenCondition | undefined;
    set internalValue(value: DataCloudflareAccountTokenCondition | undefined);
    private _requestIp;
    get requestIp(): DataCloudflareAccountTokenConditionRequestIpOutputReference;
}
export interface DataCloudflareAccountTokenFilter {
    /**
    * Direction to order results.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token#direction DataCloudflareAccountToken#direction}
    */
    readonly direction?: string;
    /**
    * When true, includes recently-expired tokens in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token#include_expired DataCloudflareAccountToken#include_expired}
    */
    readonly includeExpired?: boolean | cdktn.IResolvable;
}
export declare function dataCloudflareAccountTokenFilterToTerraform(struct?: DataCloudflareAccountTokenFilter | cdktn.IResolvable): any;
export declare function dataCloudflareAccountTokenFilterToHclTerraform(struct?: DataCloudflareAccountTokenFilter | cdktn.IResolvable): any;
export declare class DataCloudflareAccountTokenFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountTokenFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareAccountTokenFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _includeExpired?;
    get includeExpired(): boolean | cdktn.IResolvable;
    set includeExpired(value: boolean | cdktn.IResolvable);
    resetIncludeExpired(): void;
    get includeExpiredInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataCloudflareAccountTokenPoliciesPermissionGroupsMeta {
}
export declare function dataCloudflareAccountTokenPoliciesPermissionGroupsMetaToTerraform(struct?: DataCloudflareAccountTokenPoliciesPermissionGroupsMeta): any;
export declare function dataCloudflareAccountTokenPoliciesPermissionGroupsMetaToHclTerraform(struct?: DataCloudflareAccountTokenPoliciesPermissionGroupsMeta): any;
export declare class DataCloudflareAccountTokenPoliciesPermissionGroupsMetaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountTokenPoliciesPermissionGroupsMeta | undefined;
    set internalValue(value: DataCloudflareAccountTokenPoliciesPermissionGroupsMeta | undefined);
    get key(): string;
    get value(): string;
}
export interface DataCloudflareAccountTokenPoliciesPermissionGroups {
}
export declare function dataCloudflareAccountTokenPoliciesPermissionGroupsToTerraform(struct?: DataCloudflareAccountTokenPoliciesPermissionGroups): any;
export declare function dataCloudflareAccountTokenPoliciesPermissionGroupsToHclTerraform(struct?: DataCloudflareAccountTokenPoliciesPermissionGroups): any;
export declare class DataCloudflareAccountTokenPoliciesPermissionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAccountTokenPoliciesPermissionGroups | undefined;
    set internalValue(value: DataCloudflareAccountTokenPoliciesPermissionGroups | undefined);
    get id(): string;
    private _meta;
    get meta(): DataCloudflareAccountTokenPoliciesPermissionGroupsMetaOutputReference;
    get name(): string;
}
export declare class DataCloudflareAccountTokenPoliciesPermissionGroupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAccountTokenPoliciesPermissionGroupsOutputReference;
}
export interface DataCloudflareAccountTokenPolicies {
}
export declare function dataCloudflareAccountTokenPoliciesToTerraform(struct?: DataCloudflareAccountTokenPolicies): any;
export declare function dataCloudflareAccountTokenPoliciesToHclTerraform(struct?: DataCloudflareAccountTokenPolicies): any;
export declare class DataCloudflareAccountTokenPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAccountTokenPolicies | undefined;
    set internalValue(value: DataCloudflareAccountTokenPolicies | undefined);
    get effect(): string;
    get id(): string;
    private _permissionGroups;
    get permissionGroups(): DataCloudflareAccountTokenPoliciesPermissionGroupsList;
    private _resources;
    get resources(): cdktn.StringMap;
}
export declare class DataCloudflareAccountTokenPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAccountTokenPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token cloudflare_account_token}
*/
export declare class DataCloudflareAccountToken extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_account_token";
    /**
    * Generates CDKTN code for importing a DataCloudflareAccountToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAccountToken to import
    * @param importFromId The id of the existing DataCloudflareAccountToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAccountToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/account_token cloudflare_account_token} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAccountTokenConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareAccountTokenConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _condition;
    get condition(): DataCloudflareAccountTokenConditionOutputReference;
    get expiresOn(): string;
    private _filter;
    get filter(): DataCloudflareAccountTokenFilterOutputReference;
    putFilter(value: DataCloudflareAccountTokenFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareAccountTokenFilter | undefined;
    get id(): string;
    get issuedOn(): string;
    get lastUsedOn(): string;
    get modifiedOn(): string;
    get name(): string;
    get notBefore(): string;
    private _policies;
    get policies(): DataCloudflareAccountTokenPoliciesList;
    get status(): string;
    private _tokenId?;
    get tokenId(): string;
    set tokenId(value: string);
    resetTokenId(): void;
    get tokenIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
