/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAccountPermissionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_permission_group#account_id DataCloudflareAccountPermissionGroup#account_id}
    */
    readonly accountId: string;
    /**
    * Permission Group identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_permission_group#permission_group_id DataCloudflareAccountPermissionGroup#permission_group_id}
    */
    readonly permissionGroupId: string;
}
export interface DataCloudflareAccountPermissionGroupMeta {
}
export declare function dataCloudflareAccountPermissionGroupMetaToTerraform(struct?: DataCloudflareAccountPermissionGroupMeta): any;
export declare function dataCloudflareAccountPermissionGroupMetaToHclTerraform(struct?: DataCloudflareAccountPermissionGroupMeta): any;
export declare class DataCloudflareAccountPermissionGroupMetaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountPermissionGroupMeta | undefined;
    set internalValue(value: DataCloudflareAccountPermissionGroupMeta | undefined);
    get key(): string;
    get value(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_permission_group cloudflare_account_permission_group}
*/
export declare class DataCloudflareAccountPermissionGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_account_permission_group";
    /**
    * Generates CDKTN code for importing a DataCloudflareAccountPermissionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAccountPermissionGroup to import
    * @param importFromId The id of the existing DataCloudflareAccountPermissionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_permission_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAccountPermissionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_permission_group cloudflare_account_permission_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAccountPermissionGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareAccountPermissionGroupConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get id(): string;
    private _meta;
    get meta(): DataCloudflareAccountPermissionGroupMetaOutputReference;
    get name(): string;
    private _permissionGroupId?;
    get permissionGroupId(): string;
    set permissionGroupId(value: string);
    get permissionGroupIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
