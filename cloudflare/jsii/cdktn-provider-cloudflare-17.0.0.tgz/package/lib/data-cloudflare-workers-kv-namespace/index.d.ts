/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkersKvNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the Cloudflare account that owns the Workers KV namespaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace#account_id DataCloudflareWorkersKvNamespace#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace#filter DataCloudflareWorkersKvNamespace#filter}
    */
    readonly filter?: DataCloudflareWorkersKvNamespaceFilter;
    /**
    * ID of the Workers KV namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace#namespace_id DataCloudflareWorkersKvNamespace#namespace_id}
    */
    readonly namespaceId?: string;
}
export interface DataCloudflareWorkersKvNamespaceFilter {
    /**
    * Sort namespaces in ascending (`asc`) or descending (`desc`) order.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace#direction DataCloudflareWorkersKvNamespace#direction}
    */
    readonly direction?: string;
    /**
    * Namespace field to sort by (`id` or `title`).
    * Available values: "id", "title".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace#order DataCloudflareWorkersKvNamespace#order}
    */
    readonly order?: string;
}
export declare function dataCloudflareWorkersKvNamespaceFilterToTerraform(struct?: DataCloudflareWorkersKvNamespaceFilter | cdktn.IResolvable): any;
export declare function dataCloudflareWorkersKvNamespaceFilterToHclTerraform(struct?: DataCloudflareWorkersKvNamespaceFilter | cdktn.IResolvable): any;
export declare class DataCloudflareWorkersKvNamespaceFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersKvNamespaceFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareWorkersKvNamespaceFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace cloudflare_workers_kv_namespace}
*/
export declare class DataCloudflareWorkersKvNamespace extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_workers_kv_namespace";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkersKvNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkersKvNamespace to import
    * @param importFromId The id of the existing DataCloudflareWorkersKvNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkersKvNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/workers_kv_namespace cloudflare_workers_kv_namespace} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkersKvNamespaceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWorkersKvNamespaceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _filter;
    get filter(): DataCloudflareWorkersKvNamespaceFilterOutputReference;
    putFilter(value: DataCloudflareWorkersKvNamespaceFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareWorkersKvNamespaceFilter | undefined;
    get id(): string;
    get jurisdiction(): string;
    get mode(): string;
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    resetNamespaceId(): void;
    get namespaceIdInput(): string | undefined;
    get supportsUrlEncoding(): cdktn.IResolvable;
    get title(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
