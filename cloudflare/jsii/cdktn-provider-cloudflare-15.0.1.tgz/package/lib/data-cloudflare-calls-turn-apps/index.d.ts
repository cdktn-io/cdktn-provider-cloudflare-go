/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCallsTurnAppsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/calls_turn_apps#account_id DataCloudflareCallsTurnApps#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/calls_turn_apps#max_items DataCloudflareCallsTurnApps#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareCallsTurnAppsResult {
}
export declare function dataCloudflareCallsTurnAppsResultToTerraform(struct?: DataCloudflareCallsTurnAppsResult): any;
export declare function dataCloudflareCallsTurnAppsResultToHclTerraform(struct?: DataCloudflareCallsTurnAppsResult): any;
export declare class DataCloudflareCallsTurnAppsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCallsTurnAppsResult | undefined;
    set internalValue(value: DataCloudflareCallsTurnAppsResult | undefined);
    get created(): string;
    get modified(): string;
    get name(): string;
    get uid(): string;
}
export declare class DataCloudflareCallsTurnAppsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCallsTurnAppsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/calls_turn_apps cloudflare_calls_turn_apps}
*/
export declare class DataCloudflareCallsTurnApps extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_calls_turn_apps";
    /**
    * Generates CDKTN code for importing a DataCloudflareCallsTurnApps resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCallsTurnApps to import
    * @param importFromId The id of the existing DataCloudflareCallsTurnApps that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/calls_turn_apps#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCallsTurnApps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/calls_turn_apps cloudflare_calls_turn_apps} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCallsTurnAppsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareCallsTurnAppsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareCallsTurnAppsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
