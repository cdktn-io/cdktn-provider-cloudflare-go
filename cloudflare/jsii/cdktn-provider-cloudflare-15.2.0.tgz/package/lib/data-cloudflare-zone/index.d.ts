/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZoneConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#filter DataCloudflareZone#filter}
    */
    readonly filter?: DataCloudflareZoneFilter;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#zone_id DataCloudflareZone#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareZoneAccount {
}
export declare function dataCloudflareZoneAccountToTerraform(struct?: DataCloudflareZoneAccount): any;
export declare function dataCloudflareZoneAccountToHclTerraform(struct?: DataCloudflareZoneAccount): any;
export declare class DataCloudflareZoneAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneAccount | undefined;
    set internalValue(value: DataCloudflareZoneAccount | undefined);
    get id(): string;
    get name(): string;
}
export interface DataCloudflareZoneFilterAccount {
    /**
    * Filter by an account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#id DataCloudflareZone#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * An account Name. Optional filter operators can be provided to extend refine the search:
    *   * `equal` (default)
    *   * `not_equal`
    *   * `starts_with`
    *   * `ends_with`
    *   * `contains`
    *   * `starts_with_case_sensitive`
    *   * `ends_with_case_sensitive`
    *   * `contains_case_sensitive`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#name DataCloudflareZone#name}
    */
    readonly name?: string;
}
export declare function dataCloudflareZoneFilterAccountToTerraform(struct?: DataCloudflareZoneFilterAccount | cdktn.IResolvable): any;
export declare function dataCloudflareZoneFilterAccountToHclTerraform(struct?: DataCloudflareZoneFilterAccount | cdktn.IResolvable): any;
export declare class DataCloudflareZoneFilterAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneFilterAccount | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZoneFilterAccount | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DataCloudflareZoneFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#account DataCloudflareZone#account}
    */
    readonly account?: DataCloudflareZoneFilterAccount;
    /**
    * Direction to order zones.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#direction DataCloudflareZone#direction}
    */
    readonly direction?: string;
    /**
    * Whether to match all search requirements or at least one (any).
    * Available values: "any", "all".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#match DataCloudflareZone#match}
    */
    readonly match?: string;
    /**
    * A domain name. Optional filter operators can be provided to extend refine the search:
    *   * `equal` (default)
    *   * `not_equal`
    *   * `starts_with`
    *   * `ends_with`
    *   * `contains`
    *   * `starts_with_case_sensitive`
    *   * `ends_with_case_sensitive`
    *   * `contains_case_sensitive`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#name DataCloudflareZone#name}
    */
    readonly name?: string;
    /**
    * Field to order zones by.
    * Available values: "name", "status", "account.id", "account.name", "plan.id".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#order DataCloudflareZone#order}
    */
    readonly order?: string;
    /**
    * Specify a zone status to filter by.
    * Available values: "initializing", "pending", "active", "moved".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#status DataCloudflareZone#status}
    */
    readonly status?: string;
    /**
    * Zone types to filter by. Multiple types can be specified as a comma-separated list (e.g., ?type=full,partial,secondary). When this parameter is not provided, zones with type "internal" are excluded from the results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#type DataCloudflareZone#type}
    */
    readonly type?: string[];
}
export declare function dataCloudflareZoneFilterToTerraform(struct?: DataCloudflareZoneFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZoneFilterToHclTerraform(struct?: DataCloudflareZoneFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZoneFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZoneFilter | cdktn.IResolvable | undefined);
    private _account;
    get account(): DataCloudflareZoneFilterAccountOutputReference;
    putAccount(value: DataCloudflareZoneFilterAccount): void;
    resetAccount(): void;
    get accountInput(): cdktn.IResolvable | DataCloudflareZoneFilterAccount | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _type?;
    get type(): string[];
    set type(value: string[]);
    resetType(): void;
    get typeInput(): string[] | undefined;
}
export interface DataCloudflareZoneMeta {
}
export declare function dataCloudflareZoneMetaToTerraform(struct?: DataCloudflareZoneMeta): any;
export declare function dataCloudflareZoneMetaToHclTerraform(struct?: DataCloudflareZoneMeta): any;
export declare class DataCloudflareZoneMetaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneMeta | undefined;
    set internalValue(value: DataCloudflareZoneMeta | undefined);
    get cdnOnly(): cdktn.IResolvable;
    get customCertificateQuota(): number;
    get dnsOnly(): cdktn.IResolvable;
    get foundationDns(): cdktn.IResolvable;
    get pageRuleQuota(): number;
    get phishingDetected(): cdktn.IResolvable;
    get step(): number;
}
export interface DataCloudflareZoneOwner {
}
export declare function dataCloudflareZoneOwnerToTerraform(struct?: DataCloudflareZoneOwner): any;
export declare function dataCloudflareZoneOwnerToHclTerraform(struct?: DataCloudflareZoneOwner): any;
export declare class DataCloudflareZoneOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneOwner | undefined;
    set internalValue(value: DataCloudflareZoneOwner | undefined);
    get id(): string;
    get name(): string;
    get type(): string;
}
export interface DataCloudflareZonePlan {
}
export declare function dataCloudflareZonePlanToTerraform(struct?: DataCloudflareZonePlan): any;
export declare function dataCloudflareZonePlanToHclTerraform(struct?: DataCloudflareZonePlan): any;
export declare class DataCloudflareZonePlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZonePlan | undefined;
    set internalValue(value: DataCloudflareZonePlan | undefined);
    get canSubscribe(): cdktn.IResolvable;
    get currency(): string;
    get externallyManaged(): cdktn.IResolvable;
    get frequency(): string;
    get id(): string;
    get isSubscribed(): cdktn.IResolvable;
    get legacyDiscount(): cdktn.IResolvable;
    get legacyId(): string;
    get name(): string;
    get price(): number;
}
export interface DataCloudflareZoneTenant {
}
export declare function dataCloudflareZoneTenantToTerraform(struct?: DataCloudflareZoneTenant): any;
export declare function dataCloudflareZoneTenantToHclTerraform(struct?: DataCloudflareZoneTenant): any;
export declare class DataCloudflareZoneTenantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneTenant | undefined;
    set internalValue(value: DataCloudflareZoneTenant | undefined);
    get id(): string;
    get name(): string;
}
export interface DataCloudflareZoneTenantUnit {
}
export declare function dataCloudflareZoneTenantUnitToTerraform(struct?: DataCloudflareZoneTenantUnit): any;
export declare function dataCloudflareZoneTenantUnitToHclTerraform(struct?: DataCloudflareZoneTenantUnit): any;
export declare class DataCloudflareZoneTenantUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneTenantUnit | undefined;
    set internalValue(value: DataCloudflareZoneTenantUnit | undefined);
    get id(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone cloudflare_zone}
*/
export declare class DataCloudflareZone extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zone";
    /**
    * Generates CDKTN code for importing a DataCloudflareZone resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZone to import
    * @param importFromId The id of the existing DataCloudflareZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zone cloudflare_zone} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZoneConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZoneConfig);
    private _account;
    get account(): DataCloudflareZoneAccountOutputReference;
    get activatedOn(): string;
    get cnameSuffix(): string;
    get createdOn(): string;
    get developmentMode(): number;
    private _filter;
    get filter(): DataCloudflareZoneFilterOutputReference;
    putFilter(value: DataCloudflareZoneFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZoneFilter | undefined;
    get id(): string;
    private _meta;
    get meta(): DataCloudflareZoneMetaOutputReference;
    get modifiedOn(): string;
    get name(): string;
    get nameServers(): string[];
    get originalDnshost(): string;
    get originalNameServers(): string[];
    get originalRegistrar(): string;
    private _owner;
    get owner(): DataCloudflareZoneOwnerOutputReference;
    get paused(): cdktn.IResolvable;
    get permissions(): string[];
    private _plan;
    get plan(): DataCloudflareZonePlanOutputReference;
    get status(): string;
    private _tenant;
    get tenant(): DataCloudflareZoneTenantOutputReference;
    private _tenantUnit;
    get tenantUnit(): DataCloudflareZoneTenantUnitOutputReference;
    get type(): string;
    get vanityNameServers(): string[];
    get verificationKey(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
