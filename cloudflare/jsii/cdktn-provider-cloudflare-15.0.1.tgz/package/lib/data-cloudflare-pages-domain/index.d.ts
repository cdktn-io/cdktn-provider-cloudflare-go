/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflarePagesDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/pages_domain#account_id DataCloudflarePagesDomain#account_id}
    */
    readonly accountId?: string;
    /**
    * The domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/pages_domain#domain_name DataCloudflarePagesDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Name of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/pages_domain#project_name DataCloudflarePagesDomain#project_name}
    */
    readonly projectName: string;
}
export interface DataCloudflarePagesDomainValidationData {
}
export declare function dataCloudflarePagesDomainValidationDataToTerraform(struct?: DataCloudflarePagesDomainValidationData): any;
export declare function dataCloudflarePagesDomainValidationDataToHclTerraform(struct?: DataCloudflarePagesDomainValidationData): any;
export declare class DataCloudflarePagesDomainValidationDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesDomainValidationData | undefined;
    set internalValue(value: DataCloudflarePagesDomainValidationData | undefined);
    get errorMessage(): string;
    get method(): string;
    get status(): string;
    get txtName(): string;
    get txtValue(): string;
}
export interface DataCloudflarePagesDomainVerificationData {
}
export declare function dataCloudflarePagesDomainVerificationDataToTerraform(struct?: DataCloudflarePagesDomainVerificationData): any;
export declare function dataCloudflarePagesDomainVerificationDataToHclTerraform(struct?: DataCloudflarePagesDomainVerificationData): any;
export declare class DataCloudflarePagesDomainVerificationDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesDomainVerificationData | undefined;
    set internalValue(value: DataCloudflarePagesDomainVerificationData | undefined);
    get errorMessage(): string;
    get status(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/pages_domain cloudflare_pages_domain}
*/
export declare class DataCloudflarePagesDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_pages_domain";
    /**
    * Generates CDKTN code for importing a DataCloudflarePagesDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflarePagesDomain to import
    * @param importFromId The id of the existing DataCloudflarePagesDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/pages_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflarePagesDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/pages_domain cloudflare_pages_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflarePagesDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflarePagesDomainConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get certificateAuthority(): string;
    get createdOn(): string;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    get status(): string;
    private _validationData;
    get validationData(): DataCloudflarePagesDomainValidationDataOutputReference;
    private _verificationData;
    get verificationData(): DataCloudflarePagesDomainVerificationDataOutputReference;
    get zoneTag(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
