/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustGatewayProxyEndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints#account_id DataCloudflareZeroTrustGatewayProxyEndpoints#account_id}
    */
    readonly accountId?: string;
    /**
    * Sort direction. Only takes effect when `order_by` is also provided; it
    * is ignored otherwise. When `direction` is omitted the effective
    * direction is field-specific: `created_at` and `updated_at` default to
    * descending (newest first); `name` defaults to ascending.
    *   * `asc` — ascending.
    *   * `desc` — descending.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints#direction DataCloudflareZeroTrustGatewayProxyEndpoints#direction}
    */
    readonly direction?: string;
    /**
    * Filter the returned proxy endpoints by one or more `field:value` pairs.
    * Repeat the parameter to apply multiple filters; they are combined with
    * logical AND (an endpoint must satisfy every filter to be returned).
    *
    * Supported fields and their matching behaviour:
    *   * `name` — case-insensitive substring match on the endpoint name.
    *   * `id` — substring match on the endpoint ID (UUID), with or without dashes.
    *   * `kind` — exact match on the endpoint kind. The value must be `ip` or `identity`; any other value returns `400`.
    *
    * Each entry must match one of the per-field patterns below: the field
    * must be one of `name`, `id`, or `kind`; `name`/`id` accept any value,
    * while `kind` only accepts `ip` or `identity`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints#filter DataCloudflareZeroTrustGatewayProxyEndpoints#filter}
    */
    readonly filter?: string[];
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints#max_items DataCloudflareZeroTrustGatewayProxyEndpoints#max_items}
    */
    readonly maxItems?: number;
    /**
    * Field to sort the returned endpoints by. When omitted, the order of
    * results is unspecified. Supported values:
    *   * `name` — sort alphabetically by endpoint name.
    *   * `created_at` — sort by creation time; defaults to descending unless `direction` is set.
    *   * `updated_at` — sort by last-modified time; defaults to descending unless `direction` is set.
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints#order_by DataCloudflareZeroTrustGatewayProxyEndpoints#order_by}
    */
    readonly orderBy?: string;
    /**
    * Case-insensitive substring match on the endpoint name. When combined
    * with `filter`, both must match (logical AND).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints#search DataCloudflareZeroTrustGatewayProxyEndpoints#search}
    */
    readonly search?: string;
}
export interface DataCloudflareZeroTrustGatewayProxyEndpointsResult {
}
export declare function dataCloudflareZeroTrustGatewayProxyEndpointsResultToTerraform(struct?: DataCloudflareZeroTrustGatewayProxyEndpointsResult): any;
export declare function dataCloudflareZeroTrustGatewayProxyEndpointsResultToHclTerraform(struct?: DataCloudflareZeroTrustGatewayProxyEndpointsResult): any;
export declare class DataCloudflareZeroTrustGatewayProxyEndpointsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustGatewayProxyEndpointsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayProxyEndpointsResult | undefined);
    get createdAt(): string;
    get id(): string;
    get ips(): string[];
    get kind(): string;
    get name(): string;
    get subdomain(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustGatewayProxyEndpointsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustGatewayProxyEndpointsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints cloudflare_zero_trust_gateway_proxy_endpoints}
*/
export declare class DataCloudflareZeroTrustGatewayProxyEndpoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_gateway_proxy_endpoints";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustGatewayProxyEndpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustGatewayProxyEndpoints to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustGatewayProxyEndpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustGatewayProxyEndpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_gateway_proxy_endpoints cloudflare_zero_trust_gateway_proxy_endpoints} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustGatewayProxyEndpointsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustGatewayProxyEndpointsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _filter?;
    get filter(): string[];
    set filter(value: string[]);
    resetFilter(): void;
    get filterInput(): string[] | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustGatewayProxyEndpointsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
