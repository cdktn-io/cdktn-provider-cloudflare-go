/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareR2CustomDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/r2_custom_domain#account_id DataCloudflareR2CustomDomain#account_id}
    */
    readonly accountId: string;
    /**
    * Name of the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/r2_custom_domain#bucket_name DataCloudflareR2CustomDomain#bucket_name}
    */
    readonly bucketName: string;
    /**
    * Name of the custom domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/r2_custom_domain#domain DataCloudflareR2CustomDomain#domain}
    */
    readonly domain: string;
}
export interface DataCloudflareR2CustomDomainStatus {
}
export declare function dataCloudflareR2CustomDomainStatusToTerraform(struct?: DataCloudflareR2CustomDomainStatus): any;
export declare function dataCloudflareR2CustomDomainStatusToHclTerraform(struct?: DataCloudflareR2CustomDomainStatus): any;
export declare class DataCloudflareR2CustomDomainStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareR2CustomDomainStatus | undefined;
    set internalValue(value: DataCloudflareR2CustomDomainStatus | undefined);
    get ownership(): string;
    get ssl(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/r2_custom_domain cloudflare_r2_custom_domain}
*/
export declare class DataCloudflareR2CustomDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_r2_custom_domain";
    /**
    * Generates CDKTN code for importing a DataCloudflareR2CustomDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareR2CustomDomain to import
    * @param importFromId The id of the existing DataCloudflareR2CustomDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/r2_custom_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareR2CustomDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/r2_custom_domain cloudflare_r2_custom_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareR2CustomDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareR2CustomDomainConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    get ciphers(): string[];
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    get enabled(): cdktn.IResolvable;
    get minTls(): string;
    private _status;
    get status(): DataCloudflareR2CustomDomainStatusOutputReference;
    get zoneId(): string;
    get zoneName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
