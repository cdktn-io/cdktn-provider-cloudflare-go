/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareQueueConfig extends cdktn.TerraformMetaArguments {
    /**
    * A Resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/queue#account_id DataCloudflareQueue#account_id}
    */
    readonly accountId?: string;
    /**
    * A Resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/queue#queue_id DataCloudflareQueue#queue_id}
    */
    readonly queueId: string;
}
export interface DataCloudflareQueueConsumersSettings {
}
export declare function dataCloudflareQueueConsumersSettingsToTerraform(struct?: DataCloudflareQueueConsumersSettings): any;
export declare function dataCloudflareQueueConsumersSettingsToHclTerraform(struct?: DataCloudflareQueueConsumersSettings): any;
export declare class DataCloudflareQueueConsumersSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareQueueConsumersSettings | undefined;
    set internalValue(value: DataCloudflareQueueConsumersSettings | undefined);
    get batchSize(): number;
    get maxConcurrency(): number;
    get maxRetries(): number;
    get maxWaitTimeMs(): number;
    get retryDelay(): number;
    get visibilityTimeoutMs(): number;
}
export interface DataCloudflareQueueConsumers {
}
export declare function dataCloudflareQueueConsumersToTerraform(struct?: DataCloudflareQueueConsumers): any;
export declare function dataCloudflareQueueConsumersToHclTerraform(struct?: DataCloudflareQueueConsumers): any;
export declare class DataCloudflareQueueConsumersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareQueueConsumers | undefined;
    set internalValue(value: DataCloudflareQueueConsumers | undefined);
    get consumerId(): string;
    get createdOn(): string;
    get deadLetterQueue(): string;
    get queueName(): string;
    get scriptName(): string;
    private _settings;
    get settings(): DataCloudflareQueueConsumersSettingsOutputReference;
    get type(): string;
}
export declare class DataCloudflareQueueConsumersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareQueueConsumersOutputReference;
}
export interface DataCloudflareQueueProducers {
}
export declare function dataCloudflareQueueProducersToTerraform(struct?: DataCloudflareQueueProducers): any;
export declare function dataCloudflareQueueProducersToHclTerraform(struct?: DataCloudflareQueueProducers): any;
export declare class DataCloudflareQueueProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareQueueProducers | undefined;
    set internalValue(value: DataCloudflareQueueProducers | undefined);
    get bucketName(): string;
    get script(): string;
    get type(): string;
}
export declare class DataCloudflareQueueProducersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareQueueProducersOutputReference;
}
export interface DataCloudflareQueueSettings {
}
export declare function dataCloudflareQueueSettingsToTerraform(struct?: DataCloudflareQueueSettings): any;
export declare function dataCloudflareQueueSettingsToHclTerraform(struct?: DataCloudflareQueueSettings): any;
export declare class DataCloudflareQueueSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareQueueSettings | undefined;
    set internalValue(value: DataCloudflareQueueSettings | undefined);
    get deliveryDelay(): number;
    get deliveryPaused(): cdktn.IResolvable;
    get messageRetentionPeriod(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/queue cloudflare_queue}
*/
export declare class DataCloudflareQueue extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_queue";
    /**
    * Generates CDKTN code for importing a DataCloudflareQueue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareQueue to import
    * @param importFromId The id of the existing DataCloudflareQueue that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/queue#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareQueue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/queue cloudflare_queue} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareQueueConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareQueueConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _consumers;
    get consumers(): DataCloudflareQueueConsumersList;
    get consumersTotalCount(): number;
    get createdOn(): string;
    get id(): string;
    get modifiedOn(): string;
    private _producers;
    get producers(): DataCloudflareQueueProducersList;
    get producersTotalCount(): number;
    private _queueId?;
    get queueId(): string;
    set queueId(value: string);
    get queueIdInput(): string | undefined;
    get queueName(): string;
    private _settings;
    get settings(): DataCloudflareQueueSettingsOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
