/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareQueuesConfig extends cdktn.TerraformMetaArguments {
    /**
    * A Resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/queues#account_id DataCloudflareQueues#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/queues#max_items DataCloudflareQueues#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareQueuesResultConsumersSettings {
}
export declare function dataCloudflareQueuesResultConsumersSettingsToTerraform(struct?: DataCloudflareQueuesResultConsumersSettings): any;
export declare function dataCloudflareQueuesResultConsumersSettingsToHclTerraform(struct?: DataCloudflareQueuesResultConsumersSettings): any;
export declare class DataCloudflareQueuesResultConsumersSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareQueuesResultConsumersSettings | undefined;
    set internalValue(value: DataCloudflareQueuesResultConsumersSettings | undefined);
    get batchSize(): number;
    get maxConcurrency(): number;
    get maxRetries(): number;
    get maxWaitTimeMs(): number;
    get retryDelay(): number;
    get visibilityTimeoutMs(): number;
}
export interface DataCloudflareQueuesResultConsumers {
}
export declare function dataCloudflareQueuesResultConsumersToTerraform(struct?: DataCloudflareQueuesResultConsumers): any;
export declare function dataCloudflareQueuesResultConsumersToHclTerraform(struct?: DataCloudflareQueuesResultConsumers): any;
export declare class DataCloudflareQueuesResultConsumersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareQueuesResultConsumers | undefined;
    set internalValue(value: DataCloudflareQueuesResultConsumers | undefined);
    get consumerId(): string;
    get createdOn(): string;
    get deadLetterQueue(): string;
    get queueName(): string;
    get scriptName(): string;
    private _settings;
    get settings(): DataCloudflareQueuesResultConsumersSettingsOutputReference;
    get type(): string;
}
export declare class DataCloudflareQueuesResultConsumersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareQueuesResultConsumersOutputReference;
}
export interface DataCloudflareQueuesResultProducers {
}
export declare function dataCloudflareQueuesResultProducersToTerraform(struct?: DataCloudflareQueuesResultProducers): any;
export declare function dataCloudflareQueuesResultProducersToHclTerraform(struct?: DataCloudflareQueuesResultProducers): any;
export declare class DataCloudflareQueuesResultProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareQueuesResultProducers | undefined;
    set internalValue(value: DataCloudflareQueuesResultProducers | undefined);
    get bucketName(): string;
    get script(): string;
    get type(): string;
}
export declare class DataCloudflareQueuesResultProducersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareQueuesResultProducersOutputReference;
}
export interface DataCloudflareQueuesResultSettings {
}
export declare function dataCloudflareQueuesResultSettingsToTerraform(struct?: DataCloudflareQueuesResultSettings): any;
export declare function dataCloudflareQueuesResultSettingsToHclTerraform(struct?: DataCloudflareQueuesResultSettings): any;
export declare class DataCloudflareQueuesResultSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareQueuesResultSettings | undefined;
    set internalValue(value: DataCloudflareQueuesResultSettings | undefined);
    get deliveryDelay(): number;
    get deliveryPaused(): cdktn.IResolvable;
    get messageRetentionPeriod(): number;
}
export interface DataCloudflareQueuesResult {
}
export declare function dataCloudflareQueuesResultToTerraform(struct?: DataCloudflareQueuesResult): any;
export declare function dataCloudflareQueuesResultToHclTerraform(struct?: DataCloudflareQueuesResult): any;
export declare class DataCloudflareQueuesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareQueuesResult | undefined;
    set internalValue(value: DataCloudflareQueuesResult | undefined);
    private _consumers;
    get consumers(): DataCloudflareQueuesResultConsumersList;
    get consumersTotalCount(): number;
    get createdOn(): string;
    get id(): string;
    get modifiedOn(): string;
    private _producers;
    get producers(): DataCloudflareQueuesResultProducersList;
    get producersTotalCount(): number;
    get queueId(): string;
    get queueName(): string;
    private _settings;
    get settings(): DataCloudflareQueuesResultSettingsOutputReference;
}
export declare class DataCloudflareQueuesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareQueuesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/queues cloudflare_queues}
*/
export declare class DataCloudflareQueues extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_queues";
    /**
    * Generates CDKTN code for importing a DataCloudflareQueues resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareQueues to import
    * @param importFromId The id of the existing DataCloudflareQueues that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/queues#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareQueues to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/queues cloudflare_queues} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareQueuesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareQueuesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareQueuesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
