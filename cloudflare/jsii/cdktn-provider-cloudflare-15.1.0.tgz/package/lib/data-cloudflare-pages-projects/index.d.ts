/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflarePagesProjectsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/pages_projects#account_id DataCloudflarePagesProjects#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/pages_projects#max_items DataCloudflarePagesProjects#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflarePagesProjectsResultBuildConfig {
}
export declare function dataCloudflarePagesProjectsResultBuildConfigToTerraform(struct?: DataCloudflarePagesProjectsResultBuildConfig): any;
export declare function dataCloudflarePagesProjectsResultBuildConfigToHclTerraform(struct?: DataCloudflarePagesProjectsResultBuildConfig): any;
export declare class DataCloudflarePagesProjectsResultBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultBuildConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfig {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfigToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfig): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfigToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfig): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadata {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadataToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadata): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadataToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadata): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadata | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadata | undefined);
    get branch(): string;
    get commitDirty(): cdktn.IResolvable;
    get commitHash(): string;
    get commitMessage(): string;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTrigger {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTrigger): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTrigger): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTrigger | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTrigger | undefined);
    private _metadata;
    get metadata(): DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerMetadataOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVars {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentEnvVarsToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVars): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVars): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentLatestStage {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentLatestStageToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentLatestStage): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentLatestStageToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentLatestStage): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentLatestStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentLatestStage | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentLatestStage | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfig {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfigToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfig): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfigToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfig): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentSource {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentSourceToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentSource): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentSourceToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentSource): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentSource | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentSource | undefined);
    private _config;
    get config(): DataCloudflarePagesProjectsResultCanonicalDeploymentSourceConfigOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeploymentStages {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentStagesToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentStages): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentStagesToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeploymentStages): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeploymentStages | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeploymentStages | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePagesProjectsResultCanonicalDeploymentStagesOutputReference;
}
export interface DataCloudflarePagesProjectsResultCanonicalDeployment {
}
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentToTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeployment): any;
export declare function dataCloudflarePagesProjectsResultCanonicalDeploymentToHclTerraform(struct?: DataCloudflarePagesProjectsResultCanonicalDeployment): any;
export declare class DataCloudflarePagesProjectsResultCanonicalDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultCanonicalDeployment | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultCanonicalDeployment | undefined);
    get aliases(): string[];
    private _buildConfig;
    get buildConfig(): DataCloudflarePagesProjectsResultCanonicalDeploymentBuildConfigOutputReference;
    get createdOn(): string;
    private _deploymentTrigger;
    get deploymentTrigger(): DataCloudflarePagesProjectsResultCanonicalDeploymentDeploymentTriggerOutputReference;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectsResultCanonicalDeploymentEnvVarsMap;
    get environment(): string;
    get id(): string;
    get isSkipped(): cdktn.IResolvable;
    private _latestStage;
    get latestStage(): DataCloudflarePagesProjectsResultCanonicalDeploymentLatestStageOutputReference;
    get modifiedOn(): string;
    get projectId(): string;
    get projectName(): string;
    get shortId(): string;
    private _source;
    get source(): DataCloudflarePagesProjectsResultCanonicalDeploymentSourceOutputReference;
    private _stages;
    get stages(): DataCloudflarePagesProjectsResultCanonicalDeploymentStagesList;
    get url(): string;
    get usesFunctions(): cdktn.IResolvable;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindings {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindingsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindings): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindingsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindings): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindings | undefined);
    get projectId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindingsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasets {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasetsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasets): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasetsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasets): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasets | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasets | undefined);
    get dataset(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasetsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasetsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsers {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsersToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsers): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsersToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsers): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsers | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsers | undefined);
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsersOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1Databases {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1DatabasesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1Databases): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1DatabasesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1Databases): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1DatabasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1Databases | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1Databases | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1DatabasesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1DatabasesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespaces {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespacesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespaces): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespaces): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVars {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVarsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVars): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVars): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindings {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindingsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindings): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindingsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindings): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindings | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindingsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespaces {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespacesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespaces): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespaces): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimits {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimitsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimits): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimitsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimits): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimits | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimits | undefined);
    get cpuMs(): number;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificates {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificatesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificates): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificatesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificates): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificates | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificates | undefined);
    get certificateId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificatesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificatesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacement {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacementToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacement): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacementToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacement): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacement | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacement | undefined);
    get mode(): string;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducers {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducersToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducers): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducersToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducers): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducers | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducers | undefined);
    get name(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducersOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2Buckets {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2BucketsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2Buckets): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2BucketsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2Buckets): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2BucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2Buckets | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2Buckets | undefined);
    get jurisdiction(): string;
    get name(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2BucketsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2BucketsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServices {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewServicesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServices): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewServicesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServices): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServices | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServices | undefined);
    get entrypoint(): string;
    get environment(): string;
    get service(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServicesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServicesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindings {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindingsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindings): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindingsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindings): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindings | undefined);
    get indexName(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindingsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsPreview {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreview): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsPreviewToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsPreview): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsPreviewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsPreview | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsPreview | undefined);
    private _aiBindings;
    get aiBindings(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAiBindingsMap;
    get alwaysUseLatestCompatibilityDate(): cdktn.IResolvable;
    private _analyticsEngineDatasets;
    get analyticsEngineDatasets(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewAnalyticsEngineDatasetsMap;
    private _browsers;
    get browsers(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewBrowsersMap;
    get buildImageMajorVersion(): number;
    get compatibilityDate(): string;
    get compatibilityFlags(): string[];
    private _d1Databases;
    get d1Databases(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewD1DatabasesMap;
    private _durableObjectNamespaces;
    get durableObjectNamespaces(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewDurableObjectNamespacesMap;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewEnvVarsMap;
    get failOpen(): cdktn.IResolvable;
    private _hyperdriveBindings;
    get hyperdriveBindings(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewHyperdriveBindingsMap;
    private _kvNamespaces;
    get kvNamespaces(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewKvNamespacesMap;
    private _limits;
    get limits(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewLimitsOutputReference;
    private _mtlsCertificates;
    get mtlsCertificates(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewMtlsCertificatesMap;
    private _placement;
    get placement(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewPlacementOutputReference;
    private _queueProducers;
    get queueProducers(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewQueueProducersMap;
    private _r2Buckets;
    get r2Buckets(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewR2BucketsMap;
    private _services;
    get services(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewServicesMap;
    get usageModel(): string;
    private _vectorizeBindings;
    get vectorizeBindings(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewVectorizeBindingsMap;
    get wranglerConfigHash(): string;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindings {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindingsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindings): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindingsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindings): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindings | undefined);
    get projectId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindingsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasets {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasetsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasets): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasetsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasets): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasets | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasets | undefined);
    get dataset(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasetsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasetsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsers {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsersToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsers): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsersToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsers): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsers | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsers | undefined);
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsersOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1Databases {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionD1DatabasesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1Databases): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionD1DatabasesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1Databases): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1DatabasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1Databases | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1Databases | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1DatabasesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1DatabasesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespaces {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespacesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespaces): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespaces): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVars {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVarsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVars): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVars): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindings {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindingsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindings): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindingsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindings): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindings | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindingsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespaces {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespacesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespaces): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespaces): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionLimits {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionLimitsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionLimits): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionLimitsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionLimits): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionLimits | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionLimits | undefined);
    get cpuMs(): number;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificates {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificatesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificates): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificatesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificates): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificates | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificates | undefined);
    get certificateId(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificatesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificatesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacement {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacementToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacement): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacementToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacement): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacement | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacement | undefined);
    get mode(): string;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducers {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducersToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducers): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducersToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducers): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducers | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducers | undefined);
    get name(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducersOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2Buckets {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionR2BucketsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2Buckets): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionR2BucketsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2Buckets): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2BucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2Buckets | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2Buckets | undefined);
    get jurisdiction(): string;
    get name(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2BucketsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2BucketsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionServices {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionServicesToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionServices): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionServicesToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionServices): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionServices | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionServices | undefined);
    get entrypoint(): string;
    get environment(): string;
    get service(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionServicesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionServicesOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindings {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindingsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindings): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindingsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindings): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindings | undefined);
    get indexName(): string;
}
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindingsOutputReference;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigsProduction {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProduction): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsProductionToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigsProduction): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsProductionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigsProduction | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigsProduction | undefined);
    private _aiBindings;
    get aiBindings(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionAiBindingsMap;
    get alwaysUseLatestCompatibilityDate(): cdktn.IResolvable;
    private _analyticsEngineDatasets;
    get analyticsEngineDatasets(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionAnalyticsEngineDatasetsMap;
    private _browsers;
    get browsers(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionBrowsersMap;
    get buildImageMajorVersion(): number;
    get compatibilityDate(): string;
    get compatibilityFlags(): string[];
    private _d1Databases;
    get d1Databases(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionD1DatabasesMap;
    private _durableObjectNamespaces;
    get durableObjectNamespaces(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionDurableObjectNamespacesMap;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionEnvVarsMap;
    get failOpen(): cdktn.IResolvable;
    private _hyperdriveBindings;
    get hyperdriveBindings(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionHyperdriveBindingsMap;
    private _kvNamespaces;
    get kvNamespaces(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionKvNamespacesMap;
    private _limits;
    get limits(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionLimitsOutputReference;
    private _mtlsCertificates;
    get mtlsCertificates(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionMtlsCertificatesMap;
    private _placement;
    get placement(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionPlacementOutputReference;
    private _queueProducers;
    get queueProducers(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionQueueProducersMap;
    private _r2Buckets;
    get r2Buckets(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionR2BucketsMap;
    private _services;
    get services(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionServicesMap;
    get usageModel(): string;
    private _vectorizeBindings;
    get vectorizeBindings(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionVectorizeBindingsMap;
    get wranglerConfigHash(): string;
}
export interface DataCloudflarePagesProjectsResultDeploymentConfigs {
}
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsToTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigs): any;
export declare function dataCloudflarePagesProjectsResultDeploymentConfigsToHclTerraform(struct?: DataCloudflarePagesProjectsResultDeploymentConfigs): any;
export declare class DataCloudflarePagesProjectsResultDeploymentConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultDeploymentConfigs | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultDeploymentConfigs | undefined);
    private _preview;
    get preview(): DataCloudflarePagesProjectsResultDeploymentConfigsPreviewOutputReference;
    private _production;
    get production(): DataCloudflarePagesProjectsResultDeploymentConfigsProductionOutputReference;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentBuildConfig {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentBuildConfigToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentBuildConfig): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentBuildConfigToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentBuildConfig): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentBuildConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadata {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadataToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadata): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadataToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadata): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadata | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadata | undefined);
    get branch(): string;
    get commitDirty(): cdktn.IResolvable;
    get commitHash(): string;
    get commitMessage(): string;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTrigger {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTrigger): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTrigger): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTrigger | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTrigger | undefined);
    private _metadata;
    get metadata(): DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerMetadataOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentEnvVars {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentEnvVarsToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentEnvVars): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentEnvVars): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectsResultLatestDeploymentEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectsResultLatestDeploymentEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentLatestStage {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentLatestStageToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentLatestStage): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentLatestStageToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentLatestStage): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentLatestStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentLatestStage | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentLatestStage | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentSourceConfig {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentSourceConfigToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentSourceConfig): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentSourceConfigToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentSourceConfig): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentSourceConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentSource {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentSourceToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentSource): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentSourceToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentSource): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentSource | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentSource | undefined);
    private _config;
    get config(): DataCloudflarePagesProjectsResultLatestDeploymentSourceConfigOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectsResultLatestDeploymentStages {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentStagesToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentStages): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentStagesToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeploymentStages): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeploymentStages | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeploymentStages | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export declare class DataCloudflarePagesProjectsResultLatestDeploymentStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePagesProjectsResultLatestDeploymentStagesOutputReference;
}
export interface DataCloudflarePagesProjectsResultLatestDeployment {
}
export declare function dataCloudflarePagesProjectsResultLatestDeploymentToTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeployment): any;
export declare function dataCloudflarePagesProjectsResultLatestDeploymentToHclTerraform(struct?: DataCloudflarePagesProjectsResultLatestDeployment): any;
export declare class DataCloudflarePagesProjectsResultLatestDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultLatestDeployment | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultLatestDeployment | undefined);
    get aliases(): string[];
    private _buildConfig;
    get buildConfig(): DataCloudflarePagesProjectsResultLatestDeploymentBuildConfigOutputReference;
    get createdOn(): string;
    private _deploymentTrigger;
    get deploymentTrigger(): DataCloudflarePagesProjectsResultLatestDeploymentDeploymentTriggerOutputReference;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectsResultLatestDeploymentEnvVarsMap;
    get environment(): string;
    get id(): string;
    get isSkipped(): cdktn.IResolvable;
    private _latestStage;
    get latestStage(): DataCloudflarePagesProjectsResultLatestDeploymentLatestStageOutputReference;
    get modifiedOn(): string;
    get projectId(): string;
    get projectName(): string;
    get shortId(): string;
    private _source;
    get source(): DataCloudflarePagesProjectsResultLatestDeploymentSourceOutputReference;
    private _stages;
    get stages(): DataCloudflarePagesProjectsResultLatestDeploymentStagesList;
    get url(): string;
    get usesFunctions(): cdktn.IResolvable;
}
export interface DataCloudflarePagesProjectsResultSourceConfig {
}
export declare function dataCloudflarePagesProjectsResultSourceConfigToTerraform(struct?: DataCloudflarePagesProjectsResultSourceConfig): any;
export declare function dataCloudflarePagesProjectsResultSourceConfigToHclTerraform(struct?: DataCloudflarePagesProjectsResultSourceConfig): any;
export declare class DataCloudflarePagesProjectsResultSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultSourceConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface DataCloudflarePagesProjectsResultSource {
}
export declare function dataCloudflarePagesProjectsResultSourceToTerraform(struct?: DataCloudflarePagesProjectsResultSource): any;
export declare function dataCloudflarePagesProjectsResultSourceToHclTerraform(struct?: DataCloudflarePagesProjectsResultSource): any;
export declare class DataCloudflarePagesProjectsResultSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectsResultSource | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResultSource | undefined);
    private _config;
    get config(): DataCloudflarePagesProjectsResultSourceConfigOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectsResult {
}
export declare function dataCloudflarePagesProjectsResultToTerraform(struct?: DataCloudflarePagesProjectsResult): any;
export declare function dataCloudflarePagesProjectsResultToHclTerraform(struct?: DataCloudflarePagesProjectsResult): any;
export declare class DataCloudflarePagesProjectsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePagesProjectsResult | undefined;
    set internalValue(value: DataCloudflarePagesProjectsResult | undefined);
    private _buildConfig;
    get buildConfig(): DataCloudflarePagesProjectsResultBuildConfigOutputReference;
    private _canonicalDeployment;
    get canonicalDeployment(): DataCloudflarePagesProjectsResultCanonicalDeploymentOutputReference;
    get createdOn(): string;
    private _deploymentConfigs;
    get deploymentConfigs(): DataCloudflarePagesProjectsResultDeploymentConfigsOutputReference;
    get domains(): string[];
    get framework(): string;
    get frameworkVersion(): string;
    get id(): string;
    private _latestDeployment;
    get latestDeployment(): DataCloudflarePagesProjectsResultLatestDeploymentOutputReference;
    get name(): string;
    get previewScriptName(): string;
    get productionBranch(): string;
    get productionScriptName(): string;
    private _source;
    get source(): DataCloudflarePagesProjectsResultSourceOutputReference;
    get subdomain(): string;
    get usesFunctions(): cdktn.IResolvable;
}
export declare class DataCloudflarePagesProjectsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePagesProjectsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/pages_projects cloudflare_pages_projects}
*/
export declare class DataCloudflarePagesProjects extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_pages_projects";
    /**
    * Generates CDKTN code for importing a DataCloudflarePagesProjects resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflarePagesProjects to import
    * @param importFromId The id of the existing DataCloudflarePagesProjects that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/pages_projects#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflarePagesProjects to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/pages_projects cloudflare_pages_projects} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflarePagesProjectsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflarePagesProjectsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflarePagesProjectsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
