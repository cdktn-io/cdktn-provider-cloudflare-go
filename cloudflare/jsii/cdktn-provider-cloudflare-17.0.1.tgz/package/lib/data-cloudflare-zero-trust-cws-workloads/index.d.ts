/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsWorkloadsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads#account_id DataCloudflareZeroTrustCwsWorkloads#account_id}
    */
    readonly accountId: string;
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads#direction DataCloudflareZeroTrustCwsWorkloads#direction}
    */
    readonly direction?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads#max_items DataCloudflareZeroTrustCwsWorkloads#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter by workload name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads#name DataCloudflareZeroTrustCwsWorkloads#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads#order DataCloudflareZeroTrustCwsWorkloads#order}
    */
    readonly order?: string;
    /**
    * Filter to workloads attached to this policy set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads#policy_set_id DataCloudflareZeroTrustCwsWorkloads#policy_set_id}
    */
    readonly policySetId?: string;
}
export interface DataCloudflareZeroTrustCwsWorkloadsResult {
}
export declare function dataCloudflareZeroTrustCwsWorkloadsResultToTerraform(struct?: DataCloudflareZeroTrustCwsWorkloadsResult): any;
export declare function dataCloudflareZeroTrustCwsWorkloadsResultToHclTerraform(struct?: DataCloudflareZeroTrustCwsWorkloadsResult): any;
export declare class DataCloudflareZeroTrustCwsWorkloadsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCwsWorkloadsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsWorkloadsResult | undefined);
    get createdAt(): string;
    get description(): string;
    get filter(): string;
    get id(): string;
    get name(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustCwsWorkloadsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCwsWorkloadsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads cloudflare_zero_trust_cws_workloads}
*/
export declare class DataCloudflareZeroTrustCwsWorkloads extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_workloads";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsWorkloads resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsWorkloads to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsWorkloads that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsWorkloads to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workloads cloudflare_zero_trust_cws_workloads} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsWorkloadsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsWorkloadsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _policySetId?;
    get policySetId(): string;
    set policySetId(value: string);
    resetPolicySetId(): void;
    get policySetIdInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCwsWorkloadsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
