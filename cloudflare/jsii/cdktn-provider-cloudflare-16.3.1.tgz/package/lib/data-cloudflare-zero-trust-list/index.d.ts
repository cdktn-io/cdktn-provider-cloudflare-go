/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specify the Cloudflare account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#account_id DataCloudflareZeroTrustList#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#filter DataCloudflareZeroTrustList#filter}
    */
    readonly filter?: DataCloudflareZeroTrustListFilter;
    /**
    * Identify the API resource with a UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#list_id DataCloudflareZeroTrustList#list_id}
    */
    readonly listId?: string;
}
export interface DataCloudflareZeroTrustListFilter {
    /**
    * Sort direction. Applies to the field named in `order_by`; when `order_by`
    * is omitted it applies to the default `created_at` ordering. When
    * `direction` is omitted the default is field-specific: explicitly choosing
    * `created_at` or `updated_at` defaults to descending (newest first); `name`
    * and `item_count` default to ascending; and the default `created_at`
    * ordering used when `order_by` is omitted is ascending (for backwards
    * compatibility).
    *   * `asc` — ascending.
    *   * `desc` — descending.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#direction DataCloudflareZeroTrustList#direction}
    */
    readonly direction?: string;
    /**
    * Filter the returned lists by one or more `field:value` pairs.
    * Repeat the parameter to apply multiple filters; they are combined with
    * logical AND (a list must satisfy every filter to be returned).
    *
    * Supported fields and their matching behaviour:
    *   * `name` — case-insensitive substring match on the list name.
    *   * `id` — substring match on the list ID (UUID), with or without dashes.
    *   * `type` — exact match on the list type. Supersedes the legacy `type` query
    *     parameter when both are supplied. Must be one of the valid type values.
    *   * `item_count` — exact integer match on the number of items in the list.
    *
    * Each entry must match one of the per-field patterns below: the field must be
    * one of `name`, `id`, `type`, or `item_count`; `name`/`id` accept any value,
    * `type` is restricted to the valid list type values, and `item_count` must be
    * a non-negative integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#filter DataCloudflareZeroTrustList#filter}
    */
    readonly filter?: string[];
    /**
    * Field to sort the returned lists by. When omitted, results are ordered by
    * `created_at` in ascending order (i.e. creation order) for backwards
    * compatibility. Supported values:
    *   * `name` — sort alphabetically by list name.
    *   * `created_at` — sort by creation time; defaults to descending unless `direction` is set.
    *   * `updated_at` — sort by last-modified time; defaults to descending unless `direction` is set.
    *   * `item_count` — sort by number of items in the list.
    * Available values: "name", "created_at", "updated_at", "item_count".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#order_by DataCloudflareZeroTrustList#order_by}
    */
    readonly orderBy?: string;
    /**
    * Case-insensitive substring match on the list name or description. When
    * combined with `filter`, both must match (logical AND).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#search DataCloudflareZeroTrustList#search}
    */
    readonly search?: string;
    /**
    * Specify the list type.
    * Available values: "SERIAL", "URL", "DOMAIN", "EMAIL", "IP", "CATEGORY", "LOCATION", "DEVICE", "AAGUID".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#type DataCloudflareZeroTrustList#type}
    */
    readonly type?: string;
}
export declare function dataCloudflareZeroTrustListFilterToTerraform(struct?: DataCloudflareZeroTrustListFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustListFilterToHclTerraform(struct?: DataCloudflareZeroTrustListFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustListFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustListFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustListFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _filter?;
    get filter(): string[];
    set filter(value: string[]);
    resetFilter(): void;
    get filterInput(): string[] | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DataCloudflareZeroTrustListItems {
}
export declare function dataCloudflareZeroTrustListItemsToTerraform(struct?: DataCloudflareZeroTrustListItems): any;
export declare function dataCloudflareZeroTrustListItemsToHclTerraform(struct?: DataCloudflareZeroTrustListItems): any;
export declare class DataCloudflareZeroTrustListItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustListItems | undefined;
    set internalValue(value: DataCloudflareZeroTrustListItems | undefined);
    get createdAt(): string;
    get description(): string;
    get value(): string;
}
export declare class DataCloudflareZeroTrustListItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustListItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list cloudflare_zero_trust_list}
*/
export declare class DataCloudflareZeroTrustList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_list";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustList to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustList that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_list cloudflare_zero_trust_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustListConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustListConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get description(): string;
    private _filter;
    get filter(): DataCloudflareZeroTrustListFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustListFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustListFilter | undefined;
    get id(): string;
    private _items;
    get items(): DataCloudflareZeroTrustListItemsList;
    get listCount(): number;
    private _listId?;
    get listId(): string;
    set listId(value: string);
    resetListId(): void;
    get listIdInput(): string | undefined;
    get name(): string;
    get type(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
