/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsWorkloadConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#account_id DataCloudflareZeroTrustCwsWorkload#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#find_one_by DataCloudflareZeroTrustCwsWorkload#find_one_by}
    */
    readonly findOneBy?: DataCloudflareZeroTrustCwsWorkloadFindOneBy;
    /**
    * ID of the workload to retrieve
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#workload_id DataCloudflareZeroTrustCwsWorkload#workload_id}
    */
    readonly workloadId?: string;
}
export interface DataCloudflareZeroTrustCwsWorkloadFindOneBy {
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#direction DataCloudflareZeroTrustCwsWorkload#direction}
    */
    readonly direction?: string;
    /**
    * Filter by workload name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#name DataCloudflareZeroTrustCwsWorkload#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#order DataCloudflareZeroTrustCwsWorkload#order}
    */
    readonly order?: string;
    /**
    * Filter to workloads attached to this policy set
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#policy_set_id DataCloudflareZeroTrustCwsWorkload#policy_set_id}
    */
    readonly policySetId?: string;
}
export declare function dataCloudflareZeroTrustCwsWorkloadFindOneByToTerraform(struct?: DataCloudflareZeroTrustCwsWorkloadFindOneBy | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustCwsWorkloadFindOneByToHclTerraform(struct?: DataCloudflareZeroTrustCwsWorkloadFindOneBy | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustCwsWorkloadFindOneByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCwsWorkloadFindOneBy | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsWorkloadFindOneBy | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _policySetId?;
    get policySetId(): string;
    set policySetId(value: string);
    resetPolicySetId(): void;
    get policySetIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload cloudflare_zero_trust_cws_workload}
*/
export declare class DataCloudflareZeroTrustCwsWorkload extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_workload";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsWorkload resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsWorkload to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsWorkload that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsWorkload to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_workload cloudflare_zero_trust_cws_workload} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsWorkloadConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsWorkloadConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get description(): string;
    get filter(): string;
    private _findOneBy;
    get findOneBy(): DataCloudflareZeroTrustCwsWorkloadFindOneByOutputReference;
    putFindOneBy(value: DataCloudflareZeroTrustCwsWorkloadFindOneBy): void;
    resetFindOneBy(): void;
    get findOneByInput(): cdktn.IResolvable | DataCloudflareZeroTrustCwsWorkloadFindOneBy | undefined;
    get id(): string;
    get name(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get updatedAt(): string;
    private _workloadId?;
    get workloadId(): string;
    set workloadId(value: string);
    resetWorkloadId(): void;
    get workloadIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
