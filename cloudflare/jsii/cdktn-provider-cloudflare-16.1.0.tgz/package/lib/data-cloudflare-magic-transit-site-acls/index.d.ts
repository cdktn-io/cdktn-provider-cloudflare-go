/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicTransitSiteAclsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_site_acls#account_id DataCloudflareMagicTransitSiteAcls#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_site_acls#max_items DataCloudflareMagicTransitSiteAcls#max_items}
    */
    readonly maxItems?: number;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_site_acls#site_id DataCloudflareMagicTransitSiteAcls#site_id}
    */
    readonly siteId: string;
}
export interface DataCloudflareMagicTransitSiteAclsResultLan1 {
}
export declare function dataCloudflareMagicTransitSiteAclsResultLan1ToTerraform(struct?: DataCloudflareMagicTransitSiteAclsResultLan1): any;
export declare function dataCloudflareMagicTransitSiteAclsResultLan1ToHclTerraform(struct?: DataCloudflareMagicTransitSiteAclsResultLan1): any;
export declare class DataCloudflareMagicTransitSiteAclsResultLan1OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitSiteAclsResultLan1 | undefined;
    set internalValue(value: DataCloudflareMagicTransitSiteAclsResultLan1 | undefined);
    get lanId(): string;
    get lanName(): string;
    get portRanges(): string[];
    get ports(): number[];
    get subnets(): string[];
}
export interface DataCloudflareMagicTransitSiteAclsResultLan2 {
}
export declare function dataCloudflareMagicTransitSiteAclsResultLan2ToTerraform(struct?: DataCloudflareMagicTransitSiteAclsResultLan2): any;
export declare function dataCloudflareMagicTransitSiteAclsResultLan2ToHclTerraform(struct?: DataCloudflareMagicTransitSiteAclsResultLan2): any;
export declare class DataCloudflareMagicTransitSiteAclsResultLan2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitSiteAclsResultLan2 | undefined;
    set internalValue(value: DataCloudflareMagicTransitSiteAclsResultLan2 | undefined);
    get lanId(): string;
    get lanName(): string;
    get portRanges(): string[];
    get ports(): number[];
    get subnets(): string[];
}
export interface DataCloudflareMagicTransitSiteAclsResult {
}
export declare function dataCloudflareMagicTransitSiteAclsResultToTerraform(struct?: DataCloudflareMagicTransitSiteAclsResult): any;
export declare function dataCloudflareMagicTransitSiteAclsResultToHclTerraform(struct?: DataCloudflareMagicTransitSiteAclsResult): any;
export declare class DataCloudflareMagicTransitSiteAclsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMagicTransitSiteAclsResult | undefined;
    set internalValue(value: DataCloudflareMagicTransitSiteAclsResult | undefined);
    get description(): string;
    get forwardLocally(): cdktn.IResolvable;
    get id(): string;
    private _lan1;
    get lan1(): DataCloudflareMagicTransitSiteAclsResultLan1OutputReference;
    private _lan2;
    get lan2(): DataCloudflareMagicTransitSiteAclsResultLan2OutputReference;
    get name(): string;
    get protocols(): string[];
    get unidirectional(): cdktn.IResolvable;
}
export declare class DataCloudflareMagicTransitSiteAclsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMagicTransitSiteAclsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_site_acls cloudflare_magic_transit_site_acls}
*/
export declare class DataCloudflareMagicTransitSiteAcls extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_transit_site_acls";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicTransitSiteAcls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicTransitSiteAcls to import
    * @param importFromId The id of the existing DataCloudflareMagicTransitSiteAcls that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_site_acls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicTransitSiteAcls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_site_acls cloudflare_magic_transit_site_acls} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicTransitSiteAclsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicTransitSiteAclsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareMagicTransitSiteAclsResultList;
    private _siteId?;
    get siteId(): string;
    set siteId(value: string);
    get siteIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
