/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpCustomEntryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_custom_entry#account_id DataCloudflareZeroTrustDlpCustomEntry#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_custom_entry#entry_id DataCloudflareZeroTrustDlpCustomEntry#entry_id}
    */
    readonly entryId: string;
}
export interface DataCloudflareZeroTrustDlpCustomEntryConfidence {
}
export declare function dataCloudflareZeroTrustDlpCustomEntryConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryConfidence): any;
export declare function dataCloudflareZeroTrustDlpCustomEntryConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryConfidence): any;
export declare class DataCloudflareZeroTrustDlpCustomEntryConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomEntryConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomEntryConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpCustomEntryPattern {
}
export declare function dataCloudflareZeroTrustDlpCustomEntryPatternToTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryPattern): any;
export declare function dataCloudflareZeroTrustDlpCustomEntryPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryPattern): any;
export declare class DataCloudflareZeroTrustDlpCustomEntryPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomEntryPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomEntryPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpCustomEntryProfiles {
}
export declare function dataCloudflareZeroTrustDlpCustomEntryProfilesToTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryProfiles): any;
export declare function dataCloudflareZeroTrustDlpCustomEntryProfilesToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryProfiles): any;
export declare class DataCloudflareZeroTrustDlpCustomEntryProfilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpCustomEntryProfiles | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomEntryProfiles | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZeroTrustDlpCustomEntryProfilesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpCustomEntryProfilesOutputReference;
}
export interface DataCloudflareZeroTrustDlpCustomEntryVariant {
}
export declare function dataCloudflareZeroTrustDlpCustomEntryVariantToTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryVariant): any;
export declare function dataCloudflareZeroTrustDlpCustomEntryVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpCustomEntryVariant): any;
export declare class DataCloudflareZeroTrustDlpCustomEntryVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpCustomEntryVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpCustomEntryVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_custom_entry cloudflare_zero_trust_dlp_custom_entry}
*/
export declare class DataCloudflareZeroTrustDlpCustomEntry extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_custom_entry";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpCustomEntry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpCustomEntry to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpCustomEntry that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_custom_entry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpCustomEntry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_custom_entry cloudflare_zero_trust_dlp_custom_entry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpCustomEntryConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpCustomEntryConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpCustomEntryConfidenceOutputReference;
    get createdAt(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _entryId?;
    get entryId(): string;
    set entryId(value: string);
    get entryIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpCustomEntryPatternOutputReference;
    get profileId(): string;
    private _profiles;
    get profiles(): DataCloudflareZeroTrustDlpCustomEntryProfilesList;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    get uploadStatus(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpCustomEntryVariantOutputReference;
    get wordList(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
