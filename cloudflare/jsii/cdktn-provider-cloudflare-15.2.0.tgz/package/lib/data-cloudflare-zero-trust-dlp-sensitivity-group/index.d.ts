/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpSensitivityGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_sensitivity_group#account_id DataCloudflareZeroTrustDlpSensitivityGroup#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_sensitivity_group#sensitivity_group_id DataCloudflareZeroTrustDlpSensitivityGroup#sensitivity_group_id}
    */
    readonly sensitivityGroupId: string;
}
export interface DataCloudflareZeroTrustDlpSensitivityGroupLevels {
}
export declare function dataCloudflareZeroTrustDlpSensitivityGroupLevelsToTerraform(struct?: DataCloudflareZeroTrustDlpSensitivityGroupLevels): any;
export declare function dataCloudflareZeroTrustDlpSensitivityGroupLevelsToHclTerraform(struct?: DataCloudflareZeroTrustDlpSensitivityGroupLevels): any;
export declare class DataCloudflareZeroTrustDlpSensitivityGroupLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpSensitivityGroupLevels | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpSensitivityGroupLevels | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustDlpSensitivityGroupLevelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpSensitivityGroupLevelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_sensitivity_group cloudflare_zero_trust_dlp_sensitivity_group}
*/
export declare class DataCloudflareZeroTrustDlpSensitivityGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_sensitivity_group";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpSensitivityGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpSensitivityGroup to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpSensitivityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_sensitivity_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpSensitivityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_sensitivity_group cloudflare_zero_trust_dlp_sensitivity_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpSensitivityGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpSensitivityGroupConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get description(): string;
    get id(): string;
    private _levels;
    get levels(): DataCloudflareZeroTrustDlpSensitivityGroupLevelsList;
    get name(): string;
    private _sensitivityGroupId?;
    get sensitivityGroupId(): string;
    set sensitivityGroupId(value: string);
    get sensitivityGroupIdInput(): string | undefined;
    get templateId(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
