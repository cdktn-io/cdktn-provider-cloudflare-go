/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiSearchNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#account_id AiSearchNamespace#account_id}
    */
    readonly accountId: string;
    /**
    * Optional description for the namespace. Max 256 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#description AiSearchNamespace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#name AiSearchNamespace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#public_endpoint_params AiSearchNamespace#public_endpoint_params}
    */
    readonly publicEndpointParams?: AiSearchNamespacePublicEndpointParams;
}
export interface AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint {
    /**
    * Disable chat completions endpoint for this public endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#disabled AiSearchNamespace#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
}
export declare function aiSearchNamespacePublicEndpointParamsChatCompletionsEndpointToTerraform(struct?: AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable): any;
export declare function aiSearchNamespacePublicEndpointParamsChatCompletionsEndpointToHclTerraform(struct?: AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable): any;
export declare class AiSearchNamespacePublicEndpointParamsChatCompletionsEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchNamespacePublicEndpointParamsMcp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#description AiSearchNamespace#description}
    */
    readonly description?: string;
    /**
    * Disable MCP endpoint for this public endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#disabled AiSearchNamespace#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
}
export declare function aiSearchNamespacePublicEndpointParamsMcpToTerraform(struct?: AiSearchNamespacePublicEndpointParamsMcp | cdktn.IResolvable): any;
export declare function aiSearchNamespacePublicEndpointParamsMcpToHclTerraform(struct?: AiSearchNamespacePublicEndpointParamsMcp | cdktn.IResolvable): any;
export declare class AiSearchNamespacePublicEndpointParamsMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchNamespacePublicEndpointParamsMcp | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchNamespacePublicEndpointParamsMcp | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchNamespacePublicEndpointParamsRateLimit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#period_ms AiSearchNamespace#period_ms}
    */
    readonly periodMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#requests AiSearchNamespace#requests}
    */
    readonly requests?: number;
    /**
    * Available values: "fixed", "sliding".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#technique AiSearchNamespace#technique}
    */
    readonly technique?: string;
}
export declare function aiSearchNamespacePublicEndpointParamsRateLimitToTerraform(struct?: AiSearchNamespacePublicEndpointParamsRateLimit | cdktn.IResolvable): any;
export declare function aiSearchNamespacePublicEndpointParamsRateLimitToHclTerraform(struct?: AiSearchNamespacePublicEndpointParamsRateLimit | cdktn.IResolvable): any;
export declare class AiSearchNamespacePublicEndpointParamsRateLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchNamespacePublicEndpointParamsRateLimit | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchNamespacePublicEndpointParamsRateLimit | cdktn.IResolvable | undefined);
    private _periodMs?;
    get periodMs(): number;
    set periodMs(value: number);
    resetPeriodMs(): void;
    get periodMsInput(): number | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _technique?;
    get technique(): string;
    set technique(value: string);
    resetTechnique(): void;
    get techniqueInput(): string | undefined;
}
export interface AiSearchNamespacePublicEndpointParamsSearchEndpoint {
    /**
    * Disable search endpoint for this public endpoint
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#disabled AiSearchNamespace#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
}
export declare function aiSearchNamespacePublicEndpointParamsSearchEndpointToTerraform(struct?: AiSearchNamespacePublicEndpointParamsSearchEndpoint | cdktn.IResolvable): any;
export declare function aiSearchNamespacePublicEndpointParamsSearchEndpointToHclTerraform(struct?: AiSearchNamespacePublicEndpointParamsSearchEndpoint | cdktn.IResolvable): any;
export declare class AiSearchNamespacePublicEndpointParamsSearchEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchNamespacePublicEndpointParamsSearchEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchNamespacePublicEndpointParamsSearchEndpoint | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AiSearchNamespacePublicEndpointParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#authorized_hosts AiSearchNamespace#authorized_hosts}
    */
    readonly authorizedHosts?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#chat_completions_endpoint AiSearchNamespace#chat_completions_endpoint}
    */
    readonly chatCompletionsEndpoint?: AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint;
    /**
    * Custom domain hostnames that alias this public endpoint. GET and create responses return the current set; on update (PUT) this field is only echoed back when supplied in the request body, otherwise it is null (omit it to leave domains unchanged).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#custom_domains AiSearchNamespace#custom_domains}
    */
    readonly customDomains?: string[];
    /**
    * When false, the instance is reachable only via a registered custom domain and the default <public_endpoint_id>.search.ai.cloudflare.com host returns 404. Requires at least one custom domain. Defaults to true. public_endpoint_params is replaced wholesale on update, so resend default_domain_enabled on every update to keep the default host off — omitting it resets to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#default_domain_enabled AiSearchNamespace#default_domain_enabled}
    */
    readonly defaultDomainEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#enabled AiSearchNamespace#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Instance IDs exposed through the namespace public endpoint. Empty means nothing is searchable. Every ID must be an existing instance in this namespace, and the list cannot exceed the account's multi-instance search limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#instances_allowed AiSearchNamespace#instances_allowed}
    */
    readonly instancesAllowed?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#mcp AiSearchNamespace#mcp}
    */
    readonly mcp?: AiSearchNamespacePublicEndpointParamsMcp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#rate_limit AiSearchNamespace#rate_limit}
    */
    readonly rateLimit?: AiSearchNamespacePublicEndpointParamsRateLimit;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#search_endpoint AiSearchNamespace#search_endpoint}
    */
    readonly searchEndpoint?: AiSearchNamespacePublicEndpointParamsSearchEndpoint;
}
export declare function aiSearchNamespacePublicEndpointParamsToTerraform(struct?: AiSearchNamespacePublicEndpointParams | cdktn.IResolvable): any;
export declare function aiSearchNamespacePublicEndpointParamsToHclTerraform(struct?: AiSearchNamespacePublicEndpointParams | cdktn.IResolvable): any;
export declare class AiSearchNamespacePublicEndpointParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchNamespacePublicEndpointParams | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchNamespacePublicEndpointParams | cdktn.IResolvable | undefined);
    private _authorizedHosts?;
    get authorizedHosts(): string[];
    set authorizedHosts(value: string[]);
    resetAuthorizedHosts(): void;
    get authorizedHostsInput(): string[] | undefined;
    private _chatCompletionsEndpoint;
    get chatCompletionsEndpoint(): AiSearchNamespacePublicEndpointParamsChatCompletionsEndpointOutputReference;
    putChatCompletionsEndpoint(value: AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint): void;
    resetChatCompletionsEndpoint(): void;
    get chatCompletionsEndpointInput(): cdktn.IResolvable | AiSearchNamespacePublicEndpointParamsChatCompletionsEndpoint | undefined;
    private _customDomains?;
    get customDomains(): string[];
    set customDomains(value: string[]);
    resetCustomDomains(): void;
    get customDomainsInput(): string[] | undefined;
    private _defaultDomainEnabled?;
    get defaultDomainEnabled(): boolean | cdktn.IResolvable;
    set defaultDomainEnabled(value: boolean | cdktn.IResolvable);
    resetDefaultDomainEnabled(): void;
    get defaultDomainEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _instancesAllowed?;
    get instancesAllowed(): string[];
    set instancesAllowed(value: string[]);
    resetInstancesAllowed(): void;
    get instancesAllowedInput(): string[] | undefined;
    private _mcp;
    get mcp(): AiSearchNamespacePublicEndpointParamsMcpOutputReference;
    putMcp(value: AiSearchNamespacePublicEndpointParamsMcp): void;
    resetMcp(): void;
    get mcpInput(): cdktn.IResolvable | AiSearchNamespacePublicEndpointParamsMcp | undefined;
    private _rateLimit;
    get rateLimit(): AiSearchNamespacePublicEndpointParamsRateLimitOutputReference;
    putRateLimit(value: AiSearchNamespacePublicEndpointParamsRateLimit): void;
    resetRateLimit(): void;
    get rateLimitInput(): cdktn.IResolvable | AiSearchNamespacePublicEndpointParamsRateLimit | undefined;
    private _searchEndpoint;
    get searchEndpoint(): AiSearchNamespacePublicEndpointParamsSearchEndpointOutputReference;
    putSearchEndpoint(value: AiSearchNamespacePublicEndpointParamsSearchEndpoint): void;
    resetSearchEndpoint(): void;
    get searchEndpointInput(): cdktn.IResolvable | AiSearchNamespacePublicEndpointParamsSearchEndpoint | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace cloudflare_ai_search_namespace}
*/
export declare class AiSearchNamespace extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ai_search_namespace";
    /**
    * Generates CDKTN code for importing a AiSearchNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiSearchNamespace to import
    * @param importFromId The id of the existing AiSearchNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiSearchNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/ai_search_namespace cloudflare_ai_search_namespace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiSearchNamespaceConfig
    */
    constructor(scope: Construct, id: string, config: AiSearchNamespaceConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicEndpointId(): string;
    private _publicEndpointParams;
    get publicEndpointParams(): AiSearchNamespacePublicEndpointParamsOutputReference;
    putPublicEndpointParams(value: AiSearchNamespacePublicEndpointParams): void;
    resetPublicEndpointParams(): void;
    get publicEndpointParamsInput(): cdktn.IResolvable | AiSearchNamespacePublicEndpointParams | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
