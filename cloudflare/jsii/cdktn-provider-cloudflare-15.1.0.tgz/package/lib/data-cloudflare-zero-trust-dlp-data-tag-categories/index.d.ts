/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpDataTagCategoriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_data_tag_categories#account_id DataCloudflareZeroTrustDlpDataTagCategories#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_data_tag_categories#max_items DataCloudflareZeroTrustDlpDataTagCategories#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDlpDataTagCategoriesResultTags {
}
export declare function dataCloudflareZeroTrustDlpDataTagCategoriesResultTagsToTerraform(struct?: DataCloudflareZeroTrustDlpDataTagCategoriesResultTags): any;
export declare function dataCloudflareZeroTrustDlpDataTagCategoriesResultTagsToHclTerraform(struct?: DataCloudflareZeroTrustDlpDataTagCategoriesResultTags): any;
export declare class DataCloudflareZeroTrustDlpDataTagCategoriesResultTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpDataTagCategoriesResultTags | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpDataTagCategoriesResultTags | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustDlpDataTagCategoriesResultTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpDataTagCategoriesResultTagsOutputReference;
}
export interface DataCloudflareZeroTrustDlpDataTagCategoriesResult {
}
export declare function dataCloudflareZeroTrustDlpDataTagCategoriesResultToTerraform(struct?: DataCloudflareZeroTrustDlpDataTagCategoriesResult): any;
export declare function dataCloudflareZeroTrustDlpDataTagCategoriesResultToHclTerraform(struct?: DataCloudflareZeroTrustDlpDataTagCategoriesResult): any;
export declare class DataCloudflareZeroTrustDlpDataTagCategoriesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpDataTagCategoriesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpDataTagCategoriesResult | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    private _tags;
    get tags(): DataCloudflareZeroTrustDlpDataTagCategoriesResultTagsList;
    get templateId(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustDlpDataTagCategoriesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpDataTagCategoriesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_data_tag_categories cloudflare_zero_trust_dlp_data_tag_categories}
*/
export declare class DataCloudflareZeroTrustDlpDataTagCategories extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_data_tag_categories";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpDataTagCategories resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpDataTagCategories to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpDataTagCategories that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_data_tag_categories#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpDataTagCategories to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/zero_trust_dlp_data_tag_categories cloudflare_zero_trust_dlp_data_tag_categories} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpDataTagCategoriesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpDataTagCategoriesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDlpDataTagCategoriesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
