/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustAccessAiControlsMcpPortalsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_access_ai_controls_mcp_portals#account_id DataCloudflareZeroTrustAccessAiControlsMcpPortals#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_access_ai_controls_mcp_portals#max_items DataCloudflareZeroTrustAccessAiControlsMcpPortals#max_items}
    */
    readonly maxItems?: number;
    /**
    * Search by id, name, hostname
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_access_ai_controls_mcp_portals#search DataCloudflareZeroTrustAccessAiControlsMcpPortals#search}
    */
    readonly search?: string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetails {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetailsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetails): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetailsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetails): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetails | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetails | undefined);
    get cause(): string;
    get isUpstream(): cdktn.IResolvable;
    get mcpCode(): number;
    get retryable(): cdktn.IResolvable;
    get statusCode(): number;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPrompts {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPromptsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPrompts): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPromptsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPrompts): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPromptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPrompts | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPrompts | undefined);
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get portalAlias(): string;
    get portalDescription(): string;
    get serverAlias(): string;
    get serverDescription(): string;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPromptsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPromptsOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedTools {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedToolsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedTools): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedToolsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedTools): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedTools | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedTools | undefined);
    get enabled(): cdktn.IResolvable;
    get name(): string;
    get portalAlias(): string;
    get portalDescription(): string;
    get serverAlias(): string;
    get serverDescription(): string;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedToolsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedToolsOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServers {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServers): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServers): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServers | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServers | undefined);
    get authType(): string;
    get createdAt(): string;
    get createdBy(): string;
    get defaultDisabled(): cdktn.IResolvable;
    get description(): string;
    get error(): string;
    private _errorDetails;
    get errorDetails(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersErrorDetailsOutputReference;
    get hostname(): string;
    get id(): string;
    get isSharedOauthCallbackEnabled(): cdktn.IResolvable;
    get lastSuccessfulSync(): string;
    get lastSynced(): string;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get name(): string;
    get onBehalf(): cdktn.IResolvable;
    private _prompts;
    get prompts(): cdktn.StringMapList;
    get secureWebGateway(): cdktn.IResolvable;
    get serverId(): string;
    get status(): string;
    private _tools;
    get tools(): cdktn.StringMapList;
    private _updatedPrompts;
    get updatedPrompts(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedPromptsList;
    private _updatedTools;
    get updatedTools(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersUpdatedToolsList;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpPortalsResult {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResult): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpPortalsResultToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResult): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpPortalsResult | undefined);
    get allowCodeMode(): cdktn.IResolvable;
    get createdAt(): string;
    get createdBy(): string;
    get description(): string;
    get hostname(): string;
    get id(): string;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get name(): string;
    get secureWebGateway(): cdktn.IResolvable;
    private _servers;
    get servers(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultServersList;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_access_ai_controls_mcp_portals cloudflare_zero_trust_access_ai_controls_mcp_portals}
*/
export declare class DataCloudflareZeroTrustAccessAiControlsMcpPortals extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_access_ai_controls_mcp_portals";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustAccessAiControlsMcpPortals resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustAccessAiControlsMcpPortals to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustAccessAiControlsMcpPortals that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_access_ai_controls_mcp_portals#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustAccessAiControlsMcpPortals to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_access_ai_controls_mcp_portals cloudflare_zero_trust_access_ai_controls_mcp_portals} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustAccessAiControlsMcpPortalsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustAccessAiControlsMcpPortalsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustAccessAiControlsMcpPortalsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
