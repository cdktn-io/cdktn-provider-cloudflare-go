/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareOauthScopesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/oauth_scopes#max_items DataCloudflareOauthScopes#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareOauthScopesResult {
}
export declare function dataCloudflareOauthScopesResultToTerraform(struct?: DataCloudflareOauthScopesResult): any;
export declare function dataCloudflareOauthScopesResultToHclTerraform(struct?: DataCloudflareOauthScopesResult): any;
export declare class DataCloudflareOauthScopesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareOauthScopesResult | undefined;
    set internalValue(value: DataCloudflareOauthScopesResult | undefined);
    get category(): string;
    get id(): string;
    get name(): string;
    get scopes(): string[];
}
export declare class DataCloudflareOauthScopesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareOauthScopesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/oauth_scopes cloudflare_oauth_scopes}
*/
export declare class DataCloudflareOauthScopes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_oauth_scopes";
    /**
    * Generates CDKTN code for importing a DataCloudflareOauthScopes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareOauthScopes to import
    * @param importFromId The id of the existing DataCloudflareOauthScopes that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/oauth_scopes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareOauthScopes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/oauth_scopes cloudflare_oauth_scopes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareOauthScopesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareOauthScopesConfig);
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareOauthScopesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
