/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCasbWebhooksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_webhooks#account_id DataCloudflareZeroTrustCasbWebhooks#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_webhooks#max_items DataCloudflareZeroTrustCasbWebhooks#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustCasbWebhooksResultHeaders {
}
export declare function dataCloudflareZeroTrustCasbWebhooksResultHeadersToTerraform(struct?: DataCloudflareZeroTrustCasbWebhooksResultHeaders): any;
export declare function dataCloudflareZeroTrustCasbWebhooksResultHeadersToHclTerraform(struct?: DataCloudflareZeroTrustCasbWebhooksResultHeaders): any;
export declare class DataCloudflareZeroTrustCasbWebhooksResultHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbWebhooksResultHeaders | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbWebhooksResultHeaders | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataCloudflareZeroTrustCasbWebhooksResultHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbWebhooksResultHeadersOutputReference;
}
export interface DataCloudflareZeroTrustCasbWebhooksResult {
}
export declare function dataCloudflareZeroTrustCasbWebhooksResultToTerraform(struct?: DataCloudflareZeroTrustCasbWebhooksResult): any;
export declare function dataCloudflareZeroTrustCasbWebhooksResultToHclTerraform(struct?: DataCloudflareZeroTrustCasbWebhooksResult): any;
export declare class DataCloudflareZeroTrustCasbWebhooksResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbWebhooksResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbWebhooksResult | undefined);
    get authenticationType(): string;
    get createdAt(): string;
    get destinationUrl(): string;
    private _headers;
    get headers(): DataCloudflareZeroTrustCasbWebhooksResultHeadersList;
    get id(): string;
    get label(): string;
    get status(): string;
    get updatedAt(): string;
    get version(): number;
}
export declare class DataCloudflareZeroTrustCasbWebhooksResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbWebhooksResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_webhooks cloudflare_zero_trust_casb_webhooks}
*/
export declare class DataCloudflareZeroTrustCasbWebhooks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_casb_webhooks";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCasbWebhooks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCasbWebhooks to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCasbWebhooks that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_webhooks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCasbWebhooks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_webhooks cloudflare_zero_trust_casb_webhooks} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCasbWebhooksConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCasbWebhooksConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCasbWebhooksResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
