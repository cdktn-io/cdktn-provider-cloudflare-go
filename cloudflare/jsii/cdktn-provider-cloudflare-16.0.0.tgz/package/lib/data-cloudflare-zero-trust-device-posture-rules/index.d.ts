/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDevicePostureRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_device_posture_rules#account_id DataCloudflareZeroTrustDevicePostureRules#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_device_posture_rules#max_items DataCloudflareZeroTrustDevicePostureRules#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDevicePostureRulesResultInputLocations {
}
export declare function dataCloudflareZeroTrustDevicePostureRulesResultInputLocationsToTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResultInputLocations): any;
export declare function dataCloudflareZeroTrustDevicePostureRulesResultInputLocationsToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResultInputLocations): any;
export declare class DataCloudflareZeroTrustDevicePostureRulesResultInputLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDevicePostureRulesResultInputLocations | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureRulesResultInputLocations | undefined);
    get paths(): string[];
    get trustStores(): string[];
}
export interface DataCloudflareZeroTrustDevicePostureRulesResultInput {
}
export declare function dataCloudflareZeroTrustDevicePostureRulesResultInputToTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResultInput): any;
export declare function dataCloudflareZeroTrustDevicePostureRulesResultInputToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResultInput): any;
export declare class DataCloudflareZeroTrustDevicePostureRulesResultInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDevicePostureRulesResultInput | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureRulesResultInput | undefined);
    get activeThreats(): number;
    get authState(): string[];
    get certificateId(): string;
    get checkDisks(): string[];
    get checkPrivateKey(): cdktn.IResolvable;
    get cn(): string;
    get complianceStatus(): string;
    get connectionId(): string;
    get countOperator(): string;
    get domain(): string;
    get eidLastSeen(): string;
    get enabled(): cdktn.IResolvable;
    get exists(): cdktn.IResolvable;
    get extendedKeyUsage(): string[];
    get id(): string;
    get infected(): cdktn.IResolvable;
    get isActive(): cdktn.IResolvable;
    get issueCount(): string;
    get lastSeen(): string;
    private _locations;
    get locations(): DataCloudflareZeroTrustDevicePostureRulesResultInputLocationsOutputReference;
    get networkStatus(): string;
    get operatingSystem(): string;
    get operationalState(): string;
    get operator(): string;
    get os(): string;
    get osDistroName(): string;
    get osDistroRevision(): string;
    get osVersionExtra(): string;
    get overall(): string;
    get path(): string;
    get requireAll(): cdktn.IResolvable;
    get riskLevel(): string;
    get score(): number;
    get scoreOperator(): string;
    get sensorConfig(): string;
    get sha256(): string;
    get state(): string;
    get subjectAlternativeNames(): string[];
    get thumbprint(): string;
    get totalScore(): number;
    get updateWindowDays(): number;
    get version(): string;
    get versionOperator(): string;
}
export interface DataCloudflareZeroTrustDevicePostureRulesResultMatch {
}
export declare function dataCloudflareZeroTrustDevicePostureRulesResultMatchToTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResultMatch): any;
export declare function dataCloudflareZeroTrustDevicePostureRulesResultMatchToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResultMatch): any;
export declare class DataCloudflareZeroTrustDevicePostureRulesResultMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDevicePostureRulesResultMatch | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureRulesResultMatch | undefined);
    get platform(): string;
}
export declare class DataCloudflareZeroTrustDevicePostureRulesResultMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDevicePostureRulesResultMatchOutputReference;
}
export interface DataCloudflareZeroTrustDevicePostureRulesResult {
}
export declare function dataCloudflareZeroTrustDevicePostureRulesResultToTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResult): any;
export declare function dataCloudflareZeroTrustDevicePostureRulesResultToHclTerraform(struct?: DataCloudflareZeroTrustDevicePostureRulesResult): any;
export declare class DataCloudflareZeroTrustDevicePostureRulesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDevicePostureRulesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDevicePostureRulesResult | undefined);
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expiration(): string;
    get id(): string;
    private _input;
    get input(): DataCloudflareZeroTrustDevicePostureRulesResultInputOutputReference;
    private _match;
    get match(): DataCloudflareZeroTrustDevicePostureRulesResultMatchList;
    get name(): string;
    get schedule(): string;
    get type(): string;
}
export declare class DataCloudflareZeroTrustDevicePostureRulesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDevicePostureRulesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_device_posture_rules cloudflare_zero_trust_device_posture_rules}
*/
export declare class DataCloudflareZeroTrustDevicePostureRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_posture_rules";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDevicePostureRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDevicePostureRules to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDevicePostureRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_device_posture_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDevicePostureRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_device_posture_rules cloudflare_zero_trust_device_posture_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDevicePostureRulesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustDevicePostureRulesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDevicePostureRulesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
