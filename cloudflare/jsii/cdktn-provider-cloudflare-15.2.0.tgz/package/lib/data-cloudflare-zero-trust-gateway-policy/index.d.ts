/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustGatewayPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_gateway_policy#account_id DataCloudflareZeroTrustGatewayPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * Identify the API resource with a UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_gateway_policy#rule_id DataCloudflareZeroTrustGatewayPolicy#rule_id}
    */
    readonly ruleId: string;
}
export interface DataCloudflareZeroTrustGatewayPolicyExpiration {
}
export declare function dataCloudflareZeroTrustGatewayPolicyExpirationToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyExpiration): any;
export declare function dataCloudflareZeroTrustGatewayPolicyExpirationToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyExpiration): any;
export declare class DataCloudflareZeroTrustGatewayPolicyExpirationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyExpiration | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyExpiration | undefined);
    get duration(): number;
    get expired(): cdktn.IResolvable;
    get expiresAt(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSsh {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSshToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSsh): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSshToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSsh): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSshOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSsh | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSsh | undefined);
    get commandLogging(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControls {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControlsToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControls): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControlsToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControls): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControls | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControls | undefined);
    get copy(): string;
    get dcp(): cdktn.IResolvable;
    get dd(): cdktn.IResolvable;
    get dk(): cdktn.IResolvable;
    get download(): string;
    get dp(): cdktn.IResolvable;
    get du(): cdktn.IResolvable;
    get keyboard(): string;
    get paste(): string;
    get printing(): string;
    get upload(): string;
    get version(): string;
    get wmId(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPage {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPageToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPage): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPageToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPage): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPage | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPage | undefined);
    get includeContext(): cdktn.IResolvable;
    get targetUri(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSession {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSessionToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSession): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSessionToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSession): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSessionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSession | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSession | undefined);
    get duration(): string;
    get enforce(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4 {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4ToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4ToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4 | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4 | undefined);
    get ip(): string;
    get port(): number;
    get routeThroughPrivateNetwork(): cdktn.IResolvable;
    get vnetId(): string;
}
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4List extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4OutputReference;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6 {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6ToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6ToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6 | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6 | undefined);
    get ip(): string;
    get port(): number;
    get routeThroughPrivateNetwork(): cdktn.IResolvable;
    get vnetId(): string;
}
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6List extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6OutputReference;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolvers {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolvers): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolvers): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolvers | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolvers | undefined);
    private _ipv4;
    get ipv4(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv4List;
    private _ipv6;
    get ipv6(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversIpv6List;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsEgress {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsEgressToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsEgress): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsEgressToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsEgress): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsEgress | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsEgress | undefined);
    get ipv4(): string;
    get ipv4Fallback(): string;
    get ipv6(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopy {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopyToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopy): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopyToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopy): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopy | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopy | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsL4Override {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsL4OverrideToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsL4Override): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsL4OverrideToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsL4Override): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsL4OverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsL4Override | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsL4Override | undefined);
    get ip(): string;
    get port(): number;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettings {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettingsToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettings): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettingsToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettings): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettings | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettings | undefined);
    get enabled(): cdktn.IResolvable;
    get includeContext(): cdktn.IResolvable;
    get msg(): string;
    get supportUrl(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLog {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLogToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLog): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLogToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLog): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLog | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLog | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantine {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantineToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantine): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantineToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantine): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantine | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantine | undefined);
    get fileTypes(): string[];
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirect {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirectToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirect): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirectToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirect): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirect | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirect | undefined);
    get includeContext(): cdktn.IResolvable;
    get preservePathAndQuery(): cdktn.IResolvable;
    get targetUri(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternally {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternallyToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternally): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternallyToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternally): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternallyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternally | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternally | undefined);
    get fallback(): string;
    get viewId(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCert {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCertToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCert): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCertToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCert): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCert | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCert | undefined);
    get action(): string;
}
export interface DataCloudflareZeroTrustGatewayPolicyRuleSettings {
}
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettings): any;
export declare function dataCloudflareZeroTrustGatewayPolicyRuleSettingsToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicyRuleSettings): any;
export declare class DataCloudflareZeroTrustGatewayPolicyRuleSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicyRuleSettings | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicyRuleSettings | undefined);
    private _addHeaders;
    get addHeaders(): cdktn.StringListMap;
    get allowChildBypass(): cdktn.IResolvable;
    private _auditSsh;
    get auditSsh(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsAuditSshOutputReference;
    private _bisoAdminControls;
    get bisoAdminControls(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsBisoAdminControlsOutputReference;
    private _blockPage;
    get blockPage(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsBlockPageOutputReference;
    get blockPageEnabled(): cdktn.IResolvable;
    get blockReason(): string;
    get bypassParentRule(): cdktn.IResolvable;
    private _checkSession;
    get checkSession(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsCheckSessionOutputReference;
    private _dnsResolvers;
    get dnsResolvers(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsDnsResolversOutputReference;
    private _egress;
    get egress(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsEgressOutputReference;
    private _forensicCopy;
    get forensicCopy(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsForensicCopyOutputReference;
    get ignoreCnameCategoryMatches(): cdktn.IResolvable;
    get insecureDisableDnssecValidation(): cdktn.IResolvable;
    get ipCategories(): cdktn.IResolvable;
    get ipIndicatorFeeds(): cdktn.IResolvable;
    private _l4Override;
    get l4Override(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsL4OverrideOutputReference;
    private _notificationSettings;
    get notificationSettings(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsNotificationSettingsOutputReference;
    get overrideHost(): string;
    get overrideIps(): string[];
    private _payloadLog;
    get payloadLog(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsPayloadLogOutputReference;
    private _quarantine;
    get quarantine(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsQuarantineOutputReference;
    private _redirect;
    get redirect(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsRedirectOutputReference;
    private _resolveDnsInternally;
    get resolveDnsInternally(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsResolveDnsInternallyOutputReference;
    get resolveDnsThroughCloudflare(): cdktn.IResolvable;
    private _untrustedCert;
    get untrustedCert(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsUntrustedCertOutputReference;
}
export interface DataCloudflareZeroTrustGatewayPolicySchedule {
}
export declare function dataCloudflareZeroTrustGatewayPolicyScheduleToTerraform(struct?: DataCloudflareZeroTrustGatewayPolicySchedule): any;
export declare function dataCloudflareZeroTrustGatewayPolicyScheduleToHclTerraform(struct?: DataCloudflareZeroTrustGatewayPolicySchedule): any;
export declare class DataCloudflareZeroTrustGatewayPolicyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewayPolicySchedule | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewayPolicySchedule | undefined);
    get fri(): string;
    get mon(): string;
    get sat(): string;
    get sun(): string;
    get thu(): string;
    get timeZone(): string;
    get tue(): string;
    get wed(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_gateway_policy cloudflare_zero_trust_gateway_policy}
*/
export declare class DataCloudflareZeroTrustGatewayPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_gateway_policy";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustGatewayPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustGatewayPolicy to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustGatewayPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_gateway_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustGatewayPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_gateway_policy cloudflare_zero_trust_gateway_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustGatewayPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustGatewayPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get action(): string;
    get createdAt(): string;
    get deletedAt(): string;
    get description(): string;
    get devicePosture(): string;
    get enabled(): cdktn.IResolvable;
    private _expiration;
    get expiration(): DataCloudflareZeroTrustGatewayPolicyExpirationOutputReference;
    get filters(): string[];
    get id(): string;
    get identity(): string;
    get name(): string;
    get precedence(): number;
    get readOnly(): cdktn.IResolvable;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
    private _ruleSettings;
    get ruleSettings(): DataCloudflareZeroTrustGatewayPolicyRuleSettingsOutputReference;
    private _schedule;
    get schedule(): DataCloudflareZeroTrustGatewayPolicyScheduleOutputReference;
    get sharable(): cdktn.IResolvable;
    get sourceAccount(): string;
    get traffic(): string;
    get updatedAt(): string;
    get version(): number;
    get warningStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
