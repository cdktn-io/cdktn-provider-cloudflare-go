/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWaitingRoomEventConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room_event#event_id DataCloudflareWaitingRoomEvent#event_id}
    */
    readonly eventId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room_event#waiting_room_id DataCloudflareWaitingRoomEvent#waiting_room_id}
    */
    readonly waitingRoomId: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room_event#zone_id DataCloudflareWaitingRoomEvent#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room_event cloudflare_waiting_room_event}
*/
export declare class DataCloudflareWaitingRoomEvent extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_waiting_room_event";
    /**
    * Generates CDKTN code for importing a DataCloudflareWaitingRoomEvent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWaitingRoomEvent to import
    * @param importFromId The id of the existing DataCloudflareWaitingRoomEvent that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room_event#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWaitingRoomEvent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/waiting_room_event cloudflare_waiting_room_event} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWaitingRoomEventConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareWaitingRoomEventConfig);
    get createdOn(): string;
    get customPageHtml(): string;
    get description(): string;
    get disableSessionRenewal(): cdktn.IResolvable;
    get eventEndTime(): string;
    private _eventId?;
    get eventId(): string;
    set eventId(value: string);
    get eventIdInput(): string | undefined;
    get eventStartTime(): string;
    get id(): string;
    get modifiedOn(): string;
    get name(): string;
    get newUsersPerMinute(): number;
    get prequeueStartTime(): string;
    get queueingMethod(): string;
    get sessionDuration(): number;
    get shuffleAtEventStart(): cdktn.IResolvable;
    get suspended(): cdktn.IResolvable;
    get totalActiveUsers(): number;
    get turnstileAction(): string;
    get turnstileMode(): string;
    private _waitingRoomId?;
    get waitingRoomId(): string;
    set waitingRoomId(value: string);
    get waitingRoomIdInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
