/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflarePageShieldCookiesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/page_shield_cookies#cookie_id DataCloudflarePageShieldCookies#cookie_id}
    */
    readonly cookieId: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/page_shield_cookies#zone_id DataCloudflarePageShieldCookies#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/page_shield_cookies cloudflare_page_shield_cookies}
*/
export declare class DataCloudflarePageShieldCookies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_page_shield_cookies";
    /**
    * Generates CDKTN code for importing a DataCloudflarePageShieldCookies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflarePageShieldCookies to import
    * @param importFromId The id of the existing DataCloudflarePageShieldCookies that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/page_shield_cookies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflarePageShieldCookies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/page_shield_cookies cloudflare_page_shield_cookies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflarePageShieldCookiesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflarePageShieldCookiesConfig);
    private _cookieId?;
    get cookieId(): string;
    set cookieId(value: string);
    get cookieIdInput(): string | undefined;
    get domainAttribute(): string;
    get expiresAttribute(): string;
    get firstSeenAt(): string;
    get host(): string;
    get httpOnlyAttribute(): cdktn.IResolvable;
    get id(): string;
    get lastSeenAt(): string;
    get maxAgeAttribute(): number;
    get name(): string;
    get pageUrls(): string[];
    get pathAttribute(): string;
    get sameSiteAttribute(): string;
    get secureAttribute(): cdktn.IResolvable;
    get type(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
