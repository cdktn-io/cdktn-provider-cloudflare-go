/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCasbIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#account_id DataCloudflareZeroTrustCasbIntegration#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#filter DataCloudflareZeroTrustCasbIntegration#filter}
    */
    readonly filter?: DataCloudflareZeroTrustCasbIntegrationFilter;
    /**
    * Integration ID to look up. Exactly one of `id` or `filter` must be configured.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#id DataCloudflareZeroTrustCasbIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataCloudflareZeroTrustCasbIntegrationAuthorizationLink {
}
export declare function dataCloudflareZeroTrustCasbIntegrationAuthorizationLinkToTerraform(struct?: DataCloudflareZeroTrustCasbIntegrationAuthorizationLink): any;
export declare function dataCloudflareZeroTrustCasbIntegrationAuthorizationLinkToHclTerraform(struct?: DataCloudflareZeroTrustCasbIntegrationAuthorizationLink): any;
export declare class DataCloudflareZeroTrustCasbIntegrationAuthorizationLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCasbIntegrationAuthorizationLink | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbIntegrationAuthorizationLink | undefined);
    private _components;
    get components(): cdktn.StringMap;
    get link(): string;
}
export interface DataCloudflareZeroTrustCasbIntegrationFilter {
    /**
    * Filter by application/vendor (e.g., GOOGLE_WORKSPACE, MICROSOFT_INTERNAL).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#application DataCloudflareZeroTrustCasbIntegration#application}
    */
    readonly application?: string;
    /**
    * Direction to order results.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#direction DataCloudflareZeroTrustCasbIntegration#direction}
    */
    readonly direction?: string;
    /**
    * Filter by DLP enabled status (true/false).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#dlp_enabled DataCloudflareZeroTrustCasbIntegration#dlp_enabled}
    */
    readonly dlpEnabled?: boolean | cdktn.IResolvable;
    /**
    * Field to order results by.
    * Available values: "application", "created", "name", "status".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#order DataCloudflareZeroTrustCasbIntegration#order}
    */
    readonly order?: string;
    /**
    * Page number within the paginated result set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#page DataCloudflareZeroTrustCasbIntegration#page}
    */
    readonly page?: number;
    /**
    * Number of results per page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#page_size DataCloudflareZeroTrustCasbIntegration#page_size}
    */
    readonly pageSize?: number;
    /**
    * Search integrations by name or application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#search DataCloudflareZeroTrustCasbIntegration#search}
    */
    readonly search?: string;
    /**
    * Filter by integration status.
    * Available values: "Healthy", "Initializing", "Offline", "Unhealthy".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#status DataCloudflareZeroTrustCasbIntegration#status}
    */
    readonly status?: string;
    /**
    * Filter by one enabled use case (for example, casb or ces).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#use_cases DataCloudflareZeroTrustCasbIntegration#use_cases}
    */
    readonly useCases?: string;
}
export declare function dataCloudflareZeroTrustCasbIntegrationFilterToTerraform(struct?: DataCloudflareZeroTrustCasbIntegrationFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustCasbIntegrationFilterToHclTerraform(struct?: DataCloudflareZeroTrustCasbIntegrationFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustCasbIntegrationFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCasbIntegrationFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbIntegrationFilter | cdktn.IResolvable | undefined);
    private _application?;
    get application(): string;
    set application(value: string);
    resetApplication(): void;
    get applicationInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _dlpEnabled?;
    get dlpEnabled(): boolean | cdktn.IResolvable;
    set dlpEnabled(value: boolean | cdktn.IResolvable);
    resetDlpEnabled(): void;
    get dlpEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _page?;
    get page(): number;
    set page(value: number);
    resetPage(): void;
    get pageInput(): number | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _useCases?;
    get useCases(): string;
    set useCases(value: string);
    resetUseCases(): void;
    get useCasesInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration cloudflare_zero_trust_casb_integration}
*/
export declare class DataCloudflareZeroTrustCasbIntegration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_casb_integration";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCasbIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCasbIntegration to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCasbIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCasbIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_casb_integration cloudflare_zero_trust_casb_integration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCasbIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCasbIntegrationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _application;
    get application(): cdktn.StringMap;
    private _authMethod;
    get authMethod(): cdktn.StringMap;
    private _authorizationLink;
    get authorizationLink(): DataCloudflareZeroTrustCasbIntegrationAuthorizationLinkOutputReference;
    get created(): string;
    get credentialsExpiry(): string;
    get dlpProfiles(): string[];
    private _filter;
    get filter(): DataCloudflareZeroTrustCasbIntegrationFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustCasbIntegrationFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustCasbIntegrationFilter | undefined;
    private _healthDetails;
    get healthDetails(): cdktn.StringMapList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isPaused(): cdktn.IResolvable;
    get lastHydrated(): string;
    get name(): string;
    get status(): string;
    get updated(): string;
    private _useCases;
    get useCases(): cdktn.StringMapList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
