/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpDataClassesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_data_classes#account_id DataCloudflareZeroTrustDlpDataClasses#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_data_classes#max_items DataCloudflareZeroTrustDlpDataClasses#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevels {
}
export declare function dataCloudflareZeroTrustDlpDataClassesResultSensitivityLevelsToTerraform(struct?: DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevels): any;
export declare function dataCloudflareZeroTrustDlpDataClassesResultSensitivityLevelsToHclTerraform(struct?: DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevels): any;
export declare class DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevels | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevels | undefined);
    get groupId(): string;
    get levelId(): string;
}
export declare class DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevelsOutputReference;
}
export interface DataCloudflareZeroTrustDlpDataClassesResult {
}
export declare function dataCloudflareZeroTrustDlpDataClassesResultToTerraform(struct?: DataCloudflareZeroTrustDlpDataClassesResult): any;
export declare function dataCloudflareZeroTrustDlpDataClassesResultToHclTerraform(struct?: DataCloudflareZeroTrustDlpDataClassesResult): any;
export declare class DataCloudflareZeroTrustDlpDataClassesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpDataClassesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpDataClassesResult | undefined);
    get createdAt(): string;
    get dataTags(): string[];
    get description(): string;
    get expression(): string;
    get id(): string;
    get name(): string;
    private _sensitivityLevels;
    get sensitivityLevels(): DataCloudflareZeroTrustDlpDataClassesResultSensitivityLevelsList;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustDlpDataClassesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpDataClassesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_data_classes cloudflare_zero_trust_dlp_data_classes}
*/
export declare class DataCloudflareZeroTrustDlpDataClasses extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_data_classes";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpDataClasses resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpDataClasses to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpDataClasses that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_data_classes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpDataClasses to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/zero_trust_dlp_data_classes cloudflare_zero_trust_dlp_data_classes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpDataClassesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpDataClassesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDlpDataClassesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
