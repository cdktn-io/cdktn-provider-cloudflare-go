/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLoadBalancerMonitorGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/load_balancer_monitor_group#account_id DataCloudflareLoadBalancerMonitorGroup#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/load_balancer_monitor_group#monitor_group_id DataCloudflareLoadBalancerMonitorGroup#monitor_group_id}
    */
    readonly monitorGroupId: string;
}
export interface DataCloudflareLoadBalancerMonitorGroupMembers {
}
export declare function dataCloudflareLoadBalancerMonitorGroupMembersToTerraform(struct?: DataCloudflareLoadBalancerMonitorGroupMembers): any;
export declare function dataCloudflareLoadBalancerMonitorGroupMembersToHclTerraform(struct?: DataCloudflareLoadBalancerMonitorGroupMembers): any;
export declare class DataCloudflareLoadBalancerMonitorGroupMembersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerMonitorGroupMembers | undefined;
    set internalValue(value: DataCloudflareLoadBalancerMonitorGroupMembers | undefined);
    get createdAt(): string;
    get enabled(): cdktn.IResolvable;
    get monitorId(): string;
    get monitoringOnly(): cdktn.IResolvable;
    get mustBeHealthy(): cdktn.IResolvable;
    get updatedAt(): string;
}
export declare class DataCloudflareLoadBalancerMonitorGroupMembersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerMonitorGroupMembersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/load_balancer_monitor_group cloudflare_load_balancer_monitor_group}
*/
export declare class DataCloudflareLoadBalancerMonitorGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_load_balancer_monitor_group";
    /**
    * Generates CDKTN code for importing a DataCloudflareLoadBalancerMonitorGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLoadBalancerMonitorGroup to import
    * @param importFromId The id of the existing DataCloudflareLoadBalancerMonitorGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/load_balancer_monitor_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLoadBalancerMonitorGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/load_balancer_monitor_group cloudflare_load_balancer_monitor_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLoadBalancerMonitorGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareLoadBalancerMonitorGroupConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdOn(): string;
    get description(): string;
    get id(): string;
    private _members;
    get members(): DataCloudflareLoadBalancerMonitorGroupMembersList;
    get modifiedOn(): string;
    private _monitorGroupId?;
    get monitorGroupId(): string;
    set monitorGroupId(value: string);
    get monitorGroupIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
