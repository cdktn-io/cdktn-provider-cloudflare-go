/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RulesetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique ID of the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#account_id Ruleset#account_id}
    */
    readonly accountId?: string;
    /**
    * An informative description of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#description Ruleset#description}
    */
    readonly description?: string;
    /**
    * The kind of the ruleset.
    * Available values: "managed", "custom", "root", "zone".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#kind Ruleset#kind}
    */
    readonly kind: string;
    /**
    * The human-readable name of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
    /**
    * The phase of the ruleset.
    * Available values: "ddos_l4", "ddos_l7", "http_config_settings", "http_custom_errors", "http_log_custom_fields", "http_ratelimit", "http_request_cache_settings", "http_request_dynamic_redirect", "http_request_firewall_custom", "http_request_firewall_managed", "http_request_late_transform", "http_request_origin", "http_request_redirect", "http_request_sanitize", "http_request_sbfm", "http_request_transform", "http_response_cache_settings", "http_response_compression", "http_response_firewall_managed", "http_response_headers_transform", "magic_transit", "magic_transit_ids_managed", "magic_transit_managed", "magic_transit_ratelimit".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#phase Ruleset#phase}
    */
    readonly phase: string;
    /**
    * The list of rules in the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: RulesetRules[] | cdktn.IResolvable;
    /**
    * The unique ID of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#zone_id Ruleset#zone_id}
    */
    readonly zoneId?: string;
}
export interface RulesetRulesActionParametersAlgorithms {
    /**
    * Name of the compression algorithm to enable.
    * Available values: "none", "auto", "default", "gzip", "brotli", "zstd".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name?: string;
}
export declare function rulesetRulesActionParametersAlgorithmsToTerraform(struct?: RulesetRulesActionParametersAlgorithms | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersAlgorithmsToHclTerraform(struct?: RulesetRulesActionParametersAlgorithms | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersAlgorithmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersAlgorithms | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersAlgorithms | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class RulesetRulesActionParametersAlgorithmsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersAlgorithms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersAlgorithmsOutputReference;
}
export interface RulesetRulesActionParametersAutominify {
    /**
    * Whether to minify CSS files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#css Ruleset#css}
    */
    readonly css?: boolean | cdktn.IResolvable;
    /**
    * Whether to minify HTML files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#html Ruleset#html}
    */
    readonly html?: boolean | cdktn.IResolvable;
    /**
    * Whether to minify JavaScript files.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#js Ruleset#js}
    */
    readonly js?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersAutominifyToTerraform(struct?: RulesetRulesActionParametersAutominify | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersAutominifyToHclTerraform(struct?: RulesetRulesActionParametersAutominify | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersAutominifyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersAutominify | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersAutominify | cdktn.IResolvable | undefined);
    private _css?;
    get css(): boolean | cdktn.IResolvable;
    set css(value: boolean | cdktn.IResolvable);
    resetCss(): void;
    get cssInput(): boolean | cdktn.IResolvable | undefined;
    private _html?;
    get html(): boolean | cdktn.IResolvable;
    set html(value: boolean | cdktn.IResolvable);
    resetHtml(): void;
    get htmlInput(): boolean | cdktn.IResolvable | undefined;
    private _js?;
    get js(): boolean | cdktn.IResolvable;
    set js(value: boolean | cdktn.IResolvable);
    resetJs(): void;
    get jsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface RulesetRulesActionParametersBrowserTtl {
    /**
    * The browser TTL (in seconds) if you choose the "override_origin" mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#default Ruleset#default}
    */
    readonly default?: number;
    /**
    * The browser TTL mode.
    * Available values: "respect_origin", "bypass_by_default", "override_origin", "bypass".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#mode Ruleset#mode}
    */
    readonly mode: string;
}
export declare function rulesetRulesActionParametersBrowserTtlToTerraform(struct?: RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersBrowserTtlToHclTerraform(struct?: RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersBrowserTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersBrowserTtl | cdktn.IResolvable | undefined);
    private _default?;
    get default(): number;
    set default(value: number);
    resetDefault(): void;
    get defaultInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyCookie {
    /**
    * A list of cookies to check for the presence of. The presence of these cookies is included in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#check_presence Ruleset#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * A list of cookies to include in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyCookieToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyCookieToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyCookie | cdktn.IResolvable | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyHeader {
    /**
    * A list of headers to check for the presence of. The presence of these headers is included in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#check_presence Ruleset#check_presence}
    */
    readonly checkPresence?: string[];
    /**
    * A mapping of header names to a list of values. If a header is present in the request and contains any of the values provided, its value is included in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#contains Ruleset#contains}
    */
    readonly contains?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Whether to exclude the origin header in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#exclude_origin Ruleset#exclude_origin}
    */
    readonly excludeOrigin?: boolean | cdktn.IResolvable;
    /**
    * A list of headers to include in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHeaderToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHeaderToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyHeader | cdktn.IResolvable | undefined);
    private _checkPresence?;
    get checkPresence(): string[];
    set checkPresence(value: string[]);
    resetCheckPresence(): void;
    get checkPresenceInput(): string[] | undefined;
    private _contains?;
    get contains(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set contains(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetContains(): void;
    get containsInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _excludeOrigin?;
    get excludeOrigin(): boolean | cdktn.IResolvable;
    set excludeOrigin(value: boolean | cdktn.IResolvable);
    resetExcludeOrigin(): void;
    get excludeOriginInput(): boolean | cdktn.IResolvable | undefined;
    private _include?;
    get include(): string[];
    set include(value: string[]);
    resetInclude(): void;
    get includeInput(): string[] | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyHost {
    /**
    * Whether to use the resolved host in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#resolved Ruleset#resolved}
    */
    readonly resolved?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHostToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyHostToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyHost | cdktn.IResolvable | undefined);
    private _resolved?;
    get resolved(): boolean | cdktn.IResolvable;
    set resolved(value: boolean | cdktn.IResolvable);
    resetResolved(): void;
    get resolvedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude {
    /**
    * Whether to exclude all query string parameters from the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#all Ruleset#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * A list of query string parameters to exclude from the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#list Ruleset#list}
    */
    readonly list?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _list?;
    get list(): string[];
    set list(value: string[]);
    resetList(): void;
    get listInput(): string[] | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude {
    /**
    * Whether to include all query string parameters in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#all Ruleset#all}
    */
    readonly all?: boolean | cdktn.IResolvable;
    /**
    * A list of query string parameters to include in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#list Ruleset#list}
    */
    readonly list?: string[];
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude | cdktn.IResolvable | undefined);
    private _all?;
    get all(): boolean | cdktn.IResolvable;
    set all(value: boolean | cdktn.IResolvable);
    resetAll(): void;
    get allInput(): boolean | cdktn.IResolvable | undefined;
    private _list?;
    get list(): string[];
    set list(value: string[]);
    resetList(): void;
    get listInput(): string[] | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyQueryString {
    /**
    * Which query string parameters to exclude from the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#exclude Ruleset#exclude}
    */
    readonly exclude?: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude;
    /**
    * Which query string parameters to include in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#include Ruleset#include}
    */
    readonly include?: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyQueryStringToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryString | cdktn.IResolvable | undefined);
    private _exclude;
    get exclude(): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeOutputReference;
    putExclude(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude): void;
    resetExclude(): void;
    get excludeInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude | undefined;
    private _include;
    get include(): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeOutputReference;
    putInclude(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude): void;
    resetInclude(): void;
    get includeInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKeyUser {
    /**
    * Whether to use the user agent's device type in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#device_type Ruleset#device_type}
    */
    readonly deviceType?: boolean | cdktn.IResolvable;
    /**
    * Whether to use the user agents's country in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#geo Ruleset#geo}
    */
    readonly geo?: boolean | cdktn.IResolvable;
    /**
    * Whether to use the user agent's language in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#lang Ruleset#lang}
    */
    readonly lang?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyUserToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyUserToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKeyUser | cdktn.IResolvable | undefined);
    private _deviceType?;
    get deviceType(): boolean | cdktn.IResolvable;
    set deviceType(value: boolean | cdktn.IResolvable);
    resetDeviceType(): void;
    get deviceTypeInput(): boolean | cdktn.IResolvable | undefined;
    private _geo?;
    get geo(): boolean | cdktn.IResolvable;
    set geo(value: boolean | cdktn.IResolvable);
    resetGeo(): void;
    get geoInput(): boolean | cdktn.IResolvable | undefined;
    private _lang?;
    get lang(): boolean | cdktn.IResolvable;
    set lang(value: boolean | cdktn.IResolvable);
    resetLang(): void;
    get langInput(): boolean | cdktn.IResolvable | undefined;
}
export interface RulesetRulesActionParametersCacheKeyCustomKey {
    /**
    * Which cookies to include in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cookie Ruleset#cookie}
    */
    readonly cookie?: RulesetRulesActionParametersCacheKeyCustomKeyCookie;
    /**
    * Which headers to include in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#header Ruleset#header}
    */
    readonly header?: RulesetRulesActionParametersCacheKeyCustomKeyHeader;
    /**
    * How to use the host in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#host Ruleset#host}
    */
    readonly host?: RulesetRulesActionParametersCacheKeyCustomKeyHost;
    /**
    * Which query string parameters to include in or exclude from the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#query_string Ruleset#query_string}
    */
    readonly queryString?: RulesetRulesActionParametersCacheKeyCustomKeyQueryString;
    /**
    * How to use characteristics of the request user agent in the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#user Ruleset#user}
    */
    readonly user?: RulesetRulesActionParametersCacheKeyCustomKeyUser;
}
export declare function rulesetRulesActionParametersCacheKeyCustomKeyToTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyCustomKeyToHclTerraform(struct?: RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyCustomKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKeyCustomKey | cdktn.IResolvable | undefined);
    private _cookie;
    get cookie(): RulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference;
    putCookie(value: RulesetRulesActionParametersCacheKeyCustomKeyCookie): void;
    resetCookie(): void;
    get cookieInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyCookie | undefined;
    private _header;
    get header(): RulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference;
    putHeader(value: RulesetRulesActionParametersCacheKeyCustomKeyHeader): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyHeader | undefined;
    private _host;
    get host(): RulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference;
    putHost(value: RulesetRulesActionParametersCacheKeyCustomKeyHost): void;
    resetHost(): void;
    get hostInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyHost | undefined;
    private _queryString;
    get queryString(): RulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference;
    putQueryString(value: RulesetRulesActionParametersCacheKeyCustomKeyQueryString): void;
    resetQueryString(): void;
    get queryStringInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyQueryString | undefined;
    private _user;
    get user(): RulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference;
    putUser(value: RulesetRulesActionParametersCacheKeyCustomKeyUser): void;
    resetUser(): void;
    get userInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKeyUser | undefined;
}
export interface RulesetRulesActionParametersCacheKey {
    /**
    * Whether to separate cached content based on the visitor's device type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cache_by_device_type Ruleset#cache_by_device_type}
    */
    readonly cacheByDeviceType?: boolean | cdktn.IResolvable;
    /**
    * Whether to protect from web cache deception attacks, while allowing static assets to be cached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cache_deception_armor Ruleset#cache_deception_armor}
    */
    readonly cacheDeceptionArmor?: boolean | cdktn.IResolvable;
    /**
    * Which components of the request are included or excluded from the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#custom_key Ruleset#custom_key}
    */
    readonly customKey?: RulesetRulesActionParametersCacheKeyCustomKey;
    /**
    * Whether to treat requests with the same query parameters the same, regardless of the order those query parameters are in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#ignore_query_strings_order Ruleset#ignore_query_strings_order}
    */
    readonly ignoreQueryStringsOrder?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersCacheKeyToTerraform(struct?: RulesetRulesActionParametersCacheKey | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheKeyToHclTerraform(struct?: RulesetRulesActionParametersCacheKey | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheKey | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheKey | cdktn.IResolvable | undefined);
    private _cacheByDeviceType?;
    get cacheByDeviceType(): boolean | cdktn.IResolvable;
    set cacheByDeviceType(value: boolean | cdktn.IResolvable);
    resetCacheByDeviceType(): void;
    get cacheByDeviceTypeInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheDeceptionArmor?;
    get cacheDeceptionArmor(): boolean | cdktn.IResolvable;
    set cacheDeceptionArmor(value: boolean | cdktn.IResolvable);
    resetCacheDeceptionArmor(): void;
    get cacheDeceptionArmorInput(): boolean | cdktn.IResolvable | undefined;
    private _customKey;
    get customKey(): RulesetRulesActionParametersCacheKeyCustomKeyOutputReference;
    putCustomKey(value: RulesetRulesActionParametersCacheKeyCustomKey): void;
    resetCustomKey(): void;
    get customKeyInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKeyCustomKey | undefined;
    private _ignoreQueryStringsOrder?;
    get ignoreQueryStringsOrder(): boolean | cdktn.IResolvable;
    set ignoreQueryStringsOrder(value: boolean | cdktn.IResolvable);
    resetIgnoreQueryStringsOrder(): void;
    get ignoreQueryStringsOrderInput(): boolean | cdktn.IResolvable | undefined;
}
export interface RulesetRulesActionParametersCacheReserve {
    /**
    * Whether Cache Reserve is enabled. If this is true and a request meets eligibility criteria, Cloudflare will write the resource to Cache Reserve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#eligible Ruleset#eligible}
    */
    readonly eligible: boolean | cdktn.IResolvable;
    /**
    * The minimum file size eligible for storage in Cache Reserve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#minimum_file_size Ruleset#minimum_file_size}
    */
    readonly minimumFileSize?: number;
}
export declare function rulesetRulesActionParametersCacheReserveToTerraform(struct?: RulesetRulesActionParametersCacheReserve | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCacheReserveToHclTerraform(struct?: RulesetRulesActionParametersCacheReserve | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCacheReserveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersCacheReserve | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCacheReserve | cdktn.IResolvable | undefined);
    private _eligible?;
    get eligible(): boolean | cdktn.IResolvable;
    set eligible(value: boolean | cdktn.IResolvable);
    get eligibleInput(): boolean | cdktn.IResolvable | undefined;
    private _minimumFileSize?;
    get minimumFileSize(): number;
    set minimumFileSize(value: number);
    resetMinimumFileSize(): void;
    get minimumFileSizeInput(): number | undefined;
}
export interface RulesetRulesActionParametersCookieFields {
    /**
    * The name of the cookie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
}
export declare function rulesetRulesActionParametersCookieFieldsToTerraform(struct?: RulesetRulesActionParametersCookieFields | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersCookieFieldsToHclTerraform(struct?: RulesetRulesActionParametersCookieFields | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersCookieFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersCookieFields | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersCookieFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class RulesetRulesActionParametersCookieFieldsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersCookieFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersCookieFieldsOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange {
    /**
    * The lower bound of the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#from Ruleset#from}
    */
    readonly from?: number;
    /**
    * The upper bound of the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#to Ruleset#to}
    */
    readonly to?: number;
}
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | cdktn.IResolvable | undefined);
    private _from?;
    get from(): number;
    set from(value: number);
    resetFrom(): void;
    get fromInput(): number | undefined;
    private _to?;
    get to(): number;
    set to(value: number);
    resetTo(): void;
    get toInput(): number | undefined;
}
export interface RulesetRulesActionParametersEdgeTtlStatusCodeTtl {
    /**
    * A single status code to apply the TTL to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * A range of status codes to apply the TTL to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#status_code_range Ruleset#status_code_range}
    */
    readonly statusCodeRange?: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange;
    /**
    * The time to cache the response for (in seconds). A value of 0 is equivalent to setting the cache control header with the value "no-cache". A value of -1 is equivalent to setting the cache control header with the value of "no-store".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value: number;
}
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlToTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlStatusCodeTtlToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtl | cdktn.IResolvable | undefined);
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _statusCodeRange;
    get statusCodeRange(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference;
    putStatusCodeRange(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange): void;
    resetStatusCodeRange(): void;
    get statusCodeRangeInput(): cdktn.IResolvable | RulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class RulesetRulesActionParametersEdgeTtlStatusCodeTtlList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference;
}
export interface RulesetRulesActionParametersEdgeTtl {
    /**
    * The edge TTL (in seconds) if you choose the "override_origin" mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#default Ruleset#default}
    */
    readonly default?: number;
    /**
    * The edge TTL mode.
    * Available values: "respect_origin", "bypass_by_default", "override_origin".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#mode Ruleset#mode}
    */
    readonly mode: string;
    /**
    * A list of TTLs to apply to specific status codes or status code ranges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#status_code_ttl Ruleset#status_code_ttl}
    */
    readonly statusCodeTtl?: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersEdgeTtlToTerraform(struct?: RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersEdgeTtlToHclTerraform(struct?: RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersEdgeTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersEdgeTtl | cdktn.IResolvable | undefined);
    private _default?;
    get default(): number;
    set default(value: number);
    resetDefault(): void;
    get defaultInput(): number | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _statusCodeTtl;
    get statusCodeTtl(): RulesetRulesActionParametersEdgeTtlStatusCodeTtlList;
    putStatusCodeTtl(value: RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | cdktn.IResolvable): void;
    resetStatusCodeTtl(): void;
    get statusCodeTtlInput(): cdktn.IResolvable | RulesetRulesActionParametersEdgeTtlStatusCodeTtl[] | undefined;
}
export interface RulesetRulesActionParametersFromListStruct {
    /**
    * An expression that evaluates to the list lookup key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#key Ruleset#key}
    */
    readonly key: string;
    /**
    * The name of the list to match against.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
}
export declare function rulesetRulesActionParametersFromListStructToTerraform(struct?: RulesetRulesActionParametersFromListStruct | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersFromListStructToHclTerraform(struct?: RulesetRulesActionParametersFromListStruct | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersFromListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersFromListStruct | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromListStruct | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface RulesetRulesActionParametersFromValueTargetUrl {
    /**
    * An expression that evaluates to a URL to redirect the request to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * A URL to redirect the request to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersFromValueTargetUrlToTerraform(struct?: RulesetRulesActionParametersFromValueTargetUrl): any;
export declare function rulesetRulesActionParametersFromValueTargetUrlToHclTerraform(struct?: RulesetRulesActionParametersFromValueTargetUrl): any;
export declare class RulesetRulesActionParametersFromValueTargetUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersFromValueTargetUrl | undefined;
    set internalValue(value: RulesetRulesActionParametersFromValueTargetUrl | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface RulesetRulesActionParametersFromValue {
    /**
    * Whether to keep the query string of the original request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#preserve_query_string Ruleset#preserve_query_string}
    */
    readonly preserveQueryString?: boolean | cdktn.IResolvable;
    /**
    * The status code to use for the redirect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * A URL to redirect the request to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#target_url Ruleset#target_url}
    */
    readonly targetUrl: RulesetRulesActionParametersFromValueTargetUrl;
}
export declare function rulesetRulesActionParametersFromValueToTerraform(struct?: RulesetRulesActionParametersFromValue | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersFromValueToHclTerraform(struct?: RulesetRulesActionParametersFromValue | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersFromValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersFromValue | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersFromValue | cdktn.IResolvable | undefined);
    private _preserveQueryString?;
    get preserveQueryString(): boolean | cdktn.IResolvable;
    set preserveQueryString(value: boolean | cdktn.IResolvable);
    resetPreserveQueryString(): void;
    get preserveQueryStringInput(): boolean | cdktn.IResolvable | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _targetUrl;
    get targetUrl(): RulesetRulesActionParametersFromValueTargetUrlOutputReference;
    putTargetUrl(value: RulesetRulesActionParametersFromValueTargetUrl): void;
    get targetUrlInput(): RulesetRulesActionParametersFromValueTargetUrl | undefined;
}
export interface RulesetRulesActionParametersHeaders {
    /**
    * An expression that evaluates to a value for the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * The operation to perform on the header.
    * Available values: "add", "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
    /**
    * A static value for the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersHeadersToTerraform(struct?: RulesetRulesActionParametersHeaders | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersHeadersToHclTerraform(struct?: RulesetRulesActionParametersHeaders | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): RulesetRulesActionParametersHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersHeaders | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class RulesetRulesActionParametersHeadersMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: RulesetRulesActionParametersHeaders;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): RulesetRulesActionParametersHeadersOutputReference;
}
export interface RulesetRulesActionParametersImmutable {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
}
export declare function rulesetRulesActionParametersImmutableToTerraform(struct?: RulesetRulesActionParametersImmutable | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersImmutableToHclTerraform(struct?: RulesetRulesActionParametersImmutable | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersImmutableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersImmutable | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersImmutable | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface RulesetRulesActionParametersMatchedData {
    /**
    * The public key to encrypt matched data logs with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#public_key Ruleset#public_key}
    */
    readonly publicKey: string;
}
export declare function rulesetRulesActionParametersMatchedDataToTerraform(struct?: RulesetRulesActionParametersMatchedData | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersMatchedDataToHclTerraform(struct?: RulesetRulesActionParametersMatchedData | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersMatchedDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersMatchedData | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersMatchedData | cdktn.IResolvable | undefined);
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
}
export interface RulesetRulesActionParametersMaxAge {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
    /**
    * The value for the directive in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: number;
}
export declare function rulesetRulesActionParametersMaxAgeToTerraform(struct?: RulesetRulesActionParametersMaxAge | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersMaxAgeToHclTerraform(struct?: RulesetRulesActionParametersMaxAge | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersMaxAgeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersMaxAge | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersMaxAge | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface RulesetRulesActionParametersMustRevalidate {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
}
export declare function rulesetRulesActionParametersMustRevalidateToTerraform(struct?: RulesetRulesActionParametersMustRevalidate | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersMustRevalidateToHclTerraform(struct?: RulesetRulesActionParametersMustRevalidate | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersMustRevalidateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersMustRevalidate | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersMustRevalidate | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface RulesetRulesActionParametersMustUnderstand {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
}
export declare function rulesetRulesActionParametersMustUnderstandToTerraform(struct?: RulesetRulesActionParametersMustUnderstand | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersMustUnderstandToHclTerraform(struct?: RulesetRulesActionParametersMustUnderstand | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersMustUnderstandOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersMustUnderstand | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersMustUnderstand | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface RulesetRulesActionParametersNoCache {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
    /**
    * The qualifiers for the directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#qualifiers Ruleset#qualifiers}
    */
    readonly qualifiers?: string[];
}
export declare function rulesetRulesActionParametersNoCacheToTerraform(struct?: RulesetRulesActionParametersNoCache | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersNoCacheToHclTerraform(struct?: RulesetRulesActionParametersNoCache | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersNoCacheOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersNoCache | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersNoCache | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _qualifiers?;
    get qualifiers(): string[];
    set qualifiers(value: string[]);
    resetQualifiers(): void;
    get qualifiersInput(): string[] | undefined;
}
export interface RulesetRulesActionParametersNoStore {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
}
export declare function rulesetRulesActionParametersNoStoreToTerraform(struct?: RulesetRulesActionParametersNoStore | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersNoStoreToHclTerraform(struct?: RulesetRulesActionParametersNoStore | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersNoStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersNoStore | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersNoStore | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface RulesetRulesActionParametersNoTransform {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
}
export declare function rulesetRulesActionParametersNoTransformToTerraform(struct?: RulesetRulesActionParametersNoTransform | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersNoTransformToHclTerraform(struct?: RulesetRulesActionParametersNoTransform | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersNoTransformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersNoTransform | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersNoTransform | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface RulesetRulesActionParametersOrigin {
    /**
    * A resolved host to route to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#host Ruleset#host}
    */
    readonly host?: string;
    /**
    * A destination port to route to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#port Ruleset#port}
    */
    readonly port?: number;
}
export declare function rulesetRulesActionParametersOriginToTerraform(struct?: RulesetRulesActionParametersOrigin | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOriginToHclTerraform(struct?: RulesetRulesActionParametersOrigin | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOrigin | cdktn.IResolvable | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
}
export interface RulesetRulesActionParametersOverridesCategories {
    /**
    * The action to override rules in the category with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * The name of the category to override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#category Ruleset#category}
    */
    readonly category: string;
    /**
    * Whether to enable execution of rules in the category.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The sensitivity level to use for rules in the category. This option is only applicable for DDoS phases.
    * Available values: "default", "medium", "low", "eoff".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#sensitivity_level Ruleset#sensitivity_level}
    */
    readonly sensitivityLevel?: string;
}
export declare function rulesetRulesActionParametersOverridesCategoriesToTerraform(struct?: RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesCategoriesToHclTerraform(struct?: RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverridesCategories | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sensitivityLevel?;
    get sensitivityLevel(): string;
    set sensitivityLevel(value: string);
    resetSensitivityLevel(): void;
    get sensitivityLevelInput(): string | undefined;
}
export declare class RulesetRulesActionParametersOverridesCategoriesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersOverridesCategories[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesCategoriesOutputReference;
}
export interface RulesetRulesActionParametersOverridesRules {
    /**
    * The action to override the rule with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * Whether to enable execution of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * The ID of the rule to override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * The score threshold to use for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#score_threshold Ruleset#score_threshold}
    */
    readonly scoreThreshold?: number;
    /**
    * The sensitivity level to use for the rule. This option is only applicable for DDoS phases.
    * Available values: "default", "medium", "low", "eoff".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#sensitivity_level Ruleset#sensitivity_level}
    */
    readonly sensitivityLevel?: string;
}
export declare function rulesetRulesActionParametersOverridesRulesToTerraform(struct?: RulesetRulesActionParametersOverridesRules | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesRulesToHclTerraform(struct?: RulesetRulesActionParametersOverridesRules | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersOverridesRules | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverridesRules | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _scoreThreshold?;
    get scoreThreshold(): number;
    set scoreThreshold(value: number);
    resetScoreThreshold(): void;
    get scoreThresholdInput(): number | undefined;
    private _sensitivityLevel?;
    get sensitivityLevel(): string;
    set sensitivityLevel(value: string);
    resetSensitivityLevel(): void;
    get sensitivityLevelInput(): string | undefined;
}
export declare class RulesetRulesActionParametersOverridesRulesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersOverridesRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersOverridesRulesOutputReference;
}
export interface RulesetRulesActionParametersOverrides {
    /**
    * An action to override all rules with. This option has lower precedence than rule and category overrides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action?: string;
    /**
    * A list of category-level overrides. This option has the second-highest precedence after rule-level overrides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#categories Ruleset#categories}
    */
    readonly categories?: RulesetRulesActionParametersOverridesCategories[] | cdktn.IResolvable;
    /**
    * Whether to enable execution of all rules. This option has lower precedence than rule and category overrides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * A list of rule-level overrides. This option has the highest precedence.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: RulesetRulesActionParametersOverridesRules[] | cdktn.IResolvable;
    /**
    * A sensitivity level to set for all rules. This option has lower precedence than rule and category overrides and is only applicable for DDoS phases.
    * Available values: "default", "medium", "low", "eoff".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#sensitivity_level Ruleset#sensitivity_level}
    */
    readonly sensitivityLevel?: string;
}
export declare function rulesetRulesActionParametersOverridesToTerraform(struct?: RulesetRulesActionParametersOverrides | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersOverridesToHclTerraform(struct?: RulesetRulesActionParametersOverrides | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersOverrides | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _categories;
    get categories(): RulesetRulesActionParametersOverridesCategoriesList;
    putCategories(value: RulesetRulesActionParametersOverridesCategories[] | cdktn.IResolvable): void;
    resetCategories(): void;
    get categoriesInput(): cdktn.IResolvable | RulesetRulesActionParametersOverridesCategories[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _rules;
    get rules(): RulesetRulesActionParametersOverridesRulesList;
    putRules(value: RulesetRulesActionParametersOverridesRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | RulesetRulesActionParametersOverridesRules[] | undefined;
    private _sensitivityLevel?;
    get sensitivityLevel(): string;
    set sensitivityLevel(value: string);
    resetSensitivityLevel(): void;
    get sensitivityLevelInput(): string | undefined;
}
export interface RulesetRulesActionParametersPrivate {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
    /**
    * The qualifiers for the directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#qualifiers Ruleset#qualifiers}
    */
    readonly qualifiers?: string[];
}
export declare function rulesetRulesActionParametersPrivateToTerraform(struct?: RulesetRulesActionParametersPrivate | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersPrivateToHclTerraform(struct?: RulesetRulesActionParametersPrivate | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersPrivateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersPrivate | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersPrivate | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _qualifiers?;
    get qualifiers(): string[];
    set qualifiers(value: string[]);
    resetQualifiers(): void;
    get qualifiersInput(): string[] | undefined;
}
export interface RulesetRulesActionParametersProxyRevalidate {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
}
export declare function rulesetRulesActionParametersProxyRevalidateToTerraform(struct?: RulesetRulesActionParametersProxyRevalidate | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersProxyRevalidateToHclTerraform(struct?: RulesetRulesActionParametersProxyRevalidate | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersProxyRevalidateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersProxyRevalidate | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersProxyRevalidate | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface RulesetRulesActionParametersPublic {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
}
export declare function rulesetRulesActionParametersPublicToTerraform(struct?: RulesetRulesActionParametersPublic | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersPublicToHclTerraform(struct?: RulesetRulesActionParametersPublic | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersPublicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersPublic | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersPublic | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
}
export interface RulesetRulesActionParametersRawResponseFields {
    /**
    * The name of the response header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
    /**
    * Whether to log duplicate values of the same header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#preserve_duplicates Ruleset#preserve_duplicates}
    */
    readonly preserveDuplicates?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersRawResponseFieldsToTerraform(struct?: RulesetRulesActionParametersRawResponseFields | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersRawResponseFieldsToHclTerraform(struct?: RulesetRulesActionParametersRawResponseFields | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersRawResponseFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersRawResponseFields | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersRawResponseFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _preserveDuplicates?;
    get preserveDuplicates(): boolean | cdktn.IResolvable;
    set preserveDuplicates(value: boolean | cdktn.IResolvable);
    resetPreserveDuplicates(): void;
    get preserveDuplicatesInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersRawResponseFieldsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersRawResponseFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersRawResponseFieldsOutputReference;
}
export interface RulesetRulesActionParametersRequestFields {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
}
export declare function rulesetRulesActionParametersRequestFieldsToTerraform(struct?: RulesetRulesActionParametersRequestFields | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersRequestFieldsToHclTerraform(struct?: RulesetRulesActionParametersRequestFields | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersRequestFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersRequestFields | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersRequestFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class RulesetRulesActionParametersRequestFieldsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersRequestFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersRequestFieldsOutputReference;
}
export interface RulesetRulesActionParametersResponse {
    /**
    * The content to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#content Ruleset#content}
    */
    readonly content: string;
    /**
    * The type of the content to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#content_type Ruleset#content_type}
    */
    readonly contentType: string;
    /**
    * The status code to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode: number;
}
export declare function rulesetRulesActionParametersResponseToTerraform(struct?: RulesetRulesActionParametersResponse | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersResponseToHclTerraform(struct?: RulesetRulesActionParametersResponse | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersResponse | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersResponse | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    get contentTypeInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    get statusCodeInput(): number | undefined;
}
export interface RulesetRulesActionParametersResponseFields {
    /**
    * The name of the response header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
    /**
    * Whether to log duplicate values of the same header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#preserve_duplicates Ruleset#preserve_duplicates}
    */
    readonly preserveDuplicates?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersResponseFieldsToTerraform(struct?: RulesetRulesActionParametersResponseFields | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersResponseFieldsToHclTerraform(struct?: RulesetRulesActionParametersResponseFields | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersResponseFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersResponseFields | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersResponseFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _preserveDuplicates?;
    get preserveDuplicates(): boolean | cdktn.IResolvable;
    set preserveDuplicates(value: boolean | cdktn.IResolvable);
    resetPreserveDuplicates(): void;
    get preserveDuplicatesInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class RulesetRulesActionParametersResponseFieldsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersResponseFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersResponseFieldsOutputReference;
}
export interface RulesetRulesActionParametersSMaxage {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
    /**
    * The value for the directive in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: number;
}
export declare function rulesetRulesActionParametersSMaxageToTerraform(struct?: RulesetRulesActionParametersSMaxage | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersSMaxageToHclTerraform(struct?: RulesetRulesActionParametersSMaxage | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersSMaxageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersSMaxage | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersSMaxage | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface RulesetRulesActionParametersServeStale {
    /**
    * Whether Cloudflare should disable serving stale content while getting the latest content from the origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#disable_stale_while_updating Ruleset#disable_stale_while_updating}
    */
    readonly disableStaleWhileUpdating?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesActionParametersServeStaleToTerraform(struct?: RulesetRulesActionParametersServeStale | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersServeStaleToHclTerraform(struct?: RulesetRulesActionParametersServeStale | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersServeStaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersServeStale | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersServeStale | cdktn.IResolvable | undefined);
    private _disableStaleWhileUpdating?;
    get disableStaleWhileUpdating(): boolean | cdktn.IResolvable;
    set disableStaleWhileUpdating(value: boolean | cdktn.IResolvable);
    resetDisableStaleWhileUpdating(): void;
    get disableStaleWhileUpdatingInput(): boolean | cdktn.IResolvable | undefined;
}
export interface RulesetRulesActionParametersSni {
    /**
    * A value to override the SNI to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value: string;
}
export declare function rulesetRulesActionParametersSniToTerraform(struct?: RulesetRulesActionParametersSni | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersSniToHclTerraform(struct?: RulesetRulesActionParametersSni | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersSniOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersSni | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersSni | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface RulesetRulesActionParametersStaleIfError {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
    /**
    * The value for the directive in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: number;
}
export declare function rulesetRulesActionParametersStaleIfErrorToTerraform(struct?: RulesetRulesActionParametersStaleIfError | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersStaleIfErrorToHclTerraform(struct?: RulesetRulesActionParametersStaleIfError | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersStaleIfErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersStaleIfError | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersStaleIfError | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface RulesetRulesActionParametersStaleWhileRevalidate {
    /**
    * Whether to apply the directive only to Cloudflare's cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cloudflare_only Ruleset#cloudflare_only}
    */
    readonly cloudflareOnly?: boolean | cdktn.IResolvable;
    /**
    * The operation to perform.
    * Available values: "set", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation: string;
    /**
    * The value for the directive in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: number;
}
export declare function rulesetRulesActionParametersStaleWhileRevalidateToTerraform(struct?: RulesetRulesActionParametersStaleWhileRevalidate | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersStaleWhileRevalidateToHclTerraform(struct?: RulesetRulesActionParametersStaleWhileRevalidate | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersStaleWhileRevalidateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersStaleWhileRevalidate | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersStaleWhileRevalidate | cdktn.IResolvable | undefined);
    private _cloudflareOnly?;
    get cloudflareOnly(): boolean | cdktn.IResolvable;
    set cloudflareOnly(value: boolean | cdktn.IResolvable);
    resetCloudflareOnly(): void;
    get cloudflareOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    get operationInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface RulesetRulesActionParametersTransformedRequestFields {
    /**
    * The name of the header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#name Ruleset#name}
    */
    readonly name: string;
}
export declare function rulesetRulesActionParametersTransformedRequestFieldsToTerraform(struct?: RulesetRulesActionParametersTransformedRequestFields | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersTransformedRequestFieldsToHclTerraform(struct?: RulesetRulesActionParametersTransformedRequestFields | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersTransformedRequestFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRulesActionParametersTransformedRequestFields | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersTransformedRequestFields | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class RulesetRulesActionParametersTransformedRequestFieldsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRulesActionParametersTransformedRequestFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesActionParametersTransformedRequestFieldsOutputReference;
}
export interface RulesetRulesActionParametersUriPath {
    /**
    * An expression that evaluates to a value to rewrite the URI path to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * A value to rewrite the URI path to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersUriPathToTerraform(struct?: RulesetRulesActionParametersUriPath | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersUriPathToHclTerraform(struct?: RulesetRulesActionParametersUriPath | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersUriPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersUriPath | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUriPath | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface RulesetRulesActionParametersUriQuery {
    /**
    * An expression that evaluates to a value to rewrite the URI query to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * A value to rewrite the URI query to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#value Ruleset#value}
    */
    readonly value?: string;
}
export declare function rulesetRulesActionParametersUriQueryToTerraform(struct?: RulesetRulesActionParametersUriQuery | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersUriQueryToHclTerraform(struct?: RulesetRulesActionParametersUriQuery | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersUriQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersUriQuery | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUriQuery | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface RulesetRulesActionParametersUri {
    /**
    * A URI path rewrite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#path Ruleset#path}
    */
    readonly path?: RulesetRulesActionParametersUriPath;
    /**
    * A URI query rewrite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#query Ruleset#query}
    */
    readonly query?: RulesetRulesActionParametersUriQuery;
}
export declare function rulesetRulesActionParametersUriToTerraform(struct?: RulesetRulesActionParametersUri | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersUriToHclTerraform(struct?: RulesetRulesActionParametersUri | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParametersUri | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParametersUri | cdktn.IResolvable | undefined);
    private _path;
    get path(): RulesetRulesActionParametersUriPathOutputReference;
    putPath(value: RulesetRulesActionParametersUriPath): void;
    resetPath(): void;
    get pathInput(): cdktn.IResolvable | RulesetRulesActionParametersUriPath | undefined;
    private _query;
    get query(): RulesetRulesActionParametersUriQueryOutputReference;
    putQuery(value: RulesetRulesActionParametersUriQuery): void;
    resetQuery(): void;
    get queryInput(): cdktn.IResolvable | RulesetRulesActionParametersUriQuery | undefined;
}
export interface RulesetRulesActionParameters {
    /**
    * A list of additional ports that caching should be enabled on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#additional_cacheable_ports Ruleset#additional_cacheable_ports}
    */
    readonly additionalCacheablePorts?: number[];
    /**
    * Custom order for compression algorithms.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#algorithms Ruleset#algorithms}
    */
    readonly algorithms?: RulesetRulesActionParametersAlgorithms[] | cdktn.IResolvable;
    /**
    * The name of a custom asset to serve as the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#asset_name Ruleset#asset_name}
    */
    readonly assetName?: string;
    /**
    * Whether to enable Automatic HTTPS Rewrites.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#automatic_https_rewrites Ruleset#automatic_https_rewrites}
    */
    readonly automaticHttpsRewrites?: boolean | cdktn.IResolvable;
    /**
    * Which file extensions to minify automatically.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#autominify Ruleset#autominify}
    */
    readonly autominify?: RulesetRulesActionParametersAutominify;
    /**
    * Whether to enable Browser Integrity Check (BIC).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#bic Ruleset#bic}
    */
    readonly bic?: boolean | cdktn.IResolvable;
    /**
    * How long client browsers should cache the response. Cloudflare cache purge will not purge content cached on client browsers, so high browser TTLs may lead to stale content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#browser_ttl Ruleset#browser_ttl}
    */
    readonly browserTtl?: RulesetRulesActionParametersBrowserTtl;
    /**
    * Whether the request's response from the origin is eligible for caching. Caching itself will still depend on the cache control header and your other caching configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cache Ruleset#cache}
    */
    readonly cache?: boolean | cdktn.IResolvable;
    /**
    * Which components of the request are included in or excluded from the cache key Cloudflare uses to store the response in cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cache_key Ruleset#cache_key}
    */
    readonly cacheKey?: RulesetRulesActionParametersCacheKey;
    /**
    * Settings to determine whether the request's response from origin is eligible for Cache Reserve (requires a Cache Reserve add-on plan).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cache_reserve Ruleset#cache_reserve}
    */
    readonly cacheReserve?: RulesetRulesActionParametersCacheReserve;
    /**
    * The response content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#content Ruleset#content}
    */
    readonly content?: string;
    /**
    * The content type header to set with the error response.
    * Available values: "application/json", "text/html", "text/plain", "text/xml".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#content_type Ruleset#content_type}
    */
    readonly contentType?: string;
    /**
    * The cookie fields to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#cookie_fields Ruleset#cookie_fields}
    */
    readonly cookieFields?: RulesetRulesActionParametersCookieFields[] | cdktn.IResolvable;
    /**
    * Whether to disable Cloudflare Apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#disable_apps Ruleset#disable_apps}
    */
    readonly disableApps?: boolean | cdktn.IResolvable;
    /**
    * Whether to disable Real User Monitoring (RUM).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#disable_rum Ruleset#disable_rum}
    */
    readonly disableRum?: boolean | cdktn.IResolvable;
    /**
    * Whether to disable Zaraz.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#disable_zaraz Ruleset#disable_zaraz}
    */
    readonly disableZaraz?: boolean | cdktn.IResolvable;
    /**
    * How long the Cloudflare edge network should cache the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#edge_ttl Ruleset#edge_ttl}
    */
    readonly edgeTtl?: RulesetRulesActionParametersEdgeTtl;
    /**
    * Whether to enable Email Obfuscation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#email_obfuscation Ruleset#email_obfuscation}
    */
    readonly emailObfuscation?: boolean | cdktn.IResolvable;
    /**
    * An expression to generate cache tags for set_cache_tags action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression?: string;
    /**
    * Whether to enable Cloudflare Fonts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#fonts Ruleset#fonts}
    */
    readonly fonts?: boolean | cdktn.IResolvable;
    /**
    * A redirect based on a bulk list lookup.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#from_list Ruleset#from_list}
    */
    readonly fromList?: RulesetRulesActionParametersFromListStruct;
    /**
    * A redirect based on the request properties.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#from_value Ruleset#from_value}
    */
    readonly fromValue?: RulesetRulesActionParametersFromValue;
    /**
    * A map of headers to rewrite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#headers Ruleset#headers}
    */
    readonly headers?: {
        [key: string]: RulesetRulesActionParametersHeaders;
    } | cdktn.IResolvable;
    /**
    * A value to rewrite the HTTP host header to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#host_header Ruleset#host_header}
    */
    readonly hostHeader?: string;
    /**
    * Whether to enable Hotlink Protection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#hotlink_protection Ruleset#hotlink_protection}
    */
    readonly hotlinkProtection?: boolean | cdktn.IResolvable;
    /**
    * The ID of the ruleset to execute.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#id Ruleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set the immutable cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#immutable Ruleset#immutable}
    */
    readonly immutable?: RulesetRulesActionParametersImmutable;
    /**
    * A delta to change the score by, which can be either positive or negative.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#increment Ruleset#increment}
    */
    readonly increment?: number;
    /**
    * The configuration to use for matched data logging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#matched_data Ruleset#matched_data}
    */
    readonly matchedData?: RulesetRulesActionParametersMatchedData;
    /**
    * Set the max-age cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#max_age Ruleset#max_age}
    */
    readonly maxAge?: RulesetRulesActionParametersMaxAge;
    /**
    * Whether to enable Mirage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#mirage Ruleset#mirage}
    */
    readonly mirage?: boolean | cdktn.IResolvable;
    /**
    * Set the must-revalidate cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#must_revalidate Ruleset#must_revalidate}
    */
    readonly mustRevalidate?: RulesetRulesActionParametersMustRevalidate;
    /**
    * Set the must-understand cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#must_understand Ruleset#must_understand}
    */
    readonly mustUnderstand?: RulesetRulesActionParametersMustUnderstand;
    /**
    * Set the no-cache cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#no_cache Ruleset#no_cache}
    */
    readonly noCache?: RulesetRulesActionParametersNoCache;
    /**
    * Set the no-store cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#no_store Ruleset#no_store}
    */
    readonly noStore?: RulesetRulesActionParametersNoStore;
    /**
    * Set the no-transform cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#no_transform Ruleset#no_transform}
    */
    readonly noTransform?: RulesetRulesActionParametersNoTransform;
    /**
    * The operation to perform for set_cache_tags action.
    * Available values: "set", "add", "remove".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#operation Ruleset#operation}
    */
    readonly operation?: string;
    /**
    * Whether to enable Opportunistic Encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#opportunistic_encryption Ruleset#opportunistic_encryption}
    */
    readonly opportunisticEncryption?: boolean | cdktn.IResolvable;
    /**
    * An origin to route to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#origin Ruleset#origin}
    */
    readonly origin?: RulesetRulesActionParametersOrigin;
    /**
    * Whether Cloudflare will aim to strictly adhere to RFC 7234.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#origin_cache_control Ruleset#origin_cache_control}
    */
    readonly originCacheControl?: boolean | cdktn.IResolvable;
    /**
    * Whether to generate Cloudflare error pages for issues from the origin server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#origin_error_page_passthru Ruleset#origin_error_page_passthru}
    */
    readonly originErrorPagePassthru?: boolean | cdktn.IResolvable;
    /**
    * A set of overrides to apply to the target ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#overrides Ruleset#overrides}
    */
    readonly overrides?: RulesetRulesActionParametersOverrides;
    /**
    * A list of phases to skip the execution of. This option is incompatible with the rulesets option.
    * Available values: "ddos_l4", "ddos_l7", "http_config_settings", "http_custom_errors", "http_log_custom_fields", "http_ratelimit", "http_request_cache_settings", "http_request_dynamic_redirect", "http_request_firewall_custom", "http_request_firewall_managed", "http_request_late_transform", "http_request_origin", "http_request_redirect", "http_request_sanitize", "http_request_sbfm", "http_request_transform", "http_response_cache_settings", "http_response_compression", "http_response_firewall_managed", "http_response_headers_transform", "magic_transit", "magic_transit_ids_managed", "magic_transit_managed", "magic_transit_ratelimit".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#phases Ruleset#phases}
    */
    readonly phases?: string[];
    /**
    * The Polish level to configure.
    * Available values: "off", "lossless", "lossy", "webp".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#polish Ruleset#polish}
    */
    readonly polish?: string;
    /**
    * Set the private cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#private Ruleset#private}
    */
    readonly private?: RulesetRulesActionParametersPrivate;
    /**
    * A list of legacy security products to skip the execution of.
    * Available values: "bic", "hot", "rateLimit", "securityLevel", "uaBlock", "waf", "zoneLockdown".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#products Ruleset#products}
    */
    readonly products?: string[];
    /**
    * Set the proxy-revalidate cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#proxy_revalidate Ruleset#proxy_revalidate}
    */
    readonly proxyRevalidate?: RulesetRulesActionParametersProxyRevalidate;
    /**
    * Set the public cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#public Ruleset#public}
    */
    readonly public?: RulesetRulesActionParametersPublic;
    /**
    * The raw response fields to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#raw_response_fields Ruleset#raw_response_fields}
    */
    readonly rawResponseFields?: RulesetRulesActionParametersRawResponseFields[] | cdktn.IResolvable;
    /**
    * A timeout value between two successive read operations to use for your origin server. Historically, the timeout value between two read options from Cloudflare to an origin server is 100 seconds. If you are attempting to reduce HTTP 524 errors because of timeouts from an origin server, try increasing this timeout value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#read_timeout Ruleset#read_timeout}
    */
    readonly readTimeout?: number;
    /**
    * The request body buffering mode to configure.
    * Available values: "none", "standard", "full".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#request_body_buffering Ruleset#request_body_buffering}
    */
    readonly requestBodyBuffering?: string;
    /**
    * The raw request fields to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#request_fields Ruleset#request_fields}
    */
    readonly requestFields?: RulesetRulesActionParametersRequestFields[] | cdktn.IResolvable;
    /**
    * Whether Cloudflare should respect strong ETag (entity tag) headers. If false, Cloudflare converts strong ETag headers to weak ETag headers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#respect_strong_etags Ruleset#respect_strong_etags}
    */
    readonly respectStrongEtags?: boolean | cdktn.IResolvable;
    /**
    * The response to show when the block is applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#response Ruleset#response}
    */
    readonly response?: RulesetRulesActionParametersResponse;
    /**
    * The response body buffering mode to configure.
    * Available values: "none", "standard".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#response_body_buffering Ruleset#response_body_buffering}
    */
    readonly responseBodyBuffering?: string;
    /**
    * The transformed response fields to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#response_fields Ruleset#response_fields}
    */
    readonly responseFields?: RulesetRulesActionParametersResponseFields[] | cdktn.IResolvable;
    /**
    * Whether to enable Rocket Loader.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#rocket_loader Ruleset#rocket_loader}
    */
    readonly rocketLoader?: boolean | cdktn.IResolvable;
    /**
    * A mapping of ruleset IDs to a list of rule IDs in that ruleset to skip the execution of. This option is incompatible with the ruleset option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#rules Ruleset#rules}
    */
    readonly rules?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * A ruleset to skip the execution of. This option is incompatible with the rulesets option.
    * Available values: "current".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#ruleset Ruleset#ruleset}
    */
    readonly ruleset?: string;
    /**
    * A list of ruleset IDs to skip the execution of. This option is incompatible with the ruleset and phases options.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#rulesets Ruleset#rulesets}
    */
    readonly rulesets?: string[];
    /**
    * Set the s-maxage cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#s_maxage Ruleset#s_maxage}
    */
    readonly sMaxage?: RulesetRulesActionParametersSMaxage;
    /**
    * The Security Level to configure.
    * Available values: "off", "essentially_off", "low", "medium", "high", "under_attack".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#security_level Ruleset#security_level}
    */
    readonly securityLevel?: string;
    /**
    * When to serve stale content from cache.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#serve_stale Ruleset#serve_stale}
    */
    readonly serveStale?: RulesetRulesActionParametersServeStale;
    /**
    * Whether to enable Server-Side Excludes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#server_side_excludes Ruleset#server_side_excludes}
    */
    readonly serverSideExcludes?: boolean | cdktn.IResolvable;
    /**
    * A Server Name Indication (SNI) override.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#sni Ruleset#sni}
    */
    readonly sni?: RulesetRulesActionParametersSni;
    /**
    * The SSL level to configure.
    * Available values: "off", "flexible", "full", "strict", "origin_pull".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#ssl Ruleset#ssl}
    */
    readonly ssl?: string;
    /**
    * Set the stale-if-error cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#stale_if_error Ruleset#stale_if_error}
    */
    readonly staleIfError?: RulesetRulesActionParametersStaleIfError;
    /**
    * Set the stale-while-revalidate cache control directive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#stale_while_revalidate Ruleset#stale_while_revalidate}
    */
    readonly staleWhileRevalidate?: RulesetRulesActionParametersStaleWhileRevalidate;
    /**
    * The status code to use for the error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#status_code Ruleset#status_code}
    */
    readonly statusCode?: number;
    /**
    * Whether to strip the ETag header from the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#strip_etags Ruleset#strip_etags}
    */
    readonly stripEtags?: boolean | cdktn.IResolvable;
    /**
    * Whether to strip the Last-Modified header from the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#strip_last_modified Ruleset#strip_last_modified}
    */
    readonly stripLastModified?: boolean | cdktn.IResolvable;
    /**
    * Whether to strip the Set-Cookie header from the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#strip_set_cookie Ruleset#strip_set_cookie}
    */
    readonly stripSetCookie?: boolean | cdktn.IResolvable;
    /**
    * Whether to enable Signed Exchanges (SXG).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#sxg Ruleset#sxg}
    */
    readonly sxg?: boolean | cdktn.IResolvable;
    /**
    * The transformed request fields to log.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#transformed_request_fields Ruleset#transformed_request_fields}
    */
    readonly transformedRequestFields?: RulesetRulesActionParametersTransformedRequestFields[] | cdktn.IResolvable;
    /**
    * A URI rewrite.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#uri Ruleset#uri}
    */
    readonly uri?: RulesetRulesActionParametersUri;
    /**
    * The cache tag values for set_cache_tags action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#values Ruleset#values}
    */
    readonly values?: string[];
}
export declare function rulesetRulesActionParametersToTerraform(struct?: RulesetRulesActionParameters | cdktn.IResolvable): any;
export declare function rulesetRulesActionParametersToHclTerraform(struct?: RulesetRulesActionParameters | cdktn.IResolvable): any;
export declare class RulesetRulesActionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesActionParameters | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesActionParameters | cdktn.IResolvable | undefined);
    private _additionalCacheablePorts?;
    get additionalCacheablePorts(): number[];
    set additionalCacheablePorts(value: number[]);
    resetAdditionalCacheablePorts(): void;
    get additionalCacheablePortsInput(): number[] | undefined;
    private _algorithms;
    get algorithms(): RulesetRulesActionParametersAlgorithmsList;
    putAlgorithms(value: RulesetRulesActionParametersAlgorithms[] | cdktn.IResolvable): void;
    resetAlgorithms(): void;
    get algorithmsInput(): cdktn.IResolvable | RulesetRulesActionParametersAlgorithms[] | undefined;
    private _assetName?;
    get assetName(): string;
    set assetName(value: string);
    resetAssetName(): void;
    get assetNameInput(): string | undefined;
    private _automaticHttpsRewrites?;
    get automaticHttpsRewrites(): boolean | cdktn.IResolvable;
    set automaticHttpsRewrites(value: boolean | cdktn.IResolvable);
    resetAutomaticHttpsRewrites(): void;
    get automaticHttpsRewritesInput(): boolean | cdktn.IResolvable | undefined;
    private _autominify;
    get autominify(): RulesetRulesActionParametersAutominifyOutputReference;
    putAutominify(value: RulesetRulesActionParametersAutominify): void;
    resetAutominify(): void;
    get autominifyInput(): cdktn.IResolvable | RulesetRulesActionParametersAutominify | undefined;
    private _bic?;
    get bic(): boolean | cdktn.IResolvable;
    set bic(value: boolean | cdktn.IResolvable);
    resetBic(): void;
    get bicInput(): boolean | cdktn.IResolvable | undefined;
    private _browserTtl;
    get browserTtl(): RulesetRulesActionParametersBrowserTtlOutputReference;
    putBrowserTtl(value: RulesetRulesActionParametersBrowserTtl): void;
    resetBrowserTtl(): void;
    get browserTtlInput(): cdktn.IResolvable | RulesetRulesActionParametersBrowserTtl | undefined;
    private _cache?;
    get cache(): boolean | cdktn.IResolvable;
    set cache(value: boolean | cdktn.IResolvable);
    resetCache(): void;
    get cacheInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheKey;
    get cacheKey(): RulesetRulesActionParametersCacheKeyOutputReference;
    putCacheKey(value: RulesetRulesActionParametersCacheKey): void;
    resetCacheKey(): void;
    get cacheKeyInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheKey | undefined;
    private _cacheReserve;
    get cacheReserve(): RulesetRulesActionParametersCacheReserveOutputReference;
    putCacheReserve(value: RulesetRulesActionParametersCacheReserve): void;
    resetCacheReserve(): void;
    get cacheReserveInput(): cdktn.IResolvable | RulesetRulesActionParametersCacheReserve | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _cookieFields;
    get cookieFields(): RulesetRulesActionParametersCookieFieldsList;
    putCookieFields(value: RulesetRulesActionParametersCookieFields[] | cdktn.IResolvable): void;
    resetCookieFields(): void;
    get cookieFieldsInput(): cdktn.IResolvable | RulesetRulesActionParametersCookieFields[] | undefined;
    private _disableApps?;
    get disableApps(): boolean | cdktn.IResolvable;
    set disableApps(value: boolean | cdktn.IResolvable);
    resetDisableApps(): void;
    get disableAppsInput(): boolean | cdktn.IResolvable | undefined;
    private _disableRum?;
    get disableRum(): boolean | cdktn.IResolvable;
    set disableRum(value: boolean | cdktn.IResolvable);
    resetDisableRum(): void;
    get disableRumInput(): boolean | cdktn.IResolvable | undefined;
    private _disableZaraz?;
    get disableZaraz(): boolean | cdktn.IResolvable;
    set disableZaraz(value: boolean | cdktn.IResolvable);
    resetDisableZaraz(): void;
    get disableZarazInput(): boolean | cdktn.IResolvable | undefined;
    private _edgeTtl;
    get edgeTtl(): RulesetRulesActionParametersEdgeTtlOutputReference;
    putEdgeTtl(value: RulesetRulesActionParametersEdgeTtl): void;
    resetEdgeTtl(): void;
    get edgeTtlInput(): cdktn.IResolvable | RulesetRulesActionParametersEdgeTtl | undefined;
    private _emailObfuscation?;
    get emailObfuscation(): boolean | cdktn.IResolvable;
    set emailObfuscation(value: boolean | cdktn.IResolvable);
    resetEmailObfuscation(): void;
    get emailObfuscationInput(): boolean | cdktn.IResolvable | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _fonts?;
    get fonts(): boolean | cdktn.IResolvable;
    set fonts(value: boolean | cdktn.IResolvable);
    resetFonts(): void;
    get fontsInput(): boolean | cdktn.IResolvable | undefined;
    private _fromList;
    get fromList(): RulesetRulesActionParametersFromListStructOutputReference;
    putFromList(value: RulesetRulesActionParametersFromListStruct): void;
    resetFromList(): void;
    get fromListInput(): cdktn.IResolvable | RulesetRulesActionParametersFromListStruct | undefined;
    private _fromValue;
    get fromValue(): RulesetRulesActionParametersFromValueOutputReference;
    putFromValue(value: RulesetRulesActionParametersFromValue): void;
    resetFromValue(): void;
    get fromValueInput(): cdktn.IResolvable | RulesetRulesActionParametersFromValue | undefined;
    private _headers;
    get headers(): RulesetRulesActionParametersHeadersMap;
    putHeaders(value: {
        [key: string]: RulesetRulesActionParametersHeaders;
    } | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | {
        [key: string]: RulesetRulesActionParametersHeaders;
    } | undefined;
    private _hostHeader?;
    get hostHeader(): string;
    set hostHeader(value: string);
    resetHostHeader(): void;
    get hostHeaderInput(): string | undefined;
    private _hotlinkProtection?;
    get hotlinkProtection(): boolean | cdktn.IResolvable;
    set hotlinkProtection(value: boolean | cdktn.IResolvable);
    resetHotlinkProtection(): void;
    get hotlinkProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _immutable;
    get immutable(): RulesetRulesActionParametersImmutableOutputReference;
    putImmutable(value: RulesetRulesActionParametersImmutable): void;
    resetImmutable(): void;
    get immutableInput(): cdktn.IResolvable | RulesetRulesActionParametersImmutable | undefined;
    private _increment?;
    get increment(): number;
    set increment(value: number);
    resetIncrement(): void;
    get incrementInput(): number | undefined;
    private _matchedData;
    get matchedData(): RulesetRulesActionParametersMatchedDataOutputReference;
    putMatchedData(value: RulesetRulesActionParametersMatchedData): void;
    resetMatchedData(): void;
    get matchedDataInput(): cdktn.IResolvable | RulesetRulesActionParametersMatchedData | undefined;
    private _maxAge;
    get maxAge(): RulesetRulesActionParametersMaxAgeOutputReference;
    putMaxAge(value: RulesetRulesActionParametersMaxAge): void;
    resetMaxAge(): void;
    get maxAgeInput(): cdktn.IResolvable | RulesetRulesActionParametersMaxAge | undefined;
    private _mirage?;
    get mirage(): boolean | cdktn.IResolvable;
    set mirage(value: boolean | cdktn.IResolvable);
    resetMirage(): void;
    get mirageInput(): boolean | cdktn.IResolvable | undefined;
    private _mustRevalidate;
    get mustRevalidate(): RulesetRulesActionParametersMustRevalidateOutputReference;
    putMustRevalidate(value: RulesetRulesActionParametersMustRevalidate): void;
    resetMustRevalidate(): void;
    get mustRevalidateInput(): cdktn.IResolvable | RulesetRulesActionParametersMustRevalidate | undefined;
    private _mustUnderstand;
    get mustUnderstand(): RulesetRulesActionParametersMustUnderstandOutputReference;
    putMustUnderstand(value: RulesetRulesActionParametersMustUnderstand): void;
    resetMustUnderstand(): void;
    get mustUnderstandInput(): cdktn.IResolvable | RulesetRulesActionParametersMustUnderstand | undefined;
    private _noCache;
    get noCache(): RulesetRulesActionParametersNoCacheOutputReference;
    putNoCache(value: RulesetRulesActionParametersNoCache): void;
    resetNoCache(): void;
    get noCacheInput(): cdktn.IResolvable | RulesetRulesActionParametersNoCache | undefined;
    private _noStore;
    get noStore(): RulesetRulesActionParametersNoStoreOutputReference;
    putNoStore(value: RulesetRulesActionParametersNoStore): void;
    resetNoStore(): void;
    get noStoreInput(): cdktn.IResolvable | RulesetRulesActionParametersNoStore | undefined;
    private _noTransform;
    get noTransform(): RulesetRulesActionParametersNoTransformOutputReference;
    putNoTransform(value: RulesetRulesActionParametersNoTransform): void;
    resetNoTransform(): void;
    get noTransformInput(): cdktn.IResolvable | RulesetRulesActionParametersNoTransform | undefined;
    private _operation?;
    get operation(): string;
    set operation(value: string);
    resetOperation(): void;
    get operationInput(): string | undefined;
    private _opportunisticEncryption?;
    get opportunisticEncryption(): boolean | cdktn.IResolvable;
    set opportunisticEncryption(value: boolean | cdktn.IResolvable);
    resetOpportunisticEncryption(): void;
    get opportunisticEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _origin;
    get origin(): RulesetRulesActionParametersOriginOutputReference;
    putOrigin(value: RulesetRulesActionParametersOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | RulesetRulesActionParametersOrigin | undefined;
    private _originCacheControl?;
    get originCacheControl(): boolean | cdktn.IResolvable;
    set originCacheControl(value: boolean | cdktn.IResolvable);
    resetOriginCacheControl(): void;
    get originCacheControlInput(): boolean | cdktn.IResolvable | undefined;
    private _originErrorPagePassthru?;
    get originErrorPagePassthru(): boolean | cdktn.IResolvable;
    set originErrorPagePassthru(value: boolean | cdktn.IResolvable);
    resetOriginErrorPagePassthru(): void;
    get originErrorPagePassthruInput(): boolean | cdktn.IResolvable | undefined;
    private _overrides;
    get overrides(): RulesetRulesActionParametersOverridesOutputReference;
    putOverrides(value: RulesetRulesActionParametersOverrides): void;
    resetOverrides(): void;
    get overridesInput(): cdktn.IResolvable | RulesetRulesActionParametersOverrides | undefined;
    private _phases?;
    get phases(): string[];
    set phases(value: string[]);
    resetPhases(): void;
    get phasesInput(): string[] | undefined;
    private _polish?;
    get polish(): string;
    set polish(value: string);
    resetPolish(): void;
    get polishInput(): string | undefined;
    private _private;
    get private(): RulesetRulesActionParametersPrivateOutputReference;
    putPrivate(value: RulesetRulesActionParametersPrivate): void;
    resetPrivate(): void;
    get privateInput(): cdktn.IResolvable | RulesetRulesActionParametersPrivate | undefined;
    private _products?;
    get products(): string[];
    set products(value: string[]);
    resetProducts(): void;
    get productsInput(): string[] | undefined;
    private _proxyRevalidate;
    get proxyRevalidate(): RulesetRulesActionParametersProxyRevalidateOutputReference;
    putProxyRevalidate(value: RulesetRulesActionParametersProxyRevalidate): void;
    resetProxyRevalidate(): void;
    get proxyRevalidateInput(): cdktn.IResolvable | RulesetRulesActionParametersProxyRevalidate | undefined;
    private _public;
    get public(): RulesetRulesActionParametersPublicOutputReference;
    putPublic(value: RulesetRulesActionParametersPublic): void;
    resetPublic(): void;
    get publicInput(): cdktn.IResolvable | RulesetRulesActionParametersPublic | undefined;
    private _rawResponseFields;
    get rawResponseFields(): RulesetRulesActionParametersRawResponseFieldsList;
    putRawResponseFields(value: RulesetRulesActionParametersRawResponseFields[] | cdktn.IResolvable): void;
    resetRawResponseFields(): void;
    get rawResponseFieldsInput(): cdktn.IResolvable | RulesetRulesActionParametersRawResponseFields[] | undefined;
    private _readTimeout?;
    get readTimeout(): number;
    set readTimeout(value: number);
    resetReadTimeout(): void;
    get readTimeoutInput(): number | undefined;
    private _requestBodyBuffering?;
    get requestBodyBuffering(): string;
    set requestBodyBuffering(value: string);
    resetRequestBodyBuffering(): void;
    get requestBodyBufferingInput(): string | undefined;
    private _requestFields;
    get requestFields(): RulesetRulesActionParametersRequestFieldsList;
    putRequestFields(value: RulesetRulesActionParametersRequestFields[] | cdktn.IResolvable): void;
    resetRequestFields(): void;
    get requestFieldsInput(): cdktn.IResolvable | RulesetRulesActionParametersRequestFields[] | undefined;
    private _respectStrongEtags?;
    get respectStrongEtags(): boolean | cdktn.IResolvable;
    set respectStrongEtags(value: boolean | cdktn.IResolvable);
    resetRespectStrongEtags(): void;
    get respectStrongEtagsInput(): boolean | cdktn.IResolvable | undefined;
    private _response;
    get response(): RulesetRulesActionParametersResponseOutputReference;
    putResponse(value: RulesetRulesActionParametersResponse): void;
    resetResponse(): void;
    get responseInput(): cdktn.IResolvable | RulesetRulesActionParametersResponse | undefined;
    private _responseBodyBuffering?;
    get responseBodyBuffering(): string;
    set responseBodyBuffering(value: string);
    resetResponseBodyBuffering(): void;
    get responseBodyBufferingInput(): string | undefined;
    private _responseFields;
    get responseFields(): RulesetRulesActionParametersResponseFieldsList;
    putResponseFields(value: RulesetRulesActionParametersResponseFields[] | cdktn.IResolvable): void;
    resetResponseFields(): void;
    get responseFieldsInput(): cdktn.IResolvable | RulesetRulesActionParametersResponseFields[] | undefined;
    private _rocketLoader?;
    get rocketLoader(): boolean | cdktn.IResolvable;
    set rocketLoader(value: boolean | cdktn.IResolvable);
    resetRocketLoader(): void;
    get rocketLoaderInput(): boolean | cdktn.IResolvable | undefined;
    private _rules?;
    get rules(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set rules(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _ruleset?;
    get ruleset(): string;
    set ruleset(value: string);
    resetRuleset(): void;
    get rulesetInput(): string | undefined;
    private _rulesets?;
    get rulesets(): string[];
    set rulesets(value: string[]);
    resetRulesets(): void;
    get rulesetsInput(): string[] | undefined;
    private _sMaxage;
    get sMaxage(): RulesetRulesActionParametersSMaxageOutputReference;
    putSMaxage(value: RulesetRulesActionParametersSMaxage): void;
    resetSMaxage(): void;
    get sMaxageInput(): cdktn.IResolvable | RulesetRulesActionParametersSMaxage | undefined;
    private _securityLevel?;
    get securityLevel(): string;
    set securityLevel(value: string);
    resetSecurityLevel(): void;
    get securityLevelInput(): string | undefined;
    private _serveStale;
    get serveStale(): RulesetRulesActionParametersServeStaleOutputReference;
    putServeStale(value: RulesetRulesActionParametersServeStale): void;
    resetServeStale(): void;
    get serveStaleInput(): cdktn.IResolvable | RulesetRulesActionParametersServeStale | undefined;
    private _serverSideExcludes?;
    get serverSideExcludes(): boolean | cdktn.IResolvable;
    set serverSideExcludes(value: boolean | cdktn.IResolvable);
    resetServerSideExcludes(): void;
    get serverSideExcludesInput(): boolean | cdktn.IResolvable | undefined;
    private _sni;
    get sni(): RulesetRulesActionParametersSniOutputReference;
    putSni(value: RulesetRulesActionParametersSni): void;
    resetSni(): void;
    get sniInput(): cdktn.IResolvable | RulesetRulesActionParametersSni | undefined;
    private _ssl?;
    get ssl(): string;
    set ssl(value: string);
    resetSsl(): void;
    get sslInput(): string | undefined;
    private _staleIfError;
    get staleIfError(): RulesetRulesActionParametersStaleIfErrorOutputReference;
    putStaleIfError(value: RulesetRulesActionParametersStaleIfError): void;
    resetStaleIfError(): void;
    get staleIfErrorInput(): cdktn.IResolvable | RulesetRulesActionParametersStaleIfError | undefined;
    private _staleWhileRevalidate;
    get staleWhileRevalidate(): RulesetRulesActionParametersStaleWhileRevalidateOutputReference;
    putStaleWhileRevalidate(value: RulesetRulesActionParametersStaleWhileRevalidate): void;
    resetStaleWhileRevalidate(): void;
    get staleWhileRevalidateInput(): cdktn.IResolvable | RulesetRulesActionParametersStaleWhileRevalidate | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    resetStatusCode(): void;
    get statusCodeInput(): number | undefined;
    private _stripEtags?;
    get stripEtags(): boolean | cdktn.IResolvable;
    set stripEtags(value: boolean | cdktn.IResolvable);
    resetStripEtags(): void;
    get stripEtagsInput(): boolean | cdktn.IResolvable | undefined;
    private _stripLastModified?;
    get stripLastModified(): boolean | cdktn.IResolvable;
    set stripLastModified(value: boolean | cdktn.IResolvable);
    resetStripLastModified(): void;
    get stripLastModifiedInput(): boolean | cdktn.IResolvable | undefined;
    private _stripSetCookie?;
    get stripSetCookie(): boolean | cdktn.IResolvable;
    set stripSetCookie(value: boolean | cdktn.IResolvable);
    resetStripSetCookie(): void;
    get stripSetCookieInput(): boolean | cdktn.IResolvable | undefined;
    private _sxg?;
    get sxg(): boolean | cdktn.IResolvable;
    set sxg(value: boolean | cdktn.IResolvable);
    resetSxg(): void;
    get sxgInput(): boolean | cdktn.IResolvable | undefined;
    private _transformedRequestFields;
    get transformedRequestFields(): RulesetRulesActionParametersTransformedRequestFieldsList;
    putTransformedRequestFields(value: RulesetRulesActionParametersTransformedRequestFields[] | cdktn.IResolvable): void;
    resetTransformedRequestFields(): void;
    get transformedRequestFieldsInput(): cdktn.IResolvable | RulesetRulesActionParametersTransformedRequestFields[] | undefined;
    private _uri;
    get uri(): RulesetRulesActionParametersUriOutputReference;
    putUri(value: RulesetRulesActionParametersUri): void;
    resetUri(): void;
    get uriInput(): cdktn.IResolvable | RulesetRulesActionParametersUri | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface RulesetRulesExposedCredentialCheck {
    /**
    * An expression that selects the password used in the credentials check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#password_expression Ruleset#password_expression}
    */
    readonly passwordExpression: string;
    /**
    * An expression that selects the user ID used in the credentials check.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#username_expression Ruleset#username_expression}
    */
    readonly usernameExpression: string;
}
export declare function rulesetRulesExposedCredentialCheckToTerraform(struct?: RulesetRulesExposedCredentialCheck | cdktn.IResolvable): any;
export declare function rulesetRulesExposedCredentialCheckToHclTerraform(struct?: RulesetRulesExposedCredentialCheck | cdktn.IResolvable): any;
export declare class RulesetRulesExposedCredentialCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesExposedCredentialCheck | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesExposedCredentialCheck | cdktn.IResolvable | undefined);
    private _passwordExpression?;
    get passwordExpression(): string;
    set passwordExpression(value: string);
    get passwordExpressionInput(): string | undefined;
    private _usernameExpression?;
    get usernameExpression(): string;
    set usernameExpression(value: string);
    get usernameExpressionInput(): string | undefined;
}
export interface RulesetRulesLogging {
    /**
    * Whether to generate a log when the rule matches.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function rulesetRulesLoggingToTerraform(struct?: RulesetRulesLogging | cdktn.IResolvable): any;
export declare function rulesetRulesLoggingToHclTerraform(struct?: RulesetRulesLogging | cdktn.IResolvable): any;
export declare class RulesetRulesLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesLogging | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesLogging | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface RulesetRulesRatelimit {
    /**
    * Characteristics of the request on which the rate limit counter will be incremented.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#characteristics Ruleset#characteristics}
    */
    readonly characteristics: string[];
    /**
    * An expression that defines when the rate limit counter should be incremented. It defaults to the same as the rule's expression.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#counting_expression Ruleset#counting_expression}
    */
    readonly countingExpression?: string;
    /**
    * Period of time in seconds after which the action will be disabled following its first execution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#mitigation_timeout Ruleset#mitigation_timeout}
    */
    readonly mitigationTimeout?: number;
    /**
    * Period in seconds over which the counter is being incremented.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#period Ruleset#period}
    */
    readonly period: number;
    /**
    * The threshold of requests per period after which the action will be executed for the first time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#requests_per_period Ruleset#requests_per_period}
    */
    readonly requestsPerPeriod?: number;
    /**
    * Whether counting is only performed when an origin is reached.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#requests_to_origin Ruleset#requests_to_origin}
    */
    readonly requestsToOrigin?: boolean | cdktn.IResolvable;
    /**
    * The score threshold per period for which the action will be executed the first time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#score_per_period Ruleset#score_per_period}
    */
    readonly scorePerPeriod?: number;
    /**
    * A response header name provided by the origin, which contains the score to increment rate limit counter with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#score_response_header_name Ruleset#score_response_header_name}
    */
    readonly scoreResponseHeaderName?: string;
}
export declare function rulesetRulesRatelimitToTerraform(struct?: RulesetRulesRatelimit | cdktn.IResolvable): any;
export declare function rulesetRulesRatelimitToHclTerraform(struct?: RulesetRulesRatelimit | cdktn.IResolvable): any;
export declare class RulesetRulesRatelimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RulesetRulesRatelimit | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRulesRatelimit | cdktn.IResolvable | undefined);
    private _characteristics?;
    get characteristics(): string[];
    set characteristics(value: string[]);
    get characteristicsInput(): string[] | undefined;
    private _countingExpression?;
    get countingExpression(): string;
    set countingExpression(value: string);
    resetCountingExpression(): void;
    get countingExpressionInput(): string | undefined;
    private _mitigationTimeout?;
    get mitigationTimeout(): number;
    set mitigationTimeout(value: number);
    resetMitigationTimeout(): void;
    get mitigationTimeoutInput(): number | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    get periodInput(): number | undefined;
    private _requestsPerPeriod?;
    get requestsPerPeriod(): number;
    set requestsPerPeriod(value: number);
    resetRequestsPerPeriod(): void;
    get requestsPerPeriodInput(): number | undefined;
    private _requestsToOrigin?;
    get requestsToOrigin(): boolean | cdktn.IResolvable;
    set requestsToOrigin(value: boolean | cdktn.IResolvable);
    resetRequestsToOrigin(): void;
    get requestsToOriginInput(): boolean | cdktn.IResolvable | undefined;
    private _scorePerPeriod?;
    get scorePerPeriod(): number;
    set scorePerPeriod(value: number);
    resetScorePerPeriod(): void;
    get scorePerPeriodInput(): number | undefined;
    private _scoreResponseHeaderName?;
    get scoreResponseHeaderName(): string;
    set scoreResponseHeaderName(value: string);
    resetScoreResponseHeaderName(): void;
    get scoreResponseHeaderNameInput(): string | undefined;
}
export interface RulesetRules {
    /**
    * The action to perform when the rule matches.
    * Available values: "block", "challenge", "compress_response", "ddos_dynamic", "execute", "force_connection_close", "js_challenge", "log", "log_custom_field", "managed_challenge", "redirect", "rewrite", "route", "score", "serve_error", "set_cache_control", "set_cache_settings", "set_cache_tags", "set_config", "skip".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#action Ruleset#action}
    */
    readonly action: string;
    /**
    * The parameters configuring the rule's action.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#action_parameters Ruleset#action_parameters}
    */
    readonly actionParameters?: RulesetRulesActionParameters;
    /**
    * An informative description of the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#description Ruleset#description}
    */
    readonly description?: string;
    /**
    * Whether the rule should be executed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#enabled Ruleset#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Configuration for exposed credential checking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#exposed_credential_check Ruleset#exposed_credential_check}
    */
    readonly exposedCredentialCheck?: RulesetRulesExposedCredentialCheck;
    /**
    * The expression defining which traffic will match the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#expression Ruleset#expression}
    */
    readonly expression: string;
    /**
    * An object configuring the rule's logging behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#logging Ruleset#logging}
    */
    readonly logging?: RulesetRulesLogging;
    /**
    * An object configuring the rule's rate limit behavior.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#ratelimit Ruleset#ratelimit}
    */
    readonly ratelimit?: RulesetRulesRatelimit;
    /**
    * The reference of the rule (the rule's ID by default).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#ref Ruleset#ref}
    */
    readonly ref?: string;
}
export declare function rulesetRulesToTerraform(struct?: RulesetRules | cdktn.IResolvable): any;
export declare function rulesetRulesToHclTerraform(struct?: RulesetRules | cdktn.IResolvable): any;
export declare class RulesetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RulesetRules | cdktn.IResolvable | undefined;
    set internalValue(value: RulesetRules | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _actionParameters;
    get actionParameters(): RulesetRulesActionParametersOutputReference;
    putActionParameters(value: RulesetRulesActionParameters): void;
    resetActionParameters(): void;
    get actionParametersInput(): cdktn.IResolvable | RulesetRulesActionParameters | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exposedCredentialCheck;
    get exposedCredentialCheck(): RulesetRulesExposedCredentialCheckOutputReference;
    putExposedCredentialCheck(value: RulesetRulesExposedCredentialCheck): void;
    resetExposedCredentialCheck(): void;
    get exposedCredentialCheckInput(): cdktn.IResolvable | RulesetRulesExposedCredentialCheck | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    get id(): string;
    private _logging;
    get logging(): RulesetRulesLoggingOutputReference;
    putLogging(value: RulesetRulesLogging): void;
    resetLogging(): void;
    get loggingInput(): cdktn.IResolvable | RulesetRulesLogging | undefined;
    private _ratelimit;
    get ratelimit(): RulesetRulesRatelimitOutputReference;
    putRatelimit(value: RulesetRulesRatelimit): void;
    resetRatelimit(): void;
    get ratelimitInput(): cdktn.IResolvable | RulesetRulesRatelimit | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
}
export declare class RulesetRulesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: RulesetRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RulesetRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset cloudflare_ruleset}
*/
export declare class Ruleset extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ruleset";
    /**
    * Generates CDKTN code for importing a Ruleset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Ruleset to import
    * @param importFromId The id of the existing Ruleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Ruleset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/ruleset cloudflare_ruleset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RulesetConfig
    */
    constructor(scope: Construct, id: string, config: RulesetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    get lastUpdated(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _phase?;
    get phase(): string;
    set phase(value: string);
    get phaseInput(): string | undefined;
    private _rules;
    get rules(): RulesetRulesList;
    putRules(value: RulesetRules[] | cdktn.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktn.IResolvable | RulesetRules[] | undefined;
    get version(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
