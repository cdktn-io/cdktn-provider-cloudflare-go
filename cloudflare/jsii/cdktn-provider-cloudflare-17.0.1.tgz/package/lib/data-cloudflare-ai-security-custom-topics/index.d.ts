/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAiSecurityCustomTopicsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Defines the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/ai_security_custom_topics#zone_id DataCloudflareAiSecurityCustomTopics#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflareAiSecurityCustomTopicsTopics {
}
export declare function dataCloudflareAiSecurityCustomTopicsTopicsToTerraform(struct?: DataCloudflareAiSecurityCustomTopicsTopics): any;
export declare function dataCloudflareAiSecurityCustomTopicsTopicsToHclTerraform(struct?: DataCloudflareAiSecurityCustomTopicsTopics): any;
export declare class DataCloudflareAiSecurityCustomTopicsTopicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiSecurityCustomTopicsTopics | undefined;
    set internalValue(value: DataCloudflareAiSecurityCustomTopicsTopics | undefined);
    get label(): string;
    get topic(): string;
}
export declare class DataCloudflareAiSecurityCustomTopicsTopicsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiSecurityCustomTopicsTopicsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/ai_security_custom_topics cloudflare_ai_security_custom_topics}
*/
export declare class DataCloudflareAiSecurityCustomTopics extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ai_security_custom_topics";
    /**
    * Generates CDKTN code for importing a DataCloudflareAiSecurityCustomTopics resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAiSecurityCustomTopics to import
    * @param importFromId The id of the existing DataCloudflareAiSecurityCustomTopics that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/ai_security_custom_topics#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAiSecurityCustomTopics to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/ai_security_custom_topics cloudflare_ai_security_custom_topics} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAiSecurityCustomTopicsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareAiSecurityCustomTopicsConfig);
    get id(): string;
    private _topics;
    get topics(): DataCloudflareAiSecurityCustomTopicsTopicsList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
