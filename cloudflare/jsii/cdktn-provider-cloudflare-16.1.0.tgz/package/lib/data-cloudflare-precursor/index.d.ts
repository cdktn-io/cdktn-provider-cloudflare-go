/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflarePrecursorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/precursor#zone_id DataCloudflarePrecursor#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflarePrecursorEnforcementRules {
}
export declare function dataCloudflarePrecursorEnforcementRulesToTerraform(struct?: DataCloudflarePrecursorEnforcementRules): any;
export declare function dataCloudflarePrecursorEnforcementRulesToHclTerraform(struct?: DataCloudflarePrecursorEnforcementRules): any;
export declare class DataCloudflarePrecursorEnforcementRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePrecursorEnforcementRules | undefined;
    set internalValue(value: DataCloudflarePrecursorEnforcementRules | undefined);
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expression(): string;
    get id(): string;
    get mode(): string;
}
export declare class DataCloudflarePrecursorEnforcementRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePrecursorEnforcementRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/precursor cloudflare_precursor}
*/
export declare class DataCloudflarePrecursor extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_precursor";
    /**
    * Generates CDKTN code for importing a DataCloudflarePrecursor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflarePrecursor to import
    * @param importFromId The id of the existing DataCloudflarePrecursor that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/precursor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflarePrecursor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/precursor cloudflare_precursor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflarePrecursorConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflarePrecursorConfig);
    get defaultMode(): string;
    private _enforcementRules;
    get enforcementRules(): DataCloudflarePrecursorEnforcementRulesList;
    get id(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
