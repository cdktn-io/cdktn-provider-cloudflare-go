/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpPredefinedEntriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_predefined_entries#account_id DataCloudflareZeroTrustDlpPredefinedEntries#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_predefined_entries#max_items DataCloudflareZeroTrustDlpPredefinedEntries#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDlpPredefinedEntriesResultConfidence {
}
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResultConfidence): any;
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResultConfidence): any;
export declare class DataCloudflareZeroTrustDlpPredefinedEntriesResultConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedEntriesResultConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedEntriesResultConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpPredefinedEntriesResultPattern {
}
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultPatternToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResultPattern): any;
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResultPattern): any;
export declare class DataCloudflareZeroTrustDlpPredefinedEntriesResultPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedEntriesResultPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedEntriesResultPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpPredefinedEntriesResultVariant {
}
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultVariantToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResultVariant): any;
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResultVariant): any;
export declare class DataCloudflareZeroTrustDlpPredefinedEntriesResultVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedEntriesResultVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedEntriesResultVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
export interface DataCloudflareZeroTrustDlpPredefinedEntriesResult {
}
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResult): any;
export declare function dataCloudflareZeroTrustDlpPredefinedEntriesResultToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedEntriesResult): any;
export declare class DataCloudflareZeroTrustDlpPredefinedEntriesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedEntriesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedEntriesResult | undefined);
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpPredefinedEntriesResultConfidenceOutputReference;
    get createdAt(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpPredefinedEntriesResultPatternOutputReference;
    get profileId(): string;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    get uploadStatus(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpPredefinedEntriesResultVariantOutputReference;
    get wordList(): string;
}
export declare class DataCloudflareZeroTrustDlpPredefinedEntriesResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpPredefinedEntriesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_predefined_entries cloudflare_zero_trust_dlp_predefined_entries}
*/
export declare class DataCloudflareZeroTrustDlpPredefinedEntries extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_predefined_entries";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpPredefinedEntries resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpPredefinedEntries to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpPredefinedEntries that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_predefined_entries#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpPredefinedEntries to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_predefined_entries cloudflare_zero_trust_dlp_predefined_entries} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpPredefinedEntriesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpPredefinedEntriesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDlpPredefinedEntriesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
