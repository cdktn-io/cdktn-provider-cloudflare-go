/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareArgoSmartRoutingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the zone associated with the API call.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/argo_smart_routing#zone_id DataCloudflareArgoSmartRouting#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/argo_smart_routing cloudflare_argo_smart_routing}
*/
export declare class DataCloudflareArgoSmartRouting extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_argo_smart_routing";
    /**
    * Generates CDKTN code for importing a DataCloudflareArgoSmartRouting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareArgoSmartRouting to import
    * @param importFromId The id of the existing DataCloudflareArgoSmartRouting that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/argo_smart_routing#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareArgoSmartRouting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/argo_smart_routing cloudflare_argo_smart_routing} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareArgoSmartRoutingConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareArgoSmartRoutingConfig);
    get editable(): cdktn.IResolvable;
    get id(): string;
    get modifiedOn(): string;
    get value(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
