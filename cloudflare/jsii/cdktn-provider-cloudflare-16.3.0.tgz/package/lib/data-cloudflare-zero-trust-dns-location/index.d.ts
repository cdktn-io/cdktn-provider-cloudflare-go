/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDnsLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#account_id DataCloudflareZeroTrustDnsLocation#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#filter DataCloudflareZeroTrustDnsLocation#filter}
    */
    readonly filter?: DataCloudflareZeroTrustDnsLocationFilter;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#location_id DataCloudflareZeroTrustDnsLocation#location_id}
    */
    readonly locationId?: string;
}
export interface DataCloudflareZeroTrustDnsLocationEndpointsDohNetworks {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDohNetworksToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDohNetworks): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDohNetworksToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDohNetworks): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsDohNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpointsDohNetworks | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpointsDohNetworks | undefined);
    get network(): string;
}
export declare class DataCloudflareZeroTrustDnsLocationEndpointsDohNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDnsLocationEndpointsDohNetworksOutputReference;
}
export interface DataCloudflareZeroTrustDnsLocationEndpointsDoh {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDohToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDoh): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDohToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDoh): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsDohOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpointsDoh | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpointsDoh | undefined);
    get enabled(): cdktn.IResolvable;
    private _networks;
    get networks(): DataCloudflareZeroTrustDnsLocationEndpointsDohNetworksList;
    get requireToken(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDnsLocationEndpointsDotNetworks {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDotNetworksToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDotNetworks): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDotNetworksToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDotNetworks): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsDotNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpointsDotNetworks | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpointsDotNetworks | undefined);
    get network(): string;
}
export declare class DataCloudflareZeroTrustDnsLocationEndpointsDotNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDnsLocationEndpointsDotNetworksOutputReference;
}
export interface DataCloudflareZeroTrustDnsLocationEndpointsDot {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDotToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDot): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsDotToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsDot): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsDotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpointsDot | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpointsDot | undefined);
    get enabled(): cdktn.IResolvable;
    private _networks;
    get networks(): DataCloudflareZeroTrustDnsLocationEndpointsDotNetworksList;
}
export interface DataCloudflareZeroTrustDnsLocationEndpointsIpv4 {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsIpv4ToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsIpv4): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsIpv4ToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsIpv4): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsIpv4OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpointsIpv4 | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpointsIpv4 | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDnsLocationEndpointsIpv6Networks {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsIpv6NetworksToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsIpv6Networks): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsIpv6NetworksToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsIpv6Networks): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsIpv6NetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpointsIpv6Networks | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpointsIpv6Networks | undefined);
    get network(): string;
}
export declare class DataCloudflareZeroTrustDnsLocationEndpointsIpv6NetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDnsLocationEndpointsIpv6NetworksOutputReference;
}
export interface DataCloudflareZeroTrustDnsLocationEndpointsIpv6 {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsIpv6ToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsIpv6): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsIpv6ToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpointsIpv6): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsIpv6OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpointsIpv6 | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpointsIpv6 | undefined);
    get enabled(): cdktn.IResolvable;
    private _networks;
    get networks(): DataCloudflareZeroTrustDnsLocationEndpointsIpv6NetworksList;
}
export interface DataCloudflareZeroTrustDnsLocationEndpoints {
}
export declare function dataCloudflareZeroTrustDnsLocationEndpointsToTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpoints): any;
export declare function dataCloudflareZeroTrustDnsLocationEndpointsToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationEndpoints): any;
export declare class DataCloudflareZeroTrustDnsLocationEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDnsLocationEndpoints | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationEndpoints | undefined);
    private _doh;
    get doh(): DataCloudflareZeroTrustDnsLocationEndpointsDohOutputReference;
    private _dot;
    get dot(): DataCloudflareZeroTrustDnsLocationEndpointsDotOutputReference;
    private _ipv4;
    get ipv4(): DataCloudflareZeroTrustDnsLocationEndpointsIpv4OutputReference;
    private _ipv6;
    get ipv6(): DataCloudflareZeroTrustDnsLocationEndpointsIpv6OutputReference;
}
export interface DataCloudflareZeroTrustDnsLocationFilter {
    /**
    * Sort direction. Only takes effect when `order_by` is also provided; it
    * is ignored otherwise. When `direction` is omitted the effective
    * direction is field-specific: `created_at` and `updated_at` default to
    * descending (newest first); `name` defaults to ascending.
    *   * `asc` — ascending.
    *   * `desc` — descending.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#direction DataCloudflareZeroTrustDnsLocation#direction}
    */
    readonly direction?: string;
    /**
    * Filter the returned locations by one or more `field:value` pairs.
    * Repeat the parameter to apply multiple filters; they are combined with
    * logical AND (a location must satisfy every filter to be returned).
    *
    * Supported fields and their matching behaviour:
    *   * `name` — case-insensitive substring match on the location name.
    *   * `id` — substring match on the location ID (UUID), with or without dashes.
    *   * `is_default` — whether it is the default for the account.
    *
    * Each entry must match one of the per-field patterns below:
    *   * the field must be one of `name`, `id`, or `is_default`;
    *   * `name`/`id` accept any value;
    *   * `is_default` only accepts `true` or `false`; any other value returns `400`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#filter DataCloudflareZeroTrustDnsLocation#filter}
    */
    readonly filter?: string[];
    /**
    * Field to sort the returned locations by. When omitted, the order of
    * results is unspecified. Supported values:
    *   * `name` — sort alphabetically by location name.
    *   * `created_at` — sort by creation time; defaults to descending unless `direction` is set.
    *   * `updated_at` — sort by last-modified time; defaults to descending unless `direction` is set.
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#order_by DataCloudflareZeroTrustDnsLocation#order_by}
    */
    readonly orderBy?: string;
    /**
    * Case-insensitive substring match on the location name. When combined
    * with `filter`, both must match (logical AND).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#search DataCloudflareZeroTrustDnsLocation#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareZeroTrustDnsLocationFilterToTerraform(struct?: DataCloudflareZeroTrustDnsLocationFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustDnsLocationFilterToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustDnsLocationFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDnsLocationFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _filter?;
    get filter(): string[];
    set filter(value: string[]);
    resetFilter(): void;
    get filterInput(): string[] | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
export interface DataCloudflareZeroTrustDnsLocationMaxTtl {
}
export declare function dataCloudflareZeroTrustDnsLocationMaxTtlToTerraform(struct?: DataCloudflareZeroTrustDnsLocationMaxTtl): any;
export declare function dataCloudflareZeroTrustDnsLocationMaxTtlToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationMaxTtl): any;
export declare class DataCloudflareZeroTrustDnsLocationMaxTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDnsLocationMaxTtl | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationMaxTtl | undefined);
    get mode(): string;
    get ttlSecs(): number;
}
export interface DataCloudflareZeroTrustDnsLocationNetworks {
}
export declare function dataCloudflareZeroTrustDnsLocationNetworksToTerraform(struct?: DataCloudflareZeroTrustDnsLocationNetworks): any;
export declare function dataCloudflareZeroTrustDnsLocationNetworksToHclTerraform(struct?: DataCloudflareZeroTrustDnsLocationNetworks): any;
export declare class DataCloudflareZeroTrustDnsLocationNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDnsLocationNetworks | undefined;
    set internalValue(value: DataCloudflareZeroTrustDnsLocationNetworks | undefined);
    get network(): string;
}
export declare class DataCloudflareZeroTrustDnsLocationNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDnsLocationNetworksOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location cloudflare_zero_trust_dns_location}
*/
export declare class DataCloudflareZeroTrustDnsLocation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dns_location";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDnsLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDnsLocation to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDnsLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDnsLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_dns_location cloudflare_zero_trust_dns_location} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDnsLocationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustDnsLocationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get clientDefault(): cdktn.IResolvable;
    get createdAt(): string;
    get dnsDestinationIpsId(): string;
    get dnsDestinationIpv6BlockId(): string;
    get dohSubdomain(): string;
    get ecsSupport(): cdktn.IResolvable;
    private _endpoints;
    get endpoints(): DataCloudflareZeroTrustDnsLocationEndpointsOutputReference;
    private _filter;
    get filter(): DataCloudflareZeroTrustDnsLocationFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustDnsLocationFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustDnsLocationFilter | undefined;
    get id(): string;
    get ip(): string;
    get ipv4Destination(): string;
    get ipv4DestinationBackup(): string;
    private _locationId?;
    get locationId(): string;
    set locationId(value: string);
    resetLocationId(): void;
    get locationIdInput(): string | undefined;
    private _maxTtl;
    get maxTtl(): DataCloudflareZeroTrustDnsLocationMaxTtlOutputReference;
    get name(): string;
    private _networks;
    get networks(): DataCloudflareZeroTrustDnsLocationNetworksList;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
