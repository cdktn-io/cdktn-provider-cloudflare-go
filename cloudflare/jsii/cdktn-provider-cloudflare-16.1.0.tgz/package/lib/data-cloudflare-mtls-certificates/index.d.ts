/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMtlsCertificatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/mtls_certificates#account_id DataCloudflareMtlsCertificates#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/mtls_certificates#max_items DataCloudflareMtlsCertificates#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareMtlsCertificatesResult {
}
export declare function dataCloudflareMtlsCertificatesResultToTerraform(struct?: DataCloudflareMtlsCertificatesResult): any;
export declare function dataCloudflareMtlsCertificatesResultToHclTerraform(struct?: DataCloudflareMtlsCertificatesResult): any;
export declare class DataCloudflareMtlsCertificatesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMtlsCertificatesResult | undefined;
    set internalValue(value: DataCloudflareMtlsCertificatesResult | undefined);
    get ca(): cdktn.IResolvable;
    get certificates(): string;
    get expiresOn(): string;
    get id(): string;
    get issuer(): string;
    get name(): string;
    get serialNumber(): string;
    get signature(): string;
    get uploadedOn(): string;
}
export declare class DataCloudflareMtlsCertificatesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMtlsCertificatesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/mtls_certificates cloudflare_mtls_certificates}
*/
export declare class DataCloudflareMtlsCertificates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_mtls_certificates";
    /**
    * Generates CDKTN code for importing a DataCloudflareMtlsCertificates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMtlsCertificates to import
    * @param importFromId The id of the existing DataCloudflareMtlsCertificates that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/mtls_certificates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMtlsCertificates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/mtls_certificates cloudflare_mtls_certificates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMtlsCertificatesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMtlsCertificatesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareMtlsCertificatesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
