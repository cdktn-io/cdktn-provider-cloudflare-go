/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustResourceLibraryApplicationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#account_id DataCloudflareZeroTrustResourceLibraryApplications#account_id}
    */
    readonly accountId: string;
    /**
    * Return only the listed properties on each application, as a comma-separated list.
    * Use this to keep responses small when you only need part of each application, for
    * example populating a picker with `fields=id,name` instead of downloading every
    * hostname and IP subnet.
    *
    * Omit this parameter to receive the full application object, including
    * when lookup is used.
    *
    * `id` is always returned.
    *
    * Selectable properties: `id`, `name`, `human_id`, `version`, `hostnames`,
    * `support_domains`, `ip_subnets`, `port_protocols`, `supported`, `gen_ai_score`,
    * `application_confidence_score`, `created_at`, `updated_at`, `review_status`.
    *
    * Unknown or empty property names return `400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#fields DataCloudflareZeroTrustResourceLibraryApplications#fields}
    */
    readonly fields?: string;
    /**
    * Filter applications using `key:value` format. Supported filter keys:
    * - `name`: application name (for example, `name:HR`).
    * - `id`: application ID (for example, `id:498`).
    * - `human_id`: human-readable ID (for example, `human_id:HR`).
    * - `hostname`: hostname or support domain (for example, `hostname:portal.example.com`).
    * - `source`: application source name (for example, `source:cloudflare`).
    * - `ip_subnet`: CIDR containment; returns applications where a stored subnet contains the search value (for example, `ip_subnet:10.0.1.5/32` matches `10.0.0.0/16`).
    * - `category_id`: category ID (for example, `category_id:12`).
    * - `category_name`: category name (for example, `category_name:HR`).
    * - `supported`: supported Cloudflare product. Values: `GATEWAY`, `ACCESS`, `CASB`.
    * - `review_status`: account-specific Gateway review status. Values: `approved`, `unapproved`, `in_review`, `unreviewed`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#filter DataCloudflareZeroTrustResourceLibraryApplications#filter}
    */
    readonly filter?: string;
    /**
    * Number of results to return. Defaults to 25; values are clamped to 1–250.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#limit DataCloudflareZeroTrustResourceLibraryApplications#limit}
    */
    readonly limit?: number;
    /**
    * Find complete, case-insensitive application name mentions in a phrase or
    * rule sentence. Misspelled names do not match. Returns matching applications
    * ranked by relevance. Must be between 2 and 1000 characters. Uses the same
    * filters, fields, and pagination as listing. `search` cannot be combined
    * with lookup. Results are ranked by relevance, so `order_by` is ignored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#lookup DataCloudflareZeroTrustResourceLibraryApplications#lookup}
    */
    readonly lookup?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#max_items DataCloudflareZeroTrustResourceLibraryApplications#max_items}
    */
    readonly maxItems?: number;
    /**
    * Number of results to skip. Defaults to 0; negative values are clamped to 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#offset DataCloudflareZeroTrustResourceLibraryApplications#offset}
    */
    readonly offset?: number;
    /**
    * Order results using field:direction format. Supported fields are name, id, human_id,
    * category_id, application_type, application_confidence_score, and gen_ai_score.
    * Supported directions are asc and desc. Ignored when search is provided; results are
    * ranked by relevance instead. Also ignored when lookup is provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#order_by DataCloudflareZeroTrustResourceLibraryApplications#order_by}
    */
    readonly orderBy?: string;
    /**
    * Fuzzy search across application name and hostnames. Results are ranked by relevance. Must be between 2 and 200 characters. Can be combined with filter parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#search DataCloudflareZeroTrustResourceLibraryApplications#search}
    */
    readonly search?: string;
}
export interface DataCloudflareZeroTrustResourceLibraryApplicationsResult {
}
export declare function dataCloudflareZeroTrustResourceLibraryApplicationsResultToTerraform(struct?: DataCloudflareZeroTrustResourceLibraryApplicationsResult): any;
export declare function dataCloudflareZeroTrustResourceLibraryApplicationsResultToHclTerraform(struct?: DataCloudflareZeroTrustResourceLibraryApplicationsResult): any;
export declare class DataCloudflareZeroTrustResourceLibraryApplicationsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustResourceLibraryApplicationsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustResourceLibraryApplicationsResult | undefined);
    get applicationConfidenceScore(): number;
    get applicationScoreComposition(): string;
    get applicationSource(): string;
    get applicationType(): string;
    get applicationTypeDescription(): string;
    get categoryId(): number;
    get createdAt(): string;
    get genAiScore(): number;
    get hostnames(): string[];
    get humanId(): string;
    get id(): number;
    get ipSubnets(): string[];
    get name(): string;
    get portProtocols(): string[];
    get reviewStatus(): string;
    get supportDomains(): string[];
    get supported(): string[];
    get updatedAt(): string;
    get version(): string;
}
export declare class DataCloudflareZeroTrustResourceLibraryApplicationsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustResourceLibraryApplicationsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications cloudflare_zero_trust_resource_library_applications}
*/
export declare class DataCloudflareZeroTrustResourceLibraryApplications extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_resource_library_applications";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustResourceLibraryApplications resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustResourceLibraryApplications to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustResourceLibraryApplications that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustResourceLibraryApplications to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.28.1/docs/data-sources/zero_trust_resource_library_applications cloudflare_zero_trust_resource_library_applications} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustResourceLibraryApplicationsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustResourceLibraryApplicationsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _fields?;
    get fields(): string;
    set fields(value: string);
    resetFields(): void;
    get fieldsInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _lookup?;
    get lookup(): string;
    set lookup(value: string);
    resetLookup(): void;
    get lookupInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _offset?;
    get offset(): number;
    set offset(value: number);
    resetOffset(): void;
    get offsetInput(): number | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustResourceLibraryApplicationsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
