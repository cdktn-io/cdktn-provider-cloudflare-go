/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCustomHostnameConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#custom_hostname_id DataCloudflareCustomHostname#custom_hostname_id}
    */
    readonly customHostnameId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#filter DataCloudflareCustomHostname#filter}
    */
    readonly filter?: DataCloudflareCustomHostnameFilter;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#zone_id DataCloudflareCustomHostname#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareCustomHostnameFilterHostname {
    /**
    * Filters hostnames by a substring match on the hostname value. This parameter cannot be used with the 'id', 'hostname', 'hostname.exact', or 'hostname.startsWith' parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#contain DataCloudflareCustomHostname#contain}
    */
    readonly contain?: string;
    /**
    * Fully qualified domain name to match against. This parameter cannot be used with the 'id', 'hostname', 'hostname.contain', or 'hostname.startsWith' parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#exact DataCloudflareCustomHostname#exact}
    */
    readonly exact?: string;
    /**
    * Filters hostnames by a prefix match on the hostname value. This parameter cannot be used with the 'id', 'hostname', 'hostname.exact', or 'hostname.contain' parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#starts_with DataCloudflareCustomHostname#starts_with}
    */
    readonly startsWith?: string;
}
export declare function dataCloudflareCustomHostnameFilterHostnameToTerraform(struct?: DataCloudflareCustomHostnameFilterHostname | cdktn.IResolvable): any;
export declare function dataCloudflareCustomHostnameFilterHostnameToHclTerraform(struct?: DataCloudflareCustomHostnameFilterHostname | cdktn.IResolvable): any;
export declare class DataCloudflareCustomHostnameFilterHostnameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomHostnameFilterHostname | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareCustomHostnameFilterHostname | cdktn.IResolvable | undefined);
    private _contain?;
    get contain(): string;
    set contain(value: string);
    resetContain(): void;
    get containInput(): string | undefined;
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _startsWith?;
    get startsWith(): string;
    set startsWith(value: string);
    resetStartsWith(): void;
    get startsWithInput(): string | undefined;
}
export interface DataCloudflareCustomHostnameFilter {
    /**
    * Filter by the certificate authority that issued the SSL certificate.
    * Available values: "google", "lets_encrypt", "ssl_com".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#certificate_authority DataCloudflareCustomHostname#certificate_authority}
    */
    readonly certificateAuthority?: string;
    /**
    * Filter by custom origin server name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#custom_origin_server DataCloudflareCustomHostname#custom_origin_server}
    */
    readonly customOriginServer?: string;
    /**
    * Direction to order hostnames.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#direction DataCloudflareCustomHostname#direction}
    */
    readonly direction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#hostname DataCloudflareCustomHostname#hostname}
    */
    readonly hostname?: DataCloudflareCustomHostnameFilterHostname;
    /**
    * Filter by the hostname's activation status.
    * Available values: "active", "pending", "active_redeploying", "moved", "pending_deletion", "deleted", "pending_blocked", "pending_migration", "pending_provisioned", "test_pending", "test_active", "test_active_apex", "test_blocked", "test_failed", "provisioned", "blocked".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#hostname_status DataCloudflareCustomHostname#hostname_status}
    */
    readonly hostnameStatus?: string;
    /**
    * Hostname ID to match against. This ID was generated and returned during the initial custom_hostname creation. This parameter cannot be used with the 'hostname', 'hostname.exact', 'hostname.contain', or 'hostname.startsWith' parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#id DataCloudflareCustomHostname#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Field to order hostnames by.
    * Available values: "ssl", "ssl_status".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#order DataCloudflareCustomHostname#order}
    */
    readonly order?: string;
    /**
    * Whether to filter hostnames based on if they have SSL enabled.
    * Available values: 0, 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#ssl DataCloudflareCustomHostname#ssl}
    */
    readonly ssl?: number;
    /**
    * Filter by SSL certificate status.
    * Available values: "initializing", "pending_validation", "deleted", "pending_issuance", "pending_deployment", "pending_deletion", "pending_expiration", "expired", "active", "initializing_timed_out", "validation_timed_out", "issuance_timed_out", "deployment_timed_out", "deletion_timed_out", "pending_cleanup", "staging_deployment", "staging_active", "deactivating", "inactive", "backup_issued", "holding_deployment".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#ssl_status DataCloudflareCustomHostname#ssl_status}
    */
    readonly sslStatus?: string;
    /**
    * Filter by whether the custom hostname is a wildcard hostname.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#wildcard DataCloudflareCustomHostname#wildcard}
    */
    readonly wildcard?: boolean | cdktn.IResolvable;
}
export declare function dataCloudflareCustomHostnameFilterToTerraform(struct?: DataCloudflareCustomHostnameFilter | cdktn.IResolvable): any;
export declare function dataCloudflareCustomHostnameFilterToHclTerraform(struct?: DataCloudflareCustomHostnameFilter | cdktn.IResolvable): any;
export declare class DataCloudflareCustomHostnameFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomHostnameFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareCustomHostnameFilter | cdktn.IResolvable | undefined);
    private _certificateAuthority?;
    get certificateAuthority(): string;
    set certificateAuthority(value: string);
    resetCertificateAuthority(): void;
    get certificateAuthorityInput(): string | undefined;
    private _customOriginServer?;
    get customOriginServer(): string;
    set customOriginServer(value: string);
    resetCustomOriginServer(): void;
    get customOriginServerInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _hostname;
    get hostname(): DataCloudflareCustomHostnameFilterHostnameOutputReference;
    putHostname(value: DataCloudflareCustomHostnameFilterHostname): void;
    resetHostname(): void;
    get hostnameInput(): cdktn.IResolvable | DataCloudflareCustomHostnameFilterHostname | undefined;
    private _hostnameStatus?;
    get hostnameStatus(): string;
    set hostnameStatus(value: string);
    resetHostnameStatus(): void;
    get hostnameStatusInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _ssl?;
    get ssl(): number;
    set ssl(value: number);
    resetSsl(): void;
    get sslInput(): number | undefined;
    private _sslStatus?;
    get sslStatus(): string;
    set sslStatus(value: string);
    resetSslStatus(): void;
    get sslStatusInput(): string | undefined;
    private _wildcard?;
    get wildcard(): boolean | cdktn.IResolvable;
    set wildcard(value: boolean | cdktn.IResolvable);
    resetWildcard(): void;
    get wildcardInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataCloudflareCustomHostnameOwnershipVerification {
}
export declare function dataCloudflareCustomHostnameOwnershipVerificationToTerraform(struct?: DataCloudflareCustomHostnameOwnershipVerification): any;
export declare function dataCloudflareCustomHostnameOwnershipVerificationToHclTerraform(struct?: DataCloudflareCustomHostnameOwnershipVerification): any;
export declare class DataCloudflareCustomHostnameOwnershipVerificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomHostnameOwnershipVerification | undefined;
    set internalValue(value: DataCloudflareCustomHostnameOwnershipVerification | undefined);
    get name(): string;
    get type(): string;
    get value(): string;
}
export interface DataCloudflareCustomHostnameOwnershipVerificationHttp {
}
export declare function dataCloudflareCustomHostnameOwnershipVerificationHttpToTerraform(struct?: DataCloudflareCustomHostnameOwnershipVerificationHttp): any;
export declare function dataCloudflareCustomHostnameOwnershipVerificationHttpToHclTerraform(struct?: DataCloudflareCustomHostnameOwnershipVerificationHttp): any;
export declare class DataCloudflareCustomHostnameOwnershipVerificationHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomHostnameOwnershipVerificationHttp | undefined;
    set internalValue(value: DataCloudflareCustomHostnameOwnershipVerificationHttp | undefined);
    get httpBody(): string;
    get httpUrl(): string;
}
export interface DataCloudflareCustomHostnameSslDcvDelegationRecords {
}
export declare function dataCloudflareCustomHostnameSslDcvDelegationRecordsToTerraform(struct?: DataCloudflareCustomHostnameSslDcvDelegationRecords): any;
export declare function dataCloudflareCustomHostnameSslDcvDelegationRecordsToHclTerraform(struct?: DataCloudflareCustomHostnameSslDcvDelegationRecords): any;
export declare class DataCloudflareCustomHostnameSslDcvDelegationRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCustomHostnameSslDcvDelegationRecords | undefined;
    set internalValue(value: DataCloudflareCustomHostnameSslDcvDelegationRecords | undefined);
    get cname(): string;
    get cnameTarget(): string;
    get emails(): string[];
    get httpBody(): string;
    get httpUrl(): string;
    get status(): string;
    get txtName(): string;
    get txtValue(): string;
}
export declare class DataCloudflareCustomHostnameSslDcvDelegationRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCustomHostnameSslDcvDelegationRecordsOutputReference;
}
export interface DataCloudflareCustomHostnameSslSettings {
}
export declare function dataCloudflareCustomHostnameSslSettingsToTerraform(struct?: DataCloudflareCustomHostnameSslSettings): any;
export declare function dataCloudflareCustomHostnameSslSettingsToHclTerraform(struct?: DataCloudflareCustomHostnameSslSettings): any;
export declare class DataCloudflareCustomHostnameSslSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomHostnameSslSettings | undefined;
    set internalValue(value: DataCloudflareCustomHostnameSslSettings | undefined);
    get ciphers(): string[];
    get earlyHints(): string;
    get http2(): string;
    get minTlsVersion(): string;
    get tls13(): string;
}
export interface DataCloudflareCustomHostnameSslValidationErrors {
}
export declare function dataCloudflareCustomHostnameSslValidationErrorsToTerraform(struct?: DataCloudflareCustomHostnameSslValidationErrors): any;
export declare function dataCloudflareCustomHostnameSslValidationErrorsToHclTerraform(struct?: DataCloudflareCustomHostnameSslValidationErrors): any;
export declare class DataCloudflareCustomHostnameSslValidationErrorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCustomHostnameSslValidationErrors | undefined;
    set internalValue(value: DataCloudflareCustomHostnameSslValidationErrors | undefined);
    get message(): string;
}
export declare class DataCloudflareCustomHostnameSslValidationErrorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCustomHostnameSslValidationErrorsOutputReference;
}
export interface DataCloudflareCustomHostnameSslValidationRecords {
}
export declare function dataCloudflareCustomHostnameSslValidationRecordsToTerraform(struct?: DataCloudflareCustomHostnameSslValidationRecords): any;
export declare function dataCloudflareCustomHostnameSslValidationRecordsToHclTerraform(struct?: DataCloudflareCustomHostnameSslValidationRecords): any;
export declare class DataCloudflareCustomHostnameSslValidationRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCustomHostnameSslValidationRecords | undefined;
    set internalValue(value: DataCloudflareCustomHostnameSslValidationRecords | undefined);
    get cname(): string;
    get cnameTarget(): string;
    get emails(): string[];
    get httpBody(): string;
    get httpUrl(): string;
    get status(): string;
    get txtName(): string;
    get txtValue(): string;
}
export declare class DataCloudflareCustomHostnameSslValidationRecordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCustomHostnameSslValidationRecordsOutputReference;
}
export interface DataCloudflareCustomHostnameSsl {
}
export declare function dataCloudflareCustomHostnameSslToTerraform(struct?: DataCloudflareCustomHostnameSsl): any;
export declare function dataCloudflareCustomHostnameSslToHclTerraform(struct?: DataCloudflareCustomHostnameSsl): any;
export declare class DataCloudflareCustomHostnameSslOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomHostnameSsl | undefined;
    set internalValue(value: DataCloudflareCustomHostnameSsl | undefined);
    get bundleMethod(): string;
    get certificateAuthority(): string;
    get customCertificate(): string;
    get customCsrId(): string;
    get customKey(): string;
    private _dcvDelegationRecords;
    get dcvDelegationRecords(): DataCloudflareCustomHostnameSslDcvDelegationRecordsList;
    get expiresOn(): string;
    get hosts(): string[];
    get id(): string;
    get issuer(): string;
    get method(): string;
    get serialNumber(): string;
    private _settings;
    get settings(): DataCloudflareCustomHostnameSslSettingsOutputReference;
    get signature(): string;
    get status(): string;
    get type(): string;
    get uploadedOn(): string;
    private _validationErrors;
    get validationErrors(): DataCloudflareCustomHostnameSslValidationErrorsList;
    private _validationRecords;
    get validationRecords(): DataCloudflareCustomHostnameSslValidationRecordsList;
    get wildcard(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname cloudflare_custom_hostname}
*/
export declare class DataCloudflareCustomHostname extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_custom_hostname";
    /**
    * Generates CDKTN code for importing a DataCloudflareCustomHostname resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCustomHostname to import
    * @param importFromId The id of the existing DataCloudflareCustomHostname that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCustomHostname to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/custom_hostname cloudflare_custom_hostname} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCustomHostnameConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareCustomHostnameConfig);
    get createdAt(): string;
    private _customHostnameId?;
    get customHostnameId(): string;
    set customHostnameId(value: string);
    resetCustomHostnameId(): void;
    get customHostnameIdInput(): string | undefined;
    private _customMetadata;
    get customMetadata(): cdktn.StringMap;
    get customOriginServer(): string;
    get customOriginSni(): string;
    private _filter;
    get filter(): DataCloudflareCustomHostnameFilterOutputReference;
    putFilter(value: DataCloudflareCustomHostnameFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareCustomHostnameFilter | undefined;
    get hostname(): string;
    get id(): string;
    private _ownershipVerification;
    get ownershipVerification(): DataCloudflareCustomHostnameOwnershipVerificationOutputReference;
    private _ownershipVerificationHttp;
    get ownershipVerificationHttp(): DataCloudflareCustomHostnameOwnershipVerificationHttpOutputReference;
    private _ssl;
    get ssl(): DataCloudflareCustomHostnameSslOutputReference;
    get status(): string;
    get verificationErrors(): string[];
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
