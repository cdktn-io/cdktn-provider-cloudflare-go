/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSchemaValidationOperationSettingsListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/schema_validation_operation_settings_list#max_items DataCloudflareSchemaValidationOperationSettingsList#max_items}
    */
    readonly maxItems?: number;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/schema_validation_operation_settings_list#zone_id DataCloudflareSchemaValidationOperationSettingsList#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareSchemaValidationOperationSettingsListResult {
}
export declare function dataCloudflareSchemaValidationOperationSettingsListResultToTerraform(struct?: DataCloudflareSchemaValidationOperationSettingsListResult): any;
export declare function dataCloudflareSchemaValidationOperationSettingsListResultToHclTerraform(struct?: DataCloudflareSchemaValidationOperationSettingsListResult): any;
export declare class DataCloudflareSchemaValidationOperationSettingsListResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareSchemaValidationOperationSettingsListResult | undefined;
    set internalValue(value: DataCloudflareSchemaValidationOperationSettingsListResult | undefined);
    get mitigationAction(): string;
    get operationId(): string;
}
export declare class DataCloudflareSchemaValidationOperationSettingsListResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareSchemaValidationOperationSettingsListResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/schema_validation_operation_settings_list cloudflare_schema_validation_operation_settings_list}
*/
export declare class DataCloudflareSchemaValidationOperationSettingsList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_schema_validation_operation_settings_list";
    /**
    * Generates CDKTN code for importing a DataCloudflareSchemaValidationOperationSettingsList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSchemaValidationOperationSettingsList to import
    * @param importFromId The id of the existing DataCloudflareSchemaValidationOperationSettingsList that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/schema_validation_operation_settings_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSchemaValidationOperationSettingsList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/schema_validation_operation_settings_list cloudflare_schema_validation_operation_settings_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSchemaValidationOperationSettingsListConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareSchemaValidationOperationSettingsListConfig);
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareSchemaValidationOperationSettingsListResultList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
