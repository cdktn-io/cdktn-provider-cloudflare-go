/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDeviceCustomProfilesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_device_custom_profiles#account_id DataCloudflareZeroTrustDeviceCustomProfiles#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_device_custom_profiles#max_items DataCloudflareZeroTrustDeviceCustomProfiles#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter profiles by client type. When omitted, only WARP profiles are returned.
    * Available values: "warp", "browser_extension".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_device_custom_profiles#profile_type DataCloudflareZeroTrustDeviceCustomProfiles#profile_type}
    */
    readonly profileType?: string;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfig {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfigToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfig): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfigToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfig): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfig | undefined);
    get proxyControl(): string;
    get proxyEnabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixes {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixesToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixes): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixesToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixes): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixes | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixes | undefined);
    get description(): string;
    get suffix(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixesOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultExclude {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultExcludeToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultExclude): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultExcludeToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultExclude): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultExclude | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultExclude | undefined);
    get address(): string;
    get description(): string;
    get host(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultExcludeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfilesResultExcludeOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomains {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomainsToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomains): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomainsToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomains): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomains | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomains | undefined);
    get description(): string;
    get dnsServer(): string[];
    get suffix(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomainsOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultInclude {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultIncludeToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultInclude): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultIncludeToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultInclude): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultInclude | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultInclude | undefined);
    get address(): string;
    get description(): string;
    get host(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultIncludeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfilesResultIncludeOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2 {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2ToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2ToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2 | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2 | undefined);
    get mode(): string;
    get port(): number;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTests {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultTargetTestsToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTests): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultTargetTestsToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTests): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTests | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTests | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTestsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTestsOutputReference;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworks {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworksToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworks): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworksToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworks): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworks | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworks | undefined);
    get allowed(): string[];
    get default(): string;
}
export interface DataCloudflareZeroTrustDeviceCustomProfilesResult {
}
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultToTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResult): any;
export declare function dataCloudflareZeroTrustDeviceCustomProfilesResultToHclTerraform(struct?: DataCloudflareZeroTrustDeviceCustomProfilesResult): any;
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceCustomProfilesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceCustomProfilesResult | undefined);
    get allowModeSwitch(): cdktn.IResolvable;
    get allowUpdates(): cdktn.IResolvable;
    get allowedToLeave(): cdktn.IResolvable;
    get autoConnect(): number;
    private _browserExtensionConfig;
    get browserExtensionConfig(): DataCloudflareZeroTrustDeviceCustomProfilesResultBrowserExtensionConfigOutputReference;
    get captivePortal(): number;
    get default(): cdktn.IResolvable;
    get description(): string;
    get disableAutoFallback(): cdktn.IResolvable;
    private _dnsSearchSuffixes;
    get dnsSearchSuffixes(): DataCloudflareZeroTrustDeviceCustomProfilesResultDnsSearchSuffixesList;
    get enabled(): cdktn.IResolvable;
    private _exclude;
    get exclude(): DataCloudflareZeroTrustDeviceCustomProfilesResultExcludeList;
    get excludeOfficeIps(): cdktn.IResolvable;
    private _fallbackDomains;
    get fallbackDomains(): DataCloudflareZeroTrustDeviceCustomProfilesResultFallbackDomainsList;
    get gatewayUniqueId(): string;
    get id(): string;
    private _include;
    get include(): DataCloudflareZeroTrustDeviceCustomProfilesResultIncludeList;
    get lanAllowMinutes(): number;
    get lanAllowSubnetSize(): number;
    get match(): string;
    get name(): string;
    get policyId(): string;
    get precedence(): number;
    get profileType(): string;
    get registerInterfaceIpWithDns(): cdktn.IResolvable;
    get sccmVpnBoundarySupport(): cdktn.IResolvable;
    private _serviceModeV2;
    get serviceModeV2(): DataCloudflareZeroTrustDeviceCustomProfilesResultServiceModeV2OutputReference;
    get supportUrl(): string;
    get switchLocked(): cdktn.IResolvable;
    private _targetTests;
    get targetTests(): DataCloudflareZeroTrustDeviceCustomProfilesResultTargetTestsList;
    get tunnelProtocol(): string;
    get uninstallProtection(): cdktn.IResolvable;
    private _virtualNetworks;
    get virtualNetworks(): DataCloudflareZeroTrustDeviceCustomProfilesResultVirtualNetworksOutputReference;
}
export declare class DataCloudflareZeroTrustDeviceCustomProfilesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceCustomProfilesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_device_custom_profiles cloudflare_zero_trust_device_custom_profiles}
*/
export declare class DataCloudflareZeroTrustDeviceCustomProfiles extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_custom_profiles";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDeviceCustomProfiles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDeviceCustomProfiles to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDeviceCustomProfiles that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_device_custom_profiles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDeviceCustomProfiles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_device_custom_profiles cloudflare_zero_trust_device_custom_profiles} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDeviceCustomProfilesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustDeviceCustomProfilesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _profileType?;
    get profileType(): string;
    set profileType(value: string);
    resetProfileType(): void;
    get profileTypeInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDeviceCustomProfilesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
