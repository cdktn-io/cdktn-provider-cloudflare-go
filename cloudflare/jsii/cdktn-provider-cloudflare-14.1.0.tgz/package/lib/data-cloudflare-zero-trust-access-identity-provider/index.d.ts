/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustAccessIdentityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider#account_id DataCloudflareZeroTrustAccessIdentityProvider#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider#filter DataCloudflareZeroTrustAccessIdentityProvider#filter}
    */
    readonly filter?: DataCloudflareZeroTrustAccessIdentityProviderFilter;
    /**
    * UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider#identity_provider_id DataCloudflareZeroTrustAccessIdentityProvider#identity_provider_id}
    */
    readonly identityProviderId?: string;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider#zone_id DataCloudflareZeroTrustAccessIdentityProvider#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributes {
}
export declare function dataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributesToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributes): any;
export declare function dataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributesToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributes): any;
export declare class DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributes | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributes | undefined);
    get attributeName(): string;
    get headerName(): string;
}
export declare class DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributesOutputReference;
}
export interface DataCloudflareZeroTrustAccessIdentityProviderConfigA {
}
export declare function dataCloudflareZeroTrustAccessIdentityProviderConfigAToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderConfigA): any;
export declare function dataCloudflareZeroTrustAccessIdentityProviderConfigAToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderConfigA): any;
export declare class DataCloudflareZeroTrustAccessIdentityProviderConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProviderConfigA | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProviderConfigA | undefined);
    get appsDomain(): string;
    get attributes(): string[];
    get authUrl(): string;
    get authorizationServerId(): string;
    get centrifyAccount(): string;
    get centrifyAppId(): string;
    get certsUrl(): string;
    get claims(): string[];
    get clientId(): string;
    get clientSecret(): string;
    get conditionalAccessEnabled(): cdktn.IResolvable;
    get directoryId(): string;
    get emailAttributeName(): string;
    get emailClaimName(): string;
    private _headerAttributes;
    get headerAttributes(): DataCloudflareZeroTrustAccessIdentityProviderConfigHeaderAttributesList;
    get idpPublicCerts(): string[];
    get issuerUrl(): string;
    get oktaAccount(): string;
    get oneloginAccount(): string;
    get pingEnvId(): string;
    get pkceEnabled(): cdktn.IResolvable;
    get prompt(): string;
    get redirectUrl(): string;
    get scopes(): string[];
    get signRequest(): cdktn.IResolvable;
    get ssoTargetUrl(): string;
    get supportGroups(): cdktn.IResolvable;
    get tokenUrl(): string;
}
export interface DataCloudflareZeroTrustAccessIdentityProviderFilter {
    /**
    * Indicates to Access to only retrieve identity providers that have the System for Cross-Domain Identity Management (SCIM) enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider#scim_enabled DataCloudflareZeroTrustAccessIdentityProvider#scim_enabled}
    */
    readonly scimEnabled?: string;
}
export declare function dataCloudflareZeroTrustAccessIdentityProviderFilterToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustAccessIdentityProviderFilterToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustAccessIdentityProviderFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProviderFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProviderFilter | cdktn.IResolvable | undefined);
    private _scimEnabled?;
    get scimEnabled(): string;
    set scimEnabled(value: string);
    resetScimEnabled(): void;
    get scimEnabledInput(): string | undefined;
}
export interface DataCloudflareZeroTrustAccessIdentityProviderScimConfig {
}
export declare function dataCloudflareZeroTrustAccessIdentityProviderScimConfigToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderScimConfig): any;
export declare function dataCloudflareZeroTrustAccessIdentityProviderScimConfigToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProviderScimConfig): any;
export declare class DataCloudflareZeroTrustAccessIdentityProviderScimConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProviderScimConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProviderScimConfig | undefined);
    get enabled(): cdktn.IResolvable;
    get identityUpdateBehavior(): string;
    get scimBaseUrl(): string;
    get seatDeprovision(): cdktn.IResolvable;
    get secret(): string;
    get userDeprovision(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider cloudflare_zero_trust_access_identity_provider}
*/
export declare class DataCloudflareZeroTrustAccessIdentityProvider extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_access_identity_provider";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustAccessIdentityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustAccessIdentityProvider to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustAccessIdentityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustAccessIdentityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_access_identity_provider cloudflare_zero_trust_access_identity_provider} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustAccessIdentityProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustAccessIdentityProviderConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _config;
    get config(): DataCloudflareZeroTrustAccessIdentityProviderConfigAOutputReference;
    private _filter;
    get filter(): DataCloudflareZeroTrustAccessIdentityProviderFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustAccessIdentityProviderFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustAccessIdentityProviderFilter | undefined;
    get id(): string;
    private _identityProviderId?;
    get identityProviderId(): string;
    set identityProviderId(value: string);
    resetIdentityProviderId(): void;
    get identityProviderIdInput(): string | undefined;
    get name(): string;
    private _scimConfig;
    get scimConfig(): DataCloudflareZeroTrustAccessIdentityProviderScimConfigOutputReference;
    get type(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
