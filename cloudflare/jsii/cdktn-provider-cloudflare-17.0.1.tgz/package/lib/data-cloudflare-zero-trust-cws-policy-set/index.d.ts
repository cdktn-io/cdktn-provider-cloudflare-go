/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsPolicySetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#account_id DataCloudflareZeroTrustCwsPolicySet#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#filter DataCloudflareZeroTrustCwsPolicySet#filter}
    */
    readonly filter?: DataCloudflareZeroTrustCwsPolicySetFilter;
    /**
    * ID of the policy set to retrieve
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#policy_set_id DataCloudflareZeroTrustCwsPolicySet#policy_set_id}
    */
    readonly policySetId?: string;
}
export interface DataCloudflareZeroTrustCwsPolicySetFilter {
    /**
    * Filter to policy sets attached to this deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#deployment_id DataCloudflareZeroTrustCwsPolicySet#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#direction DataCloudflareZeroTrustCwsPolicySet#direction}
    */
    readonly direction?: string;
    /**
    * Filter by policy set name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#name DataCloudflareZeroTrustCwsPolicySet#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#order DataCloudflareZeroTrustCwsPolicySet#order}
    */
    readonly order?: string;
}
export declare function dataCloudflareZeroTrustCwsPolicySetFilterToTerraform(struct?: DataCloudflareZeroTrustCwsPolicySetFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustCwsPolicySetFilterToHclTerraform(struct?: DataCloudflareZeroTrustCwsPolicySetFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustCwsPolicySetFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCwsPolicySetFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsPolicySetFilter | cdktn.IResolvable | undefined);
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface DataCloudflareZeroTrustCwsPolicySetPolicies {
}
export declare function dataCloudflareZeroTrustCwsPolicySetPoliciesToTerraform(struct?: DataCloudflareZeroTrustCwsPolicySetPolicies): any;
export declare function dataCloudflareZeroTrustCwsPolicySetPoliciesToHclTerraform(struct?: DataCloudflareZeroTrustCwsPolicySetPolicies): any;
export declare class DataCloudflareZeroTrustCwsPolicySetPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCwsPolicySetPolicies | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsPolicySetPolicies | undefined);
    get enforce(): cdktn.IResolvable;
    get policyId(): string;
}
export declare class DataCloudflareZeroTrustCwsPolicySetPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCwsPolicySetPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set cloudflare_zero_trust_cws_policy_set}
*/
export declare class DataCloudflareZeroTrustCwsPolicySet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_policy_set";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsPolicySet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsPolicySet to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsPolicySet that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsPolicySet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_policy_set cloudflare_zero_trust_cws_policy_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsPolicySetConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsPolicySetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get description(): string;
    get excludeWorkloadIds(): string[];
    private _filter;
    get filter(): DataCloudflareZeroTrustCwsPolicySetFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustCwsPolicySetFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustCwsPolicySetFilter | undefined;
    get id(): string;
    get includeWorkloadIds(): string[];
    get name(): string;
    private _policies;
    get policies(): DataCloudflareZeroTrustCwsPolicySetPoliciesList;
    private _policySetId?;
    get policySetId(): string;
    set policySetId(value: string);
    resetPolicySetId(): void;
    get policySetIdInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
