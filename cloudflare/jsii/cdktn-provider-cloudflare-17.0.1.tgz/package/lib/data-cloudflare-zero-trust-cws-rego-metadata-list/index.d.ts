/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsRegoMetadataListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list#account_id DataCloudflareZeroTrustCwsRegoMetadataList#account_id}
    */
    readonly accountId: string;
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list#direction DataCloudflareZeroTrustCwsRegoMetadataList#direction}
    */
    readonly direction?: string;
    /**
    * Filter by import path (case-sensitive literal substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list#import_path DataCloudflareZeroTrustCwsRegoMetadataList#import_path}
    */
    readonly importPath?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list#max_items DataCloudflareZeroTrustCwsRegoMetadataList#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter by rego metadata name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list#name DataCloudflareZeroTrustCwsRegoMetadataList#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list#order DataCloudflareZeroTrustCwsRegoMetadataList#order}
    */
    readonly order?: string;
}
export interface DataCloudflareZeroTrustCwsRegoMetadataListResult {
}
export declare function dataCloudflareZeroTrustCwsRegoMetadataListResultToTerraform(struct?: DataCloudflareZeroTrustCwsRegoMetadataListResult): any;
export declare function dataCloudflareZeroTrustCwsRegoMetadataListResultToHclTerraform(struct?: DataCloudflareZeroTrustCwsRegoMetadataListResult): any;
export declare class DataCloudflareZeroTrustCwsRegoMetadataListResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCwsRegoMetadataListResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsRegoMetadataListResult | undefined);
    get createdAt(): string;
    get data(): string;
    get id(): string;
    get importPath(): string;
    get name(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustCwsRegoMetadataListResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCwsRegoMetadataListResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list cloudflare_zero_trust_cws_rego_metadata_list}
*/
export declare class DataCloudflareZeroTrustCwsRegoMetadataList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_rego_metadata_list";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsRegoMetadataList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsRegoMetadataList to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsRegoMetadataList that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsRegoMetadataList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_rego_metadata_list cloudflare_zero_trust_cws_rego_metadata_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsRegoMetadataListConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsRegoMetadataListConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _importPath?;
    get importPath(): string;
    set importPath(value: string);
    resetImportPath(): void;
    get importPathInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCwsRegoMetadataListResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
