/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicWanIpsecTunnelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_wan_ipsec_tunnel#account_id DataCloudflareMagicWanIpsecTunnel#account_id}
    */
    readonly accountId?: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_wan_ipsec_tunnel#ipsec_tunnel_id DataCloudflareMagicWanIpsecTunnel#ipsec_tunnel_id}
    */
    readonly ipsecTunnelId: string;
}
export interface DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgp {
}
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpToTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgp): any;
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpToHclTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgp): any;
export declare class DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgp | undefined;
    set internalValue(value: DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgp | undefined);
    get customerAsn(): number;
    get extraPrefixes(): string[];
    get md5Key(): string;
}
export interface DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatus {
}
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatusToTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatus): any;
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatusToHclTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatus): any;
export declare class DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatus | undefined;
    set internalValue(value: DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatus | undefined);
    get bgpState(): string;
    get cfSpeakerIp(): string;
    get cfSpeakerPort(): number;
    get customerSpeakerIp(): string;
    get customerSpeakerPort(): number;
    get state(): string;
    get tcpEstablished(): cdktn.IResolvable;
    get updatedAt(): string;
}
export interface DataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentities {
}
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentitiesToTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentities): any;
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentitiesToHclTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentities): any;
export declare class DataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentities | undefined;
    set internalValue(value: DataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentities | undefined);
    get fqdnId(): string;
}
export interface DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTarget {
}
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTargetToTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTarget): any;
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTargetToHclTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTarget): any;
export declare class DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTarget | undefined;
    set internalValue(value: DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTarget | undefined);
    get effective(): string;
    get saved(): string;
}
export interface DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheck {
}
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckToTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheck): any;
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckToHclTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheck): any;
export declare class DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheck | undefined;
    set internalValue(value: DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheck | undefined);
    get direction(): string;
    get enabled(): cdktn.IResolvable;
    get rate(): string;
    private _target;
    get target(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckTargetOutputReference;
    get type(): string;
}
export interface DataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadata {
}
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadataToTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadata): any;
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadataToHclTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadata): any;
export declare class DataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadata | undefined;
    set internalValue(value: DataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadata | undefined);
    get lastGeneratedOn(): string;
}
export interface DataCloudflareMagicWanIpsecTunnelIpsecTunnel {
}
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelToTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnel): any;
export declare function dataCloudflareMagicWanIpsecTunnelIpsecTunnelToHclTerraform(struct?: DataCloudflareMagicWanIpsecTunnelIpsecTunnel): any;
export declare class DataCloudflareMagicWanIpsecTunnelIpsecTunnelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanIpsecTunnelIpsecTunnel | undefined;
    set internalValue(value: DataCloudflareMagicWanIpsecTunnelIpsecTunnel | undefined);
    get allowNullCipher(): cdktn.IResolvable;
    get automaticReturnRouting(): cdktn.IResolvable;
    private _bgp;
    get bgp(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpOutputReference;
    private _bgpStatus;
    get bgpStatus(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelBgpStatusOutputReference;
    get cloudflareEndpoint(): string;
    get createdOn(): string;
    private _customRemoteIdentities;
    get customRemoteIdentities(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelCustomRemoteIdentitiesOutputReference;
    get customerEndpoint(): string;
    get description(): string;
    private _healthCheck;
    get healthCheck(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelHealthCheckOutputReference;
    get id(): string;
    get interfaceAddress(): string;
    get interfaceAddress6(): string;
    get modifiedOn(): string;
    get name(): string;
    private _pskMetadata;
    get pskMetadata(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelPskMetadataOutputReference;
    get replayProtection(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_wan_ipsec_tunnel cloudflare_magic_wan_ipsec_tunnel}
*/
export declare class DataCloudflareMagicWanIpsecTunnel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_wan_ipsec_tunnel";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicWanIpsecTunnel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicWanIpsecTunnel to import
    * @param importFromId The id of the existing DataCloudflareMagicWanIpsecTunnel that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_wan_ipsec_tunnel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicWanIpsecTunnel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_wan_ipsec_tunnel cloudflare_magic_wan_ipsec_tunnel} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicWanIpsecTunnelConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicWanIpsecTunnelConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get id(): string;
    private _ipsecTunnel;
    get ipsecTunnel(): DataCloudflareMagicWanIpsecTunnelIpsecTunnelOutputReference;
    private _ipsecTunnelId?;
    get ipsecTunnelId(): string;
    set ipsecTunnelId(value: string);
    get ipsecTunnelIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
