/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkersScriptsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/workers_scripts#account_id DataCloudflareWorkersScripts#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/workers_scripts#max_items DataCloudflareWorkersScripts#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter scripts by tags. Format: comma-separated list of tag:allowed pairs where allowed is 'yes' or 'no'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/workers_scripts#tags DataCloudflareWorkersScripts#tags}
    */
    readonly tags?: string;
}
export interface DataCloudflareWorkersScriptsResultCacheOptions {
}
export declare function dataCloudflareWorkersScriptsResultCacheOptionsToTerraform(struct?: DataCloudflareWorkersScriptsResultCacheOptions): any;
export declare function dataCloudflareWorkersScriptsResultCacheOptionsToHclTerraform(struct?: DataCloudflareWorkersScriptsResultCacheOptions): any;
export declare class DataCloudflareWorkersScriptsResultCacheOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersScriptsResultCacheOptions | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultCacheOptions | undefined);
    get crossVersionCache(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareWorkersScriptsResultExportsCache {
}
export declare function dataCloudflareWorkersScriptsResultExportsCacheToTerraform(struct?: DataCloudflareWorkersScriptsResultExportsCache): any;
export declare function dataCloudflareWorkersScriptsResultExportsCacheToHclTerraform(struct?: DataCloudflareWorkersScriptsResultExportsCache): any;
export declare class DataCloudflareWorkersScriptsResultExportsCacheOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersScriptsResultExportsCache | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultExportsCache | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareWorkersScriptsResultExports {
}
export declare function dataCloudflareWorkersScriptsResultExportsToTerraform(struct?: DataCloudflareWorkersScriptsResultExports): any;
export declare function dataCloudflareWorkersScriptsResultExportsToHclTerraform(struct?: DataCloudflareWorkersScriptsResultExports): any;
export declare class DataCloudflareWorkersScriptsResultExportsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflareWorkersScriptsResultExports | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultExports | undefined);
    private _cache;
    get cache(): DataCloudflareWorkersScriptsResultExportsCacheOutputReference;
    get renamedTo(): string;
    get state(): string;
    get storage(): string;
    get transferFrom(): string;
    get transferredTo(): string;
    get type(): string;
}
export declare class DataCloudflareWorkersScriptsResultExportsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflareWorkersScriptsResultExportsOutputReference;
}
export interface DataCloudflareWorkersScriptsResultNamedHandlers {
}
export declare function dataCloudflareWorkersScriptsResultNamedHandlersToTerraform(struct?: DataCloudflareWorkersScriptsResultNamedHandlers): any;
export declare function dataCloudflareWorkersScriptsResultNamedHandlersToHclTerraform(struct?: DataCloudflareWorkersScriptsResultNamedHandlers): any;
export declare class DataCloudflareWorkersScriptsResultNamedHandlersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersScriptsResultNamedHandlers | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultNamedHandlers | undefined);
    get handlers(): string[];
    get name(): string;
}
export declare class DataCloudflareWorkersScriptsResultNamedHandlersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersScriptsResultNamedHandlersOutputReference;
}
export interface DataCloudflareWorkersScriptsResultObservabilityLogs {
}
export declare function dataCloudflareWorkersScriptsResultObservabilityLogsToTerraform(struct?: DataCloudflareWorkersScriptsResultObservabilityLogs): any;
export declare function dataCloudflareWorkersScriptsResultObservabilityLogsToHclTerraform(struct?: DataCloudflareWorkersScriptsResultObservabilityLogs): any;
export declare class DataCloudflareWorkersScriptsResultObservabilityLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersScriptsResultObservabilityLogs | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultObservabilityLogs | undefined);
    get destinations(): string[];
    get enabled(): cdktn.IResolvable;
    get headSamplingRate(): number;
    get invocationLogs(): cdktn.IResolvable;
    get persist(): cdktn.IResolvable;
}
export interface DataCloudflareWorkersScriptsResultObservabilityTraces {
}
export declare function dataCloudflareWorkersScriptsResultObservabilityTracesToTerraform(struct?: DataCloudflareWorkersScriptsResultObservabilityTraces): any;
export declare function dataCloudflareWorkersScriptsResultObservabilityTracesToHclTerraform(struct?: DataCloudflareWorkersScriptsResultObservabilityTraces): any;
export declare class DataCloudflareWorkersScriptsResultObservabilityTracesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersScriptsResultObservabilityTraces | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultObservabilityTraces | undefined);
    get destinations(): string[];
    get enabled(): cdktn.IResolvable;
    get headSamplingRate(): number;
    get persist(): cdktn.IResolvable;
    get propagationPolicy(): string;
}
export interface DataCloudflareWorkersScriptsResultObservability {
}
export declare function dataCloudflareWorkersScriptsResultObservabilityToTerraform(struct?: DataCloudflareWorkersScriptsResultObservability): any;
export declare function dataCloudflareWorkersScriptsResultObservabilityToHclTerraform(struct?: DataCloudflareWorkersScriptsResultObservability): any;
export declare class DataCloudflareWorkersScriptsResultObservabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersScriptsResultObservability | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultObservability | undefined);
    get enabled(): cdktn.IResolvable;
    get headSamplingRate(): number;
    private _logs;
    get logs(): DataCloudflareWorkersScriptsResultObservabilityLogsOutputReference;
    private _traces;
    get traces(): DataCloudflareWorkersScriptsResultObservabilityTracesOutputReference;
}
export interface DataCloudflareWorkersScriptsResultPlacementTarget {
}
export declare function dataCloudflareWorkersScriptsResultPlacementTargetToTerraform(struct?: DataCloudflareWorkersScriptsResultPlacementTarget): any;
export declare function dataCloudflareWorkersScriptsResultPlacementTargetToHclTerraform(struct?: DataCloudflareWorkersScriptsResultPlacementTarget): any;
export declare class DataCloudflareWorkersScriptsResultPlacementTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersScriptsResultPlacementTarget | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultPlacementTarget | undefined);
    get host(): string;
    get hostname(): string;
    get region(): string;
}
export declare class DataCloudflareWorkersScriptsResultPlacementTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersScriptsResultPlacementTargetOutputReference;
}
export interface DataCloudflareWorkersScriptsResultPlacement {
}
export declare function dataCloudflareWorkersScriptsResultPlacementToTerraform(struct?: DataCloudflareWorkersScriptsResultPlacement): any;
export declare function dataCloudflareWorkersScriptsResultPlacementToHclTerraform(struct?: DataCloudflareWorkersScriptsResultPlacement): any;
export declare class DataCloudflareWorkersScriptsResultPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersScriptsResultPlacement | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultPlacement | undefined);
    get host(): string;
    get hostname(): string;
    get lastAnalyzedAt(): string;
    get mode(): string;
    get region(): string;
    get status(): string;
    private _target;
    get target(): DataCloudflareWorkersScriptsResultPlacementTargetList;
}
export interface DataCloudflareWorkersScriptsResultRoutes {
}
export declare function dataCloudflareWorkersScriptsResultRoutesToTerraform(struct?: DataCloudflareWorkersScriptsResultRoutes): any;
export declare function dataCloudflareWorkersScriptsResultRoutesToHclTerraform(struct?: DataCloudflareWorkersScriptsResultRoutes): any;
export declare class DataCloudflareWorkersScriptsResultRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersScriptsResultRoutes | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultRoutes | undefined);
    get id(): string;
    get pattern(): string;
    get script(): string;
}
export declare class DataCloudflareWorkersScriptsResultRoutesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersScriptsResultRoutesOutputReference;
}
export interface DataCloudflareWorkersScriptsResultTailConsumers {
}
export declare function dataCloudflareWorkersScriptsResultTailConsumersToTerraform(struct?: DataCloudflareWorkersScriptsResultTailConsumers): any;
export declare function dataCloudflareWorkersScriptsResultTailConsumersToHclTerraform(struct?: DataCloudflareWorkersScriptsResultTailConsumers): any;
export declare class DataCloudflareWorkersScriptsResultTailConsumersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersScriptsResultTailConsumers | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResultTailConsumers | undefined);
    get environment(): string;
    get namespace(): string;
    get service(): string;
}
export declare class DataCloudflareWorkersScriptsResultTailConsumersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersScriptsResultTailConsumersOutputReference;
}
export interface DataCloudflareWorkersScriptsResult {
}
export declare function dataCloudflareWorkersScriptsResultToTerraform(struct?: DataCloudflareWorkersScriptsResult): any;
export declare function dataCloudflareWorkersScriptsResultToHclTerraform(struct?: DataCloudflareWorkersScriptsResult): any;
export declare class DataCloudflareWorkersScriptsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersScriptsResult | undefined;
    set internalValue(value: DataCloudflareWorkersScriptsResult | undefined);
    private _cacheOptions;
    get cacheOptions(): DataCloudflareWorkersScriptsResultCacheOptionsOutputReference;
    get compatibilityDate(): string;
    get compatibilityFlags(): string[];
    get createdOn(): string;
    get etag(): string;
    private _exports;
    get exports(): DataCloudflareWorkersScriptsResultExportsMap;
    get handlers(): string[];
    get hasAssets(): cdktn.IResolvable;
    get hasModules(): cdktn.IResolvable;
    get id(): string;
    get lastDeployedFrom(): string;
    get logpush(): cdktn.IResolvable;
    get migrationTag(): string;
    get modifiedOn(): string;
    private _namedHandlers;
    get namedHandlers(): DataCloudflareWorkersScriptsResultNamedHandlersList;
    private _observability;
    get observability(): DataCloudflareWorkersScriptsResultObservabilityOutputReference;
    private _placement;
    get placement(): DataCloudflareWorkersScriptsResultPlacementOutputReference;
    get placementMode(): string;
    get placementStatus(): string;
    private _routes;
    get routes(): DataCloudflareWorkersScriptsResultRoutesList;
    get tag(): string;
    get tags(): string[];
    private _tailConsumers;
    get tailConsumers(): DataCloudflareWorkersScriptsResultTailConsumersList;
    get usageModel(): string;
}
export declare class DataCloudflareWorkersScriptsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersScriptsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/workers_scripts cloudflare_workers_scripts}
*/
export declare class DataCloudflareWorkersScripts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_workers_scripts";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkersScripts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkersScripts to import
    * @param importFromId The id of the existing DataCloudflareWorkersScripts that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/workers_scripts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkersScripts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/workers_scripts cloudflare_workers_scripts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkersScriptsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWorkersScriptsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareWorkersScriptsResultList;
    private _tags?;
    get tags(): string;
    set tags(value: string);
    resetTags(): void;
    get tagsInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
