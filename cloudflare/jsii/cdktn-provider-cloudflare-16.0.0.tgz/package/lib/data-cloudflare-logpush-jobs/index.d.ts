/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLogpushJobsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/logpush_jobs#account_id DataCloudflareLogpushJobs#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/logpush_jobs#max_items DataCloudflareLogpushJobs#max_items}
    */
    readonly maxItems?: number;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/logpush_jobs#zone_id DataCloudflareLogpushJobs#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareLogpushJobsResultOutputOptions {
}
export declare function dataCloudflareLogpushJobsResultOutputOptionsToTerraform(struct?: DataCloudflareLogpushJobsResultOutputOptions): any;
export declare function dataCloudflareLogpushJobsResultOutputOptionsToHclTerraform(struct?: DataCloudflareLogpushJobsResultOutputOptions): any;
export declare class DataCloudflareLogpushJobsResultOutputOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLogpushJobsResultOutputOptions | undefined;
    set internalValue(value: DataCloudflareLogpushJobsResultOutputOptions | undefined);
    get batchPrefix(): string;
    get batchSuffix(): string;
    get cve202144228(): cdktn.IResolvable;
    get fieldDelimiter(): string;
    get fieldNames(): string[];
    get mergeSubrequests(): cdktn.IResolvable;
    get outputType(): string;
    get recordDelimiter(): string;
    get recordPrefix(): string;
    get recordSuffix(): string;
    get recordTemplate(): string;
    get sampleRate(): number;
    get timestampFormat(): string;
}
export interface DataCloudflareLogpushJobsResult {
}
export declare function dataCloudflareLogpushJobsResultToTerraform(struct?: DataCloudflareLogpushJobsResult): any;
export declare function dataCloudflareLogpushJobsResultToHclTerraform(struct?: DataCloudflareLogpushJobsResult): any;
export declare class DataCloudflareLogpushJobsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLogpushJobsResult | undefined;
    set internalValue(value: DataCloudflareLogpushJobsResult | undefined);
    get dataset(): string;
    get destinationConf(): string;
    get enabled(): cdktn.IResolvable;
    get errorMessage(): string;
    get frequency(): string;
    get id(): number;
    get kind(): string;
    get lastComplete(): string;
    get lastError(): string;
    get logpullOptions(): string;
    get maxUploadBytes(): number;
    get maxUploadIntervalSeconds(): number;
    get maxUploadRecords(): number;
    get name(): string;
    private _outputOptions;
    get outputOptions(): DataCloudflareLogpushJobsResultOutputOptionsOutputReference;
}
export declare class DataCloudflareLogpushJobsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLogpushJobsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/logpush_jobs cloudflare_logpush_jobs}
*/
export declare class DataCloudflareLogpushJobs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_logpush_jobs";
    /**
    * Generates CDKTN code for importing a DataCloudflareLogpushJobs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLogpushJobs to import
    * @param importFromId The id of the existing DataCloudflareLogpushJobs that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/logpush_jobs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLogpushJobs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/logpush_jobs cloudflare_logpush_jobs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLogpushJobsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareLogpushJobsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareLogpushJobsResultList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
