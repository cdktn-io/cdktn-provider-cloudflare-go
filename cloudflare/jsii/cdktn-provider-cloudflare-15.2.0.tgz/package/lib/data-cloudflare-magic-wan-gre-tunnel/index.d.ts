/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicWanGreTunnelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/magic_wan_gre_tunnel#account_id DataCloudflareMagicWanGreTunnel#account_id}
    */
    readonly accountId?: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/magic_wan_gre_tunnel#gre_tunnel_id DataCloudflareMagicWanGreTunnel#gre_tunnel_id}
    */
    readonly greTunnelId: string;
}
export interface DataCloudflareMagicWanGreTunnelGreTunnelBgp {
}
export declare function dataCloudflareMagicWanGreTunnelGreTunnelBgpToTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelBgp): any;
export declare function dataCloudflareMagicWanGreTunnelGreTunnelBgpToHclTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelBgp): any;
export declare class DataCloudflareMagicWanGreTunnelGreTunnelBgpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanGreTunnelGreTunnelBgp | undefined;
    set internalValue(value: DataCloudflareMagicWanGreTunnelGreTunnelBgp | undefined);
    get customerAsn(): number;
    get extraPrefixes(): string[];
    get md5Key(): string;
}
export interface DataCloudflareMagicWanGreTunnelGreTunnelBgpStatus {
}
export declare function dataCloudflareMagicWanGreTunnelGreTunnelBgpStatusToTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelBgpStatus): any;
export declare function dataCloudflareMagicWanGreTunnelGreTunnelBgpStatusToHclTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelBgpStatus): any;
export declare class DataCloudflareMagicWanGreTunnelGreTunnelBgpStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanGreTunnelGreTunnelBgpStatus | undefined;
    set internalValue(value: DataCloudflareMagicWanGreTunnelGreTunnelBgpStatus | undefined);
    get bgpState(): string;
    get cfSpeakerIp(): string;
    get cfSpeakerPort(): number;
    get customerSpeakerIp(): string;
    get customerSpeakerPort(): number;
    get state(): string;
    get tcpEstablished(): cdktn.IResolvable;
    get updatedAt(): string;
}
export interface DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTarget {
}
export declare function dataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTargetToTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTarget): any;
export declare function dataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTargetToHclTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTarget): any;
export declare class DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTarget | undefined;
    set internalValue(value: DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTarget | undefined);
    get effective(): string;
    get saved(): string;
}
export interface DataCloudflareMagicWanGreTunnelGreTunnelHealthCheck {
}
export declare function dataCloudflareMagicWanGreTunnelGreTunnelHealthCheckToTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelHealthCheck): any;
export declare function dataCloudflareMagicWanGreTunnelGreTunnelHealthCheckToHclTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnelHealthCheck): any;
export declare class DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanGreTunnelGreTunnelHealthCheck | undefined;
    set internalValue(value: DataCloudflareMagicWanGreTunnelGreTunnelHealthCheck | undefined);
    get direction(): string;
    get enabled(): cdktn.IResolvable;
    get rate(): string;
    private _target;
    get target(): DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckTargetOutputReference;
    get type(): string;
}
export interface DataCloudflareMagicWanGreTunnelGreTunnel {
}
export declare function dataCloudflareMagicWanGreTunnelGreTunnelToTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnel): any;
export declare function dataCloudflareMagicWanGreTunnelGreTunnelToHclTerraform(struct?: DataCloudflareMagicWanGreTunnelGreTunnel): any;
export declare class DataCloudflareMagicWanGreTunnelGreTunnelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanGreTunnelGreTunnel | undefined;
    set internalValue(value: DataCloudflareMagicWanGreTunnelGreTunnel | undefined);
    get automaticReturnRouting(): cdktn.IResolvable;
    private _bgp;
    get bgp(): DataCloudflareMagicWanGreTunnelGreTunnelBgpOutputReference;
    private _bgpStatus;
    get bgpStatus(): DataCloudflareMagicWanGreTunnelGreTunnelBgpStatusOutputReference;
    get cloudflareGreEndpoint(): string;
    get createdOn(): string;
    get customerGreEndpoint(): string;
    get description(): string;
    private _healthCheck;
    get healthCheck(): DataCloudflareMagicWanGreTunnelGreTunnelHealthCheckOutputReference;
    get id(): string;
    get interfaceAddress(): string;
    get interfaceAddress6(): string;
    get modifiedOn(): string;
    get mtu(): number;
    get name(): string;
    get ttl(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/magic_wan_gre_tunnel cloudflare_magic_wan_gre_tunnel}
*/
export declare class DataCloudflareMagicWanGreTunnel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_wan_gre_tunnel";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicWanGreTunnel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicWanGreTunnel to import
    * @param importFromId The id of the existing DataCloudflareMagicWanGreTunnel that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/magic_wan_gre_tunnel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicWanGreTunnel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/magic_wan_gre_tunnel cloudflare_magic_wan_gre_tunnel} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicWanGreTunnelConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicWanGreTunnelConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _greTunnel;
    get greTunnel(): DataCloudflareMagicWanGreTunnelGreTunnelOutputReference;
    private _greTunnelId?;
    get greTunnelId(): string;
    set greTunnelId(value: string);
    get greTunnelIdInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
