/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustAccessIdentityProvidersConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_access_identity_providers#account_id DataCloudflareZeroTrustAccessIdentityProviders#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_access_identity_providers#max_items DataCloudflareZeroTrustAccessIdentityProviders#max_items}
    */
    readonly maxItems?: number;
    /**
    * Indicates to Access to only retrieve identity providers that have the System for Cross-Domain Identity Management (SCIM) enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_access_identity_providers#scim_enabled DataCloudflareZeroTrustAccessIdentityProviders#scim_enabled}
    */
    readonly scimEnabled?: string;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_access_identity_providers#zone_id DataCloudflareZeroTrustAccessIdentityProviders#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributes {
}
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributesToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributes): any;
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributesToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributes): any;
export declare class DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributes | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributes | undefined);
    get attributeName(): string;
    get headerName(): string;
}
export declare class DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributesOutputReference;
}
export interface DataCloudflareZeroTrustAccessIdentityProvidersResultConfig {
}
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultConfigToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResultConfig): any;
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultConfigToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResultConfig): any;
export declare class DataCloudflareZeroTrustAccessIdentityProvidersResultConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProvidersResultConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProvidersResultConfig | undefined);
    get appsDomain(): string;
    get attributes(): string[];
    get authUrl(): string;
    get authorizationServerId(): string;
    get centrifyAccount(): string;
    get centrifyAppId(): string;
    get certsUrl(): string;
    get claims(): string[];
    get clientId(): string;
    get clientSecret(): string;
    get conditionalAccessEnabled(): cdktn.IResolvable;
    get directoryId(): string;
    get emailAttributeName(): string;
    get emailClaimName(): string;
    private _headerAttributes;
    get headerAttributes(): DataCloudflareZeroTrustAccessIdentityProvidersResultConfigHeaderAttributesList;
    get idpPublicCerts(): string[];
    get issuerUrl(): string;
    get oktaAccount(): string;
    get oneloginAccount(): string;
    get pingEnvId(): string;
    get pkceEnabled(): cdktn.IResolvable;
    get prompt(): string;
    get scopes(): string[];
    get signRequest(): cdktn.IResolvable;
    get ssoTargetUrl(): string;
    get supportGroups(): cdktn.IResolvable;
    get tokenUrl(): string;
}
export interface DataCloudflareZeroTrustAccessIdentityProvidersResultScimConfig {
}
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultScimConfigToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResultScimConfig): any;
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultScimConfigToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResultScimConfig): any;
export declare class DataCloudflareZeroTrustAccessIdentityProvidersResultScimConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProvidersResultScimConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProvidersResultScimConfig | undefined);
    get enabled(): cdktn.IResolvable;
    get identityUpdateBehavior(): string;
    get scimBaseUrl(): string;
    get seatDeprovision(): cdktn.IResolvable;
    get secret(): string;
    get userDeprovision(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustAccessIdentityProvidersResult {
}
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultToTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResult): any;
export declare function dataCloudflareZeroTrustAccessIdentityProvidersResultToHclTerraform(struct?: DataCloudflareZeroTrustAccessIdentityProvidersResult): any;
export declare class DataCloudflareZeroTrustAccessIdentityProvidersResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessIdentityProvidersResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessIdentityProvidersResult | undefined);
    private _config;
    get config(): DataCloudflareZeroTrustAccessIdentityProvidersResultConfigOutputReference;
    get id(): string;
    get name(): string;
    private _scimConfig;
    get scimConfig(): DataCloudflareZeroTrustAccessIdentityProvidersResultScimConfigOutputReference;
    get type(): string;
}
export declare class DataCloudflareZeroTrustAccessIdentityProvidersResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessIdentityProvidersResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_access_identity_providers cloudflare_zero_trust_access_identity_providers}
*/
export declare class DataCloudflareZeroTrustAccessIdentityProviders extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_access_identity_providers";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustAccessIdentityProviders resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustAccessIdentityProviders to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustAccessIdentityProviders that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_access_identity_providers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustAccessIdentityProviders to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_access_identity_providers cloudflare_zero_trust_access_identity_providers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustAccessIdentityProvidersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustAccessIdentityProvidersConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustAccessIdentityProvidersResultList;
    private _scimEnabled?;
    get scimEnabled(): string;
    set scimEnabled(value: string);
    resetScimEnabled(): void;
    get scimEnabledInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
