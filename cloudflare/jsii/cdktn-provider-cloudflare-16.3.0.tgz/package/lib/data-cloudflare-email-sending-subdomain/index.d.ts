/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSendingSubdomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Sending subdomain identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_sending_subdomain#subdomain_id DataCloudflareEmailSendingSubdomain#subdomain_id}
    */
    readonly subdomainId: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_sending_subdomain#zone_id DataCloudflareEmailSendingSubdomain#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_sending_subdomain cloudflare_email_sending_subdomain}
*/
export declare class DataCloudflareEmailSendingSubdomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_sending_subdomain";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSendingSubdomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSendingSubdomain to import
    * @param importFromId The id of the existing DataCloudflareEmailSendingSubdomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_sending_subdomain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSendingSubdomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_sending_subdomain cloudflare_email_sending_subdomain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSendingSubdomainConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareEmailSendingSubdomainConfig);
    get created(): string;
    get dkimSelector(): string;
    get dropSuppressedRecipients(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get modified(): string;
    get name(): string;
    get previewEnabled(): cdktn.IResolvable;
    get returnPathDomain(): string;
    private _subdomainId?;
    get subdomainId(): string;
    set subdomainId(value: string);
    get subdomainIdInput(): string | undefined;
    get tag(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
