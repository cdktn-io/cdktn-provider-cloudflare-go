/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZoneDnssecConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zone_dnssec#zone_id DataCloudflareZoneDnssec#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zone_dnssec cloudflare_zone_dnssec}
*/
export declare class DataCloudflareZoneDnssec extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zone_dnssec";
    /**
    * Generates CDKTN code for importing a DataCloudflareZoneDnssec resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZoneDnssec to import
    * @param importFromId The id of the existing DataCloudflareZoneDnssec that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zone_dnssec#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZoneDnssec to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zone_dnssec cloudflare_zone_dnssec} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZoneDnssecConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZoneDnssecConfig);
    get algorithm(): string;
    get digest(): string;
    get digestAlgorithm(): string;
    get digestType(): string;
    get dnssecMultiSigner(): cdktn.IResolvable;
    get dnssecPresigned(): cdktn.IResolvable;
    get dnssecUseNsec3(): cdktn.IResolvable;
    get ds(): string;
    get flags(): number;
    get id(): string;
    get keyTag(): number;
    get keyType(): string;
    get modifiedOn(): string;
    get publicKey(): string;
    get status(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
