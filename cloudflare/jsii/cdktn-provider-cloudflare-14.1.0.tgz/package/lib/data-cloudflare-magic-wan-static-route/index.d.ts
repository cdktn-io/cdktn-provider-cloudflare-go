/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicWanStaticRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/magic_wan_static_route#account_id DataCloudflareMagicWanStaticRoute#account_id}
    */
    readonly accountId: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/magic_wan_static_route#route_id DataCloudflareMagicWanStaticRoute#route_id}
    */
    readonly routeId: string;
}
export interface DataCloudflareMagicWanStaticRouteRouteScope {
}
export declare function dataCloudflareMagicWanStaticRouteRouteScopeToTerraform(struct?: DataCloudflareMagicWanStaticRouteRouteScope): any;
export declare function dataCloudflareMagicWanStaticRouteRouteScopeToHclTerraform(struct?: DataCloudflareMagicWanStaticRouteRouteScope): any;
export declare class DataCloudflareMagicWanStaticRouteRouteScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanStaticRouteRouteScope | undefined;
    set internalValue(value: DataCloudflareMagicWanStaticRouteRouteScope | undefined);
    get coloNames(): string[];
    get coloRegions(): string[];
}
export interface DataCloudflareMagicWanStaticRouteRoute {
}
export declare function dataCloudflareMagicWanStaticRouteRouteToTerraform(struct?: DataCloudflareMagicWanStaticRouteRoute): any;
export declare function dataCloudflareMagicWanStaticRouteRouteToHclTerraform(struct?: DataCloudflareMagicWanStaticRouteRoute): any;
export declare class DataCloudflareMagicWanStaticRouteRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicWanStaticRouteRoute | undefined;
    set internalValue(value: DataCloudflareMagicWanStaticRouteRoute | undefined);
    get createdOn(): string;
    get description(): string;
    get id(): string;
    get modifiedOn(): string;
    get nexthop(): string;
    get prefix(): string;
    get priority(): number;
    private _scope;
    get scope(): DataCloudflareMagicWanStaticRouteRouteScopeOutputReference;
    get weight(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/magic_wan_static_route cloudflare_magic_wan_static_route}
*/
export declare class DataCloudflareMagicWanStaticRoute extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_wan_static_route";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicWanStaticRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicWanStaticRoute to import
    * @param importFromId The id of the existing DataCloudflareMagicWanStaticRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/magic_wan_static_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicWanStaticRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/magic_wan_static_route cloudflare_magic_wan_static_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicWanStaticRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicWanStaticRouteConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get id(): string;
    private _route;
    get route(): DataCloudflareMagicWanStaticRouteRouteOutputReference;
    private _routeId?;
    get routeId(): string;
    set routeId(value: string);
    get routeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
