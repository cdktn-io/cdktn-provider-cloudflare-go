/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareNotificationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/notification_policy#account_id DataCloudflareNotificationPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * The unique identifier of a notification policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/notification_policy#policy_id DataCloudflareNotificationPolicy#policy_id}
    */
    readonly policyId: string;
}
export interface DataCloudflareNotificationPolicyFilters {
}
export declare function dataCloudflareNotificationPolicyFiltersToTerraform(struct?: DataCloudflareNotificationPolicyFilters): any;
export declare function dataCloudflareNotificationPolicyFiltersToHclTerraform(struct?: DataCloudflareNotificationPolicyFilters): any;
export declare class DataCloudflareNotificationPolicyFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareNotificationPolicyFilters | undefined;
    set internalValue(value: DataCloudflareNotificationPolicyFilters | undefined);
    get actions(): string[];
    get affectedAsns(): string[];
    get affectedComponents(): string[];
    get affectedLocations(): string[];
    get airportCode(): string[];
    get alertTriggerPreferences(): string[];
    get alertTriggerPreferencesValue(): string[];
    get enabled(): string[];
    get environment(): string[];
    get event(): string[];
    get eventSource(): string[];
    get eventType(): string[];
    get groupBy(): string[];
    get healthCheckId(): string[];
    get incidentImpact(): string[];
    get inputId(): string[];
    get insightClass(): string[];
    get limit(): string[];
    get logoTag(): string[];
    get megabitsPerSecond(): string[];
    get newHealth(): string[];
    get newStatus(): string[];
    get packetsPerSecond(): string[];
    get poolId(): string[];
    get popNames(): string[];
    get product(): string[];
    get projectId(): string[];
    get protocol(): string[];
    get queryTag(): string[];
    get requestsPerSecond(): string[];
    get selectors(): string[];
    get services(): string[];
    get slo(): string[];
    get status(): string[];
    get targetHostname(): string[];
    get targetIp(): string[];
    get targetZoneName(): string[];
    get trafficExclusions(): string[];
    get tunnelId(): string[];
    get tunnelName(): string[];
    get type(): string[];
    get where(): string[];
    get zones(): string[];
}
export interface DataCloudflareNotificationPolicyMechanismsEmail {
}
export declare function dataCloudflareNotificationPolicyMechanismsEmailToTerraform(struct?: DataCloudflareNotificationPolicyMechanismsEmail): any;
export declare function dataCloudflareNotificationPolicyMechanismsEmailToHclTerraform(struct?: DataCloudflareNotificationPolicyMechanismsEmail): any;
export declare class DataCloudflareNotificationPolicyMechanismsEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareNotificationPolicyMechanismsEmail | undefined;
    set internalValue(value: DataCloudflareNotificationPolicyMechanismsEmail | undefined);
    get id(): string;
}
export declare class DataCloudflareNotificationPolicyMechanismsEmailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareNotificationPolicyMechanismsEmailOutputReference;
}
export interface DataCloudflareNotificationPolicyMechanismsPagerduty {
}
export declare function dataCloudflareNotificationPolicyMechanismsPagerdutyToTerraform(struct?: DataCloudflareNotificationPolicyMechanismsPagerduty): any;
export declare function dataCloudflareNotificationPolicyMechanismsPagerdutyToHclTerraform(struct?: DataCloudflareNotificationPolicyMechanismsPagerduty): any;
export declare class DataCloudflareNotificationPolicyMechanismsPagerdutyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareNotificationPolicyMechanismsPagerduty | undefined;
    set internalValue(value: DataCloudflareNotificationPolicyMechanismsPagerduty | undefined);
    get id(): string;
}
export declare class DataCloudflareNotificationPolicyMechanismsPagerdutyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareNotificationPolicyMechanismsPagerdutyOutputReference;
}
export interface DataCloudflareNotificationPolicyMechanismsWebhooks {
}
export declare function dataCloudflareNotificationPolicyMechanismsWebhooksToTerraform(struct?: DataCloudflareNotificationPolicyMechanismsWebhooks): any;
export declare function dataCloudflareNotificationPolicyMechanismsWebhooksToHclTerraform(struct?: DataCloudflareNotificationPolicyMechanismsWebhooks): any;
export declare class DataCloudflareNotificationPolicyMechanismsWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareNotificationPolicyMechanismsWebhooks | undefined;
    set internalValue(value: DataCloudflareNotificationPolicyMechanismsWebhooks | undefined);
    get id(): string;
}
export declare class DataCloudflareNotificationPolicyMechanismsWebhooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareNotificationPolicyMechanismsWebhooksOutputReference;
}
export interface DataCloudflareNotificationPolicyMechanisms {
}
export declare function dataCloudflareNotificationPolicyMechanismsToTerraform(struct?: DataCloudflareNotificationPolicyMechanisms): any;
export declare function dataCloudflareNotificationPolicyMechanismsToHclTerraform(struct?: DataCloudflareNotificationPolicyMechanisms): any;
export declare class DataCloudflareNotificationPolicyMechanismsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareNotificationPolicyMechanisms | undefined;
    set internalValue(value: DataCloudflareNotificationPolicyMechanisms | undefined);
    private _email;
    get email(): DataCloudflareNotificationPolicyMechanismsEmailList;
    private _pagerduty;
    get pagerduty(): DataCloudflareNotificationPolicyMechanismsPagerdutyList;
    private _webhooks;
    get webhooks(): DataCloudflareNotificationPolicyMechanismsWebhooksList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/notification_policy cloudflare_notification_policy}
*/
export declare class DataCloudflareNotificationPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_notification_policy";
    /**
    * Generates CDKTN code for importing a DataCloudflareNotificationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareNotificationPolicy to import
    * @param importFromId The id of the existing DataCloudflareNotificationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/notification_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareNotificationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/notification_policy cloudflare_notification_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareNotificationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareNotificationPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get alertInterval(): string;
    get alertType(): string;
    get created(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _filters;
    get filters(): DataCloudflareNotificationPolicyFiltersOutputReference;
    get id(): string;
    private _mechanisms;
    get mechanisms(): DataCloudflareNotificationPolicyMechanismsOutputReference;
    get modified(): string;
    get name(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
