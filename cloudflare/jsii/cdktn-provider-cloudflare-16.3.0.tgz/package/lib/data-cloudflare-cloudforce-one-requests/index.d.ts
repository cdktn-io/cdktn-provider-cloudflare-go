/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCloudforceOneRequestsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#account_id DataCloudflareCloudforceOneRequests#account_id}
    */
    readonly accountId?: string;
    /**
    * Retrieve requests completed after this time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#completed_after DataCloudflareCloudforceOneRequests#completed_after}
    */
    readonly completedAfter?: string;
    /**
    * Retrieve requests completed before this time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#completed_before DataCloudflareCloudforceOneRequests#completed_before}
    */
    readonly completedBefore?: string;
    /**
    * Retrieve requests created after this time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#created_after DataCloudflareCloudforceOneRequests#created_after}
    */
    readonly createdAfter?: string;
    /**
    * Retrieve requests created before this time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#created_before DataCloudflareCloudforceOneRequests#created_before}
    */
    readonly createdBefore?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#max_items DataCloudflareCloudforceOneRequests#max_items}
    */
    readonly maxItems?: number;
    /**
    * Page number of results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#page DataCloudflareCloudforceOneRequests#page}
    */
    readonly page: number;
    /**
    * Number of results per page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#per_page DataCloudflareCloudforceOneRequests#per_page}
    */
    readonly perPage: number;
    /**
    * Requested information from request.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#request_type DataCloudflareCloudforceOneRequests#request_type}
    */
    readonly requestType?: string;
    /**
    * Field to sort results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#sort_by DataCloudflareCloudforceOneRequests#sort_by}
    */
    readonly sortBy?: string;
    /**
    * Sort order (asc or desc).
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#sort_order DataCloudflareCloudforceOneRequests#sort_order}
    */
    readonly sortOrder?: string;
    /**
    * Request Status.
    * Available values: "open", "accepted", "reported", "approved", "completed", "declined".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#status DataCloudflareCloudforceOneRequests#status}
    */
    readonly status?: string;
}
export interface DataCloudflareCloudforceOneRequestsResult {
}
export declare function dataCloudflareCloudforceOneRequestsResultToTerraform(struct?: DataCloudflareCloudforceOneRequestsResult): any;
export declare function dataCloudflareCloudforceOneRequestsResultToHclTerraform(struct?: DataCloudflareCloudforceOneRequestsResult): any;
export declare class DataCloudflareCloudforceOneRequestsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCloudforceOneRequestsResult | undefined;
    set internalValue(value: DataCloudflareCloudforceOneRequestsResult | undefined);
    get completed(): string;
    get created(): string;
    get id(): string;
    get messageTokens(): number;
    get priority(): string;
    get readableId(): string;
    get request(): string;
    get status(): string;
    get summary(): string;
    get tlp(): string;
    get tokens(): number;
    get updated(): string;
}
export declare class DataCloudflareCloudforceOneRequestsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCloudforceOneRequestsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests cloudflare_cloudforce_one_requests}
*/
export declare class DataCloudflareCloudforceOneRequests extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_cloudforce_one_requests";
    /**
    * Generates CDKTN code for importing a DataCloudflareCloudforceOneRequests resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCloudforceOneRequests to import
    * @param importFromId The id of the existing DataCloudflareCloudforceOneRequests that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCloudforceOneRequests to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/cloudforce_one_requests cloudflare_cloudforce_one_requests} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCloudforceOneRequestsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareCloudforceOneRequestsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _completedAfter?;
    get completedAfter(): string;
    set completedAfter(value: string);
    resetCompletedAfter(): void;
    get completedAfterInput(): string | undefined;
    private _completedBefore?;
    get completedBefore(): string;
    set completedBefore(value: string);
    resetCompletedBefore(): void;
    get completedBeforeInput(): string | undefined;
    private _createdAfter?;
    get createdAfter(): string;
    set createdAfter(value: string);
    resetCreatedAfter(): void;
    get createdAfterInput(): string | undefined;
    private _createdBefore?;
    get createdBefore(): string;
    set createdBefore(value: string);
    resetCreatedBefore(): void;
    get createdBeforeInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _page?;
    get page(): number;
    set page(value: number);
    get pageInput(): number | undefined;
    private _perPage?;
    get perPage(): number;
    set perPage(value: number);
    get perPageInput(): number | undefined;
    private _requestType?;
    get requestType(): string;
    set requestType(value: string);
    resetRequestType(): void;
    get requestTypeInput(): string | undefined;
    private _result;
    get result(): DataCloudflareCloudforceOneRequestsResultList;
    private _sortBy?;
    get sortBy(): string;
    set sortBy(value: string);
    resetSortBy(): void;
    get sortByInput(): string | undefined;
    private _sortOrder?;
    get sortOrder(): string;
    set sortOrder(value: string);
    resetSortOrder(): void;
    get sortOrderInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
