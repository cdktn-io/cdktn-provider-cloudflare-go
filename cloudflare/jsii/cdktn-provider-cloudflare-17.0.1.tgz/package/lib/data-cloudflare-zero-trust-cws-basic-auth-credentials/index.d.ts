/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsBasicAuthCredentialsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials#account_id DataCloudflareZeroTrustCwsBasicAuthCredentials#account_id}
    */
    readonly accountId: string;
    /**
    * Filter to credentials attached to this deployment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials#deployment_id DataCloudflareZeroTrustCwsBasicAuthCredentials#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials#direction DataCloudflareZeroTrustCwsBasicAuthCredentials#direction}
    */
    readonly direction?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials#max_items DataCloudflareZeroTrustCwsBasicAuthCredentials#max_items}
    */
    readonly maxItems?: number;
    /**
    * Field to order results by (default: created_at)
    * Available values: "username", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials#order DataCloudflareZeroTrustCwsBasicAuthCredentials#order}
    */
    readonly order?: string;
    /**
    * Filter by username (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials#username DataCloudflareZeroTrustCwsBasicAuthCredentials#username}
    */
    readonly username?: string;
}
export interface DataCloudflareZeroTrustCwsBasicAuthCredentialsResult {
}
export declare function dataCloudflareZeroTrustCwsBasicAuthCredentialsResultToTerraform(struct?: DataCloudflareZeroTrustCwsBasicAuthCredentialsResult): any;
export declare function dataCloudflareZeroTrustCwsBasicAuthCredentialsResultToHclTerraform(struct?: DataCloudflareZeroTrustCwsBasicAuthCredentialsResult): any;
export declare class DataCloudflareZeroTrustCwsBasicAuthCredentialsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCwsBasicAuthCredentialsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsBasicAuthCredentialsResult | undefined);
    get createdAt(): string;
    get id(): string;
    get updatedAt(): string;
    get username(): string;
}
export declare class DataCloudflareZeroTrustCwsBasicAuthCredentialsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCwsBasicAuthCredentialsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials cloudflare_zero_trust_cws_basic_auth_credentials}
*/
export declare class DataCloudflareZeroTrustCwsBasicAuthCredentials extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_basic_auth_credentials";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsBasicAuthCredentials resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsBasicAuthCredentials to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsBasicAuthCredentials that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsBasicAuthCredentials to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_basic_auth_credentials cloudflare_zero_trust_cws_basic_auth_credentials} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsBasicAuthCredentialsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsBasicAuthCredentialsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCwsBasicAuthCredentialsResultList;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
