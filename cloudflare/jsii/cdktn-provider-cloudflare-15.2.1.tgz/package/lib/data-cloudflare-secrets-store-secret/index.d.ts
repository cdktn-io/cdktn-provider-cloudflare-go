/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSecretsStoreSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#account_id DataCloudflareSecretsStoreSecret#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#filter DataCloudflareSecretsStoreSecret#filter}
    */
    readonly filter?: DataCloudflareSecretsStoreSecretFilter;
    /**
    * Secret identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#secret_id DataCloudflareSecretsStoreSecret#secret_id}
    */
    readonly secretId?: string;
    /**
    * Store Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#store_id DataCloudflareSecretsStoreSecret#store_id}
    */
    readonly storeId: string;
}
export interface DataCloudflareSecretsStoreSecretFilter {
    /**
    * Direction to sort objects
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#direction DataCloudflareSecretsStoreSecret#direction}
    */
    readonly direction?: string;
    /**
    * Order secrets by values in the given field
    * Available values: "name", "comment", "created", "modified", "status".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#order DataCloudflareSecretsStoreSecret#order}
    */
    readonly order?: string;
    /**
    * Only secrets with the given scopes will be returned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#scopes DataCloudflareSecretsStoreSecret#scopes}
    */
    readonly scopes?: string[][] | cdktn.IResolvable;
    /**
    * Search secrets using a filter string, filtering across name and comment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#search DataCloudflareSecretsStoreSecret#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareSecretsStoreSecretFilterToTerraform(struct?: DataCloudflareSecretsStoreSecretFilter | cdktn.IResolvable): any;
export declare function dataCloudflareSecretsStoreSecretFilterToHclTerraform(struct?: DataCloudflareSecretsStoreSecretFilter | cdktn.IResolvable): any;
export declare class DataCloudflareSecretsStoreSecretFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSecretsStoreSecretFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareSecretsStoreSecretFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _scopes?;
    get scopes(): string[][] | cdktn.IResolvable;
    set scopes(value: string[][] | cdktn.IResolvable);
    resetScopes(): void;
    get scopesInput(): cdktn.IResolvable | string[][] | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret cloudflare_secrets_store_secret}
*/
export declare class DataCloudflareSecretsStoreSecret extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_secrets_store_secret";
    /**
    * Generates CDKTN code for importing a DataCloudflareSecretsStoreSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSecretsStoreSecret to import
    * @param importFromId The id of the existing DataCloudflareSecretsStoreSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSecretsStoreSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/secrets_store_secret cloudflare_secrets_store_secret} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSecretsStoreSecretConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareSecretsStoreSecretConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get comment(): string;
    get created(): string;
    private _filter;
    get filter(): DataCloudflareSecretsStoreSecretFilterOutputReference;
    putFilter(value: DataCloudflareSecretsStoreSecretFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareSecretsStoreSecretFilter | undefined;
    get id(): string;
    get modified(): string;
    get name(): string;
    get scopes(): string[];
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    resetSecretId(): void;
    get secretIdInput(): string | undefined;
    get status(): string;
    private _storeId?;
    get storeId(): string;
    set storeId(value: string);
    get storeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
