/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareStreamLiveInputConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/stream_live_input#account_id DataCloudflareStreamLiveInput#account_id}
    */
    readonly accountId: string;
    /**
    * A unique identifier for a live input.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/stream_live_input#live_input_identifier DataCloudflareStreamLiveInput#live_input_identifier}
    */
    readonly liveInputIdentifier: string;
}
export interface DataCloudflareStreamLiveInputRecording {
}
export declare function dataCloudflareStreamLiveInputRecordingToTerraform(struct?: DataCloudflareStreamLiveInputRecording): any;
export declare function dataCloudflareStreamLiveInputRecordingToHclTerraform(struct?: DataCloudflareStreamLiveInputRecording): any;
export declare class DataCloudflareStreamLiveInputRecordingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamLiveInputRecording | undefined;
    set internalValue(value: DataCloudflareStreamLiveInputRecording | undefined);
    get allowedOrigins(): string[];
    get hideLiveViewerCount(): cdktn.IResolvable;
    get mode(): string;
    get requireSignedUrls(): cdktn.IResolvable;
    get timeoutSeconds(): number;
}
export interface DataCloudflareStreamLiveInputRtmps {
}
export declare function dataCloudflareStreamLiveInputRtmpsToTerraform(struct?: DataCloudflareStreamLiveInputRtmps): any;
export declare function dataCloudflareStreamLiveInputRtmpsToHclTerraform(struct?: DataCloudflareStreamLiveInputRtmps): any;
export declare class DataCloudflareStreamLiveInputRtmpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamLiveInputRtmps | undefined;
    set internalValue(value: DataCloudflareStreamLiveInputRtmps | undefined);
    get streamKey(): string;
    get url(): string;
}
export interface DataCloudflareStreamLiveInputRtmpsPlayback {
}
export declare function dataCloudflareStreamLiveInputRtmpsPlaybackToTerraform(struct?: DataCloudflareStreamLiveInputRtmpsPlayback): any;
export declare function dataCloudflareStreamLiveInputRtmpsPlaybackToHclTerraform(struct?: DataCloudflareStreamLiveInputRtmpsPlayback): any;
export declare class DataCloudflareStreamLiveInputRtmpsPlaybackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamLiveInputRtmpsPlayback | undefined;
    set internalValue(value: DataCloudflareStreamLiveInputRtmpsPlayback | undefined);
    get streamKey(): string;
    get url(): string;
}
export interface DataCloudflareStreamLiveInputSrt {
}
export declare function dataCloudflareStreamLiveInputSrtToTerraform(struct?: DataCloudflareStreamLiveInputSrt): any;
export declare function dataCloudflareStreamLiveInputSrtToHclTerraform(struct?: DataCloudflareStreamLiveInputSrt): any;
export declare class DataCloudflareStreamLiveInputSrtOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamLiveInputSrt | undefined;
    set internalValue(value: DataCloudflareStreamLiveInputSrt | undefined);
    get passphrase(): string;
    get streamId(): string;
    get url(): string;
}
export interface DataCloudflareStreamLiveInputSrtPlayback {
}
export declare function dataCloudflareStreamLiveInputSrtPlaybackToTerraform(struct?: DataCloudflareStreamLiveInputSrtPlayback): any;
export declare function dataCloudflareStreamLiveInputSrtPlaybackToHclTerraform(struct?: DataCloudflareStreamLiveInputSrtPlayback): any;
export declare class DataCloudflareStreamLiveInputSrtPlaybackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamLiveInputSrtPlayback | undefined;
    set internalValue(value: DataCloudflareStreamLiveInputSrtPlayback | undefined);
    get passphrase(): string;
    get streamId(): string;
    get url(): string;
}
export interface DataCloudflareStreamLiveInputWebRtc {
}
export declare function dataCloudflareStreamLiveInputWebRtcToTerraform(struct?: DataCloudflareStreamLiveInputWebRtc): any;
export declare function dataCloudflareStreamLiveInputWebRtcToHclTerraform(struct?: DataCloudflareStreamLiveInputWebRtc): any;
export declare class DataCloudflareStreamLiveInputWebRtcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamLiveInputWebRtc | undefined;
    set internalValue(value: DataCloudflareStreamLiveInputWebRtc | undefined);
    get url(): string;
}
export interface DataCloudflareStreamLiveInputWebRtcPlayback {
}
export declare function dataCloudflareStreamLiveInputWebRtcPlaybackToTerraform(struct?: DataCloudflareStreamLiveInputWebRtcPlayback): any;
export declare function dataCloudflareStreamLiveInputWebRtcPlaybackToHclTerraform(struct?: DataCloudflareStreamLiveInputWebRtcPlayback): any;
export declare class DataCloudflareStreamLiveInputWebRtcPlaybackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamLiveInputWebRtcPlayback | undefined;
    set internalValue(value: DataCloudflareStreamLiveInputWebRtcPlayback | undefined);
    get url(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/stream_live_input cloudflare_stream_live_input}
*/
export declare class DataCloudflareStreamLiveInput extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_stream_live_input";
    /**
    * Generates CDKTN code for importing a DataCloudflareStreamLiveInput resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareStreamLiveInput to import
    * @param importFromId The id of the existing DataCloudflareStreamLiveInput that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/stream_live_input#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareStreamLiveInput to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/stream_live_input cloudflare_stream_live_input} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareStreamLiveInputConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareStreamLiveInputConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get created(): string;
    get deleteRecordingAfterDays(): number;
    get enabled(): cdktn.IResolvable;
    get keysRotatedAt(): string;
    private _liveInputIdentifier?;
    get liveInputIdentifier(): string;
    set liveInputIdentifier(value: string);
    get liveInputIdentifierInput(): string | undefined;
    get meta(): string;
    get modified(): string;
    get preferLowLatency(): cdktn.IResolvable;
    private _recording;
    get recording(): DataCloudflareStreamLiveInputRecordingOutputReference;
    private _rtmps;
    get rtmps(): DataCloudflareStreamLiveInputRtmpsOutputReference;
    private _rtmpsPlayback;
    get rtmpsPlayback(): DataCloudflareStreamLiveInputRtmpsPlaybackOutputReference;
    private _srt;
    get srt(): DataCloudflareStreamLiveInputSrtOutputReference;
    private _srtPlayback;
    get srtPlayback(): DataCloudflareStreamLiveInputSrtPlaybackOutputReference;
    get status(): string;
    get uid(): string;
    private _webRtc;
    get webRtc(): DataCloudflareStreamLiveInputWebRtcOutputReference;
    private _webRtcPlayback;
    get webRtcPlayback(): DataCloudflareStreamLiveInputWebRtcPlaybackOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
