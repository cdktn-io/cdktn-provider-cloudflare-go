/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EmailRoutingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * List actions patterns.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#actions EmailRoutingRule#actions}
    */
    readonly actions: EmailRoutingRuleActions[] | cdktn.IResolvable;
    /**
    * Routing rule status.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#enabled EmailRoutingRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Matching patterns to forward to your actions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#matchers EmailRoutingRule#matchers}
    */
    readonly matchers: EmailRoutingRuleMatchers[] | cdktn.IResolvable;
    /**
    * Routing rule name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#name EmailRoutingRule#name}
    */
    readonly name?: string;
    /**
    * Priority of the routing rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#priority EmailRoutingRule#priority}
    */
    readonly priority?: number;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#zone_id EmailRoutingRule#zone_id}
    */
    readonly zoneId: string;
}
export interface EmailRoutingRuleActions {
    /**
    * Type of supported action.
    * Available values: "drop", "forward", "worker".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#type EmailRoutingRule#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#value EmailRoutingRule#value}
    */
    readonly value?: string[];
}
export declare function emailRoutingRuleActionsToTerraform(struct?: EmailRoutingRuleActions | cdktn.IResolvable): any;
export declare function emailRoutingRuleActionsToHclTerraform(struct?: EmailRoutingRuleActions | cdktn.IResolvable): any;
export declare class EmailRoutingRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailRoutingRuleActions | cdktn.IResolvable | undefined;
    set internalValue(value: EmailRoutingRuleActions | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string[];
    set value(value: string[]);
    resetValue(): void;
    get valueInput(): string[] | undefined;
}
export declare class EmailRoutingRuleActionsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EmailRoutingRuleActions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailRoutingRuleActionsOutputReference;
}
export interface EmailRoutingRuleMatchers {
    /**
    * Field for type matcher.
    * Available values: "to".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#field EmailRoutingRule#field}
    */
    readonly field?: string;
    /**
    * Type of matcher.
    * Available values: "all", "literal".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#type EmailRoutingRule#type}
    */
    readonly type: string;
    /**
    * Value for matcher.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#value EmailRoutingRule#value}
    */
    readonly value?: string;
}
export declare function emailRoutingRuleMatchersToTerraform(struct?: EmailRoutingRuleMatchers | cdktn.IResolvable): any;
export declare function emailRoutingRuleMatchersToHclTerraform(struct?: EmailRoutingRuleMatchers | cdktn.IResolvable): any;
export declare class EmailRoutingRuleMatchersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): EmailRoutingRuleMatchers | cdktn.IResolvable | undefined;
    set internalValue(value: EmailRoutingRuleMatchers | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class EmailRoutingRuleMatchersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: EmailRoutingRuleMatchers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): EmailRoutingRuleMatchersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule cloudflare_email_routing_rule}
*/
export declare class EmailRoutingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_email_routing_rule";
    /**
    * Generates CDKTN code for importing a EmailRoutingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EmailRoutingRule to import
    * @param importFromId The id of the existing EmailRoutingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EmailRoutingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/email_routing_rule cloudflare_email_routing_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EmailRoutingRuleConfig
    */
    constructor(scope: Construct, id: string, config: EmailRoutingRuleConfig);
    private _actions;
    get actions(): EmailRoutingRuleActionsList;
    putActions(value: EmailRoutingRuleActions[] | cdktn.IResolvable): void;
    get actionsInput(): cdktn.IResolvable | EmailRoutingRuleActions[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _matchers;
    get matchers(): EmailRoutingRuleMatchersList;
    putMatchers(value: EmailRoutingRuleMatchers[] | cdktn.IResolvable): void;
    get matchersInput(): cdktn.IResolvable | EmailRoutingRuleMatchers[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    get tag(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
