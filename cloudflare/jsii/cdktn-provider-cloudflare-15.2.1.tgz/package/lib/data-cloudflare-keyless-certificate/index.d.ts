/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareKeylessCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/keyless_certificate#keyless_certificate_id DataCloudflareKeylessCertificate#keyless_certificate_id}
    */
    readonly keylessCertificateId: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/keyless_certificate#zone_id DataCloudflareKeylessCertificate#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareKeylessCertificateTunnel {
}
export declare function dataCloudflareKeylessCertificateTunnelToTerraform(struct?: DataCloudflareKeylessCertificateTunnel): any;
export declare function dataCloudflareKeylessCertificateTunnelToHclTerraform(struct?: DataCloudflareKeylessCertificateTunnel): any;
export declare class DataCloudflareKeylessCertificateTunnelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareKeylessCertificateTunnel | undefined;
    set internalValue(value: DataCloudflareKeylessCertificateTunnel | undefined);
    get privateIp(): string;
    get vnetId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/keyless_certificate cloudflare_keyless_certificate}
*/
export declare class DataCloudflareKeylessCertificate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_keyless_certificate";
    /**
    * Generates CDKTN code for importing a DataCloudflareKeylessCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareKeylessCertificate to import
    * @param importFromId The id of the existing DataCloudflareKeylessCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/keyless_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareKeylessCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/keyless_certificate cloudflare_keyless_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareKeylessCertificateConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareKeylessCertificateConfig);
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get host(): string;
    get id(): string;
    private _keylessCertificateId?;
    get keylessCertificateId(): string;
    set keylessCertificateId(value: string);
    get keylessCertificateIdInput(): string | undefined;
    get modifiedOn(): string;
    get name(): string;
    get permissions(): string[];
    get port(): number;
    get status(): string;
    private _tunnel;
    get tunnel(): DataCloudflareKeylessCertificateTunnelOutputReference;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
