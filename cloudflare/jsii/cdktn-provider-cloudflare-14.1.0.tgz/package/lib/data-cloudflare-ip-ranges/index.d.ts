/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareIpRangesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specified as `jdcloud` to list IPs used by JD Cloud data centers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ip_ranges#networks DataCloudflareIpRanges#networks}
    */
    readonly networks?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ip_ranges cloudflare_ip_ranges}
*/
export declare class DataCloudflareIpRanges extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ip_ranges";
    /**
    * Generates CDKTN code for importing a DataCloudflareIpRanges resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareIpRanges to import
    * @param importFromId The id of the existing DataCloudflareIpRanges that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ip_ranges#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareIpRanges to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ip_ranges cloudflare_ip_ranges} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareIpRangesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareIpRangesConfig);
    get etag(): string;
    get ipv4Cidrs(): string[];
    get ipv6Cidrs(): string[];
    get jdcloudCidrs(): string[];
    private _networks?;
    get networks(): string;
    set networks(value: string);
    resetNetworks(): void;
    get networksInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
