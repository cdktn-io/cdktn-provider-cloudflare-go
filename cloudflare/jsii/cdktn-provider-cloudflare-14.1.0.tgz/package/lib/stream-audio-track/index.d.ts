/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StreamAudioTrackConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track#account_id StreamAudioTrack#account_id}
    */
    readonly accountId: string;
    /**
    * The unique identifier for an additional audio track.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track#audio_identifier StreamAudioTrack#audio_identifier}
    */
    readonly audioIdentifier?: string;
    /**
    * Denotes whether the audio track will be played by default in a player.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track#default StreamAudioTrack#default}
    */
    readonly default?: boolean | cdktn.IResolvable;
    /**
    * A Cloudflare-generated unique identifier for a media item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track#identifier StreamAudioTrack#identifier}
    */
    readonly identifier: string;
    /**
    * A string to uniquely identify the track amongst other audio track labels for the specified video.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track#label StreamAudioTrack#label}
    */
    readonly label?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track cloudflare_stream_audio_track}
*/
export declare class StreamAudioTrack extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_stream_audio_track";
    /**
    * Generates CDKTN code for importing a StreamAudioTrack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StreamAudioTrack to import
    * @param importFromId The id of the existing StreamAudioTrack that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StreamAudioTrack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/stream_audio_track cloudflare_stream_audio_track} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StreamAudioTrackConfig
    */
    constructor(scope: Construct, id: string, config: StreamAudioTrackConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _audioIdentifier?;
    get audioIdentifier(): string;
    set audioIdentifier(value: string);
    resetAudioIdentifier(): void;
    get audioIdentifierInput(): string | undefined;
    private _default?;
    get default(): boolean | cdktn.IResolvable;
    set default(value: boolean | cdktn.IResolvable);
    resetDefault(): void;
    get defaultInput(): boolean | cdktn.IResolvable | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    get status(): string;
    get uid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
