/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkflowsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/workflows#account_id DataCloudflareWorkflows#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/workflows#max_items DataCloudflareWorkflows#max_items}
    */
    readonly maxItems?: number;
    /**
    * Allows filtering workflows` name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/workflows#search DataCloudflareWorkflows#search}
    */
    readonly search?: string;
}
export interface DataCloudflareWorkflowsResultInstances {
}
export declare function dataCloudflareWorkflowsResultInstancesToTerraform(struct?: DataCloudflareWorkflowsResultInstances): any;
export declare function dataCloudflareWorkflowsResultInstancesToHclTerraform(struct?: DataCloudflareWorkflowsResultInstances): any;
export declare class DataCloudflareWorkflowsResultInstancesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkflowsResultInstances | undefined;
    set internalValue(value: DataCloudflareWorkflowsResultInstances | undefined);
    get complete(): number;
    get errored(): number;
    get paused(): number;
    get queued(): number;
    get rollingBack(): number;
    get running(): number;
    get terminated(): number;
    get waiting(): number;
    get waitingForPause(): number;
}
export interface DataCloudflareWorkflowsResultSchedules {
}
export declare function dataCloudflareWorkflowsResultSchedulesToTerraform(struct?: DataCloudflareWorkflowsResultSchedules): any;
export declare function dataCloudflareWorkflowsResultSchedulesToHclTerraform(struct?: DataCloudflareWorkflowsResultSchedules): any;
export declare class DataCloudflareWorkflowsResultSchedulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkflowsResultSchedules | undefined;
    set internalValue(value: DataCloudflareWorkflowsResultSchedules | undefined);
    get cron(): string;
    get nextInstance(): string;
}
export declare class DataCloudflareWorkflowsResultSchedulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkflowsResultSchedulesOutputReference;
}
export interface DataCloudflareWorkflowsResult {
}
export declare function dataCloudflareWorkflowsResultToTerraform(struct?: DataCloudflareWorkflowsResult): any;
export declare function dataCloudflareWorkflowsResultToHclTerraform(struct?: DataCloudflareWorkflowsResult): any;
export declare class DataCloudflareWorkflowsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkflowsResult | undefined;
    set internalValue(value: DataCloudflareWorkflowsResult | undefined);
    get className(): string;
    get createdOn(): string;
    get id(): string;
    private _instances;
    get instances(): DataCloudflareWorkflowsResultInstancesOutputReference;
    get modifiedOn(): string;
    get name(): string;
    private _schedules;
    get schedules(): DataCloudflareWorkflowsResultSchedulesList;
    get scriptName(): string;
    get triggeredOn(): string;
}
export declare class DataCloudflareWorkflowsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkflowsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/workflows cloudflare_workflows}
*/
export declare class DataCloudflareWorkflows extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_workflows";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkflows resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkflows to import
    * @param importFromId The id of the existing DataCloudflareWorkflows that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/workflows#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkflows to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/workflows cloudflare_workflows} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkflowsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWorkflowsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareWorkflowsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
