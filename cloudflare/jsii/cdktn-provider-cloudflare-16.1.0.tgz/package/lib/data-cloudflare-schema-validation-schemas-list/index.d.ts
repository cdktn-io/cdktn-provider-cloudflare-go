/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSchemaValidationSchemasListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/schema_validation_schemas_list#max_items DataCloudflareSchemaValidationSchemasList#max_items}
    */
    readonly maxItems?: number;
    /**
    * Omit the source-files of schemas and only retrieve their meta-data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/schema_validation_schemas_list#omit_source DataCloudflareSchemaValidationSchemasList#omit_source}
    */
    readonly omitSource?: boolean | cdktn.IResolvable;
    /**
    * Filter for enabled schemas
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/schema_validation_schemas_list#validation_enabled DataCloudflareSchemaValidationSchemasList#validation_enabled}
    */
    readonly validationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/schema_validation_schemas_list#zone_id DataCloudflareSchemaValidationSchemasList#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareSchemaValidationSchemasListResult {
}
export declare function dataCloudflareSchemaValidationSchemasListResultToTerraform(struct?: DataCloudflareSchemaValidationSchemasListResult): any;
export declare function dataCloudflareSchemaValidationSchemasListResultToHclTerraform(struct?: DataCloudflareSchemaValidationSchemasListResult): any;
export declare class DataCloudflareSchemaValidationSchemasListResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareSchemaValidationSchemasListResult | undefined;
    set internalValue(value: DataCloudflareSchemaValidationSchemasListResult | undefined);
    get createdAt(): string;
    get id(): string;
    get kind(): string;
    get name(): string;
    get schemaId(): string;
    get source(): string;
    get validationEnabled(): cdktn.IResolvable;
}
export declare class DataCloudflareSchemaValidationSchemasListResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareSchemaValidationSchemasListResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/schema_validation_schemas_list cloudflare_schema_validation_schemas_list}
*/
export declare class DataCloudflareSchemaValidationSchemasList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_schema_validation_schemas_list";
    /**
    * Generates CDKTN code for importing a DataCloudflareSchemaValidationSchemasList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSchemaValidationSchemasList to import
    * @param importFromId The id of the existing DataCloudflareSchemaValidationSchemasList that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/schema_validation_schemas_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSchemaValidationSchemasList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/schema_validation_schemas_list cloudflare_schema_validation_schemas_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSchemaValidationSchemasListConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareSchemaValidationSchemasListConfig);
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _omitSource?;
    get omitSource(): boolean | cdktn.IResolvable;
    set omitSource(value: boolean | cdktn.IResolvable);
    resetOmitSource(): void;
    get omitSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _result;
    get result(): DataCloudflareSchemaValidationSchemasListResultList;
    private _validationEnabled?;
    get validationEnabled(): boolean | cdktn.IResolvable;
    set validationEnabled(value: boolean | cdktn.IResolvable);
    resetValidationEnabled(): void;
    get validationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
