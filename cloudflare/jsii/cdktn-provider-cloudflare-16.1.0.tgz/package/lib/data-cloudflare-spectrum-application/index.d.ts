/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSpectrumApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * App identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application#app_id DataCloudflareSpectrumApplication#app_id}
    */
    readonly appId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application#filter DataCloudflareSpectrumApplication#filter}
    */
    readonly filter?: DataCloudflareSpectrumApplicationFilter;
    /**
    * Zone identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application#zone_id DataCloudflareSpectrumApplication#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareSpectrumApplicationDns {
}
export declare function dataCloudflareSpectrumApplicationDnsToTerraform(struct?: DataCloudflareSpectrumApplicationDns): any;
export declare function dataCloudflareSpectrumApplicationDnsToHclTerraform(struct?: DataCloudflareSpectrumApplicationDns): any;
export declare class DataCloudflareSpectrumApplicationDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSpectrumApplicationDns | undefined;
    set internalValue(value: DataCloudflareSpectrumApplicationDns | undefined);
    get name(): string;
    get type(): string;
}
export interface DataCloudflareSpectrumApplicationEdgeIps {
}
export declare function dataCloudflareSpectrumApplicationEdgeIpsToTerraform(struct?: DataCloudflareSpectrumApplicationEdgeIps): any;
export declare function dataCloudflareSpectrumApplicationEdgeIpsToHclTerraform(struct?: DataCloudflareSpectrumApplicationEdgeIps): any;
export declare class DataCloudflareSpectrumApplicationEdgeIpsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSpectrumApplicationEdgeIps | undefined;
    set internalValue(value: DataCloudflareSpectrumApplicationEdgeIps | undefined);
    get connectivity(): string;
    get ips(): string[];
    get type(): string;
}
export interface DataCloudflareSpectrumApplicationFilter {
    /**
    * Sets the direction by which results are ordered.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application#direction DataCloudflareSpectrumApplication#direction}
    */
    readonly direction?: string;
    /**
    * Application field by which results are ordered.
    * Available values: "protocol", "app_id", "created_on", "modified_on", "dns".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application#order DataCloudflareSpectrumApplication#order}
    */
    readonly order?: string;
}
export declare function dataCloudflareSpectrumApplicationFilterToTerraform(struct?: DataCloudflareSpectrumApplicationFilter | cdktn.IResolvable): any;
export declare function dataCloudflareSpectrumApplicationFilterToHclTerraform(struct?: DataCloudflareSpectrumApplicationFilter | cdktn.IResolvable): any;
export declare class DataCloudflareSpectrumApplicationFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSpectrumApplicationFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareSpectrumApplicationFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
}
export interface DataCloudflareSpectrumApplicationOriginDns {
}
export declare function dataCloudflareSpectrumApplicationOriginDnsToTerraform(struct?: DataCloudflareSpectrumApplicationOriginDns): any;
export declare function dataCloudflareSpectrumApplicationOriginDnsToHclTerraform(struct?: DataCloudflareSpectrumApplicationOriginDns): any;
export declare class DataCloudflareSpectrumApplicationOriginDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSpectrumApplicationOriginDns | undefined;
    set internalValue(value: DataCloudflareSpectrumApplicationOriginDns | undefined);
    get name(): string;
    get ttl(): number;
    get type(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application cloudflare_spectrum_application}
*/
export declare class DataCloudflareSpectrumApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_spectrum_application";
    /**
    * Generates CDKTN code for importing a DataCloudflareSpectrumApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSpectrumApplication to import
    * @param importFromId The id of the existing DataCloudflareSpectrumApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSpectrumApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/spectrum_application cloudflare_spectrum_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSpectrumApplicationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareSpectrumApplicationConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    resetAppId(): void;
    get appIdInput(): string | undefined;
    get argoSmartRouting(): cdktn.IResolvable;
    get createdOn(): string;
    private _dns;
    get dns(): DataCloudflareSpectrumApplicationDnsOutputReference;
    private _edgeIps;
    get edgeIps(): DataCloudflareSpectrumApplicationEdgeIpsOutputReference;
    private _filter;
    get filter(): DataCloudflareSpectrumApplicationFilterOutputReference;
    putFilter(value: DataCloudflareSpectrumApplicationFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareSpectrumApplicationFilter | undefined;
    get id(): string;
    get ipFirewall(): cdktn.IResolvable;
    get modifiedOn(): string;
    get originDirect(): string[];
    private _originDns;
    get originDns(): DataCloudflareSpectrumApplicationOriginDnsOutputReference;
    private _originPort;
    get originPort(): cdktn.AnyMap;
    get protocol(): string;
    get proxyProtocol(): string;
    get tls(): string;
    get trafficType(): string;
    get virtualNetworkId(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
