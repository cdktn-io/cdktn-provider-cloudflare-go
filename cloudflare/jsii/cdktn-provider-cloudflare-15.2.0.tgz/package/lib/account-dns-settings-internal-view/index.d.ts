/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountDnsSettingsInternalViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/account_dns_settings_internal_view#account_id AccountDnsSettingsInternalView#account_id}
    */
    readonly accountId: string;
    /**
    * The name of the view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/account_dns_settings_internal_view#name AccountDnsSettingsInternalView#name}
    */
    readonly name: string;
    /**
    * The list of zones linked to this view.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/account_dns_settings_internal_view#zones AccountDnsSettingsInternalView#zones}
    */
    readonly zones: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/account_dns_settings_internal_view cloudflare_account_dns_settings_internal_view}
*/
export declare class AccountDnsSettingsInternalView extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_account_dns_settings_internal_view";
    /**
    * Generates CDKTN code for importing a AccountDnsSettingsInternalView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountDnsSettingsInternalView to import
    * @param importFromId The id of the existing AccountDnsSettingsInternalView that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/account_dns_settings_internal_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountDnsSettingsInternalView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/account_dns_settings_internal_view cloudflare_account_dns_settings_internal_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountDnsSettingsInternalViewConfig
    */
    constructor(scope: Construct, id: string, config: AccountDnsSettingsInternalViewConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdTime(): string;
    get id(): string;
    get modifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _zones?;
    get zones(): string[];
    set zones(value: string[]);
    get zonesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
