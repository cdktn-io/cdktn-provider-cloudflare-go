/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareFieldExtractorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/field_extractor#account_id DataCloudflareFieldExtractor#account_id}
    */
    readonly accountId: string;
    /**
    * Extractor type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/field_extractor#extractor DataCloudflareFieldExtractor#extractor}
    */
    readonly extractor: string;
}
export interface DataCloudflareFieldExtractorRulesFields {
}
export declare function dataCloudflareFieldExtractorRulesFieldsToTerraform(struct?: DataCloudflareFieldExtractorRulesFields): any;
export declare function dataCloudflareFieldExtractorRulesFieldsToHclTerraform(struct?: DataCloudflareFieldExtractorRulesFields): any;
export declare class DataCloudflareFieldExtractorRulesFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFieldExtractorRulesFields | undefined;
    set internalValue(value: DataCloudflareFieldExtractorRulesFields | undefined);
    get expression(): string;
    get name(): string;
}
export declare class DataCloudflareFieldExtractorRulesFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFieldExtractorRulesFieldsOutputReference;
}
export interface DataCloudflareFieldExtractorRules {
}
export declare function dataCloudflareFieldExtractorRulesToTerraform(struct?: DataCloudflareFieldExtractorRules): any;
export declare function dataCloudflareFieldExtractorRulesToHclTerraform(struct?: DataCloudflareFieldExtractorRules): any;
export declare class DataCloudflareFieldExtractorRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFieldExtractorRules | undefined;
    set internalValue(value: DataCloudflareFieldExtractorRules | undefined);
    get description(): string;
    private _fields;
    get fields(): DataCloudflareFieldExtractorRulesFieldsList;
    get ref(): string;
}
export declare class DataCloudflareFieldExtractorRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFieldExtractorRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/field_extractor cloudflare_field_extractor}
*/
export declare class DataCloudflareFieldExtractor extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_field_extractor";
    /**
    * Generates CDKTN code for importing a DataCloudflareFieldExtractor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareFieldExtractor to import
    * @param importFromId The id of the existing DataCloudflareFieldExtractor that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/field_extractor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareFieldExtractor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/field_extractor cloudflare_field_extractor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareFieldExtractorConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareFieldExtractorConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _extractor?;
    get extractor(): string;
    set extractor(value: string);
    get extractorInput(): string | undefined;
    private _rules;
    get rules(): DataCloudflareFieldExtractorRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
