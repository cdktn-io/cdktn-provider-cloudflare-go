/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSchemaValidationSchemasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas#filter DataCloudflareSchemaValidationSchemas#filter}
    */
    readonly filter?: DataCloudflareSchemaValidationSchemasFilter;
    /**
    * Omit the source-files of schemas and only retrieve their meta-data.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas#omit_source DataCloudflareSchemaValidationSchemas#omit_source}
    */
    readonly omitSource?: boolean | cdktn.IResolvable;
    /**
    * UUID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas#schema_id DataCloudflareSchemaValidationSchemas#schema_id}
    */
    readonly schemaId?: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas#zone_id DataCloudflareSchemaValidationSchemas#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareSchemaValidationSchemasFilter {
    /**
    * Filter for enabled schemas
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas#validation_enabled DataCloudflareSchemaValidationSchemas#validation_enabled}
    */
    readonly validationEnabled?: boolean | cdktn.IResolvable;
}
export declare function dataCloudflareSchemaValidationSchemasFilterToTerraform(struct?: DataCloudflareSchemaValidationSchemasFilter | cdktn.IResolvable): any;
export declare function dataCloudflareSchemaValidationSchemasFilterToHclTerraform(struct?: DataCloudflareSchemaValidationSchemasFilter | cdktn.IResolvable): any;
export declare class DataCloudflareSchemaValidationSchemasFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSchemaValidationSchemasFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareSchemaValidationSchemasFilter | cdktn.IResolvable | undefined);
    private _validationEnabled?;
    get validationEnabled(): boolean | cdktn.IResolvable;
    set validationEnabled(value: boolean | cdktn.IResolvable);
    resetValidationEnabled(): void;
    get validationEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas cloudflare_schema_validation_schemas}
*/
export declare class DataCloudflareSchemaValidationSchemas extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_schema_validation_schemas";
    /**
    * Generates CDKTN code for importing a DataCloudflareSchemaValidationSchemas resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSchemaValidationSchemas to import
    * @param importFromId The id of the existing DataCloudflareSchemaValidationSchemas that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSchemaValidationSchemas to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/schema_validation_schemas cloudflare_schema_validation_schemas} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSchemaValidationSchemasConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareSchemaValidationSchemasConfig);
    get createdAt(): string;
    private _filter;
    get filter(): DataCloudflareSchemaValidationSchemasFilterOutputReference;
    putFilter(value: DataCloudflareSchemaValidationSchemasFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareSchemaValidationSchemasFilter | undefined;
    get id(): string;
    get kind(): string;
    get name(): string;
    private _omitSource?;
    get omitSource(): boolean | cdktn.IResolvable;
    set omitSource(value: boolean | cdktn.IResolvable);
    resetOmitSource(): void;
    get omitSourceInput(): boolean | cdktn.IResolvable | undefined;
    private _schemaId?;
    get schemaId(): string;
    set schemaId(value: string);
    resetSchemaId(): void;
    get schemaIdInput(): string | undefined;
    get source(): string;
    get validationEnabled(): cdktn.IResolvable;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
