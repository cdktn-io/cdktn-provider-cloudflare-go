/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDeviceDeploymentGroupsListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups_list#account_id DataCloudflareZeroTrustDeviceDeploymentGroupsList#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups_list#max_items DataCloudflareZeroTrustDeviceDeploymentGroupsList#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfig {
}
export declare function dataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfigToTerraform(struct?: DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfig): any;
export declare function dataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfigToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfig): any;
export declare class DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfig | undefined);
    get targetEnvironment(): string;
    get version(): string;
}
export declare class DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfigOutputReference;
}
export interface DataCloudflareZeroTrustDeviceDeploymentGroupsListResult {
}
export declare function dataCloudflareZeroTrustDeviceDeploymentGroupsListResultToTerraform(struct?: DataCloudflareZeroTrustDeviceDeploymentGroupsListResult): any;
export declare function dataCloudflareZeroTrustDeviceDeploymentGroupsListResultToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDeploymentGroupsListResult): any;
export declare class DataCloudflareZeroTrustDeviceDeploymentGroupsListResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceDeploymentGroupsListResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDeploymentGroupsListResult | undefined);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    get policyIds(): string[];
    get updatedAt(): string;
    private _versionConfig;
    get versionConfig(): DataCloudflareZeroTrustDeviceDeploymentGroupsListResultVersionConfigList;
}
export declare class DataCloudflareZeroTrustDeviceDeploymentGroupsListResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceDeploymentGroupsListResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups_list cloudflare_zero_trust_device_deployment_groups_list}
*/
export declare class DataCloudflareZeroTrustDeviceDeploymentGroupsList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_deployment_groups_list";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDeviceDeploymentGroupsList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDeviceDeploymentGroupsList to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDeviceDeploymentGroupsList that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDeviceDeploymentGroupsList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_deployment_groups_list cloudflare_zero_trust_device_deployment_groups_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDeviceDeploymentGroupsListConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDeviceDeploymentGroupsListConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDeviceDeploymentGroupsListResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
