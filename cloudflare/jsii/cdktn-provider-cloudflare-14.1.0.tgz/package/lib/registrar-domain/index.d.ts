/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RegistrarDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain#account_id RegistrarDomain#account_id}
    */
    readonly accountId: string;
    /**
    * Auto-renew controls whether subscription is automatically renewed upon domain expiration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain#auto_renew RegistrarDomain#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * Domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain#domain_name RegistrarDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Shows whether a registrar lock is in place for a domain.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain#locked RegistrarDomain#locked}
    */
    readonly locked?: boolean | cdktn.IResolvable;
    /**
    * Privacy option controls redacting WHOIS information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain#privacy RegistrarDomain#privacy}
    */
    readonly privacy?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain cloudflare_registrar_domain}
*/
export declare class RegistrarDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_registrar_domain";
    /**
    * Generates CDKTN code for importing a RegistrarDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RegistrarDomain to import
    * @param importFromId The id of the existing RegistrarDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RegistrarDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/registrar_domain cloudflare_registrar_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RegistrarDomainConfig
    */
    constructor(scope: Construct, id: string, config: RegistrarDomainConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _locked?;
    get locked(): boolean | cdktn.IResolvable;
    set locked(value: boolean | cdktn.IResolvable);
    resetLocked(): void;
    get lockedInput(): boolean | cdktn.IResolvable | undefined;
    private _privacy?;
    get privacy(): boolean | cdktn.IResolvable;
    set privacy(value: boolean | cdktn.IResolvable);
    resetPrivacy(): void;
    get privacyInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
