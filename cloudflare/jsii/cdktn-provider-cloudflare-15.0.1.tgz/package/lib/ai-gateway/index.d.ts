/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#account_id AiGateway#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#authentication AiGateway#authentication}
    */
    readonly authentication?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#cache_invalidate_on_update AiGateway#cache_invalidate_on_update}
    */
    readonly cacheInvalidateOnUpdate: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#cache_ttl AiGateway#cache_ttl}
    */
    readonly cacheTtl: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#collect_logs AiGateway#collect_logs}
    */
    readonly collectLogs: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#dlp AiGateway#dlp}
    */
    readonly dlp?: AiGatewayDlp;
    /**
    * gateway id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#id AiGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#log_management AiGateway#log_management}
    */
    readonly logManagement?: number;
    /**
    * Available values: "STOP_INSERTING", "DELETE_OLDEST".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#log_management_strategy AiGateway#log_management_strategy}
    */
    readonly logManagementStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#logpush AiGateway#logpush}
    */
    readonly logpush?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#logpush_public_key AiGateway#logpush_public_key}
    */
    readonly logpushPublicKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#otel AiGateway#otel}
    */
    readonly otel?: AiGatewayOtel[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#rate_limiting_interval AiGateway#rate_limiting_interval}
    */
    readonly rateLimitingInterval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#rate_limiting_limit AiGateway#rate_limiting_limit}
    */
    readonly rateLimitingLimit: number;
    /**
    * Available values: "fixed", "sliding".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#rate_limiting_technique AiGateway#rate_limiting_technique}
    */
    readonly rateLimitingTechnique?: string;
    /**
    * Backoff strategy for retry delays
    * Available values: "constant", "linear", "exponential".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#retry_backoff AiGateway#retry_backoff}
    */
    readonly retryBackoff?: string;
    /**
    * Delay between retry attempts in milliseconds (0-5000)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#retry_delay AiGateway#retry_delay}
    */
    readonly retryDelay?: number;
    /**
    * Maximum number of retry attempts for failed requests (1-5)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#retry_max_attempts AiGateway#retry_max_attempts}
    */
    readonly retryMaxAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#store_id AiGateway#store_id}
    */
    readonly storeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#stripe AiGateway#stripe}
    */
    readonly stripe?: AiGatewayStripe;
    /**
    * Controls how Workers AI inference calls routed through this gateway are billed. Only 'postpaid' is currently supported.
    * Available values: "postpaid".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#workers_ai_billing_mode AiGateway#workers_ai_billing_mode}
    */
    readonly workersAiBillingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#zdr AiGateway#zdr}
    */
    readonly zdr?: boolean | cdktn.IResolvable;
}
export interface AiGatewayDlpPolicies {
    /**
    * Available values: "FLAG", "BLOCK".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#action AiGateway#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#check AiGateway#check}
    */
    readonly check: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#enabled AiGateway#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#id AiGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#profiles AiGateway#profiles}
    */
    readonly profiles: string[];
}
export declare function aiGatewayDlpPoliciesToTerraform(struct?: AiGatewayDlpPolicies | cdktn.IResolvable): any;
export declare function aiGatewayDlpPoliciesToHclTerraform(struct?: AiGatewayDlpPolicies | cdktn.IResolvable): any;
export declare class AiGatewayDlpPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayDlpPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDlpPolicies | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _check?;
    get check(): string[];
    set check(value: string[]);
    get checkInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _profiles?;
    get profiles(): string[];
    set profiles(value: string[]);
    get profilesInput(): string[] | undefined;
}
export declare class AiGatewayDlpPoliciesList extends cdktn.ComplexList {
    internalValue?: AiGatewayDlpPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayDlpPoliciesOutputReference;
}
export interface AiGatewayDlp {
    /**
    * Available values: "BLOCK", "FLAG".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#action AiGateway#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#enabled AiGateway#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#policies AiGateway#policies}
    */
    readonly policies?: AiGatewayDlpPolicies[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#profiles AiGateway#profiles}
    */
    readonly profiles?: string[];
}
export declare function aiGatewayDlpToTerraform(struct?: AiGatewayDlp | cdktn.IResolvable): any;
export declare function aiGatewayDlpToHclTerraform(struct?: AiGatewayDlp | cdktn.IResolvable): any;
export declare class AiGatewayDlpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDlp | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDlp | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _policies;
    get policies(): AiGatewayDlpPoliciesList;
    putPolicies(value: AiGatewayDlpPolicies[] | cdktn.IResolvable): void;
    resetPolicies(): void;
    get policiesInput(): cdktn.IResolvable | AiGatewayDlpPolicies[] | undefined;
    private _profiles?;
    get profiles(): string[];
    set profiles(value: string[]);
    resetProfiles(): void;
    get profilesInput(): string[] | undefined;
}
export interface AiGatewayOtel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#authorization AiGateway#authorization}
    */
    readonly authorization: string;
    /**
    * Available values: "json", "protobuf".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#content_type AiGateway#content_type}
    */
    readonly contentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#headers AiGateway#headers}
    */
    readonly headers: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#url AiGateway#url}
    */
    readonly url: string;
}
export declare function aiGatewayOtelToTerraform(struct?: AiGatewayOtel | cdktn.IResolvable): any;
export declare function aiGatewayOtelToHclTerraform(struct?: AiGatewayOtel | cdktn.IResolvable): any;
export declare class AiGatewayOtelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayOtel | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayOtel | cdktn.IResolvable | undefined);
    private _authorization?;
    get authorization(): string;
    set authorization(value: string);
    get authorizationInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class AiGatewayOtelList extends cdktn.ComplexList {
    internalValue?: AiGatewayOtel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayOtelOutputReference;
}
export interface AiGatewayStripeUsageEvents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#payload AiGateway#payload}
    */
    readonly payload: string;
}
export declare function aiGatewayStripeUsageEventsToTerraform(struct?: AiGatewayStripeUsageEvents | cdktn.IResolvable): any;
export declare function aiGatewayStripeUsageEventsToHclTerraform(struct?: AiGatewayStripeUsageEvents | cdktn.IResolvable): any;
export declare class AiGatewayStripeUsageEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayStripeUsageEvents | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayStripeUsageEvents | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    get payloadInput(): string | undefined;
}
export declare class AiGatewayStripeUsageEventsList extends cdktn.ComplexList {
    internalValue?: AiGatewayStripeUsageEvents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayStripeUsageEventsOutputReference;
}
export interface AiGatewayStripe {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#authorization AiGateway#authorization}
    */
    readonly authorization: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#usage_events AiGateway#usage_events}
    */
    readonly usageEvents: AiGatewayStripeUsageEvents[] | cdktn.IResolvable;
}
export declare function aiGatewayStripeToTerraform(struct?: AiGatewayStripe | cdktn.IResolvable): any;
export declare function aiGatewayStripeToHclTerraform(struct?: AiGatewayStripe | cdktn.IResolvable): any;
export declare class AiGatewayStripeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayStripe | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayStripe | cdktn.IResolvable | undefined);
    private _authorization?;
    get authorization(): string;
    set authorization(value: string);
    get authorizationInput(): string | undefined;
    private _usageEvents;
    get usageEvents(): AiGatewayStripeUsageEventsList;
    putUsageEvents(value: AiGatewayStripeUsageEvents[] | cdktn.IResolvable): void;
    get usageEventsInput(): cdktn.IResolvable | AiGatewayStripeUsageEvents[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway cloudflare_ai_gateway}
*/
export declare class AiGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ai_gateway";
    /**
    * Generates CDKTN code for importing a AiGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiGateway to import
    * @param importFromId The id of the existing AiGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/ai_gateway cloudflare_ai_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiGatewayConfig
    */
    constructor(scope: Construct, id: string, config: AiGatewayConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _authentication?;
    get authentication(): boolean | cdktn.IResolvable;
    set authentication(value: boolean | cdktn.IResolvable);
    resetAuthentication(): void;
    get authenticationInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheInvalidateOnUpdate?;
    get cacheInvalidateOnUpdate(): boolean | cdktn.IResolvable;
    set cacheInvalidateOnUpdate(value: boolean | cdktn.IResolvable);
    get cacheInvalidateOnUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheTtl?;
    get cacheTtl(): number;
    set cacheTtl(value: number);
    get cacheTtlInput(): number | undefined;
    private _collectLogs?;
    get collectLogs(): boolean | cdktn.IResolvable;
    set collectLogs(value: boolean | cdktn.IResolvable);
    get collectLogsInput(): boolean | cdktn.IResolvable | undefined;
    get createdAt(): string;
    private _dlp;
    get dlp(): AiGatewayDlpOutputReference;
    putDlp(value: AiGatewayDlp): void;
    resetDlp(): void;
    get dlpInput(): cdktn.IResolvable | AiGatewayDlp | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get isDefault(): cdktn.IResolvable;
    private _logManagement?;
    get logManagement(): number;
    set logManagement(value: number);
    resetLogManagement(): void;
    get logManagementInput(): number | undefined;
    private _logManagementStrategy?;
    get logManagementStrategy(): string;
    set logManagementStrategy(value: string);
    resetLogManagementStrategy(): void;
    get logManagementStrategyInput(): string | undefined;
    private _logpush?;
    get logpush(): boolean | cdktn.IResolvable;
    set logpush(value: boolean | cdktn.IResolvable);
    resetLogpush(): void;
    get logpushInput(): boolean | cdktn.IResolvable | undefined;
    private _logpushPublicKey?;
    get logpushPublicKey(): string;
    set logpushPublicKey(value: string);
    resetLogpushPublicKey(): void;
    get logpushPublicKeyInput(): string | undefined;
    get modifiedAt(): string;
    private _otel;
    get otel(): AiGatewayOtelList;
    putOtel(value: AiGatewayOtel[] | cdktn.IResolvable): void;
    resetOtel(): void;
    get otelInput(): cdktn.IResolvable | AiGatewayOtel[] | undefined;
    private _rateLimitingInterval?;
    get rateLimitingInterval(): number;
    set rateLimitingInterval(value: number);
    get rateLimitingIntervalInput(): number | undefined;
    private _rateLimitingLimit?;
    get rateLimitingLimit(): number;
    set rateLimitingLimit(value: number);
    get rateLimitingLimitInput(): number | undefined;
    private _rateLimitingTechnique?;
    get rateLimitingTechnique(): string;
    set rateLimitingTechnique(value: string);
    resetRateLimitingTechnique(): void;
    get rateLimitingTechniqueInput(): string | undefined;
    private _retryBackoff?;
    get retryBackoff(): string;
    set retryBackoff(value: string);
    resetRetryBackoff(): void;
    get retryBackoffInput(): string | undefined;
    private _retryDelay?;
    get retryDelay(): number;
    set retryDelay(value: number);
    resetRetryDelay(): void;
    get retryDelayInput(): number | undefined;
    private _retryMaxAttempts?;
    get retryMaxAttempts(): number;
    set retryMaxAttempts(value: number);
    resetRetryMaxAttempts(): void;
    get retryMaxAttemptsInput(): number | undefined;
    private _storeId?;
    get storeId(): string;
    set storeId(value: string);
    resetStoreId(): void;
    get storeIdInput(): string | undefined;
    private _stripe;
    get stripe(): AiGatewayStripeOutputReference;
    putStripe(value: AiGatewayStripe): void;
    resetStripe(): void;
    get stripeInput(): cdktn.IResolvable | AiGatewayStripe | undefined;
    private _workersAiBillingMode?;
    get workersAiBillingMode(): string;
    set workersAiBillingMode(value: string);
    resetWorkersAiBillingMode(): void;
    get workersAiBillingModeInput(): string | undefined;
    private _zdr?;
    get zdr(): boolean | cdktn.IResolvable;
    set zdr(value: boolean | cdktn.IResolvable);
    resetZdr(): void;
    get zdrInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
