/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAiGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/ai_gateway#account_id DataCloudflareAiGateway#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/ai_gateway#filter DataCloudflareAiGateway#filter}
    */
    readonly filter?: DataCloudflareAiGatewayFilter;
    /**
    * gateway id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/ai_gateway#id DataCloudflareAiGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataCloudflareAiGatewayDlpPolicies {
}
export declare function dataCloudflareAiGatewayDlpPoliciesToTerraform(struct?: DataCloudflareAiGatewayDlpPolicies): any;
export declare function dataCloudflareAiGatewayDlpPoliciesToHclTerraform(struct?: DataCloudflareAiGatewayDlpPolicies): any;
export declare class DataCloudflareAiGatewayDlpPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewayDlpPolicies | undefined;
    set internalValue(value: DataCloudflareAiGatewayDlpPolicies | undefined);
    get action(): string;
    get check(): string[];
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get profiles(): string[];
}
export declare class DataCloudflareAiGatewayDlpPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewayDlpPoliciesOutputReference;
}
export interface DataCloudflareAiGatewayDlp {
}
export declare function dataCloudflareAiGatewayDlpToTerraform(struct?: DataCloudflareAiGatewayDlp): any;
export declare function dataCloudflareAiGatewayDlpToHclTerraform(struct?: DataCloudflareAiGatewayDlp): any;
export declare class DataCloudflareAiGatewayDlpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayDlp | undefined;
    set internalValue(value: DataCloudflareAiGatewayDlp | undefined);
    get action(): string;
    get enabled(): cdktn.IResolvable;
    private _policies;
    get policies(): DataCloudflareAiGatewayDlpPoliciesList;
    get profiles(): string[];
}
export interface DataCloudflareAiGatewayFilter {
    /**
    * Search by id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/ai_gateway#search DataCloudflareAiGateway#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareAiGatewayFilterToTerraform(struct?: DataCloudflareAiGatewayFilter | cdktn.IResolvable): any;
export declare function dataCloudflareAiGatewayFilterToHclTerraform(struct?: DataCloudflareAiGatewayFilter | cdktn.IResolvable): any;
export declare class DataCloudflareAiGatewayFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareAiGatewayFilter | cdktn.IResolvable | undefined);
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
export interface DataCloudflareAiGatewayGuardrailsPrompt {
}
export declare function dataCloudflareAiGatewayGuardrailsPromptToTerraform(struct?: DataCloudflareAiGatewayGuardrailsPrompt): any;
export declare function dataCloudflareAiGatewayGuardrailsPromptToHclTerraform(struct?: DataCloudflareAiGatewayGuardrailsPrompt): any;
export declare class DataCloudflareAiGatewayGuardrailsPromptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayGuardrailsPrompt | undefined;
    set internalValue(value: DataCloudflareAiGatewayGuardrailsPrompt | undefined);
    get p1(): string;
    get s1(): string;
    get s10(): string;
    get s11(): string;
    get s12(): string;
    get s13(): string;
    get s2(): string;
    get s3(): string;
    get s4(): string;
    get s5(): string;
    get s6(): string;
    get s7(): string;
    get s8(): string;
    get s9(): string;
}
export interface DataCloudflareAiGatewayGuardrailsResponse {
}
export declare function dataCloudflareAiGatewayGuardrailsResponseToTerraform(struct?: DataCloudflareAiGatewayGuardrailsResponse): any;
export declare function dataCloudflareAiGatewayGuardrailsResponseToHclTerraform(struct?: DataCloudflareAiGatewayGuardrailsResponse): any;
export declare class DataCloudflareAiGatewayGuardrailsResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayGuardrailsResponse | undefined;
    set internalValue(value: DataCloudflareAiGatewayGuardrailsResponse | undefined);
    get p1(): string;
    get s1(): string;
    get s10(): string;
    get s11(): string;
    get s12(): string;
    get s13(): string;
    get s2(): string;
    get s3(): string;
    get s4(): string;
    get s5(): string;
    get s6(): string;
    get s7(): string;
    get s8(): string;
    get s9(): string;
}
export interface DataCloudflareAiGatewayGuardrails {
}
export declare function dataCloudflareAiGatewayGuardrailsToTerraform(struct?: DataCloudflareAiGatewayGuardrails): any;
export declare function dataCloudflareAiGatewayGuardrailsToHclTerraform(struct?: DataCloudflareAiGatewayGuardrails): any;
export declare class DataCloudflareAiGatewayGuardrailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayGuardrails | undefined;
    set internalValue(value: DataCloudflareAiGatewayGuardrails | undefined);
    private _prompt;
    get prompt(): DataCloudflareAiGatewayGuardrailsPromptOutputReference;
    private _response;
    get response(): DataCloudflareAiGatewayGuardrailsResponseOutputReference;
}
export interface DataCloudflareAiGatewayOtel {
}
export declare function dataCloudflareAiGatewayOtelToTerraform(struct?: DataCloudflareAiGatewayOtel): any;
export declare function dataCloudflareAiGatewayOtelToHclTerraform(struct?: DataCloudflareAiGatewayOtel): any;
export declare class DataCloudflareAiGatewayOtelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewayOtel | undefined;
    set internalValue(value: DataCloudflareAiGatewayOtel | undefined);
    get authorization(): string;
    get contentType(): string;
    private _headers;
    get headers(): cdktn.StringMap;
    get url(): string;
}
export declare class DataCloudflareAiGatewayOtelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewayOtelOutputReference;
}
export interface DataCloudflareAiGatewaySpendLimitsRulesAiGatewayProvider {
}
export declare function dataCloudflareAiGatewaySpendLimitsRulesAiGatewayProviderToTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRulesAiGatewayProvider): any;
export declare function dataCloudflareAiGatewaySpendLimitsRulesAiGatewayProviderToHclTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRulesAiGatewayProvider): any;
export declare class DataCloudflareAiGatewaySpendLimitsRulesAiGatewayProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaySpendLimitsRulesAiGatewayProvider | undefined;
    set internalValue(value: DataCloudflareAiGatewaySpendLimitsRulesAiGatewayProvider | undefined);
    get mode(): string;
    get values(): string[];
}
export interface DataCloudflareAiGatewaySpendLimitsRulesMetadata {
}
export declare function dataCloudflareAiGatewaySpendLimitsRulesMetadataToTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRulesMetadata): any;
export declare function dataCloudflareAiGatewaySpendLimitsRulesMetadataToHclTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRulesMetadata): any;
export declare class DataCloudflareAiGatewaySpendLimitsRulesMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflareAiGatewaySpendLimitsRulesMetadata | undefined;
    set internalValue(value: DataCloudflareAiGatewaySpendLimitsRulesMetadata | undefined);
    get mode(): string;
    get values(): string[];
}
export declare class DataCloudflareAiGatewaySpendLimitsRulesMetadataMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflareAiGatewaySpendLimitsRulesMetadataOutputReference;
}
export interface DataCloudflareAiGatewaySpendLimitsRulesModel {
}
export declare function dataCloudflareAiGatewaySpendLimitsRulesModelToTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRulesModel): any;
export declare function dataCloudflareAiGatewaySpendLimitsRulesModelToHclTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRulesModel): any;
export declare class DataCloudflareAiGatewaySpendLimitsRulesModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaySpendLimitsRulesModel | undefined;
    set internalValue(value: DataCloudflareAiGatewaySpendLimitsRulesModel | undefined);
    get mode(): string;
    get values(): string[];
}
export interface DataCloudflareAiGatewaySpendLimitsRules {
}
export declare function dataCloudflareAiGatewaySpendLimitsRulesToTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRules): any;
export declare function dataCloudflareAiGatewaySpendLimitsRulesToHclTerraform(struct?: DataCloudflareAiGatewaySpendLimitsRules): any;
export declare class DataCloudflareAiGatewaySpendLimitsRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewaySpendLimitsRules | undefined;
    set internalValue(value: DataCloudflareAiGatewaySpendLimitsRules | undefined);
    private _aiGatewayProvider;
    get aiGatewayProvider(): DataCloudflareAiGatewaySpendLimitsRulesAiGatewayProviderOutputReference;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get limit(): number;
    get limitType(): string;
    private _metadata;
    get metadata(): DataCloudflareAiGatewaySpendLimitsRulesMetadataMap;
    private _model;
    get model(): DataCloudflareAiGatewaySpendLimitsRulesModelOutputReference;
    get technique(): string;
    get window(): number;
}
export declare class DataCloudflareAiGatewaySpendLimitsRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewaySpendLimitsRulesOutputReference;
}
export interface DataCloudflareAiGatewaySpendLimits {
}
export declare function dataCloudflareAiGatewaySpendLimitsToTerraform(struct?: DataCloudflareAiGatewaySpendLimits): any;
export declare function dataCloudflareAiGatewaySpendLimitsToHclTerraform(struct?: DataCloudflareAiGatewaySpendLimits): any;
export declare class DataCloudflareAiGatewaySpendLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaySpendLimits | undefined;
    set internalValue(value: DataCloudflareAiGatewaySpendLimits | undefined);
    get enabled(): cdktn.IResolvable;
    private _rules;
    get rules(): DataCloudflareAiGatewaySpendLimitsRulesList;
}
export interface DataCloudflareAiGatewayStripeUsageEvents {
}
export declare function dataCloudflareAiGatewayStripeUsageEventsToTerraform(struct?: DataCloudflareAiGatewayStripeUsageEvents): any;
export declare function dataCloudflareAiGatewayStripeUsageEventsToHclTerraform(struct?: DataCloudflareAiGatewayStripeUsageEvents): any;
export declare class DataCloudflareAiGatewayStripeUsageEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewayStripeUsageEvents | undefined;
    set internalValue(value: DataCloudflareAiGatewayStripeUsageEvents | undefined);
    get payload(): string;
}
export declare class DataCloudflareAiGatewayStripeUsageEventsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewayStripeUsageEventsOutputReference;
}
export interface DataCloudflareAiGatewayStripe {
}
export declare function dataCloudflareAiGatewayStripeToTerraform(struct?: DataCloudflareAiGatewayStripe): any;
export declare function dataCloudflareAiGatewayStripeToHclTerraform(struct?: DataCloudflareAiGatewayStripe): any;
export declare class DataCloudflareAiGatewayStripeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewayStripe | undefined;
    set internalValue(value: DataCloudflareAiGatewayStripe | undefined);
    get authorization(): string;
    private _usageEvents;
    get usageEvents(): DataCloudflareAiGatewayStripeUsageEventsList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/ai_gateway cloudflare_ai_gateway}
*/
export declare class DataCloudflareAiGateway extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ai_gateway";
    /**
    * Generates CDKTN code for importing a DataCloudflareAiGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAiGateway to import
    * @param importFromId The id of the existing DataCloudflareAiGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/ai_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAiGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/ai_gateway cloudflare_ai_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAiGatewayConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareAiGatewayConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get authentication(): cdktn.IResolvable;
    get cacheInvalidateOnUpdate(): cdktn.IResolvable;
    get cacheTtl(): number;
    get collectLogs(): cdktn.IResolvable;
    get createdAt(): string;
    private _dlp;
    get dlp(): DataCloudflareAiGatewayDlpOutputReference;
    private _filter;
    get filter(): DataCloudflareAiGatewayFilterOutputReference;
    putFilter(value: DataCloudflareAiGatewayFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareAiGatewayFilter | undefined;
    private _guardrails;
    get guardrails(): DataCloudflareAiGatewayGuardrailsOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isDefault(): cdktn.IResolvable;
    get logManagement(): number;
    get logManagementStrategy(): string;
    get logpush(): cdktn.IResolvable;
    get logpushPublicKey(): string;
    get modifiedAt(): string;
    private _otel;
    get otel(): DataCloudflareAiGatewayOtelList;
    get rateLimitingInterval(): number;
    get rateLimitingLimit(): number;
    get rateLimitingTechnique(): string;
    get retryBackoff(): string;
    get retryDelay(): number;
    get retryMaxAttempts(): number;
    private _spendLimits;
    get spendLimits(): DataCloudflareAiGatewaySpendLimitsOutputReference;
    get storeId(): string;
    private _stripe;
    get stripe(): DataCloudflareAiGatewayStripeOutputReference;
    get workersAiBillingMode(): string;
    get zdr(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
