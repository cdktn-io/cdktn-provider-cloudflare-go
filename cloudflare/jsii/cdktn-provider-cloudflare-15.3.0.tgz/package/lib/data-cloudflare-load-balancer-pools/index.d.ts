/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareLoadBalancerPoolsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/load_balancer_pools#account_id DataCloudflareLoadBalancerPools#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/load_balancer_pools#max_items DataCloudflareLoadBalancerPools#max_items}
    */
    readonly maxItems?: number;
    /**
    * The ID of the Monitor to use for checking the health of origins within this pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/load_balancer_pools#monitor DataCloudflareLoadBalancerPools#monitor}
    */
    readonly monitor?: string;
}
export interface DataCloudflareLoadBalancerPoolsResultLoadShedding {
}
export declare function dataCloudflareLoadBalancerPoolsResultLoadSheddingToTerraform(struct?: DataCloudflareLoadBalancerPoolsResultLoadShedding): any;
export declare function dataCloudflareLoadBalancerPoolsResultLoadSheddingToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResultLoadShedding): any;
export declare class DataCloudflareLoadBalancerPoolsResultLoadSheddingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerPoolsResultLoadShedding | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResultLoadShedding | undefined);
    get defaultPercent(): number;
    get defaultPolicy(): string;
    get sessionPercent(): number;
    get sessionPolicy(): string;
}
export interface DataCloudflareLoadBalancerPoolsResultNotificationFilterOrigin {
}
export declare function dataCloudflareLoadBalancerPoolsResultNotificationFilterOriginToTerraform(struct?: DataCloudflareLoadBalancerPoolsResultNotificationFilterOrigin): any;
export declare function dataCloudflareLoadBalancerPoolsResultNotificationFilterOriginToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResultNotificationFilterOrigin): any;
export declare class DataCloudflareLoadBalancerPoolsResultNotificationFilterOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerPoolsResultNotificationFilterOrigin | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResultNotificationFilterOrigin | undefined);
    get disable(): cdktn.IResolvable;
    get healthy(): cdktn.IResolvable;
}
export interface DataCloudflareLoadBalancerPoolsResultNotificationFilterPool {
}
export declare function dataCloudflareLoadBalancerPoolsResultNotificationFilterPoolToTerraform(struct?: DataCloudflareLoadBalancerPoolsResultNotificationFilterPool): any;
export declare function dataCloudflareLoadBalancerPoolsResultNotificationFilterPoolToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResultNotificationFilterPool): any;
export declare class DataCloudflareLoadBalancerPoolsResultNotificationFilterPoolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerPoolsResultNotificationFilterPool | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResultNotificationFilterPool | undefined);
    get disable(): cdktn.IResolvable;
    get healthy(): cdktn.IResolvable;
}
export interface DataCloudflareLoadBalancerPoolsResultNotificationFilter {
}
export declare function dataCloudflareLoadBalancerPoolsResultNotificationFilterToTerraform(struct?: DataCloudflareLoadBalancerPoolsResultNotificationFilter): any;
export declare function dataCloudflareLoadBalancerPoolsResultNotificationFilterToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResultNotificationFilter): any;
export declare class DataCloudflareLoadBalancerPoolsResultNotificationFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerPoolsResultNotificationFilter | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResultNotificationFilter | undefined);
    private _origin;
    get origin(): DataCloudflareLoadBalancerPoolsResultNotificationFilterOriginOutputReference;
    private _pool;
    get pool(): DataCloudflareLoadBalancerPoolsResultNotificationFilterPoolOutputReference;
}
export interface DataCloudflareLoadBalancerPoolsResultOriginSteering {
}
export declare function dataCloudflareLoadBalancerPoolsResultOriginSteeringToTerraform(struct?: DataCloudflareLoadBalancerPoolsResultOriginSteering): any;
export declare function dataCloudflareLoadBalancerPoolsResultOriginSteeringToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResultOriginSteering): any;
export declare class DataCloudflareLoadBalancerPoolsResultOriginSteeringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerPoolsResultOriginSteering | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResultOriginSteering | undefined);
    get policy(): string;
}
export interface DataCloudflareLoadBalancerPoolsResultOriginsHeader {
}
export declare function dataCloudflareLoadBalancerPoolsResultOriginsHeaderToTerraform(struct?: DataCloudflareLoadBalancerPoolsResultOriginsHeader): any;
export declare function dataCloudflareLoadBalancerPoolsResultOriginsHeaderToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResultOriginsHeader): any;
export declare class DataCloudflareLoadBalancerPoolsResultOriginsHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareLoadBalancerPoolsResultOriginsHeader | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResultOriginsHeader | undefined);
    get host(): string[];
}
export interface DataCloudflareLoadBalancerPoolsResultOrigins {
}
export declare function dataCloudflareLoadBalancerPoolsResultOriginsToTerraform(struct?: DataCloudflareLoadBalancerPoolsResultOrigins): any;
export declare function dataCloudflareLoadBalancerPoolsResultOriginsToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResultOrigins): any;
export declare class DataCloudflareLoadBalancerPoolsResultOriginsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerPoolsResultOrigins | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResultOrigins | undefined);
    get address(): string;
    get disabledAt(): string;
    get enabled(): cdktn.IResolvable;
    get flattenCname(): cdktn.IResolvable;
    private _header;
    get header(): DataCloudflareLoadBalancerPoolsResultOriginsHeaderOutputReference;
    get name(): string;
    get port(): number;
    get virtualNetworkId(): string;
    get weight(): number;
}
export declare class DataCloudflareLoadBalancerPoolsResultOriginsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerPoolsResultOriginsOutputReference;
}
export interface DataCloudflareLoadBalancerPoolsResult {
}
export declare function dataCloudflareLoadBalancerPoolsResultToTerraform(struct?: DataCloudflareLoadBalancerPoolsResult): any;
export declare function dataCloudflareLoadBalancerPoolsResultToHclTerraform(struct?: DataCloudflareLoadBalancerPoolsResult): any;
export declare class DataCloudflareLoadBalancerPoolsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareLoadBalancerPoolsResult | undefined;
    set internalValue(value: DataCloudflareLoadBalancerPoolsResult | undefined);
    get checkRegions(): string[];
    get createdOn(): string;
    get description(): string;
    get disabledAt(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get latitude(): number;
    private _loadShedding;
    get loadShedding(): DataCloudflareLoadBalancerPoolsResultLoadSheddingOutputReference;
    get longitude(): number;
    get minimumOrigins(): number;
    get modifiedOn(): string;
    get monitor(): string;
    get monitorGroup(): string;
    get name(): string;
    get networks(): string[];
    get notificationEmail(): string;
    private _notificationFilter;
    get notificationFilter(): DataCloudflareLoadBalancerPoolsResultNotificationFilterOutputReference;
    private _originSteering;
    get originSteering(): DataCloudflareLoadBalancerPoolsResultOriginSteeringOutputReference;
    private _origins;
    get origins(): DataCloudflareLoadBalancerPoolsResultOriginsList;
}
export declare class DataCloudflareLoadBalancerPoolsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareLoadBalancerPoolsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/load_balancer_pools cloudflare_load_balancer_pools}
*/
export declare class DataCloudflareLoadBalancerPools extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_load_balancer_pools";
    /**
    * Generates CDKTN code for importing a DataCloudflareLoadBalancerPools resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareLoadBalancerPools to import
    * @param importFromId The id of the existing DataCloudflareLoadBalancerPools that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/load_balancer_pools#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareLoadBalancerPools to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/load_balancer_pools cloudflare_load_balancer_pools} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareLoadBalancerPoolsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareLoadBalancerPoolsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _monitor?;
    get monitor(): string;
    set monitor(value: string);
    resetMonitor(): void;
    get monitorInput(): string | undefined;
    private _result;
    get result(): DataCloudflareLoadBalancerPoolsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
