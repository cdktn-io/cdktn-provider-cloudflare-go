/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAccountSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_subscription#account_id DataCloudflareAccountSubscription#account_id}
    */
    readonly accountId?: string;
}
export interface DataCloudflareAccountSubscriptionRatePlan {
}
export declare function dataCloudflareAccountSubscriptionRatePlanToTerraform(struct?: DataCloudflareAccountSubscriptionRatePlan): any;
export declare function dataCloudflareAccountSubscriptionRatePlanToHclTerraform(struct?: DataCloudflareAccountSubscriptionRatePlan): any;
export declare class DataCloudflareAccountSubscriptionRatePlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountSubscriptionRatePlan | undefined;
    set internalValue(value: DataCloudflareAccountSubscriptionRatePlan | undefined);
    get currency(): string;
    get externallyManaged(): cdktn.IResolvable;
    get id(): string;
    get isContract(): cdktn.IResolvable;
    get publicName(): string;
    get scope(): string;
    get sets(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_subscription cloudflare_account_subscription}
*/
export declare class DataCloudflareAccountSubscription extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_account_subscription";
    /**
    * Generates CDKTN code for importing a DataCloudflareAccountSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAccountSubscription to import
    * @param importFromId The id of the existing DataCloudflareAccountSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAccountSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/account_subscription cloudflare_account_subscription} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAccountSubscriptionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareAccountSubscriptionConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get currency(): string;
    get currentPeriodEnd(): string;
    get currentPeriodStart(): string;
    get frequency(): string;
    get id(): string;
    get price(): number;
    private _ratePlan;
    get ratePlan(): DataCloudflareAccountSubscriptionRatePlanOutputReference;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
