/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_organization#account_id DataCloudflareZeroTrustOrganization#account_id}
    */
    readonly accountId?: string;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_organization#zone_id DataCloudflareZeroTrustOrganization#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareZeroTrustOrganizationCustomPages {
}
export declare function dataCloudflareZeroTrustOrganizationCustomPagesToTerraform(struct?: DataCloudflareZeroTrustOrganizationCustomPages): any;
export declare function dataCloudflareZeroTrustOrganizationCustomPagesToHclTerraform(struct?: DataCloudflareZeroTrustOrganizationCustomPages): any;
export declare class DataCloudflareZeroTrustOrganizationCustomPagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustOrganizationCustomPages | undefined;
    set internalValue(value: DataCloudflareZeroTrustOrganizationCustomPages | undefined);
    get forbidden(): string;
    get identityDenied(): string;
}
export interface DataCloudflareZeroTrustOrganizationLoginDesign {
}
export declare function dataCloudflareZeroTrustOrganizationLoginDesignToTerraform(struct?: DataCloudflareZeroTrustOrganizationLoginDesign): any;
export declare function dataCloudflareZeroTrustOrganizationLoginDesignToHclTerraform(struct?: DataCloudflareZeroTrustOrganizationLoginDesign): any;
export declare class DataCloudflareZeroTrustOrganizationLoginDesignOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustOrganizationLoginDesign | undefined;
    set internalValue(value: DataCloudflareZeroTrustOrganizationLoginDesign | undefined);
    get backgroundColor(): string;
    get footerText(): string;
    get headerText(): string;
    get logoPath(): string;
    get textColor(): string;
}
export interface DataCloudflareZeroTrustOrganizationMfaConfig {
}
export declare function dataCloudflareZeroTrustOrganizationMfaConfigToTerraform(struct?: DataCloudflareZeroTrustOrganizationMfaConfig): any;
export declare function dataCloudflareZeroTrustOrganizationMfaConfigToHclTerraform(struct?: DataCloudflareZeroTrustOrganizationMfaConfig): any;
export declare class DataCloudflareZeroTrustOrganizationMfaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustOrganizationMfaConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustOrganizationMfaConfig | undefined);
    get allowedAuthenticators(): string[];
    get amrMatchingSessionDuration(): string;
    get requiredAaguids(): string;
    get sessionDuration(): string;
}
export interface DataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirements {
}
export declare function dataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirementsToTerraform(struct?: DataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirements): any;
export declare function dataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirementsToHclTerraform(struct?: DataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirements): any;
export declare class DataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirements | undefined;
    set internalValue(value: DataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirements | undefined);
    get pinPolicy(): string;
    get requireFipsDevice(): cdktn.IResolvable;
    get sshKeySize(): number[];
    get sshKeyType(): string[];
    get touchPolicy(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_organization cloudflare_zero_trust_organization}
*/
export declare class DataCloudflareZeroTrustOrganization extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_organization";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustOrganization to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_organization cloudflare_zero_trust_organization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustOrganizationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustOrganizationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get allowAuthenticateViaWarp(): cdktn.IResolvable;
    get authDomain(): string;
    get autoRedirectToIdentity(): cdktn.IResolvable;
    private _customPages;
    get customPages(): DataCloudflareZeroTrustOrganizationCustomPagesOutputReference;
    get denyUnmatchedRequests(): cdktn.IResolvable;
    get denyUnmatchedRequestsExemptedZoneNames(): string[];
    get isUiReadOnly(): cdktn.IResolvable;
    private _loginDesign;
    get loginDesign(): DataCloudflareZeroTrustOrganizationLoginDesignOutputReference;
    private _mfaConfig;
    get mfaConfig(): DataCloudflareZeroTrustOrganizationMfaConfigOutputReference;
    get mfaRequiredForAllApps(): cdktn.IResolvable;
    private _mfaSshPivKeyRequirements;
    get mfaSshPivKeyRequirements(): DataCloudflareZeroTrustOrganizationMfaSshPivKeyRequirementsOutputReference;
    get name(): string;
    get sessionDuration(): string;
    get uiReadOnlyToggleReason(): string;
    get userSeatExpirationInactiveTime(): string;
    get warpAuthSessionDuration(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
