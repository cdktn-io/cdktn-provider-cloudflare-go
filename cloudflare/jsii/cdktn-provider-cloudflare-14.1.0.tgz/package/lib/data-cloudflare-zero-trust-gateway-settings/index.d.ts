/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustGatewaySettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_gateway_settings#account_id DataCloudflareZeroTrustGatewaySettings#account_id}
    */
    readonly accountId: string;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsActivityLog {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsActivityLogToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsActivityLog): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsActivityLogToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsActivityLog): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsActivityLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsActivityLog | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsActivityLog | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettings {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettingsToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettings): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettingsToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettings): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettings | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettings | undefined);
    get enabled(): cdktn.IResolvable;
    get includeContext(): cdktn.IResolvable;
    get msg(): string;
    get supportUrl(): string;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsAntivirus {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsAntivirusToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsAntivirus): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsAntivirusToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsAntivirus): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsAntivirus | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsAntivirus | undefined);
    get enabledDownloadPhase(): cdktn.IResolvable;
    get enabledUploadPhase(): cdktn.IResolvable;
    get failClosed(): cdktn.IResolvable;
    private _notificationSettings;
    get notificationSettings(): DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusNotificationSettingsOutputReference;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsBlockPage {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsBlockPageToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsBlockPage): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsBlockPageToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsBlockPage): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsBlockPageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsBlockPage | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsBlockPage | undefined);
    get backgroundColor(): string;
    get enabled(): cdktn.IResolvable;
    get footerText(): string;
    get headerText(): string;
    get includeContext(): cdktn.IResolvable;
    get logoPath(): string;
    get mailtoAddress(): string;
    get mailtoSubject(): string;
    get mode(): string;
    get name(): string;
    get readOnly(): cdktn.IResolvable;
    get sourceAccount(): string;
    get suppressFooter(): cdktn.IResolvable;
    get targetUri(): string;
    get version(): number;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsBodyScanning {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsBodyScanningToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsBodyScanning): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsBodyScanningToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsBodyScanning): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsBodyScanningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsBodyScanning | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsBodyScanning | undefined);
    get inspectionMode(): string;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolation {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolationToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolation): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolationToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolation): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolation | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolation | undefined);
    get nonIdentityEnabled(): cdktn.IResolvable;
    get urlBrowserIsolationEnabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsCertificate {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsCertificateToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsCertificate): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsCertificateToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsCertificate): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsCertificate | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsCertificate | undefined);
    get id(): string;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificate {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificateToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificate): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificateToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificate): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificate | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificate | undefined);
    get bindingStatus(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get updatedAt(): string;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatching {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatchingToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatching): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatchingToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatching): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatchingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatching | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatching | undefined);
    get enabled(): cdktn.IResolvable;
    get readOnly(): cdktn.IResolvable;
    get sourceAccount(): string;
    get version(): number;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsFips {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsFipsToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsFips): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsFipsToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsFips): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsFipsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsFips | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsFips | undefined);
    get tls(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsHostSelector {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsHostSelectorToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsHostSelector): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsHostSelectorToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsHostSelector): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsHostSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsHostSelector | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsHostSelector | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsInspection {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsInspectionToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsInspection): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsInspectionToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsInspection): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsInspectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsInspection | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsInspection | undefined);
    get mode(): string;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetection {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetectionToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetection): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetectionToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetection): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetection | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetection | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsSandbox {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsSandboxToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsSandbox): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsSandboxToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsSandbox): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsSandboxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsSandbox | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsSandbox | undefined);
    get enabled(): cdktn.IResolvable;
    get fallbackAction(): string;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettingsTlsDecrypt {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsTlsDecryptToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsTlsDecrypt): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsTlsDecryptToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettingsTlsDecrypt): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsTlsDecryptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettingsTlsDecrypt | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettingsTlsDecrypt | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustGatewaySettingsSettings {
}
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsToTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettings): any;
export declare function dataCloudflareZeroTrustGatewaySettingsSettingsToHclTerraform(struct?: DataCloudflareZeroTrustGatewaySettingsSettings): any;
export declare class DataCloudflareZeroTrustGatewaySettingsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustGatewaySettingsSettings | undefined;
    set internalValue(value: DataCloudflareZeroTrustGatewaySettingsSettings | undefined);
    private _activityLog;
    get activityLog(): DataCloudflareZeroTrustGatewaySettingsSettingsActivityLogOutputReference;
    private _antivirus;
    get antivirus(): DataCloudflareZeroTrustGatewaySettingsSettingsAntivirusOutputReference;
    private _blockPage;
    get blockPage(): DataCloudflareZeroTrustGatewaySettingsSettingsBlockPageOutputReference;
    private _bodyScanning;
    get bodyScanning(): DataCloudflareZeroTrustGatewaySettingsSettingsBodyScanningOutputReference;
    private _browserIsolation;
    get browserIsolation(): DataCloudflareZeroTrustGatewaySettingsSettingsBrowserIsolationOutputReference;
    private _certificate;
    get certificate(): DataCloudflareZeroTrustGatewaySettingsSettingsCertificateOutputReference;
    private _customCertificate;
    get customCertificate(): DataCloudflareZeroTrustGatewaySettingsSettingsCustomCertificateOutputReference;
    private _extendedEmailMatching;
    get extendedEmailMatching(): DataCloudflareZeroTrustGatewaySettingsSettingsExtendedEmailMatchingOutputReference;
    private _fips;
    get fips(): DataCloudflareZeroTrustGatewaySettingsSettingsFipsOutputReference;
    private _hostSelector;
    get hostSelector(): DataCloudflareZeroTrustGatewaySettingsSettingsHostSelectorOutputReference;
    private _inspection;
    get inspection(): DataCloudflareZeroTrustGatewaySettingsSettingsInspectionOutputReference;
    private _protocolDetection;
    get protocolDetection(): DataCloudflareZeroTrustGatewaySettingsSettingsProtocolDetectionOutputReference;
    private _sandbox;
    get sandbox(): DataCloudflareZeroTrustGatewaySettingsSettingsSandboxOutputReference;
    private _tlsDecrypt;
    get tlsDecrypt(): DataCloudflareZeroTrustGatewaySettingsSettingsTlsDecryptOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_gateway_settings cloudflare_zero_trust_gateway_settings}
*/
export declare class DataCloudflareZeroTrustGatewaySettings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_gateway_settings";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustGatewaySettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustGatewaySettings to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustGatewaySettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_gateway_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustGatewaySettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_gateway_settings cloudflare_zero_trust_gateway_settings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustGatewaySettingsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustGatewaySettingsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get id(): string;
    private _settings;
    get settings(): DataCloudflareZeroTrustGatewaySettingsSettingsOutputReference;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
