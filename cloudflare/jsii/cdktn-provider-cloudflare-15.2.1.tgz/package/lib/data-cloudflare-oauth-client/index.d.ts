/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareOauthClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/oauth_client#account_id DataCloudflareOauthClient#account_id}
    */
    readonly accountId: string;
    /**
    * The unique identifier for an OAuth client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/oauth_client#oauth_client_id DataCloudflareOauthClient#oauth_client_id}
    */
    readonly oauthClientId: string;
}
export interface DataCloudflareOauthClientClientUriVerification {
}
export declare function dataCloudflareOauthClientClientUriVerificationToTerraform(struct?: DataCloudflareOauthClientClientUriVerification): any;
export declare function dataCloudflareOauthClientClientUriVerificationToHclTerraform(struct?: DataCloudflareOauthClientClientUriVerification): any;
export declare class DataCloudflareOauthClientClientUriVerificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareOauthClientClientUriVerification | undefined;
    set internalValue(value: DataCloudflareOauthClientClientUriVerification | undefined);
    get status(): string;
    get text(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/oauth_client cloudflare_oauth_client}
*/
export declare class DataCloudflareOauthClient extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_oauth_client";
    /**
    * Generates CDKTN code for importing a DataCloudflareOauthClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareOauthClient to import
    * @param importFromId The id of the existing DataCloudflareOauthClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/oauth_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareOauthClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/oauth_client cloudflare_oauth_client} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareOauthClientConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareOauthClientConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get allowedCorsOrigins(): string[];
    get clientId(): string;
    get clientName(): string;
    get clientUri(): string;
    private _clientUriVerification;
    get clientUriVerification(): DataCloudflareOauthClientClientUriVerificationOutputReference;
    get createdAt(): string;
    get grantTypes(): string[];
    get hasRotatedSecret(): cdktn.IResolvable;
    get logoUri(): string;
    private _oauthClientId?;
    get oauthClientId(): string;
    set oauthClientId(value: string);
    get oauthClientIdInput(): string | undefined;
    get policyUri(): string;
    get postLogoutRedirectUris(): string[];
    get promotedAt(): string;
    get redirectUris(): string[];
    get responseTypes(): string[];
    get scopes(): string[];
    get tokenEndpointAuthMethod(): string;
    get tosUri(): string;
    get updatedAt(): string;
    get visibility(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
