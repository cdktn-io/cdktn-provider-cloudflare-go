/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAiSearchTokensConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ai_search_tokens#account_id DataCloudflareAiSearchTokens#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ai_search_tokens#max_items DataCloudflareAiSearchTokens#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter tokens whose name contains this string (case-insensitive).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ai_search_tokens#search DataCloudflareAiSearchTokens#search}
    */
    readonly search?: string;
}
export interface DataCloudflareAiSearchTokensResult {
}
export declare function dataCloudflareAiSearchTokensResultToTerraform(struct?: DataCloudflareAiSearchTokensResult): any;
export declare function dataCloudflareAiSearchTokensResultToHclTerraform(struct?: DataCloudflareAiSearchTokensResult): any;
export declare class DataCloudflareAiSearchTokensResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiSearchTokensResult | undefined;
    set internalValue(value: DataCloudflareAiSearchTokensResult | undefined);
    get cfApiId(): string;
    get createdAt(): string;
    get createdBy(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get legacy(): cdktn.IResolvable;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get name(): string;
}
export declare class DataCloudflareAiSearchTokensResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiSearchTokensResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ai_search_tokens cloudflare_ai_search_tokens}
*/
export declare class DataCloudflareAiSearchTokens extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ai_search_tokens";
    /**
    * Generates CDKTN code for importing a DataCloudflareAiSearchTokens resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAiSearchTokens to import
    * @param importFromId The id of the existing DataCloudflareAiSearchTokens that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ai_search_tokens#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAiSearchTokens to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ai_search_tokens cloudflare_ai_search_tokens} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAiSearchTokensConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareAiSearchTokensConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareAiSearchTokensResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
