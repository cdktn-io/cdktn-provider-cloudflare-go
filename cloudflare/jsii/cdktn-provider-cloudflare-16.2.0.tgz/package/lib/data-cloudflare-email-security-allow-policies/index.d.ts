/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSecurityAllowPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#account_id DataCloudflareEmailSecurityAllowPolicies#account_id}
    */
    readonly accountId: string;
    /**
    * The sorting direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#direction DataCloudflareEmailSecurityAllowPolicies#direction}
    */
    readonly direction?: string;
    /**
    * Filter to show only policies where messages from the sender are exempted from Spam, Spoof, and Bulk dispositions (not Malicious or Suspicious).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#is_acceptable_sender DataCloudflareEmailSecurityAllowPolicies#is_acceptable_sender}
    */
    readonly isAcceptableSender?: boolean | cdktn.IResolvable;
    /**
    * Filter to show only policies where messages to the recipient bypass all detections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#is_exempt_recipient DataCloudflareEmailSecurityAllowPolicies#is_exempt_recipient}
    */
    readonly isExemptRecipient?: boolean | cdktn.IResolvable;
    /**
    * Filter to show only policies where messages from the sender bypass all detections and link following.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#is_trusted_sender DataCloudflareEmailSecurityAllowPolicies#is_trusted_sender}
    */
    readonly isTrustedSender?: boolean | cdktn.IResolvable;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#max_items DataCloudflareEmailSecurityAllowPolicies#max_items}
    */
    readonly maxItems?: number;
    /**
    * Field to sort by.
    * Available values: "pattern", "created_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#order DataCloudflareEmailSecurityAllowPolicies#order}
    */
    readonly order?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#pattern DataCloudflareEmailSecurityAllowPolicies#pattern}
    */
    readonly pattern?: string;
    /**
    * Type of pattern matching.
    * - EMAIL: matches a full email address (e.g. `user@example.com`)
    * - DOMAIN: matches a domain name (e.g. `example.com`)
    * - IP: matches a plain IPv4 or IPv6 address (e.g. `1.2.3.4` or `2606:4700:4700::1111`) or CIDR block (e.g. `1.2.3.0/24` or `2606:4700:4700::/48`). The API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents.
    * - UNKNOWN: deprecated; you cannot use this when creating or updating policies, but it may appear on existing entries.
    * Available values: "EMAIL", "DOMAIN", "IP", "UNKNOWN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#pattern_type DataCloudflareEmailSecurityAllowPolicies#pattern_type}
    */
    readonly patternType?: string;
    /**
    * Search term for filtering records. Behavior may change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#search DataCloudflareEmailSecurityAllowPolicies#search}
    */
    readonly search?: string;
    /**
    * Filter to show only policies that enforce DMARC, SPF, or DKIM authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#verify_sender DataCloudflareEmailSecurityAllowPolicies#verify_sender}
    */
    readonly verifySender?: boolean | cdktn.IResolvable;
}
export interface DataCloudflareEmailSecurityAllowPoliciesResult {
}
export declare function dataCloudflareEmailSecurityAllowPoliciesResultToTerraform(struct?: DataCloudflareEmailSecurityAllowPoliciesResult): any;
export declare function dataCloudflareEmailSecurityAllowPoliciesResultToHclTerraform(struct?: DataCloudflareEmailSecurityAllowPoliciesResult): any;
export declare class DataCloudflareEmailSecurityAllowPoliciesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareEmailSecurityAllowPoliciesResult | undefined;
    set internalValue(value: DataCloudflareEmailSecurityAllowPoliciesResult | undefined);
    get comments(): string;
    get createdAt(): string;
    get id(): string;
    get isAcceptableSender(): cdktn.IResolvable;
    get isExemptRecipient(): cdktn.IResolvable;
    get isRecipient(): cdktn.IResolvable;
    get isRegex(): cdktn.IResolvable;
    get isSender(): cdktn.IResolvable;
    get isSpoof(): cdktn.IResolvable;
    get isTrustedSender(): cdktn.IResolvable;
    get lastModified(): string;
    get modifiedAt(): string;
    get pattern(): string;
    get patternType(): string;
    get verifySender(): cdktn.IResolvable;
}
export declare class DataCloudflareEmailSecurityAllowPoliciesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareEmailSecurityAllowPoliciesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies cloudflare_email_security_allow_policies}
*/
export declare class DataCloudflareEmailSecurityAllowPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_security_allow_policies";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSecurityAllowPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSecurityAllowPolicies to import
    * @param importFromId The id of the existing DataCloudflareEmailSecurityAllowPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSecurityAllowPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/email_security_allow_policies cloudflare_email_security_allow_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSecurityAllowPoliciesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareEmailSecurityAllowPoliciesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _isAcceptableSender?;
    get isAcceptableSender(): boolean | cdktn.IResolvable;
    set isAcceptableSender(value: boolean | cdktn.IResolvable);
    resetIsAcceptableSender(): void;
    get isAcceptableSenderInput(): boolean | cdktn.IResolvable | undefined;
    private _isExemptRecipient?;
    get isExemptRecipient(): boolean | cdktn.IResolvable;
    set isExemptRecipient(value: boolean | cdktn.IResolvable);
    resetIsExemptRecipient(): void;
    get isExemptRecipientInput(): boolean | cdktn.IResolvable | undefined;
    private _isTrustedSender?;
    get isTrustedSender(): boolean | cdktn.IResolvable;
    set isTrustedSender(value: boolean | cdktn.IResolvable);
    resetIsTrustedSender(): void;
    get isTrustedSenderInput(): boolean | cdktn.IResolvable | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _patternType?;
    get patternType(): string;
    set patternType(value: string);
    resetPatternType(): void;
    get patternTypeInput(): string | undefined;
    private _result;
    get result(): DataCloudflareEmailSecurityAllowPoliciesResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _verifySender?;
    get verifySender(): boolean | cdktn.IResolvable;
    set verifySender(value: boolean | cdktn.IResolvable);
    resetVerifySender(): void;
    get verifySenderInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
