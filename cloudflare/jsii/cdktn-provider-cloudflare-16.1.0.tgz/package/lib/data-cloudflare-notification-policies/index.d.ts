/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareNotificationPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/notification_policies#account_id DataCloudflareNotificationPolicies#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/notification_policies#max_items DataCloudflareNotificationPolicies#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareNotificationPoliciesResultFilters {
}
export declare function dataCloudflareNotificationPoliciesResultFiltersToTerraform(struct?: DataCloudflareNotificationPoliciesResultFilters): any;
export declare function dataCloudflareNotificationPoliciesResultFiltersToHclTerraform(struct?: DataCloudflareNotificationPoliciesResultFilters): any;
export declare class DataCloudflareNotificationPoliciesResultFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareNotificationPoliciesResultFilters | undefined;
    set internalValue(value: DataCloudflareNotificationPoliciesResultFilters | undefined);
    get actions(): string[];
    get affectedAsns(): string[];
    get affectedComponents(): string[];
    get affectedLocations(): string[];
    get airportCode(): string[];
    get alertTriggerPreferences(): string[];
    get alertTriggerPreferencesValue(): string[];
    get enabled(): string[];
    get environment(): string[];
    get event(): string[];
    get eventSource(): string[];
    get eventType(): string[];
    get groupBy(): string[];
    get healthCheckId(): string[];
    get incidentImpact(): string[];
    get inputId(): string[];
    get insightClass(): string[];
    get limit(): string[];
    get logoTag(): string[];
    get megabitsPerSecond(): string[];
    get newHealth(): string[];
    get newStatus(): string[];
    get packetsPerSecond(): string[];
    get poolId(): string[];
    get popNames(): string[];
    get product(): string[];
    get projectId(): string[];
    get protocol(): string[];
    get queryTag(): string[];
    get requestsPerSecond(): string[];
    get selectors(): string[];
    get services(): string[];
    get slo(): string[];
    get status(): string[];
    get targetHostname(): string[];
    get targetIp(): string[];
    get targetZoneName(): string[];
    get trafficExclusions(): string[];
    get tunnelId(): string[];
    get tunnelName(): string[];
    get type(): string[];
    get where(): string[];
    get zones(): string[];
}
export interface DataCloudflareNotificationPoliciesResultMechanismsEmail {
}
export declare function dataCloudflareNotificationPoliciesResultMechanismsEmailToTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanismsEmail): any;
export declare function dataCloudflareNotificationPoliciesResultMechanismsEmailToHclTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanismsEmail): any;
export declare class DataCloudflareNotificationPoliciesResultMechanismsEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareNotificationPoliciesResultMechanismsEmail | undefined;
    set internalValue(value: DataCloudflareNotificationPoliciesResultMechanismsEmail | undefined);
    get id(): string;
}
export declare class DataCloudflareNotificationPoliciesResultMechanismsEmailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareNotificationPoliciesResultMechanismsEmailOutputReference;
}
export interface DataCloudflareNotificationPoliciesResultMechanismsPagerduty {
}
export declare function dataCloudflareNotificationPoliciesResultMechanismsPagerdutyToTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanismsPagerduty): any;
export declare function dataCloudflareNotificationPoliciesResultMechanismsPagerdutyToHclTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanismsPagerduty): any;
export declare class DataCloudflareNotificationPoliciesResultMechanismsPagerdutyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareNotificationPoliciesResultMechanismsPagerduty | undefined;
    set internalValue(value: DataCloudflareNotificationPoliciesResultMechanismsPagerduty | undefined);
    get id(): string;
}
export declare class DataCloudflareNotificationPoliciesResultMechanismsPagerdutyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareNotificationPoliciesResultMechanismsPagerdutyOutputReference;
}
export interface DataCloudflareNotificationPoliciesResultMechanismsWebhooks {
}
export declare function dataCloudflareNotificationPoliciesResultMechanismsWebhooksToTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanismsWebhooks): any;
export declare function dataCloudflareNotificationPoliciesResultMechanismsWebhooksToHclTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanismsWebhooks): any;
export declare class DataCloudflareNotificationPoliciesResultMechanismsWebhooksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareNotificationPoliciesResultMechanismsWebhooks | undefined;
    set internalValue(value: DataCloudflareNotificationPoliciesResultMechanismsWebhooks | undefined);
    get id(): string;
}
export declare class DataCloudflareNotificationPoliciesResultMechanismsWebhooksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareNotificationPoliciesResultMechanismsWebhooksOutputReference;
}
export interface DataCloudflareNotificationPoliciesResultMechanisms {
}
export declare function dataCloudflareNotificationPoliciesResultMechanismsToTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanisms): any;
export declare function dataCloudflareNotificationPoliciesResultMechanismsToHclTerraform(struct?: DataCloudflareNotificationPoliciesResultMechanisms): any;
export declare class DataCloudflareNotificationPoliciesResultMechanismsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareNotificationPoliciesResultMechanisms | undefined;
    set internalValue(value: DataCloudflareNotificationPoliciesResultMechanisms | undefined);
    private _email;
    get email(): DataCloudflareNotificationPoliciesResultMechanismsEmailList;
    private _pagerduty;
    get pagerduty(): DataCloudflareNotificationPoliciesResultMechanismsPagerdutyList;
    private _webhooks;
    get webhooks(): DataCloudflareNotificationPoliciesResultMechanismsWebhooksList;
}
export interface DataCloudflareNotificationPoliciesResult {
}
export declare function dataCloudflareNotificationPoliciesResultToTerraform(struct?: DataCloudflareNotificationPoliciesResult): any;
export declare function dataCloudflareNotificationPoliciesResultToHclTerraform(struct?: DataCloudflareNotificationPoliciesResult): any;
export declare class DataCloudflareNotificationPoliciesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareNotificationPoliciesResult | undefined;
    set internalValue(value: DataCloudflareNotificationPoliciesResult | undefined);
    get alertInterval(): string;
    get alertType(): string;
    get created(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _filters;
    get filters(): DataCloudflareNotificationPoliciesResultFiltersOutputReference;
    get id(): string;
    private _mechanisms;
    get mechanisms(): DataCloudflareNotificationPoliciesResultMechanismsOutputReference;
    get modified(): string;
    get name(): string;
}
export declare class DataCloudflareNotificationPoliciesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareNotificationPoliciesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/notification_policies cloudflare_notification_policies}
*/
export declare class DataCloudflareNotificationPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_notification_policies";
    /**
    * Generates CDKTN code for importing a DataCloudflareNotificationPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareNotificationPolicies to import
    * @param importFromId The id of the existing DataCloudflareNotificationPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/notification_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareNotificationPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/notification_policies cloudflare_notification_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareNotificationPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareNotificationPoliciesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareNotificationPoliciesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
