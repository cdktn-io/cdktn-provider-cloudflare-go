/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiGatewayDynamicRoutingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#account_id AiGatewayDynamicRouting#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#elements AiGatewayDynamicRouting#elements}
    */
    readonly elements: AiGatewayDynamicRoutingElements[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#gateway_id AiGatewayDynamicRouting#gateway_id}
    */
    readonly gatewayId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#name AiGatewayDynamicRouting#name}
    */
    readonly name: string;
}
export interface AiGatewayDynamicRoutingDeployment {
}
export declare function aiGatewayDynamicRoutingDeploymentToTerraform(struct?: AiGatewayDynamicRoutingDeployment): any;
export declare function aiGatewayDynamicRoutingDeploymentToHclTerraform(struct?: AiGatewayDynamicRoutingDeployment): any;
export declare class AiGatewayDynamicRoutingDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingDeployment | undefined;
    set internalValue(value: AiGatewayDynamicRoutingDeployment | undefined);
    get createdAt(): string;
    get deploymentId(): string;
    get versionId(): string;
}
export interface AiGatewayDynamicRoutingElementsOutputsFallback {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#element_id AiGatewayDynamicRouting#element_id}
    */
    readonly elementId: string;
}
export declare function aiGatewayDynamicRoutingElementsOutputsFallbackToTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsFallback | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsOutputsFallbackToHclTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsFallback | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsOutputsFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingElementsOutputsFallback | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElementsOutputsFallback | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    get elementIdInput(): string | undefined;
}
export interface AiGatewayDynamicRoutingElementsOutputsFalse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#element_id AiGatewayDynamicRouting#element_id}
    */
    readonly elementId: string;
}
export declare function aiGatewayDynamicRoutingElementsOutputsFalseToTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsFalse | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsOutputsFalseToHclTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsFalse | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsOutputsFalseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingElementsOutputsFalse | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElementsOutputsFalse | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    get elementIdInput(): string | undefined;
}
export interface AiGatewayDynamicRoutingElementsOutputsNext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#element_id AiGatewayDynamicRouting#element_id}
    */
    readonly elementId: string;
}
export declare function aiGatewayDynamicRoutingElementsOutputsNextToTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsNext | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsOutputsNextToHclTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsNext | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsOutputsNextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingElementsOutputsNext | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElementsOutputsNext | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    get elementIdInput(): string | undefined;
}
export interface AiGatewayDynamicRoutingElementsOutputsSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#element_id AiGatewayDynamicRouting#element_id}
    */
    readonly elementId: string;
}
export declare function aiGatewayDynamicRoutingElementsOutputsSuccessToTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsSuccess | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsOutputsSuccessToHclTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsSuccess | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsOutputsSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingElementsOutputsSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElementsOutputsSuccess | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    get elementIdInput(): string | undefined;
}
export interface AiGatewayDynamicRoutingElementsOutputsTrue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#element_id AiGatewayDynamicRouting#element_id}
    */
    readonly elementId: string;
}
export declare function aiGatewayDynamicRoutingElementsOutputsTrueToTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsTrue | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsOutputsTrueToHclTerraform(struct?: AiGatewayDynamicRoutingElementsOutputsTrue | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsOutputsTrueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingElementsOutputsTrue | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElementsOutputsTrue | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    get elementIdInput(): string | undefined;
}
export interface AiGatewayDynamicRoutingElementsOutputs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#element_id AiGatewayDynamicRouting#element_id}
    */
    readonly elementId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#fallback AiGatewayDynamicRouting#fallback}
    */
    readonly fallback?: AiGatewayDynamicRoutingElementsOutputsFallback;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#false AiGatewayDynamicRouting#false}
    */
    readonly false?: AiGatewayDynamicRoutingElementsOutputsFalse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#next AiGatewayDynamicRouting#next}
    */
    readonly next?: AiGatewayDynamicRoutingElementsOutputsNext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#success AiGatewayDynamicRouting#success}
    */
    readonly success?: AiGatewayDynamicRoutingElementsOutputsSuccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#true AiGatewayDynamicRouting#true}
    */
    readonly true?: AiGatewayDynamicRoutingElementsOutputsTrue;
}
export declare function aiGatewayDynamicRoutingElementsOutputsToTerraform(struct?: AiGatewayDynamicRoutingElementsOutputs | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsOutputsToHclTerraform(struct?: AiGatewayDynamicRoutingElementsOutputs | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsOutputsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingElementsOutputs | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElementsOutputs | cdktn.IResolvable | undefined);
    private _elementId?;
    get elementId(): string;
    set elementId(value: string);
    resetElementId(): void;
    get elementIdInput(): string | undefined;
    private _fallback;
    get fallback(): AiGatewayDynamicRoutingElementsOutputsFallbackOutputReference;
    putFallback(value: AiGatewayDynamicRoutingElementsOutputsFallback): void;
    resetFallback(): void;
    get fallbackInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElementsOutputsFallback | undefined;
    private _false;
    get false(): AiGatewayDynamicRoutingElementsOutputsFalseOutputReference;
    putFalse(value: AiGatewayDynamicRoutingElementsOutputsFalse): void;
    resetFalse(): void;
    get falseInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElementsOutputsFalse | undefined;
    private _next;
    get next(): AiGatewayDynamicRoutingElementsOutputsNextOutputReference;
    putNext(value: AiGatewayDynamicRoutingElementsOutputsNext): void;
    resetNext(): void;
    get nextInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElementsOutputsNext | undefined;
    private _success;
    get success(): AiGatewayDynamicRoutingElementsOutputsSuccessOutputReference;
    putSuccess(value: AiGatewayDynamicRoutingElementsOutputsSuccess): void;
    resetSuccess(): void;
    get successInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElementsOutputsSuccess | undefined;
    private _true;
    get true(): AiGatewayDynamicRoutingElementsOutputsTrueOutputReference;
    putTrue(value: AiGatewayDynamicRoutingElementsOutputsTrue): void;
    resetTrue(): void;
    get trueInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElementsOutputsTrue | undefined;
}
export interface AiGatewayDynamicRoutingElementsProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#ai_gateway_dynamic_routing_provider AiGatewayDynamicRouting#ai_gateway_dynamic_routing_provider}
    */
    readonly aiGatewayDynamicRoutingProvider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#conditions AiGatewayDynamicRouting#conditions}
    */
    readonly conditions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#key AiGatewayDynamicRouting#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#limit AiGatewayDynamicRouting#limit}
    */
    readonly limit?: number;
    /**
    * Available values: "count", "cost".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#limit_type AiGatewayDynamicRouting#limit_type}
    */
    readonly limitType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#model AiGatewayDynamicRouting#model}
    */
    readonly model?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#retries AiGatewayDynamicRouting#retries}
    */
    readonly retries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#timeout AiGatewayDynamicRouting#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#window AiGatewayDynamicRouting#window}
    */
    readonly window?: number;
}
export declare function aiGatewayDynamicRoutingElementsPropertiesToTerraform(struct?: AiGatewayDynamicRoutingElementsProperties | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsPropertiesToHclTerraform(struct?: AiGatewayDynamicRoutingElementsProperties | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingElementsProperties | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElementsProperties | cdktn.IResolvable | undefined);
    private _aiGatewayDynamicRoutingProvider?;
    get aiGatewayDynamicRoutingProvider(): string;
    set aiGatewayDynamicRoutingProvider(value: string);
    resetAiGatewayDynamicRoutingProvider(): void;
    get aiGatewayDynamicRoutingProviderInput(): string | undefined;
    private _conditions?;
    get conditions(): string;
    set conditions(value: string);
    resetConditions(): void;
    get conditionsInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _limitType?;
    get limitType(): string;
    set limitType(value: string);
    resetLimitType(): void;
    get limitTypeInput(): string | undefined;
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _retries?;
    get retries(): number;
    set retries(value: number);
    resetRetries(): void;
    get retriesInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _window?;
    get window(): number;
    set window(value: number);
    resetWindow(): void;
    get windowInput(): number | undefined;
}
export interface AiGatewayDynamicRoutingElements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#id AiGatewayDynamicRouting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#outputs AiGatewayDynamicRouting#outputs}
    */
    readonly outputs: AiGatewayDynamicRoutingElementsOutputs;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#properties AiGatewayDynamicRouting#properties}
    */
    readonly properties?: AiGatewayDynamicRoutingElementsProperties;
    /**
    * Available values: "start", "conditional", "percentage", "rate", "model", "end".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#type AiGatewayDynamicRouting#type}
    */
    readonly type: string;
}
export declare function aiGatewayDynamicRoutingElementsToTerraform(struct?: AiGatewayDynamicRoutingElements | cdktn.IResolvable): any;
export declare function aiGatewayDynamicRoutingElementsToHclTerraform(struct?: AiGatewayDynamicRoutingElements | cdktn.IResolvable): any;
export declare class AiGatewayDynamicRoutingElementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayDynamicRoutingElements | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayDynamicRoutingElements | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _outputs;
    get outputs(): AiGatewayDynamicRoutingElementsOutputsOutputReference;
    putOutputs(value: AiGatewayDynamicRoutingElementsOutputs): void;
    get outputsInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElementsOutputs | undefined;
    private _properties;
    get properties(): AiGatewayDynamicRoutingElementsPropertiesOutputReference;
    putProperties(value: AiGatewayDynamicRoutingElementsProperties): void;
    resetProperties(): void;
    get propertiesInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElementsProperties | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class AiGatewayDynamicRoutingElementsList extends cdktn.ComplexList {
    internalValue?: AiGatewayDynamicRoutingElements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayDynamicRoutingElementsOutputReference;
}
export interface AiGatewayDynamicRoutingRouteDeployment {
}
export declare function aiGatewayDynamicRoutingRouteDeploymentToTerraform(struct?: AiGatewayDynamicRoutingRouteDeployment): any;
export declare function aiGatewayDynamicRoutingRouteDeploymentToHclTerraform(struct?: AiGatewayDynamicRoutingRouteDeployment): any;
export declare class AiGatewayDynamicRoutingRouteDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteDeployment | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteDeployment | undefined);
    get createdAt(): string;
    get deploymentId(): string;
    get versionId(): string;
}
export interface AiGatewayDynamicRoutingRouteElementsOutputsFallback {
}
export declare function aiGatewayDynamicRoutingRouteElementsOutputsFallbackToTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsFallback): any;
export declare function aiGatewayDynamicRoutingRouteElementsOutputsFallbackToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsFallback): any;
export declare class AiGatewayDynamicRoutingRouteElementsOutputsFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteElementsOutputsFallback | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElementsOutputsFallback | undefined);
    get elementId(): string;
}
export interface AiGatewayDynamicRoutingRouteElementsOutputsFalse {
}
export declare function aiGatewayDynamicRoutingRouteElementsOutputsFalseToTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsFalse): any;
export declare function aiGatewayDynamicRoutingRouteElementsOutputsFalseToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsFalse): any;
export declare class AiGatewayDynamicRoutingRouteElementsOutputsFalseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteElementsOutputsFalse | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElementsOutputsFalse | undefined);
    get elementId(): string;
}
export interface AiGatewayDynamicRoutingRouteElementsOutputsNext {
}
export declare function aiGatewayDynamicRoutingRouteElementsOutputsNextToTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsNext): any;
export declare function aiGatewayDynamicRoutingRouteElementsOutputsNextToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsNext): any;
export declare class AiGatewayDynamicRoutingRouteElementsOutputsNextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteElementsOutputsNext | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElementsOutputsNext | undefined);
    get elementId(): string;
}
export interface AiGatewayDynamicRoutingRouteElementsOutputsSuccess {
}
export declare function aiGatewayDynamicRoutingRouteElementsOutputsSuccessToTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsSuccess): any;
export declare function aiGatewayDynamicRoutingRouteElementsOutputsSuccessToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsSuccess): any;
export declare class AiGatewayDynamicRoutingRouteElementsOutputsSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteElementsOutputsSuccess | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElementsOutputsSuccess | undefined);
    get elementId(): string;
}
export interface AiGatewayDynamicRoutingRouteElementsOutputsTrue {
}
export declare function aiGatewayDynamicRoutingRouteElementsOutputsTrueToTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsTrue): any;
export declare function aiGatewayDynamicRoutingRouteElementsOutputsTrueToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputsTrue): any;
export declare class AiGatewayDynamicRoutingRouteElementsOutputsTrueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteElementsOutputsTrue | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElementsOutputsTrue | undefined);
    get elementId(): string;
}
export interface AiGatewayDynamicRoutingRouteElementsOutputs {
}
export declare function aiGatewayDynamicRoutingRouteElementsOutputsToTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputs): any;
export declare function aiGatewayDynamicRoutingRouteElementsOutputsToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElementsOutputs): any;
export declare class AiGatewayDynamicRoutingRouteElementsOutputsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteElementsOutputs | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElementsOutputs | undefined);
    get elementId(): string;
    private _fallback;
    get fallback(): AiGatewayDynamicRoutingRouteElementsOutputsFallbackOutputReference;
    private _false;
    get false(): AiGatewayDynamicRoutingRouteElementsOutputsFalseOutputReference;
    private _next;
    get next(): AiGatewayDynamicRoutingRouteElementsOutputsNextOutputReference;
    private _success;
    get success(): AiGatewayDynamicRoutingRouteElementsOutputsSuccessOutputReference;
    private _true;
    get true(): AiGatewayDynamicRoutingRouteElementsOutputsTrueOutputReference;
}
export interface AiGatewayDynamicRoutingRouteElementsProperties {
}
export declare function aiGatewayDynamicRoutingRouteElementsPropertiesToTerraform(struct?: AiGatewayDynamicRoutingRouteElementsProperties): any;
export declare function aiGatewayDynamicRoutingRouteElementsPropertiesToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElementsProperties): any;
export declare class AiGatewayDynamicRoutingRouteElementsPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteElementsProperties | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElementsProperties | undefined);
    get aiGatewayDynamicRoutingProvider(): string;
    get conditions(): string;
    get key(): string;
    get limit(): number;
    get limitType(): string;
    get model(): string;
    get retries(): number;
    get timeout(): number;
    get window(): number;
}
export interface AiGatewayDynamicRoutingRouteElements {
}
export declare function aiGatewayDynamicRoutingRouteElementsToTerraform(struct?: AiGatewayDynamicRoutingRouteElements): any;
export declare function aiGatewayDynamicRoutingRouteElementsToHclTerraform(struct?: AiGatewayDynamicRoutingRouteElements): any;
export declare class AiGatewayDynamicRoutingRouteElementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayDynamicRoutingRouteElements | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteElements | undefined);
    get id(): string;
    private _outputs;
    get outputs(): AiGatewayDynamicRoutingRouteElementsOutputsOutputReference;
    private _properties;
    get properties(): AiGatewayDynamicRoutingRouteElementsPropertiesOutputReference;
    get type(): string;
}
export declare class AiGatewayDynamicRoutingRouteElementsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayDynamicRoutingRouteElementsOutputReference;
}
export interface AiGatewayDynamicRoutingRouteVersion {
}
export declare function aiGatewayDynamicRoutingRouteVersionToTerraform(struct?: AiGatewayDynamicRoutingRouteVersion): any;
export declare function aiGatewayDynamicRoutingRouteVersionToHclTerraform(struct?: AiGatewayDynamicRoutingRouteVersion): any;
export declare class AiGatewayDynamicRoutingRouteVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRouteVersion | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRouteVersion | undefined);
    get active(): string;
    get createdAt(): string;
    get data(): string;
    get isValid(): cdktn.IResolvable;
    get versionId(): string;
}
export interface AiGatewayDynamicRoutingRoute {
}
export declare function aiGatewayDynamicRoutingRouteToTerraform(struct?: AiGatewayDynamicRoutingRoute): any;
export declare function aiGatewayDynamicRoutingRouteToHclTerraform(struct?: AiGatewayDynamicRoutingRoute): any;
export declare class AiGatewayDynamicRoutingRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingRoute | undefined;
    set internalValue(value: AiGatewayDynamicRoutingRoute | undefined);
    get accountTag(): string;
    get createdAt(): string;
    private _deployment;
    get deployment(): AiGatewayDynamicRoutingRouteDeploymentOutputReference;
    private _elements;
    get elements(): AiGatewayDynamicRoutingRouteElementsList;
    get gatewayId(): string;
    get id(): string;
    get modifiedAt(): string;
    get name(): string;
    private _version;
    get version(): AiGatewayDynamicRoutingRouteVersionOutputReference;
}
export interface AiGatewayDynamicRoutingVersion {
}
export declare function aiGatewayDynamicRoutingVersionToTerraform(struct?: AiGatewayDynamicRoutingVersion): any;
export declare function aiGatewayDynamicRoutingVersionToHclTerraform(struct?: AiGatewayDynamicRoutingVersion): any;
export declare class AiGatewayDynamicRoutingVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayDynamicRoutingVersion | undefined;
    set internalValue(value: AiGatewayDynamicRoutingVersion | undefined);
    get active(): string;
    get createdAt(): string;
    get data(): string;
    get isValid(): cdktn.IResolvable;
    get versionId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing cloudflare_ai_gateway_dynamic_routing}
*/
export declare class AiGatewayDynamicRouting extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_ai_gateway_dynamic_routing";
    /**
    * Generates CDKTN code for importing a AiGatewayDynamicRouting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiGatewayDynamicRouting to import
    * @param importFromId The id of the existing AiGatewayDynamicRouting that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiGatewayDynamicRouting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/resources/ai_gateway_dynamic_routing cloudflare_ai_gateway_dynamic_routing} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiGatewayDynamicRoutingConfig
    */
    constructor(scope: Construct, id: string, config: AiGatewayDynamicRoutingConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    private _deployment;
    get deployment(): AiGatewayDynamicRoutingDeploymentOutputReference;
    private _elements;
    get elements(): AiGatewayDynamicRoutingElementsList;
    putElements(value: AiGatewayDynamicRoutingElements[] | cdktn.IResolvable): void;
    get elementsInput(): cdktn.IResolvable | AiGatewayDynamicRoutingElements[] | undefined;
    private _gatewayId?;
    get gatewayId(): string;
    set gatewayId(value: string);
    get gatewayIdInput(): string | undefined;
    get id(): string;
    get modifiedAt(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _route;
    get route(): AiGatewayDynamicRoutingRouteOutputReference;
    get success(): cdktn.IResolvable;
    private _version;
    get version(): AiGatewayDynamicRoutingVersionOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
