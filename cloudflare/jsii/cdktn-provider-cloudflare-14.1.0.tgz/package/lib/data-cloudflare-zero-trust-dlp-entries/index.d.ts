/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpEntriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_entries#account_id DataCloudflareZeroTrustDlpEntries#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_entries#max_items DataCloudflareZeroTrustDlpEntries#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustDlpEntriesResultConfidence {
}
export declare function dataCloudflareZeroTrustDlpEntriesResultConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResultConfidence): any;
export declare function dataCloudflareZeroTrustDlpEntriesResultConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResultConfidence): any;
export declare class DataCloudflareZeroTrustDlpEntriesResultConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpEntriesResultConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntriesResultConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpEntriesResultPattern {
}
export declare function dataCloudflareZeroTrustDlpEntriesResultPatternToTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResultPattern): any;
export declare function dataCloudflareZeroTrustDlpEntriesResultPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResultPattern): any;
export declare class DataCloudflareZeroTrustDlpEntriesResultPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpEntriesResultPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntriesResultPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpEntriesResultVariant {
}
export declare function dataCloudflareZeroTrustDlpEntriesResultVariantToTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResultVariant): any;
export declare function dataCloudflareZeroTrustDlpEntriesResultVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResultVariant): any;
export declare class DataCloudflareZeroTrustDlpEntriesResultVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpEntriesResultVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntriesResultVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
export interface DataCloudflareZeroTrustDlpEntriesResult {
}
export declare function dataCloudflareZeroTrustDlpEntriesResultToTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResult): any;
export declare function dataCloudflareZeroTrustDlpEntriesResultToHclTerraform(struct?: DataCloudflareZeroTrustDlpEntriesResult): any;
export declare class DataCloudflareZeroTrustDlpEntriesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpEntriesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpEntriesResult | undefined);
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpEntriesResultConfidenceOutputReference;
    get createdAt(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpEntriesResultPatternOutputReference;
    get profileId(): string;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    get uploadStatus(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpEntriesResultVariantOutputReference;
    get wordList(): string;
}
export declare class DataCloudflareZeroTrustDlpEntriesResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpEntriesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_entries cloudflare_zero_trust_dlp_entries}
*/
export declare class DataCloudflareZeroTrustDlpEntries extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_entries";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpEntries resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpEntries to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpEntries that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_entries#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpEntries to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/zero_trust_dlp_entries cloudflare_zero_trust_dlp_entries} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpEntriesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpEntriesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustDlpEntriesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
