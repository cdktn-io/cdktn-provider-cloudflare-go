/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSecurityImpersonationRegistryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#account_id DataCloudflareEmailSecurityImpersonationRegistry#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#filter DataCloudflareEmailSecurityImpersonationRegistry#filter}
    */
    readonly filter?: DataCloudflareEmailSecurityImpersonationRegistryFilter;
    /**
    * Impersonation registry entry identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#impersonation_registry_id DataCloudflareEmailSecurityImpersonationRegistry#impersonation_registry_id}
    */
    readonly impersonationRegistryId?: string;
}
export interface DataCloudflareEmailSecurityImpersonationRegistryFilter {
    /**
    * The sorting direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#direction DataCloudflareEmailSecurityImpersonationRegistry#direction}
    */
    readonly direction?: string;
    /**
    * Field to sort by.
    * Available values: "name", "email", "created_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#order DataCloudflareEmailSecurityImpersonationRegistry#order}
    */
    readonly order?: string;
    /**
    * Available values: "A1S_INTERNAL", "SNOOPY-CASB_OFFICE_365", "SNOOPY-OFFICE_365", "SNOOPY-GOOGLE_DIRECTORY".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#provenance DataCloudflareEmailSecurityImpersonationRegistry#provenance}
    */
    readonly provenance?: string;
    /**
    * Search term for filtering records. Behavior may change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#search DataCloudflareEmailSecurityImpersonationRegistry#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareEmailSecurityImpersonationRegistryFilterToTerraform(struct?: DataCloudflareEmailSecurityImpersonationRegistryFilter | cdktn.IResolvable): any;
export declare function dataCloudflareEmailSecurityImpersonationRegistryFilterToHclTerraform(struct?: DataCloudflareEmailSecurityImpersonationRegistryFilter | cdktn.IResolvable): any;
export declare class DataCloudflareEmailSecurityImpersonationRegistryFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityImpersonationRegistryFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareEmailSecurityImpersonationRegistryFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _provenance?;
    get provenance(): string;
    set provenance(value: string);
    resetProvenance(): void;
    get provenanceInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry cloudflare_email_security_impersonation_registry}
*/
export declare class DataCloudflareEmailSecurityImpersonationRegistry extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_security_impersonation_registry";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSecurityImpersonationRegistry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSecurityImpersonationRegistry to import
    * @param importFromId The id of the existing DataCloudflareEmailSecurityImpersonationRegistry that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSecurityImpersonationRegistry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/email_security_impersonation_registry cloudflare_email_security_impersonation_registry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSecurityImpersonationRegistryConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareEmailSecurityImpersonationRegistryConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get comments(): string;
    get createdAt(): string;
    get directoryId(): number;
    get directoryNodeId(): number;
    get email(): string;
    get externalDirectoryNodeId(): string;
    private _filter;
    get filter(): DataCloudflareEmailSecurityImpersonationRegistryFilterOutputReference;
    putFilter(value: DataCloudflareEmailSecurityImpersonationRegistryFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareEmailSecurityImpersonationRegistryFilter | undefined;
    get id(): string;
    private _impersonationRegistryId?;
    get impersonationRegistryId(): string;
    set impersonationRegistryId(value: string);
    resetImpersonationRegistryId(): void;
    get impersonationRegistryIdInput(): string | undefined;
    get isEmailRegex(): cdktn.IResolvable;
    get lastModified(): string;
    get modifiedAt(): string;
    get name(): string;
    get provenance(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
