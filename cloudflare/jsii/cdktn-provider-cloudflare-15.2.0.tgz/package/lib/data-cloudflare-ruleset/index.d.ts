/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareRulesetConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique ID of the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ruleset#account_id DataCloudflareRuleset#account_id}
    */
    readonly accountId?: string;
    /**
    * The unique ID of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ruleset#id DataCloudflareRuleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique ID of the ruleset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ruleset#ruleset_id DataCloudflareRuleset#ruleset_id}
    */
    readonly rulesetId?: string;
    /**
    * The unique ID of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ruleset#zone_id DataCloudflareRuleset#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareRulesetRulesActionParametersAlgorithms {
}
export declare function dataCloudflareRulesetRulesActionParametersAlgorithmsToTerraform(struct?: DataCloudflareRulesetRulesActionParametersAlgorithms): any;
export declare function dataCloudflareRulesetRulesActionParametersAlgorithmsToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersAlgorithms): any;
export declare class DataCloudflareRulesetRulesActionParametersAlgorithmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersAlgorithms | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersAlgorithms | undefined);
    get name(): string;
}
export declare class DataCloudflareRulesetRulesActionParametersAlgorithmsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersAlgorithmsOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersAutominify {
}
export declare function dataCloudflareRulesetRulesActionParametersAutominifyToTerraform(struct?: DataCloudflareRulesetRulesActionParametersAutominify): any;
export declare function dataCloudflareRulesetRulesActionParametersAutominifyToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersAutominify): any;
export declare class DataCloudflareRulesetRulesActionParametersAutominifyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersAutominify | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersAutominify | undefined);
    get css(): cdktn.IResolvable;
    get html(): cdktn.IResolvable;
    get js(): cdktn.IResolvable;
}
export interface DataCloudflareRulesetRulesActionParametersBrowserTtl {
}
export declare function dataCloudflareRulesetRulesActionParametersBrowserTtlToTerraform(struct?: DataCloudflareRulesetRulesActionParametersBrowserTtl): any;
export declare function dataCloudflareRulesetRulesActionParametersBrowserTtlToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersBrowserTtl): any;
export declare class DataCloudflareRulesetRulesActionParametersBrowserTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersBrowserTtl | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersBrowserTtl | undefined);
    get default(): number;
    get mode(): string;
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookie {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookieToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookie): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookieToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookie): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookie | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookie | undefined);
    get checkPresence(): string[];
    get include(): string[];
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeader {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeaderToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeader): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeaderToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeader): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeader | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeader | undefined);
    get checkPresence(): string[];
    private _contains;
    get contains(): cdktn.StringListMap;
    get excludeOrigin(): cdktn.IResolvable;
    get include(): string[];
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHost {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHostToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHost): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHostToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHost): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHost | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHost | undefined);
    get resolved(): cdktn.IResolvable;
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExclude | undefined);
    get all(): cdktn.IResolvable;
    get list(): string[];
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringInclude | undefined);
    get all(): cdktn.IResolvable;
    get list(): string[];
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryString {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryString): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryString): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryString | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryString | undefined);
    private _exclude;
    get exclude(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringExcludeOutputReference;
    private _include;
    get include(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringIncludeOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUser {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUserToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUser): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUserToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUser): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUser | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUser | undefined);
    get deviceType(): cdktn.IResolvable;
    get geo(): cdktn.IResolvable;
    get lang(): cdktn.IResolvable;
}
export interface DataCloudflareRulesetRulesActionParametersCacheKeyCustomKey {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKey): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKey): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKey | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKeyCustomKey | undefined);
    private _cookie;
    get cookie(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyCookieOutputReference;
    private _header;
    get header(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHeaderOutputReference;
    private _host;
    get host(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyHostOutputReference;
    private _queryString;
    get queryString(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyQueryStringOutputReference;
    private _user;
    get user(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyUserOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersCacheKey {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKey): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheKeyToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheKey): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheKey | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheKey | undefined);
    get cacheByDeviceType(): cdktn.IResolvable;
    get cacheDeceptionArmor(): cdktn.IResolvable;
    private _customKey;
    get customKey(): DataCloudflareRulesetRulesActionParametersCacheKeyCustomKeyOutputReference;
    get ignoreQueryStringsOrder(): cdktn.IResolvable;
}
export interface DataCloudflareRulesetRulesActionParametersCacheReserve {
}
export declare function dataCloudflareRulesetRulesActionParametersCacheReserveToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheReserve): any;
export declare function dataCloudflareRulesetRulesActionParametersCacheReserveToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCacheReserve): any;
export declare class DataCloudflareRulesetRulesActionParametersCacheReserveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCacheReserve | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCacheReserve | undefined);
    get eligible(): cdktn.IResolvable;
    get minimumFileSize(): number;
}
export interface DataCloudflareRulesetRulesActionParametersCookieFields {
}
export declare function dataCloudflareRulesetRulesActionParametersCookieFieldsToTerraform(struct?: DataCloudflareRulesetRulesActionParametersCookieFields): any;
export declare function dataCloudflareRulesetRulesActionParametersCookieFieldsToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersCookieFields): any;
export declare class DataCloudflareRulesetRulesActionParametersCookieFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersCookieFields | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersCookieFields | undefined);
    get name(): string;
}
export declare class DataCloudflareRulesetRulesActionParametersCookieFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersCookieFieldsOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange {
}
export declare function dataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToTerraform(struct?: DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange): any;
export declare function dataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange): any;
export declare class DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRange | undefined);
    get from(): number;
    get to(): number;
}
export interface DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtl {
}
export declare function dataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlToTerraform(struct?: DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtl): any;
export declare function dataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtl): any;
export declare class DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtl | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtl | undefined);
    get statusCode(): number;
    private _statusCodeRange;
    get statusCodeRange(): DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlStatusCodeRangeOutputReference;
    get value(): number;
}
export declare class DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersEdgeTtl {
}
export declare function dataCloudflareRulesetRulesActionParametersEdgeTtlToTerraform(struct?: DataCloudflareRulesetRulesActionParametersEdgeTtl): any;
export declare function dataCloudflareRulesetRulesActionParametersEdgeTtlToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersEdgeTtl): any;
export declare class DataCloudflareRulesetRulesActionParametersEdgeTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersEdgeTtl | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersEdgeTtl | undefined);
    get default(): number;
    get mode(): string;
    private _statusCodeTtl;
    get statusCodeTtl(): DataCloudflareRulesetRulesActionParametersEdgeTtlStatusCodeTtlList;
}
export interface DataCloudflareRulesetRulesActionParametersFromListStruct {
}
export declare function dataCloudflareRulesetRulesActionParametersFromListStructToTerraform(struct?: DataCloudflareRulesetRulesActionParametersFromListStruct): any;
export declare function dataCloudflareRulesetRulesActionParametersFromListStructToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersFromListStruct): any;
export declare class DataCloudflareRulesetRulesActionParametersFromListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersFromListStruct | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersFromListStruct | undefined);
    get key(): string;
    get name(): string;
}
export interface DataCloudflareRulesetRulesActionParametersFromValueTargetUrl {
}
export declare function dataCloudflareRulesetRulesActionParametersFromValueTargetUrlToTerraform(struct?: DataCloudflareRulesetRulesActionParametersFromValueTargetUrl): any;
export declare function dataCloudflareRulesetRulesActionParametersFromValueTargetUrlToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersFromValueTargetUrl): any;
export declare class DataCloudflareRulesetRulesActionParametersFromValueTargetUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersFromValueTargetUrl | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersFromValueTargetUrl | undefined);
    get expression(): string;
    get value(): string;
}
export interface DataCloudflareRulesetRulesActionParametersFromValue {
}
export declare function dataCloudflareRulesetRulesActionParametersFromValueToTerraform(struct?: DataCloudflareRulesetRulesActionParametersFromValue): any;
export declare function dataCloudflareRulesetRulesActionParametersFromValueToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersFromValue): any;
export declare class DataCloudflareRulesetRulesActionParametersFromValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersFromValue | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersFromValue | undefined);
    get preserveQueryString(): cdktn.IResolvable;
    get statusCode(): number;
    private _targetUrl;
    get targetUrl(): DataCloudflareRulesetRulesActionParametersFromValueTargetUrlOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersHeaders {
}
export declare function dataCloudflareRulesetRulesActionParametersHeadersToTerraform(struct?: DataCloudflareRulesetRulesActionParametersHeaders): any;
export declare function dataCloudflareRulesetRulesActionParametersHeadersToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersHeaders): any;
export declare class DataCloudflareRulesetRulesActionParametersHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersHeaders | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersHeaders | undefined);
    get expression(): string;
    get operation(): string;
    get value(): string;
}
export declare class DataCloudflareRulesetRulesActionParametersHeadersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflareRulesetRulesActionParametersHeadersOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersImmutable {
}
export declare function dataCloudflareRulesetRulesActionParametersImmutableToTerraform(struct?: DataCloudflareRulesetRulesActionParametersImmutable): any;
export declare function dataCloudflareRulesetRulesActionParametersImmutableToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersImmutable): any;
export declare class DataCloudflareRulesetRulesActionParametersImmutableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersImmutable | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersImmutable | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
}
export interface DataCloudflareRulesetRulesActionParametersMatchedData {
}
export declare function dataCloudflareRulesetRulesActionParametersMatchedDataToTerraform(struct?: DataCloudflareRulesetRulesActionParametersMatchedData): any;
export declare function dataCloudflareRulesetRulesActionParametersMatchedDataToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersMatchedData): any;
export declare class DataCloudflareRulesetRulesActionParametersMatchedDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersMatchedData | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersMatchedData | undefined);
    get publicKey(): string;
}
export interface DataCloudflareRulesetRulesActionParametersMaxAge {
}
export declare function dataCloudflareRulesetRulesActionParametersMaxAgeToTerraform(struct?: DataCloudflareRulesetRulesActionParametersMaxAge): any;
export declare function dataCloudflareRulesetRulesActionParametersMaxAgeToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersMaxAge): any;
export declare class DataCloudflareRulesetRulesActionParametersMaxAgeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersMaxAge | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersMaxAge | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
    get value(): number;
}
export interface DataCloudflareRulesetRulesActionParametersMustRevalidate {
}
export declare function dataCloudflareRulesetRulesActionParametersMustRevalidateToTerraform(struct?: DataCloudflareRulesetRulesActionParametersMustRevalidate): any;
export declare function dataCloudflareRulesetRulesActionParametersMustRevalidateToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersMustRevalidate): any;
export declare class DataCloudflareRulesetRulesActionParametersMustRevalidateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersMustRevalidate | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersMustRevalidate | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
}
export interface DataCloudflareRulesetRulesActionParametersMustUnderstand {
}
export declare function dataCloudflareRulesetRulesActionParametersMustUnderstandToTerraform(struct?: DataCloudflareRulesetRulesActionParametersMustUnderstand): any;
export declare function dataCloudflareRulesetRulesActionParametersMustUnderstandToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersMustUnderstand): any;
export declare class DataCloudflareRulesetRulesActionParametersMustUnderstandOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersMustUnderstand | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersMustUnderstand | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
}
export interface DataCloudflareRulesetRulesActionParametersNoCache {
}
export declare function dataCloudflareRulesetRulesActionParametersNoCacheToTerraform(struct?: DataCloudflareRulesetRulesActionParametersNoCache): any;
export declare function dataCloudflareRulesetRulesActionParametersNoCacheToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersNoCache): any;
export declare class DataCloudflareRulesetRulesActionParametersNoCacheOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersNoCache | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersNoCache | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
    get qualifiers(): string[];
}
export interface DataCloudflareRulesetRulesActionParametersNoStore {
}
export declare function dataCloudflareRulesetRulesActionParametersNoStoreToTerraform(struct?: DataCloudflareRulesetRulesActionParametersNoStore): any;
export declare function dataCloudflareRulesetRulesActionParametersNoStoreToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersNoStore): any;
export declare class DataCloudflareRulesetRulesActionParametersNoStoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersNoStore | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersNoStore | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
}
export interface DataCloudflareRulesetRulesActionParametersNoTransform {
}
export declare function dataCloudflareRulesetRulesActionParametersNoTransformToTerraform(struct?: DataCloudflareRulesetRulesActionParametersNoTransform): any;
export declare function dataCloudflareRulesetRulesActionParametersNoTransformToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersNoTransform): any;
export declare class DataCloudflareRulesetRulesActionParametersNoTransformOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersNoTransform | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersNoTransform | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
}
export interface DataCloudflareRulesetRulesActionParametersOrigin {
}
export declare function dataCloudflareRulesetRulesActionParametersOriginToTerraform(struct?: DataCloudflareRulesetRulesActionParametersOrigin): any;
export declare function dataCloudflareRulesetRulesActionParametersOriginToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersOrigin): any;
export declare class DataCloudflareRulesetRulesActionParametersOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersOrigin | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersOrigin | undefined);
    get host(): string;
    get port(): number;
}
export interface DataCloudflareRulesetRulesActionParametersOverridesCategories {
}
export declare function dataCloudflareRulesetRulesActionParametersOverridesCategoriesToTerraform(struct?: DataCloudflareRulesetRulesActionParametersOverridesCategories): any;
export declare function dataCloudflareRulesetRulesActionParametersOverridesCategoriesToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersOverridesCategories): any;
export declare class DataCloudflareRulesetRulesActionParametersOverridesCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersOverridesCategories | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersOverridesCategories | undefined);
    get action(): string;
    get category(): string;
    get enabled(): cdktn.IResolvable;
    get sensitivityLevel(): string;
}
export declare class DataCloudflareRulesetRulesActionParametersOverridesCategoriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersOverridesCategoriesOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersOverridesRules {
}
export declare function dataCloudflareRulesetRulesActionParametersOverridesRulesToTerraform(struct?: DataCloudflareRulesetRulesActionParametersOverridesRules): any;
export declare function dataCloudflareRulesetRulesActionParametersOverridesRulesToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersOverridesRules): any;
export declare class DataCloudflareRulesetRulesActionParametersOverridesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersOverridesRules | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersOverridesRules | undefined);
    get action(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get scoreThreshold(): number;
    get sensitivityLevel(): string;
}
export declare class DataCloudflareRulesetRulesActionParametersOverridesRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersOverridesRulesOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersOverrides {
}
export declare function dataCloudflareRulesetRulesActionParametersOverridesToTerraform(struct?: DataCloudflareRulesetRulesActionParametersOverrides): any;
export declare function dataCloudflareRulesetRulesActionParametersOverridesToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersOverrides): any;
export declare class DataCloudflareRulesetRulesActionParametersOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersOverrides | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersOverrides | undefined);
    get action(): string;
    private _categories;
    get categories(): DataCloudflareRulesetRulesActionParametersOverridesCategoriesList;
    get enabled(): cdktn.IResolvable;
    private _rules;
    get rules(): DataCloudflareRulesetRulesActionParametersOverridesRulesList;
    get sensitivityLevel(): string;
}
export interface DataCloudflareRulesetRulesActionParametersPrivate {
}
export declare function dataCloudflareRulesetRulesActionParametersPrivateToTerraform(struct?: DataCloudflareRulesetRulesActionParametersPrivate): any;
export declare function dataCloudflareRulesetRulesActionParametersPrivateToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersPrivate): any;
export declare class DataCloudflareRulesetRulesActionParametersPrivateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersPrivate | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersPrivate | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
    get qualifiers(): string[];
}
export interface DataCloudflareRulesetRulesActionParametersProxyRevalidate {
}
export declare function dataCloudflareRulesetRulesActionParametersProxyRevalidateToTerraform(struct?: DataCloudflareRulesetRulesActionParametersProxyRevalidate): any;
export declare function dataCloudflareRulesetRulesActionParametersProxyRevalidateToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersProxyRevalidate): any;
export declare class DataCloudflareRulesetRulesActionParametersProxyRevalidateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersProxyRevalidate | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersProxyRevalidate | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
}
export interface DataCloudflareRulesetRulesActionParametersPublic {
}
export declare function dataCloudflareRulesetRulesActionParametersPublicToTerraform(struct?: DataCloudflareRulesetRulesActionParametersPublic): any;
export declare function dataCloudflareRulesetRulesActionParametersPublicToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersPublic): any;
export declare class DataCloudflareRulesetRulesActionParametersPublicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersPublic | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersPublic | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
}
export interface DataCloudflareRulesetRulesActionParametersRawResponseFields {
}
export declare function dataCloudflareRulesetRulesActionParametersRawResponseFieldsToTerraform(struct?: DataCloudflareRulesetRulesActionParametersRawResponseFields): any;
export declare function dataCloudflareRulesetRulesActionParametersRawResponseFieldsToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersRawResponseFields): any;
export declare class DataCloudflareRulesetRulesActionParametersRawResponseFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersRawResponseFields | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersRawResponseFields | undefined);
    get name(): string;
    get preserveDuplicates(): cdktn.IResolvable;
}
export declare class DataCloudflareRulesetRulesActionParametersRawResponseFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersRawResponseFieldsOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersRequestFields {
}
export declare function dataCloudflareRulesetRulesActionParametersRequestFieldsToTerraform(struct?: DataCloudflareRulesetRulesActionParametersRequestFields): any;
export declare function dataCloudflareRulesetRulesActionParametersRequestFieldsToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersRequestFields): any;
export declare class DataCloudflareRulesetRulesActionParametersRequestFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersRequestFields | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersRequestFields | undefined);
    get name(): string;
}
export declare class DataCloudflareRulesetRulesActionParametersRequestFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersRequestFieldsOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersResponse {
}
export declare function dataCloudflareRulesetRulesActionParametersResponseToTerraform(struct?: DataCloudflareRulesetRulesActionParametersResponse): any;
export declare function dataCloudflareRulesetRulesActionParametersResponseToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersResponse): any;
export declare class DataCloudflareRulesetRulesActionParametersResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersResponse | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersResponse | undefined);
    get content(): string;
    get contentType(): string;
    get statusCode(): number;
}
export interface DataCloudflareRulesetRulesActionParametersResponseFields {
}
export declare function dataCloudflareRulesetRulesActionParametersResponseFieldsToTerraform(struct?: DataCloudflareRulesetRulesActionParametersResponseFields): any;
export declare function dataCloudflareRulesetRulesActionParametersResponseFieldsToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersResponseFields): any;
export declare class DataCloudflareRulesetRulesActionParametersResponseFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersResponseFields | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersResponseFields | undefined);
    get name(): string;
    get preserveDuplicates(): cdktn.IResolvable;
}
export declare class DataCloudflareRulesetRulesActionParametersResponseFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersResponseFieldsOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersSMaxage {
}
export declare function dataCloudflareRulesetRulesActionParametersSMaxageToTerraform(struct?: DataCloudflareRulesetRulesActionParametersSMaxage): any;
export declare function dataCloudflareRulesetRulesActionParametersSMaxageToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersSMaxage): any;
export declare class DataCloudflareRulesetRulesActionParametersSMaxageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersSMaxage | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersSMaxage | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
    get value(): number;
}
export interface DataCloudflareRulesetRulesActionParametersServeStale {
}
export declare function dataCloudflareRulesetRulesActionParametersServeStaleToTerraform(struct?: DataCloudflareRulesetRulesActionParametersServeStale): any;
export declare function dataCloudflareRulesetRulesActionParametersServeStaleToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersServeStale): any;
export declare class DataCloudflareRulesetRulesActionParametersServeStaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersServeStale | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersServeStale | undefined);
    get disableStaleWhileUpdating(): cdktn.IResolvable;
}
export interface DataCloudflareRulesetRulesActionParametersSni {
}
export declare function dataCloudflareRulesetRulesActionParametersSniToTerraform(struct?: DataCloudflareRulesetRulesActionParametersSni): any;
export declare function dataCloudflareRulesetRulesActionParametersSniToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersSni): any;
export declare class DataCloudflareRulesetRulesActionParametersSniOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersSni | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersSni | undefined);
    get value(): string;
}
export interface DataCloudflareRulesetRulesActionParametersStaleIfError {
}
export declare function dataCloudflareRulesetRulesActionParametersStaleIfErrorToTerraform(struct?: DataCloudflareRulesetRulesActionParametersStaleIfError): any;
export declare function dataCloudflareRulesetRulesActionParametersStaleIfErrorToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersStaleIfError): any;
export declare class DataCloudflareRulesetRulesActionParametersStaleIfErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersStaleIfError | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersStaleIfError | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
    get value(): number;
}
export interface DataCloudflareRulesetRulesActionParametersStaleWhileRevalidate {
}
export declare function dataCloudflareRulesetRulesActionParametersStaleWhileRevalidateToTerraform(struct?: DataCloudflareRulesetRulesActionParametersStaleWhileRevalidate): any;
export declare function dataCloudflareRulesetRulesActionParametersStaleWhileRevalidateToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersStaleWhileRevalidate): any;
export declare class DataCloudflareRulesetRulesActionParametersStaleWhileRevalidateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersStaleWhileRevalidate | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersStaleWhileRevalidate | undefined);
    get cloudflareOnly(): cdktn.IResolvable;
    get operation(): string;
    get value(): number;
}
export interface DataCloudflareRulesetRulesActionParametersTransformedRequestFields {
}
export declare function dataCloudflareRulesetRulesActionParametersTransformedRequestFieldsToTerraform(struct?: DataCloudflareRulesetRulesActionParametersTransformedRequestFields): any;
export declare function dataCloudflareRulesetRulesActionParametersTransformedRequestFieldsToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersTransformedRequestFields): any;
export declare class DataCloudflareRulesetRulesActionParametersTransformedRequestFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRulesActionParametersTransformedRequestFields | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersTransformedRequestFields | undefined);
    get name(): string;
}
export declare class DataCloudflareRulesetRulesActionParametersTransformedRequestFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesActionParametersTransformedRequestFieldsOutputReference;
}
export interface DataCloudflareRulesetRulesActionParametersUriPath {
}
export declare function dataCloudflareRulesetRulesActionParametersUriPathToTerraform(struct?: DataCloudflareRulesetRulesActionParametersUriPath): any;
export declare function dataCloudflareRulesetRulesActionParametersUriPathToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersUriPath): any;
export declare class DataCloudflareRulesetRulesActionParametersUriPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersUriPath | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersUriPath | undefined);
    get expression(): string;
    get value(): string;
}
export interface DataCloudflareRulesetRulesActionParametersUriQuery {
}
export declare function dataCloudflareRulesetRulesActionParametersUriQueryToTerraform(struct?: DataCloudflareRulesetRulesActionParametersUriQuery): any;
export declare function dataCloudflareRulesetRulesActionParametersUriQueryToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersUriQuery): any;
export declare class DataCloudflareRulesetRulesActionParametersUriQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersUriQuery | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersUriQuery | undefined);
    get expression(): string;
    get value(): string;
}
export interface DataCloudflareRulesetRulesActionParametersUri {
}
export declare function dataCloudflareRulesetRulesActionParametersUriToTerraform(struct?: DataCloudflareRulesetRulesActionParametersUri): any;
export declare function dataCloudflareRulesetRulesActionParametersUriToHclTerraform(struct?: DataCloudflareRulesetRulesActionParametersUri): any;
export declare class DataCloudflareRulesetRulesActionParametersUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParametersUri | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParametersUri | undefined);
    get origin(): cdktn.IResolvable;
    private _path;
    get path(): DataCloudflareRulesetRulesActionParametersUriPathOutputReference;
    private _query;
    get query(): DataCloudflareRulesetRulesActionParametersUriQueryOutputReference;
}
export interface DataCloudflareRulesetRulesActionParameters {
}
export declare function dataCloudflareRulesetRulesActionParametersToTerraform(struct?: DataCloudflareRulesetRulesActionParameters): any;
export declare function dataCloudflareRulesetRulesActionParametersToHclTerraform(struct?: DataCloudflareRulesetRulesActionParameters): any;
export declare class DataCloudflareRulesetRulesActionParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesActionParameters | undefined;
    set internalValue(value: DataCloudflareRulesetRulesActionParameters | undefined);
    get additionalCacheablePorts(): number[];
    private _algorithms;
    get algorithms(): DataCloudflareRulesetRulesActionParametersAlgorithmsList;
    get assetName(): string;
    get automaticHttpsRewrites(): cdktn.IResolvable;
    private _autominify;
    get autominify(): DataCloudflareRulesetRulesActionParametersAutominifyOutputReference;
    get bic(): cdktn.IResolvable;
    private _browserTtl;
    get browserTtl(): DataCloudflareRulesetRulesActionParametersBrowserTtlOutputReference;
    get cache(): cdktn.IResolvable;
    private _cacheKey;
    get cacheKey(): DataCloudflareRulesetRulesActionParametersCacheKeyOutputReference;
    private _cacheReserve;
    get cacheReserve(): DataCloudflareRulesetRulesActionParametersCacheReserveOutputReference;
    get content(): string;
    get contentConverter(): cdktn.IResolvable;
    get contentType(): string;
    private _cookieFields;
    get cookieFields(): DataCloudflareRulesetRulesActionParametersCookieFieldsList;
    get disableApps(): cdktn.IResolvable;
    get disableRum(): cdktn.IResolvable;
    get disableZaraz(): cdktn.IResolvable;
    private _edgeTtl;
    get edgeTtl(): DataCloudflareRulesetRulesActionParametersEdgeTtlOutputReference;
    get emailObfuscation(): cdktn.IResolvable;
    get expression(): string;
    get fonts(): cdktn.IResolvable;
    private _fromList;
    get fromList(): DataCloudflareRulesetRulesActionParametersFromListStructOutputReference;
    private _fromValue;
    get fromValue(): DataCloudflareRulesetRulesActionParametersFromValueOutputReference;
    private _headers;
    get headers(): DataCloudflareRulesetRulesActionParametersHeadersMap;
    get hostHeader(): string;
    get hotlinkProtection(): cdktn.IResolvable;
    get id(): string;
    private _immutable;
    get immutable(): DataCloudflareRulesetRulesActionParametersImmutableOutputReference;
    get increment(): number;
    private _matchedData;
    get matchedData(): DataCloudflareRulesetRulesActionParametersMatchedDataOutputReference;
    private _maxAge;
    get maxAge(): DataCloudflareRulesetRulesActionParametersMaxAgeOutputReference;
    get mirage(): cdktn.IResolvable;
    private _mustRevalidate;
    get mustRevalidate(): DataCloudflareRulesetRulesActionParametersMustRevalidateOutputReference;
    private _mustUnderstand;
    get mustUnderstand(): DataCloudflareRulesetRulesActionParametersMustUnderstandOutputReference;
    private _noCache;
    get noCache(): DataCloudflareRulesetRulesActionParametersNoCacheOutputReference;
    private _noStore;
    get noStore(): DataCloudflareRulesetRulesActionParametersNoStoreOutputReference;
    private _noTransform;
    get noTransform(): DataCloudflareRulesetRulesActionParametersNoTransformOutputReference;
    get operation(): string;
    get opportunisticEncryption(): cdktn.IResolvable;
    private _origin;
    get origin(): DataCloudflareRulesetRulesActionParametersOriginOutputReference;
    get originCacheControl(): cdktn.IResolvable;
    get originErrorPagePassthru(): cdktn.IResolvable;
    private _overrides;
    get overrides(): DataCloudflareRulesetRulesActionParametersOverridesOutputReference;
    get phases(): string[];
    get polish(): string;
    private _private;
    get private(): DataCloudflareRulesetRulesActionParametersPrivateOutputReference;
    get products(): string[];
    private _proxyRevalidate;
    get proxyRevalidate(): DataCloudflareRulesetRulesActionParametersProxyRevalidateOutputReference;
    private _public;
    get public(): DataCloudflareRulesetRulesActionParametersPublicOutputReference;
    private _rawResponseFields;
    get rawResponseFields(): DataCloudflareRulesetRulesActionParametersRawResponseFieldsList;
    get readTimeout(): number;
    get redirectsForAiTraining(): cdktn.IResolvable;
    get requestBodyBuffering(): string;
    private _requestFields;
    get requestFields(): DataCloudflareRulesetRulesActionParametersRequestFieldsList;
    get respectStrongEtags(): cdktn.IResolvable;
    private _response;
    get response(): DataCloudflareRulesetRulesActionParametersResponseOutputReference;
    get responseBodyBuffering(): string;
    private _responseFields;
    get responseFields(): DataCloudflareRulesetRulesActionParametersResponseFieldsList;
    get rocketLoader(): cdktn.IResolvable;
    private _rules;
    get rules(): cdktn.StringListMap;
    get ruleset(): string;
    get rulesets(): string[];
    private _sMaxage;
    get sMaxage(): DataCloudflareRulesetRulesActionParametersSMaxageOutputReference;
    get securityLevel(): string;
    private _serveStale;
    get serveStale(): DataCloudflareRulesetRulesActionParametersServeStaleOutputReference;
    get serverSideExcludes(): cdktn.IResolvable;
    private _sni;
    get sni(): DataCloudflareRulesetRulesActionParametersSniOutputReference;
    get ssl(): string;
    private _staleIfError;
    get staleIfError(): DataCloudflareRulesetRulesActionParametersStaleIfErrorOutputReference;
    private _staleWhileRevalidate;
    get staleWhileRevalidate(): DataCloudflareRulesetRulesActionParametersStaleWhileRevalidateOutputReference;
    get statusCode(): number;
    get stripEtags(): cdktn.IResolvable;
    get stripLastModified(): cdktn.IResolvable;
    get stripSetCookie(): cdktn.IResolvable;
    get sxg(): cdktn.IResolvable;
    private _transformedRequestFields;
    get transformedRequestFields(): DataCloudflareRulesetRulesActionParametersTransformedRequestFieldsList;
    private _uri;
    get uri(): DataCloudflareRulesetRulesActionParametersUriOutputReference;
    get values(): string[];
}
export interface DataCloudflareRulesetRulesExposedCredentialCheck {
}
export declare function dataCloudflareRulesetRulesExposedCredentialCheckToTerraform(struct?: DataCloudflareRulesetRulesExposedCredentialCheck): any;
export declare function dataCloudflareRulesetRulesExposedCredentialCheckToHclTerraform(struct?: DataCloudflareRulesetRulesExposedCredentialCheck): any;
export declare class DataCloudflareRulesetRulesExposedCredentialCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesExposedCredentialCheck | undefined;
    set internalValue(value: DataCloudflareRulesetRulesExposedCredentialCheck | undefined);
    get passwordExpression(): string;
    get usernameExpression(): string;
}
export interface DataCloudflareRulesetRulesLogging {
}
export declare function dataCloudflareRulesetRulesLoggingToTerraform(struct?: DataCloudflareRulesetRulesLogging): any;
export declare function dataCloudflareRulesetRulesLoggingToHclTerraform(struct?: DataCloudflareRulesetRulesLogging): any;
export declare class DataCloudflareRulesetRulesLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesLogging | undefined;
    set internalValue(value: DataCloudflareRulesetRulesLogging | undefined);
    get enabled(): cdktn.IResolvable;
}
export interface DataCloudflareRulesetRulesRatelimit {
}
export declare function dataCloudflareRulesetRulesRatelimitToTerraform(struct?: DataCloudflareRulesetRulesRatelimit): any;
export declare function dataCloudflareRulesetRulesRatelimitToHclTerraform(struct?: DataCloudflareRulesetRulesRatelimit): any;
export declare class DataCloudflareRulesetRulesRatelimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRulesetRulesRatelimit | undefined;
    set internalValue(value: DataCloudflareRulesetRulesRatelimit | undefined);
    get characteristics(): string[];
    get countingExpression(): string;
    get mitigationTimeout(): number;
    get period(): number;
    get requestsPerPeriod(): number;
    get requestsToOrigin(): cdktn.IResolvable;
    get scorePerPeriod(): number;
    get scoreResponseHeaderName(): string;
}
export interface DataCloudflareRulesetRules {
}
export declare function dataCloudflareRulesetRulesToTerraform(struct?: DataCloudflareRulesetRules): any;
export declare function dataCloudflareRulesetRulesToHclTerraform(struct?: DataCloudflareRulesetRules): any;
export declare class DataCloudflareRulesetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRulesetRules | undefined;
    set internalValue(value: DataCloudflareRulesetRules | undefined);
    get action(): string;
    private _actionParameters;
    get actionParameters(): DataCloudflareRulesetRulesActionParametersOutputReference;
    get categories(): string[];
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _exposedCredentialCheck;
    get exposedCredentialCheck(): DataCloudflareRulesetRulesExposedCredentialCheckOutputReference;
    get expression(): string;
    get id(): string;
    private _logging;
    get logging(): DataCloudflareRulesetRulesLoggingOutputReference;
    private _ratelimit;
    get ratelimit(): DataCloudflareRulesetRulesRatelimitOutputReference;
    get ref(): string;
}
export declare class DataCloudflareRulesetRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRulesetRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ruleset cloudflare_ruleset}
*/
export declare class DataCloudflareRuleset extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ruleset";
    /**
    * Generates CDKTN code for importing a DataCloudflareRuleset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareRuleset to import
    * @param importFromId The id of the existing DataCloudflareRuleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ruleset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareRuleset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/ruleset cloudflare_ruleset} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareRulesetConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareRulesetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kind(): string;
    get lastUpdated(): string;
    get name(): string;
    get phase(): string;
    private _rules;
    get rules(): DataCloudflareRulesetRulesList;
    private _rulesetId?;
    get rulesetId(): string;
    set rulesetId(value: string);
    resetRulesetId(): void;
    get rulesetIdInput(): string | undefined;
    get version(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
