/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpPredefinedProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_predefined_profile#account_id DataCloudflareZeroTrustDlpPredefinedProfile#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_predefined_profile#profile_id DataCloudflareZeroTrustDlpPredefinedProfile#profile_id}
    */
    readonly profileId: string;
}
export interface DataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidence {
}
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidence): any;
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidence): any;
export declare class DataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpPredefinedProfileEntriesPattern {
}
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesPatternToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntriesPattern): any;
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntriesPattern): any;
export declare class DataCloudflareZeroTrustDlpPredefinedProfileEntriesPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedProfileEntriesPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedProfileEntriesPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpPredefinedProfileEntriesVariant {
}
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesVariantToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntriesVariant): any;
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntriesVariant): any;
export declare class DataCloudflareZeroTrustDlpPredefinedProfileEntriesVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedProfileEntriesVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedProfileEntriesVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
export interface DataCloudflareZeroTrustDlpPredefinedProfileEntries {
}
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesToTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntries): any;
export declare function dataCloudflareZeroTrustDlpPredefinedProfileEntriesToHclTerraform(struct?: DataCloudflareZeroTrustDlpPredefinedProfileEntries): any;
export declare class DataCloudflareZeroTrustDlpPredefinedProfileEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpPredefinedProfileEntries | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpPredefinedProfileEntries | undefined);
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpPredefinedProfileEntriesConfidenceOutputReference;
    get createdAt(): string;
    get deprecated(): cdktn.IResolvable;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpPredefinedProfileEntriesPatternOutputReference;
    get profileId(): string;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpPredefinedProfileEntriesVariantOutputReference;
    get wordList(): string;
}
export declare class DataCloudflareZeroTrustDlpPredefinedProfileEntriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpPredefinedProfileEntriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_predefined_profile cloudflare_zero_trust_dlp_predefined_profile}
*/
export declare class DataCloudflareZeroTrustDlpPredefinedProfile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_predefined_profile";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpPredefinedProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpPredefinedProfile to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpPredefinedProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_predefined_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpPredefinedProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_predefined_profile cloudflare_zero_trust_dlp_predefined_profile} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpPredefinedProfileConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpPredefinedProfileConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get aiContextEnabled(): cdktn.IResolvable;
    get allowedMatchCount(): number;
    get confidenceThreshold(): string;
    get enabledEntries(): string[];
    private _entries;
    get entries(): DataCloudflareZeroTrustDlpPredefinedProfileEntriesList;
    get id(): string;
    get name(): string;
    get ocrEnabled(): cdktn.IResolvable;
    get openAccess(): cdktn.IResolvable;
    private _profileId?;
    get profileId(): string;
    set profileId(value: string);
    get profileIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
