/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCasbPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policies#account_id DataCloudflareZeroTrustCasbPolicies#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policies#max_items DataCloudflareZeroTrustCasbPolicies#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypes {
}
export declare function dataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypesToTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypes): any;
export declare function dataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypesToHclTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypes): any;
export declare class DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypes | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypes | undefined);
    get displayName(): string;
    get remediationType(): string;
    get remediationTypeId(): string;
}
export declare class DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypesOutputReference;
}
export interface DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigs {
}
export declare function dataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigsToTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigs): any;
export declare function dataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigsToHclTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigs): any;
export declare class DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigs | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigs | undefined);
    get displayName(): string;
    get webhookConfigId(): string;
}
export declare class DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigsOutputReference;
}
export interface DataCloudflareZeroTrustCasbPoliciesResultActions {
}
export declare function dataCloudflareZeroTrustCasbPoliciesResultActionsToTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResultActions): any;
export declare function dataCloudflareZeroTrustCasbPoliciesResultActionsToHclTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResultActions): any;
export declare class DataCloudflareZeroTrustCasbPoliciesResultActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustCasbPoliciesResultActions | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbPoliciesResultActions | undefined);
    private _remediationTypes;
    get remediationTypes(): DataCloudflareZeroTrustCasbPoliciesResultActionsRemediationTypesList;
    private _webhookConfigs;
    get webhookConfigs(): DataCloudflareZeroTrustCasbPoliciesResultActionsWebhookConfigsList;
}
export interface DataCloudflareZeroTrustCasbPoliciesResult {
}
export declare function dataCloudflareZeroTrustCasbPoliciesResultToTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResult): any;
export declare function dataCloudflareZeroTrustCasbPoliciesResultToHclTerraform(struct?: DataCloudflareZeroTrustCasbPoliciesResult): any;
export declare class DataCloudflareZeroTrustCasbPoliciesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbPoliciesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbPoliciesResult | undefined);
    private _actions;
    get actions(): DataCloudflareZeroTrustCasbPoliciesResultActionsOutputReference;
    get appliesToAllIntegrations(): cdktn.IResolvable;
    get createdAt(): string;
    get description(): string;
    get disabledAt(): string;
    get displayName(): string;
    get enabled(): cdktn.IResolvable;
    get findingTypeId(): string;
    get id(): string;
    get integrationIds(): string[];
    get lastTriggeredAt(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustCasbPoliciesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbPoliciesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policies cloudflare_zero_trust_casb_policies}
*/
export declare class DataCloudflareZeroTrustCasbPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_casb_policies";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCasbPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCasbPolicies to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCasbPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCasbPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_policies cloudflare_zero_trust_casb_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCasbPoliciesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCasbPoliciesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCasbPoliciesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
