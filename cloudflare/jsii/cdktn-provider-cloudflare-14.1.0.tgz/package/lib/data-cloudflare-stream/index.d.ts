/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream#account_id DataCloudflareStream#account_id}
    */
    readonly accountId: string;
    /**
    * A Cloudflare-generated unique identifier for a media item.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream#identifier DataCloudflareStream#identifier}
    */
    readonly identifier: string;
}
export interface DataCloudflareStreamInput {
}
export declare function dataCloudflareStreamInputToTerraform(struct?: DataCloudflareStreamInput): any;
export declare function dataCloudflareStreamInputToHclTerraform(struct?: DataCloudflareStreamInput): any;
export declare class DataCloudflareStreamInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamInput | undefined;
    set internalValue(value: DataCloudflareStreamInput | undefined);
    get height(): number;
    get width(): number;
}
export interface DataCloudflareStreamPlayback {
}
export declare function dataCloudflareStreamPlaybackToTerraform(struct?: DataCloudflareStreamPlayback): any;
export declare function dataCloudflareStreamPlaybackToHclTerraform(struct?: DataCloudflareStreamPlayback): any;
export declare class DataCloudflareStreamPlaybackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamPlayback | undefined;
    set internalValue(value: DataCloudflareStreamPlayback | undefined);
    get dash(): string;
    get hls(): string;
}
export interface DataCloudflareStreamStatus {
}
export declare function dataCloudflareStreamStatusToTerraform(struct?: DataCloudflareStreamStatus): any;
export declare function dataCloudflareStreamStatusToHclTerraform(struct?: DataCloudflareStreamStatus): any;
export declare class DataCloudflareStreamStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamStatus | undefined;
    set internalValue(value: DataCloudflareStreamStatus | undefined);
    get errorReasonCode(): string;
    get errorReasonText(): string;
    get pctComplete(): string;
    get state(): string;
}
export interface DataCloudflareStreamWatermark {
}
export declare function dataCloudflareStreamWatermarkToTerraform(struct?: DataCloudflareStreamWatermark): any;
export declare function dataCloudflareStreamWatermarkToHclTerraform(struct?: DataCloudflareStreamWatermark): any;
export declare class DataCloudflareStreamWatermarkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareStreamWatermark | undefined;
    set internalValue(value: DataCloudflareStreamWatermark | undefined);
    get created(): string;
    get downloadedFrom(): string;
    get height(): number;
    get name(): string;
    get opacity(): number;
    get padding(): number;
    get position(): string;
    get scale(): number;
    get size(): number;
    get uid(): string;
    get width(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream cloudflare_stream}
*/
export declare class DataCloudflareStream extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_stream";
    /**
    * Generates CDKTN code for importing a DataCloudflareStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareStream to import
    * @param importFromId The id of the existing DataCloudflareStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream cloudflare_stream} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareStreamConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareStreamConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get allowedOrigins(): string[];
    get created(): string;
    get creator(): string;
    get duration(): number;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _input;
    get input(): DataCloudflareStreamInputOutputReference;
    get liveInput(): string;
    get maxDurationSeconds(): number;
    get meta(): string;
    get modified(): string;
    private _playback;
    get playback(): DataCloudflareStreamPlaybackOutputReference;
    get preview(): string;
    get readyToStream(): cdktn.IResolvable;
    get readyToStreamAt(): string;
    get requireSignedUrls(): cdktn.IResolvable;
    get scheduledDeletion(): string;
    get size(): number;
    private _status;
    get status(): DataCloudflareStreamStatusOutputReference;
    get thumbnail(): string;
    get thumbnailTimestampPct(): number;
    get uid(): string;
    get uploadExpiry(): string;
    get uploaded(): string;
    private _watermark;
    get watermark(): DataCloudflareStreamWatermarkOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
