/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMoqRelaysConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays#account_id DataCloudflareMoqRelays#account_id}
    */
    readonly accountId: string;
    /**
    * Sort order by `created`. When true, results are returned oldest-first
    * (ascending); otherwise newest-first (descending, the default).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays#asc DataCloudflareMoqRelays#asc}
    */
    readonly asc?: boolean | cdktn.IResolvable;
    /**
    * Cursor for pagination. Returns relays created strictly after this
    * RFC 3339 timestamp (typically the `created` value of the last item
    * on the current page, to fetch the next page).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays#created_after DataCloudflareMoqRelays#created_after}
    */
    readonly createdAfter?: string;
    /**
    * Cursor for pagination. Returns relays created strictly before this
    * RFC 3339 timestamp (typically the `created` value of the first item
    * on the current page, to fetch the previous page).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays#created_before DataCloudflareMoqRelays#created_before}
    */
    readonly createdBefore?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays#max_items DataCloudflareMoqRelays#max_items}
    */
    readonly maxItems?: number;
    /**
    * Maximum number of relays to return per page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays#per_page DataCloudflareMoqRelays#per_page}
    */
    readonly perPage?: number;
}
export interface DataCloudflareMoqRelaysResult {
}
export declare function dataCloudflareMoqRelaysResultToTerraform(struct?: DataCloudflareMoqRelaysResult): any;
export declare function dataCloudflareMoqRelaysResultToHclTerraform(struct?: DataCloudflareMoqRelaysResult): any;
export declare class DataCloudflareMoqRelaysResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMoqRelaysResult | undefined;
    set internalValue(value: DataCloudflareMoqRelaysResult | undefined);
    get created(): string;
    get id(): string;
    get modified(): string;
    get name(): string;
    get uid(): string;
}
export declare class DataCloudflareMoqRelaysResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMoqRelaysResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays cloudflare_moq_relays}
*/
export declare class DataCloudflareMoqRelays extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_moq_relays";
    /**
    * Generates CDKTN code for importing a DataCloudflareMoqRelays resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMoqRelays to import
    * @param importFromId The id of the existing DataCloudflareMoqRelays that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMoqRelays to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/moq_relays cloudflare_moq_relays} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMoqRelaysConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMoqRelaysConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _asc?;
    get asc(): boolean | cdktn.IResolvable;
    set asc(value: boolean | cdktn.IResolvable);
    resetAsc(): void;
    get ascInput(): boolean | cdktn.IResolvable | undefined;
    private _createdAfter?;
    get createdAfter(): string;
    set createdAfter(value: string);
    resetCreatedAfter(): void;
    get createdAfterInput(): string | undefined;
    private _createdBefore?;
    get createdBefore(): string;
    set createdBefore(value: string);
    resetCreatedBefore(): void;
    get createdBeforeInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _perPage?;
    get perPage(): number;
    set perPage(value: number);
    resetPerPage(): void;
    get perPageInput(): number | undefined;
    private _result;
    get result(): DataCloudflareMoqRelaysResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
