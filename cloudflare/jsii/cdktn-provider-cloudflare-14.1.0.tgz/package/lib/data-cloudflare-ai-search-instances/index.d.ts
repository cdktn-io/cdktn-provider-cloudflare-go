/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAiSearchInstancesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ai_search_instances#account_id DataCloudflareAiSearchInstances#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ai_search_instances#max_items DataCloudflareAiSearchInstances#max_items}
    */
    readonly maxItems?: number;
    /**
    * Search by id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ai_search_instances#search DataCloudflareAiSearchInstances#search}
    */
    readonly search?: string;
}
export interface DataCloudflareAiSearchInstancesResultCustomMetadata {
}
export declare function dataCloudflareAiSearchInstancesResultCustomMetadataToTerraform(struct?: DataCloudflareAiSearchInstancesResultCustomMetadata): any;
export declare function dataCloudflareAiSearchInstancesResultCustomMetadataToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultCustomMetadata): any;
export declare class DataCloudflareAiSearchInstancesResultCustomMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiSearchInstancesResultCustomMetadata | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultCustomMetadata | undefined);
    get dataType(): string;
    get fieldName(): string;
}
export declare class DataCloudflareAiSearchInstancesResultCustomMetadataList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiSearchInstancesResultCustomMetadataOutputReference;
}
export interface DataCloudflareAiSearchInstancesResultMetadata {
}
export declare function dataCloudflareAiSearchInstancesResultMetadataToTerraform(struct?: DataCloudflareAiSearchInstancesResultMetadata): any;
export declare function dataCloudflareAiSearchInstancesResultMetadataToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultMetadata): any;
export declare class DataCloudflareAiSearchInstancesResultMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultMetadata | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultMetadata | undefined);
    get createdFromAisearchWizard(): cdktn.IResolvable;
    get workerDomain(): string;
}
export interface DataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpoint {
}
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpointToTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpoint): any;
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpointToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpoint): any;
export declare class DataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpoint | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpoint | undefined);
    get disabled(): cdktn.IResolvable;
}
export interface DataCloudflareAiSearchInstancesResultPublicEndpointParamsMcp {
}
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsMcpToTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsMcp): any;
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsMcpToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsMcp): any;
export declare class DataCloudflareAiSearchInstancesResultPublicEndpointParamsMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsMcp | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultPublicEndpointParamsMcp | undefined);
    get description(): string;
    get disabled(): cdktn.IResolvable;
}
export interface DataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimit {
}
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimitToTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimit): any;
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimitToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimit): any;
export declare class DataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimit | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimit | undefined);
    get periodMs(): number;
    get requests(): number;
    get technique(): string;
}
export interface DataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpoint {
}
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpointToTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpoint): any;
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpointToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpoint): any;
export declare class DataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpoint | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpoint | undefined);
    get disabled(): cdktn.IResolvable;
}
export interface DataCloudflareAiSearchInstancesResultPublicEndpointParams {
}
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsToTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParams): any;
export declare function dataCloudflareAiSearchInstancesResultPublicEndpointParamsToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultPublicEndpointParams): any;
export declare class DataCloudflareAiSearchInstancesResultPublicEndpointParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultPublicEndpointParams | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultPublicEndpointParams | undefined);
    get authorizedHosts(): string[];
    private _chatCompletionsEndpoint;
    get chatCompletionsEndpoint(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsChatCompletionsEndpointOutputReference;
    get enabled(): cdktn.IResolvable;
    private _mcp;
    get mcp(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsMcpOutputReference;
    private _rateLimit;
    get rateLimit(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsRateLimitOutputReference;
    private _searchEndpoint;
    get searchEndpoint(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsSearchEndpointOutputReference;
}
export interface DataCloudflareAiSearchInstancesResultRetrievalOptions {
}
export declare function dataCloudflareAiSearchInstancesResultRetrievalOptionsToTerraform(struct?: DataCloudflareAiSearchInstancesResultRetrievalOptions): any;
export declare function dataCloudflareAiSearchInstancesResultRetrievalOptionsToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultRetrievalOptions): any;
export declare class DataCloudflareAiSearchInstancesResultRetrievalOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultRetrievalOptions | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultRetrievalOptions | undefined);
    get keywordMatchMode(): string;
}
export interface DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptions {
}
export declare function dataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptionsToTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptions): any;
export declare function dataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptionsToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptions): any;
export declare class DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptions | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptions | undefined);
    private _includeHeaders;
    get includeHeaders(): cdktn.StringMap;
    get includeImages(): cdktn.IResolvable;
    get specificSitemaps(): string[];
    get useBrowserRendering(): cdktn.IResolvable;
}
export interface DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptions {
}
export declare function dataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptionsToTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptions): any;
export declare function dataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptionsToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptions): any;
export declare class DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptions | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptions | undefined);
    get r2Jurisdiction(): string;
    get storageId(): string;
    get storageType(): string;
}
export interface DataCloudflareAiSearchInstancesResultSourceParamsWebCrawler {
}
export declare function dataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerToTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawler): any;
export declare function dataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawler): any;
export declare class DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultSourceParamsWebCrawler | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultSourceParamsWebCrawler | undefined);
    private _parseOptions;
    get parseOptions(): DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerParseOptionsOutputReference;
    get parseType(): string;
    private _storeOptions;
    get storeOptions(): DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerStoreOptionsOutputReference;
}
export interface DataCloudflareAiSearchInstancesResultSourceParams {
}
export declare function dataCloudflareAiSearchInstancesResultSourceParamsToTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParams): any;
export declare function dataCloudflareAiSearchInstancesResultSourceParamsToHclTerraform(struct?: DataCloudflareAiSearchInstancesResultSourceParams): any;
export declare class DataCloudflareAiSearchInstancesResultSourceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiSearchInstancesResultSourceParams | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResultSourceParams | undefined);
    get excludeItems(): string[];
    get includeItems(): string[];
    get prefix(): string;
    get r2Jurisdiction(): string;
    private _webCrawler;
    get webCrawler(): DataCloudflareAiSearchInstancesResultSourceParamsWebCrawlerOutputReference;
}
export interface DataCloudflareAiSearchInstancesResult {
}
export declare function dataCloudflareAiSearchInstancesResultToTerraform(struct?: DataCloudflareAiSearchInstancesResult): any;
export declare function dataCloudflareAiSearchInstancesResultToHclTerraform(struct?: DataCloudflareAiSearchInstancesResult): any;
export declare class DataCloudflareAiSearchInstancesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiSearchInstancesResult | undefined;
    set internalValue(value: DataCloudflareAiSearchInstancesResult | undefined);
    get aiGatewayId(): string;
    get aisearchModel(): string;
    get cache(): cdktn.IResolvable;
    get cacheThreshold(): string;
    get chunkOverlap(): number;
    get chunkSize(): number;
    get createdAt(): string;
    get createdBy(): string;
    private _customMetadata;
    get customMetadata(): DataCloudflareAiSearchInstancesResultCustomMetadataList;
    get embeddingModel(): string;
    get enable(): cdktn.IResolvable;
    get fusionMethod(): string;
    get hybridSearchEnabled(): cdktn.IResolvable;
    get id(): string;
    get lastActivity(): string;
    get maxNumResults(): number;
    private _metadata;
    get metadata(): DataCloudflareAiSearchInstancesResultMetadataOutputReference;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get paused(): cdktn.IResolvable;
    get publicEndpointId(): string;
    private _publicEndpointParams;
    get publicEndpointParams(): DataCloudflareAiSearchInstancesResultPublicEndpointParamsOutputReference;
    get reranking(): cdktn.IResolvable;
    get rerankingModel(): string;
    private _retrievalOptions;
    get retrievalOptions(): DataCloudflareAiSearchInstancesResultRetrievalOptionsOutputReference;
    get rewriteModel(): string;
    get rewriteQuery(): cdktn.IResolvable;
    get scoreThreshold(): number;
    get source(): string;
    private _sourceParams;
    get sourceParams(): DataCloudflareAiSearchInstancesResultSourceParamsOutputReference;
    get status(): string;
    get tokenId(): string;
    get type(): string;
    get vectorizeName(): string;
}
export declare class DataCloudflareAiSearchInstancesResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiSearchInstancesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ai_search_instances cloudflare_ai_search_instances}
*/
export declare class DataCloudflareAiSearchInstances extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ai_search_instances";
    /**
    * Generates CDKTN code for importing a DataCloudflareAiSearchInstances resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAiSearchInstances to import
    * @param importFromId The id of the existing DataCloudflareAiSearchInstances that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ai_search_instances#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAiSearchInstances to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/ai_search_instances cloudflare_ai_search_instances} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAiSearchInstancesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareAiSearchInstancesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareAiSearchInstancesResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
