/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSecurityTrustedDomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#account_id DataCloudflareEmailSecurityTrustedDomains#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#filter DataCloudflareEmailSecurityTrustedDomains#filter}
    */
    readonly filter?: DataCloudflareEmailSecurityTrustedDomainsFilter;
    /**
    * Trusted domain identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#trusted_domain_id DataCloudflareEmailSecurityTrustedDomains#trusted_domain_id}
    */
    readonly trustedDomainId?: string;
}
export interface DataCloudflareEmailSecurityTrustedDomainsFilter {
    /**
    * The sorting direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#direction DataCloudflareEmailSecurityTrustedDomains#direction}
    */
    readonly direction?: string;
    /**
    * Filter to show only recently registered domains that are trusted to prevent triggering Suspicious or Malicious dispositions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#is_recent DataCloudflareEmailSecurityTrustedDomains#is_recent}
    */
    readonly isRecent?: boolean | cdktn.IResolvable;
    /**
    * Filter to show only proximity domains (partner or approved domains with similar spelling to connected domains) that prevent Spoof dispositions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#is_similarity DataCloudflareEmailSecurityTrustedDomains#is_similarity}
    */
    readonly isSimilarity?: boolean | cdktn.IResolvable;
    /**
    * Field to sort by.
    * Available values: "pattern", "created_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#order DataCloudflareEmailSecurityTrustedDomains#order}
    */
    readonly order?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#pattern DataCloudflareEmailSecurityTrustedDomains#pattern}
    */
    readonly pattern?: string;
    /**
    * Search term for filtering records. Behavior may change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#search DataCloudflareEmailSecurityTrustedDomains#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareEmailSecurityTrustedDomainsFilterToTerraform(struct?: DataCloudflareEmailSecurityTrustedDomainsFilter | cdktn.IResolvable): any;
export declare function dataCloudflareEmailSecurityTrustedDomainsFilterToHclTerraform(struct?: DataCloudflareEmailSecurityTrustedDomainsFilter | cdktn.IResolvable): any;
export declare class DataCloudflareEmailSecurityTrustedDomainsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityTrustedDomainsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareEmailSecurityTrustedDomainsFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _isRecent?;
    get isRecent(): boolean | cdktn.IResolvable;
    set isRecent(value: boolean | cdktn.IResolvable);
    resetIsRecent(): void;
    get isRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _isSimilarity?;
    get isSimilarity(): boolean | cdktn.IResolvable;
    set isSimilarity(value: boolean | cdktn.IResolvable);
    resetIsSimilarity(): void;
    get isSimilarityInput(): boolean | cdktn.IResolvable | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains cloudflare_email_security_trusted_domains}
*/
export declare class DataCloudflareEmailSecurityTrustedDomains extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_security_trusted_domains";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSecurityTrustedDomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSecurityTrustedDomains to import
    * @param importFromId The id of the existing DataCloudflareEmailSecurityTrustedDomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSecurityTrustedDomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/email_security_trusted_domains cloudflare_email_security_trusted_domains} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSecurityTrustedDomainsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareEmailSecurityTrustedDomainsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get comments(): string;
    get createdAt(): string;
    private _filter;
    get filter(): DataCloudflareEmailSecurityTrustedDomainsFilterOutputReference;
    putFilter(value: DataCloudflareEmailSecurityTrustedDomainsFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareEmailSecurityTrustedDomainsFilter | undefined;
    get id(): string;
    get isRecent(): cdktn.IResolvable;
    get isRegex(): cdktn.IResolvable;
    get isSimilarity(): cdktn.IResolvable;
    get lastModified(): string;
    get modifiedAt(): string;
    get pattern(): string;
    private _trustedDomainId?;
    get trustedDomainId(): string;
    set trustedDomainId(value: string);
    resetTrustedDomainId(): void;
    get trustedDomainIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
