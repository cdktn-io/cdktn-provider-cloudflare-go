/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareApiTokensConfig extends cdktn.TerraformMetaArguments {
    /**
    * Direction to order results.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/api_tokens#direction DataCloudflareApiTokens#direction}
    */
    readonly direction?: string;
    /**
    * When true, includes recently-expired tokens in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/api_tokens#include_expired DataCloudflareApiTokens#include_expired}
    */
    readonly includeExpired?: boolean | cdktn.IResolvable;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/api_tokens#max_items DataCloudflareApiTokens#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareApiTokensResultConditionRequestIp {
}
export declare function dataCloudflareApiTokensResultConditionRequestIpToTerraform(struct?: DataCloudflareApiTokensResultConditionRequestIp): any;
export declare function dataCloudflareApiTokensResultConditionRequestIpToHclTerraform(struct?: DataCloudflareApiTokensResultConditionRequestIp): any;
export declare class DataCloudflareApiTokensResultConditionRequestIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareApiTokensResultConditionRequestIp | undefined;
    set internalValue(value: DataCloudflareApiTokensResultConditionRequestIp | undefined);
    get in(): string[];
    get notIn(): string[];
}
export interface DataCloudflareApiTokensResultCondition {
}
export declare function dataCloudflareApiTokensResultConditionToTerraform(struct?: DataCloudflareApiTokensResultCondition): any;
export declare function dataCloudflareApiTokensResultConditionToHclTerraform(struct?: DataCloudflareApiTokensResultCondition): any;
export declare class DataCloudflareApiTokensResultConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareApiTokensResultCondition | undefined;
    set internalValue(value: DataCloudflareApiTokensResultCondition | undefined);
    private _requestIp;
    get requestIp(): DataCloudflareApiTokensResultConditionRequestIpOutputReference;
}
export interface DataCloudflareApiTokensResultPoliciesPermissionGroupsMeta {
}
export declare function dataCloudflareApiTokensResultPoliciesPermissionGroupsMetaToTerraform(struct?: DataCloudflareApiTokensResultPoliciesPermissionGroupsMeta): any;
export declare function dataCloudflareApiTokensResultPoliciesPermissionGroupsMetaToHclTerraform(struct?: DataCloudflareApiTokensResultPoliciesPermissionGroupsMeta): any;
export declare class DataCloudflareApiTokensResultPoliciesPermissionGroupsMetaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareApiTokensResultPoliciesPermissionGroupsMeta | undefined;
    set internalValue(value: DataCloudflareApiTokensResultPoliciesPermissionGroupsMeta | undefined);
    get key(): string;
    get value(): string;
}
export interface DataCloudflareApiTokensResultPoliciesPermissionGroups {
}
export declare function dataCloudflareApiTokensResultPoliciesPermissionGroupsToTerraform(struct?: DataCloudflareApiTokensResultPoliciesPermissionGroups): any;
export declare function dataCloudflareApiTokensResultPoliciesPermissionGroupsToHclTerraform(struct?: DataCloudflareApiTokensResultPoliciesPermissionGroups): any;
export declare class DataCloudflareApiTokensResultPoliciesPermissionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareApiTokensResultPoliciesPermissionGroups | undefined;
    set internalValue(value: DataCloudflareApiTokensResultPoliciesPermissionGroups | undefined);
    get id(): string;
    private _meta;
    get meta(): DataCloudflareApiTokensResultPoliciesPermissionGroupsMetaOutputReference;
    get name(): string;
}
export declare class DataCloudflareApiTokensResultPoliciesPermissionGroupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareApiTokensResultPoliciesPermissionGroupsOutputReference;
}
export interface DataCloudflareApiTokensResultPolicies {
}
export declare function dataCloudflareApiTokensResultPoliciesToTerraform(struct?: DataCloudflareApiTokensResultPolicies): any;
export declare function dataCloudflareApiTokensResultPoliciesToHclTerraform(struct?: DataCloudflareApiTokensResultPolicies): any;
export declare class DataCloudflareApiTokensResultPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareApiTokensResultPolicies | undefined;
    set internalValue(value: DataCloudflareApiTokensResultPolicies | undefined);
    get effect(): string;
    get id(): string;
    private _permissionGroups;
    get permissionGroups(): DataCloudflareApiTokensResultPoliciesPermissionGroupsList;
    private _resources;
    get resources(): cdktn.StringMap;
}
export declare class DataCloudflareApiTokensResultPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareApiTokensResultPoliciesOutputReference;
}
export interface DataCloudflareApiTokensResult {
}
export declare function dataCloudflareApiTokensResultToTerraform(struct?: DataCloudflareApiTokensResult): any;
export declare function dataCloudflareApiTokensResultToHclTerraform(struct?: DataCloudflareApiTokensResult): any;
export declare class DataCloudflareApiTokensResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareApiTokensResult | undefined;
    set internalValue(value: DataCloudflareApiTokensResult | undefined);
    private _condition;
    get condition(): DataCloudflareApiTokensResultConditionOutputReference;
    get expiresOn(): string;
    get id(): string;
    get issuedOn(): string;
    get lastUsedOn(): string;
    get modifiedOn(): string;
    get name(): string;
    get notBefore(): string;
    private _policies;
    get policies(): DataCloudflareApiTokensResultPoliciesList;
    get status(): string;
}
export declare class DataCloudflareApiTokensResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareApiTokensResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/api_tokens cloudflare_api_tokens}
*/
export declare class DataCloudflareApiTokens extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_api_tokens";
    /**
    * Generates CDKTN code for importing a DataCloudflareApiTokens resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareApiTokens to import
    * @param importFromId The id of the existing DataCloudflareApiTokens that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/api_tokens#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareApiTokens to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/api_tokens cloudflare_api_tokens} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareApiTokensConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareApiTokensConfig);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _includeExpired?;
    get includeExpired(): boolean | cdktn.IResolvable;
    set includeExpired(value: boolean | cdktn.IResolvable);
    resetIncludeExpired(): void;
    get includeExpiredInput(): boolean | cdktn.IResolvable | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareApiTokensResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
