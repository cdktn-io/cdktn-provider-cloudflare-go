/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpDataTagCategoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_data_tag_category#account_id DataCloudflareZeroTrustDlpDataTagCategory#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_data_tag_category#category_id DataCloudflareZeroTrustDlpDataTagCategory#category_id}
    */
    readonly categoryId: string;
}
export interface DataCloudflareZeroTrustDlpDataTagCategoryTags {
}
export declare function dataCloudflareZeroTrustDlpDataTagCategoryTagsToTerraform(struct?: DataCloudflareZeroTrustDlpDataTagCategoryTags): any;
export declare function dataCloudflareZeroTrustDlpDataTagCategoryTagsToHclTerraform(struct?: DataCloudflareZeroTrustDlpDataTagCategoryTags): any;
export declare class DataCloudflareZeroTrustDlpDataTagCategoryTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpDataTagCategoryTags | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpDataTagCategoryTags | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustDlpDataTagCategoryTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpDataTagCategoryTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_data_tag_category cloudflare_zero_trust_dlp_data_tag_category}
*/
export declare class DataCloudflareZeroTrustDlpDataTagCategory extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_data_tag_category";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpDataTagCategory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpDataTagCategory to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpDataTagCategory that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_data_tag_category#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpDataTagCategory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_dlp_data_tag_category cloudflare_zero_trust_dlp_data_tag_category} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpDataTagCategoryConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpDataTagCategoryConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _categoryId?;
    get categoryId(): string;
    set categoryId(value: string);
    get categoryIdInput(): string | undefined;
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
    private _tags;
    get tags(): DataCloudflareZeroTrustDlpDataTagCategoryTagsList;
    get templateId(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
