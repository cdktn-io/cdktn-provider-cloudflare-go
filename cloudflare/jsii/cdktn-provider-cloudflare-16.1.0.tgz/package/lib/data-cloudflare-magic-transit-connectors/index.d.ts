/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicTransitConnectorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_connectors#account_id DataCloudflareMagicTransitConnectors#account_id}
    */
    readonly accountId?: string;
    /**
    * Filter connectors by device type.
    * Available values: "MANAGED", "LICENSED".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_connectors#device_type DataCloudflareMagicTransitConnectors#device_type}
    */
    readonly deviceType?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_connectors#max_items DataCloudflareMagicTransitConnectors#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareMagicTransitConnectorsResultDevice {
}
export declare function dataCloudflareMagicTransitConnectorsResultDeviceToTerraform(struct?: DataCloudflareMagicTransitConnectorsResultDevice): any;
export declare function dataCloudflareMagicTransitConnectorsResultDeviceToHclTerraform(struct?: DataCloudflareMagicTransitConnectorsResultDevice): any;
export declare class DataCloudflareMagicTransitConnectorsResultDeviceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitConnectorsResultDevice | undefined;
    set internalValue(value: DataCloudflareMagicTransitConnectorsResultDevice | undefined);
    get id(): string;
    get serialNumber(): string;
    get type(): string;
}
export interface DataCloudflareMagicTransitConnectorsResult {
}
export declare function dataCloudflareMagicTransitConnectorsResultToTerraform(struct?: DataCloudflareMagicTransitConnectorsResult): any;
export declare function dataCloudflareMagicTransitConnectorsResultToHclTerraform(struct?: DataCloudflareMagicTransitConnectorsResult): any;
export declare class DataCloudflareMagicTransitConnectorsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMagicTransitConnectorsResult | undefined;
    set internalValue(value: DataCloudflareMagicTransitConnectorsResult | undefined);
    get activated(): cdktn.IResolvable;
    private _device;
    get device(): DataCloudflareMagicTransitConnectorsResultDeviceOutputReference;
    get id(): string;
    get interruptWindowDaysOfWeek(): string[];
    get interruptWindowDurationHours(): number;
    get interruptWindowEmbargoDates(): string[];
    get interruptWindowHourOfDay(): number;
    get lastHeartbeat(): string;
    get lastSeenVersion(): string;
    get lastUpdated(): string;
    get licenseKey(): string;
    get notes(): string;
    get timezone(): string;
}
export declare class DataCloudflareMagicTransitConnectorsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMagicTransitConnectorsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_connectors cloudflare_magic_transit_connectors}
*/
export declare class DataCloudflareMagicTransitConnectors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_transit_connectors";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicTransitConnectors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicTransitConnectors to import
    * @param importFromId The id of the existing DataCloudflareMagicTransitConnectors that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_connectors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicTransitConnectors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/magic_transit_connectors cloudflare_magic_transit_connectors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicTransitConnectorsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareMagicTransitConnectorsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _deviceType?;
    get deviceType(): string;
    set deviceType(value: string);
    resetDeviceType(): void;
    get deviceTypeInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareMagicTransitConnectorsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
