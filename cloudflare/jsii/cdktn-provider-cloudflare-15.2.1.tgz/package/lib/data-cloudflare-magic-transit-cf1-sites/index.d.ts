/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMagicTransitCf1SitesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_transit_cf1_sites#account_id DataCloudflareMagicTransitCf1Sites#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_transit_cf1_sites#max_items DataCloudflareMagicTransitCf1Sites#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareMagicTransitCf1SitesResultLocation {
}
export declare function dataCloudflareMagicTransitCf1SitesResultLocationToTerraform(struct?: DataCloudflareMagicTransitCf1SitesResultLocation): any;
export declare function dataCloudflareMagicTransitCf1SitesResultLocationToHclTerraform(struct?: DataCloudflareMagicTransitCf1SitesResultLocation): any;
export declare class DataCloudflareMagicTransitCf1SitesResultLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMagicTransitCf1SitesResultLocation | undefined;
    set internalValue(value: DataCloudflareMagicTransitCf1SitesResultLocation | undefined);
    get lat(): number;
    get long(): number;
    get name(): string;
}
export interface DataCloudflareMagicTransitCf1SitesResult {
}
export declare function dataCloudflareMagicTransitCf1SitesResultToTerraform(struct?: DataCloudflareMagicTransitCf1SitesResult): any;
export declare function dataCloudflareMagicTransitCf1SitesResultToHclTerraform(struct?: DataCloudflareMagicTransitCf1SitesResult): any;
export declare class DataCloudflareMagicTransitCf1SitesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMagicTransitCf1SitesResult | undefined;
    set internalValue(value: DataCloudflareMagicTransitCf1SitesResult | undefined);
    get createdOn(): string;
    get description(): string;
    get id(): string;
    private _location;
    get location(): DataCloudflareMagicTransitCf1SitesResultLocationOutputReference;
    get modifiedOn(): string;
    get name(): string;
}
export declare class DataCloudflareMagicTransitCf1SitesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMagicTransitCf1SitesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_transit_cf1_sites cloudflare_magic_transit_cf1_sites}
*/
export declare class DataCloudflareMagicTransitCf1Sites extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_magic_transit_cf1_sites";
    /**
    * Generates CDKTN code for importing a DataCloudflareMagicTransitCf1Sites resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMagicTransitCf1Sites to import
    * @param importFromId The id of the existing DataCloudflareMagicTransitCf1Sites that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_transit_cf1_sites#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMagicTransitCf1Sites to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/magic_transit_cf1_sites cloudflare_magic_transit_cf1_sites} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMagicTransitCf1SitesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMagicTransitCf1SitesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareMagicTransitCf1SitesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
