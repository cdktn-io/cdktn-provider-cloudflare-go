/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareStreamWatermarksConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream_watermarks#account_id DataCloudflareStreamWatermarks#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream_watermarks#max_items DataCloudflareStreamWatermarks#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareStreamWatermarksResult {
}
export declare function dataCloudflareStreamWatermarksResultToTerraform(struct?: DataCloudflareStreamWatermarksResult): any;
export declare function dataCloudflareStreamWatermarksResultToHclTerraform(struct?: DataCloudflareStreamWatermarksResult): any;
export declare class DataCloudflareStreamWatermarksResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareStreamWatermarksResult | undefined;
    set internalValue(value: DataCloudflareStreamWatermarksResult | undefined);
    get created(): string;
    get downloadedFrom(): string;
    get height(): number;
    get name(): string;
    get opacity(): number;
    get padding(): number;
    get position(): string;
    get scale(): number;
    get size(): number;
    get uid(): string;
    get width(): number;
}
export declare class DataCloudflareStreamWatermarksResultList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareStreamWatermarksResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream_watermarks cloudflare_stream_watermarks}
*/
export declare class DataCloudflareStreamWatermarks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_stream_watermarks";
    /**
    * Generates CDKTN code for importing a DataCloudflareStreamWatermarks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareStreamWatermarks to import
    * @param importFromId The id of the existing DataCloudflareStreamWatermarks that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream_watermarks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareStreamWatermarks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/stream_watermarks cloudflare_stream_watermarks} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareStreamWatermarksConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareStreamWatermarksConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareStreamWatermarksResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
