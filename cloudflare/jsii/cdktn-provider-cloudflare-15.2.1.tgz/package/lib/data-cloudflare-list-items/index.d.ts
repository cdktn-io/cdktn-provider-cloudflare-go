/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareListItemsAConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID for this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items#account_id DataCloudflareListItemsA#account_id}
    */
    readonly accountId?: string;
    /**
    * The unique ID of the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items#list_id DataCloudflareListItemsA#list_id}
    */
    readonly listId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items#max_items DataCloudflareListItemsA#max_items}
    */
    readonly maxItems?: number;
    /**
    * Amount of results to include in each paginated response. A non-negative 32 bit integer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items#per_page DataCloudflareListItemsA#per_page}
    */
    readonly perPage?: number;
    /**
    * A search query to filter returned items. Its meaning depends on the list type: IP addresses must start with the provided string, hostnames and bulk redirects must contain the string, and ASNs must match the string exactly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items#search DataCloudflareListItemsA#search}
    */
    readonly search?: string;
}
export interface DataCloudflareListItemsResultHostname {
}
export declare function dataCloudflareListItemsResultHostnameToTerraform(struct?: DataCloudflareListItemsResultHostname): any;
export declare function dataCloudflareListItemsResultHostnameToHclTerraform(struct?: DataCloudflareListItemsResultHostname): any;
export declare class DataCloudflareListItemsResultHostnameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareListItemsResultHostname | undefined;
    set internalValue(value: DataCloudflareListItemsResultHostname | undefined);
    get excludeExactHostname(): cdktn.IResolvable;
    get urlHostname(): string;
}
export interface DataCloudflareListItemsResultRedirect {
}
export declare function dataCloudflareListItemsResultRedirectToTerraform(struct?: DataCloudflareListItemsResultRedirect): any;
export declare function dataCloudflareListItemsResultRedirectToHclTerraform(struct?: DataCloudflareListItemsResultRedirect): any;
export declare class DataCloudflareListItemsResultRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareListItemsResultRedirect | undefined;
    set internalValue(value: DataCloudflareListItemsResultRedirect | undefined);
    get includeSubdomains(): cdktn.IResolvable;
    get preservePathSuffix(): cdktn.IResolvable;
    get preserveQueryString(): cdktn.IResolvable;
    get sourceUrl(): string;
    get statusCode(): number;
    get subpathMatching(): cdktn.IResolvable;
    get targetUrl(): string;
}
export interface DataCloudflareListItemsResult {
}
export declare function dataCloudflareListItemsResultToTerraform(struct?: DataCloudflareListItemsResult): any;
export declare function dataCloudflareListItemsResultToHclTerraform(struct?: DataCloudflareListItemsResult): any;
export declare class DataCloudflareListItemsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareListItemsResult | undefined;
    set internalValue(value: DataCloudflareListItemsResult | undefined);
    get asn(): number;
    get comment(): string;
    get createdOn(): string;
    private _hostname;
    get hostname(): DataCloudflareListItemsResultHostnameOutputReference;
    get id(): string;
    get ip(): string;
    get modifiedOn(): string;
    private _redirect;
    get redirect(): DataCloudflareListItemsResultRedirectOutputReference;
}
export declare class DataCloudflareListItemsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareListItemsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items cloudflare_list_items}
*/
export declare class DataCloudflareListItemsA extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_list_items";
    /**
    * Generates CDKTN code for importing a DataCloudflareListItemsA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareListItemsA to import
    * @param importFromId The id of the existing DataCloudflareListItemsA that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareListItemsA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/list_items cloudflare_list_items} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareListItemsAConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareListItemsAConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _listId?;
    get listId(): string;
    set listId(value: string);
    get listIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _perPage?;
    get perPage(): number;
    set perPage(value: number);
    resetPerPage(): void;
    get perPageInput(): number | undefined;
    private _result;
    get result(): DataCloudflareListItemsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
