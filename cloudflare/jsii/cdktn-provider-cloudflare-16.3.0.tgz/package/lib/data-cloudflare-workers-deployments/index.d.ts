/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkersDeploymentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments#account_id DataCloudflareWorkersDeployments#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments#max_items DataCloudflareWorkersDeployments#max_items}
    */
    readonly maxItems?: number;
    /**
    * Name of the script, used in URLs and route configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments#script_name DataCloudflareWorkersDeployments#script_name}
    */
    readonly scriptName: string;
    /**
    * Start of the deployment creation time range, inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments#since DataCloudflareWorkersDeployments#since}
    */
    readonly since?: string;
    /**
    * End of the deployment creation time range, inclusive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments#until DataCloudflareWorkersDeployments#until}
    */
    readonly until?: string;
}
export interface DataCloudflareWorkersDeploymentsResultDeploymentsAnnotations {
}
export declare function dataCloudflareWorkersDeploymentsResultDeploymentsAnnotationsToTerraform(struct?: DataCloudflareWorkersDeploymentsResultDeploymentsAnnotations): any;
export declare function dataCloudflareWorkersDeploymentsResultDeploymentsAnnotationsToHclTerraform(struct?: DataCloudflareWorkersDeploymentsResultDeploymentsAnnotations): any;
export declare class DataCloudflareWorkersDeploymentsResultDeploymentsAnnotationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkersDeploymentsResultDeploymentsAnnotations | undefined;
    set internalValue(value: DataCloudflareWorkersDeploymentsResultDeploymentsAnnotations | undefined);
    get workersMessage(): string;
    get workersTriggeredBy(): string;
}
export interface DataCloudflareWorkersDeploymentsResultDeploymentsVersions {
}
export declare function dataCloudflareWorkersDeploymentsResultDeploymentsVersionsToTerraform(struct?: DataCloudflareWorkersDeploymentsResultDeploymentsVersions): any;
export declare function dataCloudflareWorkersDeploymentsResultDeploymentsVersionsToHclTerraform(struct?: DataCloudflareWorkersDeploymentsResultDeploymentsVersions): any;
export declare class DataCloudflareWorkersDeploymentsResultDeploymentsVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersDeploymentsResultDeploymentsVersions | undefined;
    set internalValue(value: DataCloudflareWorkersDeploymentsResultDeploymentsVersions | undefined);
    get percentage(): number;
    get versionId(): string;
}
export declare class DataCloudflareWorkersDeploymentsResultDeploymentsVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersDeploymentsResultDeploymentsVersionsOutputReference;
}
export interface DataCloudflareWorkersDeploymentsResultDeployments {
}
export declare function dataCloudflareWorkersDeploymentsResultDeploymentsToTerraform(struct?: DataCloudflareWorkersDeploymentsResultDeployments): any;
export declare function dataCloudflareWorkersDeploymentsResultDeploymentsToHclTerraform(struct?: DataCloudflareWorkersDeploymentsResultDeployments): any;
export declare class DataCloudflareWorkersDeploymentsResultDeploymentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersDeploymentsResultDeployments | undefined;
    set internalValue(value: DataCloudflareWorkersDeploymentsResultDeployments | undefined);
    private _annotations;
    get annotations(): DataCloudflareWorkersDeploymentsResultDeploymentsAnnotationsOutputReference;
    get authorEmail(): string;
    get createdOn(): string;
    get id(): string;
    get source(): string;
    get strategy(): string;
    private _versions;
    get versions(): DataCloudflareWorkersDeploymentsResultDeploymentsVersionsList;
}
export declare class DataCloudflareWorkersDeploymentsResultDeploymentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersDeploymentsResultDeploymentsOutputReference;
}
export interface DataCloudflareWorkersDeploymentsResult {
}
export declare function dataCloudflareWorkersDeploymentsResultToTerraform(struct?: DataCloudflareWorkersDeploymentsResult): any;
export declare function dataCloudflareWorkersDeploymentsResultToHclTerraform(struct?: DataCloudflareWorkersDeploymentsResult): any;
export declare class DataCloudflareWorkersDeploymentsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkersDeploymentsResult | undefined;
    set internalValue(value: DataCloudflareWorkersDeploymentsResult | undefined);
    private _deployments;
    get deployments(): DataCloudflareWorkersDeploymentsResultDeploymentsList;
}
export declare class DataCloudflareWorkersDeploymentsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkersDeploymentsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments cloudflare_workers_deployments}
*/
export declare class DataCloudflareWorkersDeployments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_workers_deployments";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkersDeployments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkersDeployments to import
    * @param importFromId The id of the existing DataCloudflareWorkersDeployments that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkersDeployments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/workers_deployments cloudflare_workers_deployments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkersDeploymentsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareWorkersDeploymentsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareWorkersDeploymentsResultList;
    private _scriptName?;
    get scriptName(): string;
    set scriptName(value: string);
    get scriptNameInput(): string | undefined;
    private _since?;
    get since(): string;
    set since(value: string);
    resetSince(): void;
    get sinceInput(): string | undefined;
    private _until?;
    get until(): string;
    set until(value: string);
    resetUntil(): void;
    get untilInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
