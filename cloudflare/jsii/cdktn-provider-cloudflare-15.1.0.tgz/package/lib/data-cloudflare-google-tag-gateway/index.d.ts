/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareGoogleTagGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/google_tag_gateway#zone_id DataCloudflareGoogleTagGateway#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/google_tag_gateway cloudflare_google_tag_gateway}
*/
export declare class DataCloudflareGoogleTagGateway extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_google_tag_gateway";
    /**
    * Generates CDKTN code for importing a DataCloudflareGoogleTagGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareGoogleTagGateway to import
    * @param importFromId The id of the existing DataCloudflareGoogleTagGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/google_tag_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareGoogleTagGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/google_tag_gateway cloudflare_google_tag_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareGoogleTagGatewayConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareGoogleTagGatewayConfig);
    get enabled(): cdktn.IResolvable;
    get endpoint(): string;
    get hideOriginalIp(): cdktn.IResolvable;
    get id(): string;
    get measurementId(): string;
    get setUpTag(): cdktn.IResolvable;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
