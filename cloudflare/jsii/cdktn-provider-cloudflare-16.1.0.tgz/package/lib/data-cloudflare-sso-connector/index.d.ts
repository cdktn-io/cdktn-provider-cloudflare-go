/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareSsoConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/sso_connector#account_id DataCloudflareSsoConnector#account_id}
    */
    readonly accountId?: string;
    /**
    * SSO Connector identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/sso_connector#sso_connector_id DataCloudflareSsoConnector#sso_connector_id}
    */
    readonly ssoConnectorId: string;
}
export interface DataCloudflareSsoConnectorVerification {
}
export declare function dataCloudflareSsoConnectorVerificationToTerraform(struct?: DataCloudflareSsoConnectorVerification): any;
export declare function dataCloudflareSsoConnectorVerificationToHclTerraform(struct?: DataCloudflareSsoConnectorVerification): any;
export declare class DataCloudflareSsoConnectorVerificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareSsoConnectorVerification | undefined;
    set internalValue(value: DataCloudflareSsoConnectorVerification | undefined);
    get code(): string;
    get status(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/sso_connector cloudflare_sso_connector}
*/
export declare class DataCloudflareSsoConnector extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_sso_connector";
    /**
    * Generates CDKTN code for importing a DataCloudflareSsoConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareSsoConnector to import
    * @param importFromId The id of the existing DataCloudflareSsoConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/sso_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareSsoConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/sso_connector cloudflare_sso_connector} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareSsoConnectorConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareSsoConnectorConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get createdOn(): string;
    get emailDomain(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    private _ssoConnectorId?;
    get ssoConnectorId(): string;
    set ssoConnectorId(value: string);
    get ssoConnectorIdInput(): string | undefined;
    get updatedOn(): string;
    get useFedrampLanguage(): cdktn.IResolvable;
    private _verification;
    get verification(): DataCloudflareSsoConnectorVerificationOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
