/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription#account_id AccountSubscription#account_id}
    */
    readonly accountId?: string;
    /**
    * How often the subscription is renewed automatically.
    * Available values: "weekly", "monthly", "quarterly", "yearly".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription#frequency AccountSubscription#frequency}
    */
    readonly frequency?: string;
    /**
    * The rate plan applied to the subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription#rate_plan AccountSubscription#rate_plan}
    */
    readonly ratePlan?: AccountSubscriptionRatePlan;
}
export interface AccountSubscriptionRatePlan {
    /**
    * The ID of the rate plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription#id AccountSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The scope that this rate plan applies to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription#scope AccountSubscription#scope}
    */
    readonly scope?: string;
}
export declare function accountSubscriptionRatePlanToTerraform(struct?: AccountSubscriptionRatePlan | cdktn.IResolvable): any;
export declare function accountSubscriptionRatePlanToHclTerraform(struct?: AccountSubscriptionRatePlan | cdktn.IResolvable): any;
export declare class AccountSubscriptionRatePlanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSubscriptionRatePlan | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSubscriptionRatePlan | cdktn.IResolvable | undefined);
    get currency(): string;
    get externallyManaged(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isContract(): cdktn.IResolvable;
    get publicName(): string;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    get sets(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription cloudflare_account_subscription}
*/
export declare class AccountSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_account_subscription";
    /**
    * Generates CDKTN code for importing a AccountSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountSubscription to import
    * @param importFromId The id of the existing AccountSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account_subscription cloudflare_account_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountSubscriptionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AccountSubscriptionConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get currency(): string;
    get currentPeriodEnd(): string;
    get currentPeriodStart(): string;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    get id(): string;
    get price(): number;
    private _ratePlan;
    get ratePlan(): AccountSubscriptionRatePlanOutputReference;
    putRatePlan(value: AccountSubscriptionRatePlan): void;
    resetRatePlan(): void;
    get ratePlanInput(): cdktn.IResolvable | AccountSubscriptionRatePlan | undefined;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
