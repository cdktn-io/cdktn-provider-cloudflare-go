/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAccountRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account_role#account_id DataCloudflareAccountRole#account_id}
    */
    readonly accountId: string;
    /**
    * Role identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account_role#role_id DataCloudflareAccountRole#role_id}
    */
    readonly roleId: string;
}
export interface DataCloudflareAccountRolePermissionsAnalytics {
}
export declare function dataCloudflareAccountRolePermissionsAnalyticsToTerraform(struct?: DataCloudflareAccountRolePermissionsAnalytics): any;
export declare function dataCloudflareAccountRolePermissionsAnalyticsToHclTerraform(struct?: DataCloudflareAccountRolePermissionsAnalytics): any;
export declare class DataCloudflareAccountRolePermissionsAnalyticsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsAnalytics | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsAnalytics | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsBilling {
}
export declare function dataCloudflareAccountRolePermissionsBillingToTerraform(struct?: DataCloudflareAccountRolePermissionsBilling): any;
export declare function dataCloudflareAccountRolePermissionsBillingToHclTerraform(struct?: DataCloudflareAccountRolePermissionsBilling): any;
export declare class DataCloudflareAccountRolePermissionsBillingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsBilling | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsBilling | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsCachePurge {
}
export declare function dataCloudflareAccountRolePermissionsCachePurgeToTerraform(struct?: DataCloudflareAccountRolePermissionsCachePurge): any;
export declare function dataCloudflareAccountRolePermissionsCachePurgeToHclTerraform(struct?: DataCloudflareAccountRolePermissionsCachePurge): any;
export declare class DataCloudflareAccountRolePermissionsCachePurgeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsCachePurge | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsCachePurge | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsDns {
}
export declare function dataCloudflareAccountRolePermissionsDnsToTerraform(struct?: DataCloudflareAccountRolePermissionsDns): any;
export declare function dataCloudflareAccountRolePermissionsDnsToHclTerraform(struct?: DataCloudflareAccountRolePermissionsDns): any;
export declare class DataCloudflareAccountRolePermissionsDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsDns | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsDns | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsDnsRecords {
}
export declare function dataCloudflareAccountRolePermissionsDnsRecordsToTerraform(struct?: DataCloudflareAccountRolePermissionsDnsRecords): any;
export declare function dataCloudflareAccountRolePermissionsDnsRecordsToHclTerraform(struct?: DataCloudflareAccountRolePermissionsDnsRecords): any;
export declare class DataCloudflareAccountRolePermissionsDnsRecordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsDnsRecords | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsDnsRecords | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsLb {
}
export declare function dataCloudflareAccountRolePermissionsLbToTerraform(struct?: DataCloudflareAccountRolePermissionsLb): any;
export declare function dataCloudflareAccountRolePermissionsLbToHclTerraform(struct?: DataCloudflareAccountRolePermissionsLb): any;
export declare class DataCloudflareAccountRolePermissionsLbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsLb | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsLb | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsLogs {
}
export declare function dataCloudflareAccountRolePermissionsLogsToTerraform(struct?: DataCloudflareAccountRolePermissionsLogs): any;
export declare function dataCloudflareAccountRolePermissionsLogsToHclTerraform(struct?: DataCloudflareAccountRolePermissionsLogs): any;
export declare class DataCloudflareAccountRolePermissionsLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsLogs | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsLogs | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsOrganization {
}
export declare function dataCloudflareAccountRolePermissionsOrganizationToTerraform(struct?: DataCloudflareAccountRolePermissionsOrganization): any;
export declare function dataCloudflareAccountRolePermissionsOrganizationToHclTerraform(struct?: DataCloudflareAccountRolePermissionsOrganization): any;
export declare class DataCloudflareAccountRolePermissionsOrganizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsOrganization | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsOrganization | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsSsl {
}
export declare function dataCloudflareAccountRolePermissionsSslToTerraform(struct?: DataCloudflareAccountRolePermissionsSsl): any;
export declare function dataCloudflareAccountRolePermissionsSslToHclTerraform(struct?: DataCloudflareAccountRolePermissionsSsl): any;
export declare class DataCloudflareAccountRolePermissionsSslOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsSsl | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsSsl | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsWaf {
}
export declare function dataCloudflareAccountRolePermissionsWafToTerraform(struct?: DataCloudflareAccountRolePermissionsWaf): any;
export declare function dataCloudflareAccountRolePermissionsWafToHclTerraform(struct?: DataCloudflareAccountRolePermissionsWaf): any;
export declare class DataCloudflareAccountRolePermissionsWafOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsWaf | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsWaf | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsZoneSettings {
}
export declare function dataCloudflareAccountRolePermissionsZoneSettingsToTerraform(struct?: DataCloudflareAccountRolePermissionsZoneSettings): any;
export declare function dataCloudflareAccountRolePermissionsZoneSettingsToHclTerraform(struct?: DataCloudflareAccountRolePermissionsZoneSettings): any;
export declare class DataCloudflareAccountRolePermissionsZoneSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsZoneSettings | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsZoneSettings | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissionsZones {
}
export declare function dataCloudflareAccountRolePermissionsZonesToTerraform(struct?: DataCloudflareAccountRolePermissionsZones): any;
export declare function dataCloudflareAccountRolePermissionsZonesToHclTerraform(struct?: DataCloudflareAccountRolePermissionsZones): any;
export declare class DataCloudflareAccountRolePermissionsZonesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissionsZones | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissionsZones | undefined);
    get read(): cdktn.IResolvable;
    get write(): cdktn.IResolvable;
}
export interface DataCloudflareAccountRolePermissions {
}
export declare function dataCloudflareAccountRolePermissionsToTerraform(struct?: DataCloudflareAccountRolePermissions): any;
export declare function dataCloudflareAccountRolePermissionsToHclTerraform(struct?: DataCloudflareAccountRolePermissions): any;
export declare class DataCloudflareAccountRolePermissionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountRolePermissions | undefined;
    set internalValue(value: DataCloudflareAccountRolePermissions | undefined);
    private _analytics;
    get analytics(): DataCloudflareAccountRolePermissionsAnalyticsOutputReference;
    private _billing;
    get billing(): DataCloudflareAccountRolePermissionsBillingOutputReference;
    private _cachePurge;
    get cachePurge(): DataCloudflareAccountRolePermissionsCachePurgeOutputReference;
    private _dns;
    get dns(): DataCloudflareAccountRolePermissionsDnsOutputReference;
    private _dnsRecords;
    get dnsRecords(): DataCloudflareAccountRolePermissionsDnsRecordsOutputReference;
    private _lb;
    get lb(): DataCloudflareAccountRolePermissionsLbOutputReference;
    private _logs;
    get logs(): DataCloudflareAccountRolePermissionsLogsOutputReference;
    private _organization;
    get organization(): DataCloudflareAccountRolePermissionsOrganizationOutputReference;
    private _ssl;
    get ssl(): DataCloudflareAccountRolePermissionsSslOutputReference;
    private _waf;
    get waf(): DataCloudflareAccountRolePermissionsWafOutputReference;
    private _zoneSettings;
    get zoneSettings(): DataCloudflareAccountRolePermissionsZoneSettingsOutputReference;
    private _zones;
    get zones(): DataCloudflareAccountRolePermissionsZonesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account_role cloudflare_account_role}
*/
export declare class DataCloudflareAccountRole extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_account_role";
    /**
    * Generates CDKTN code for importing a DataCloudflareAccountRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAccountRole to import
    * @param importFromId The id of the existing DataCloudflareAccountRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAccountRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account_role cloudflare_account_role} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAccountRoleConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareAccountRoleConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get description(): string;
    get id(): string;
    get name(): string;
    private _permissions;
    get permissions(): DataCloudflareAccountRolePermissionsOutputReference;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
