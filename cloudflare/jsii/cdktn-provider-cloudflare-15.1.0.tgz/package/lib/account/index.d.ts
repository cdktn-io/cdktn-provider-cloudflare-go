/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Parent container details
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#managed_by Account#managed_by}
    */
    readonly managedBy?: AccountManagedBy;
    /**
    * Account name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#name Account#name}
    */
    readonly name: string;
    /**
    * Account settings
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#settings Account#settings}
    */
    readonly settings?: AccountSettings;
    /**
    * Available values: "standard", "enterprise".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#type Account#type}
    */
    readonly type?: string;
    /**
    * information related to the tenant unit, and optionally, an id of the unit to create the account on. see https://developers.cloudflare.com/tenant/how-to/manage-accounts/
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#unit Account#unit}
    */
    readonly unit?: AccountUnit;
}
export interface AccountManagedBy {
}
export declare function accountManagedByToTerraform(struct?: AccountManagedBy | cdktn.IResolvable): any;
export declare function accountManagedByToHclTerraform(struct?: AccountManagedBy | cdktn.IResolvable): any;
export declare class AccountManagedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountManagedBy | cdktn.IResolvable | undefined;
    set internalValue(value: AccountManagedBy | cdktn.IResolvable | undefined);
    get parentOrgId(): string;
    get parentOrgName(): string;
}
export interface AccountSettings {
    /**
    * Sets an abuse contact email to notify for abuse reports.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#abuse_contact_email Account#abuse_contact_email}
    */
    readonly abuseContactEmail?: string;
    /**
    * Indicates whether membership in this account requires that
    * Two-Factor Authentication is enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#enforce_twofactor Account#enforce_twofactor}
    */
    readonly enforceTwofactor?: boolean | cdktn.IResolvable;
}
export declare function accountSettingsToTerraform(struct?: AccountSettings | cdktn.IResolvable): any;
export declare function accountSettingsToHclTerraform(struct?: AccountSettings | cdktn.IResolvable): any;
export declare class AccountSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettings | cdktn.IResolvable | undefined);
    private _abuseContactEmail?;
    get abuseContactEmail(): string;
    set abuseContactEmail(value: string);
    resetAbuseContactEmail(): void;
    get abuseContactEmailInput(): string | undefined;
    private _enforceTwofactor?;
    get enforceTwofactor(): boolean | cdktn.IResolvable;
    set enforceTwofactor(value: boolean | cdktn.IResolvable);
    resetEnforceTwofactor(): void;
    get enforceTwofactorInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountUnit {
    /**
    * Tenant unit ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#id Account#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function accountUnitToTerraform(struct?: AccountUnit | cdktn.IResolvable): any;
export declare function accountUnitToHclTerraform(struct?: AccountUnit | cdktn.IResolvable): any;
export declare class AccountUnitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountUnit | cdktn.IResolvable | undefined;
    set internalValue(value: AccountUnit | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account cloudflare_account}
*/
export declare class Account extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_account";
    /**
    * Generates CDKTN code for importing a Account resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Account to import
    * @param importFromId The id of the existing Account that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Account to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/resources/account cloudflare_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountConfig
    */
    constructor(scope: Construct, id: string, config: AccountConfig);
    get createdOn(): string;
    get id(): string;
    private _managedBy;
    get managedBy(): AccountManagedByOutputReference;
    putManagedBy(value: AccountManagedBy): void;
    resetManagedBy(): void;
    get managedByInput(): cdktn.IResolvable | AccountManagedBy | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _settings;
    get settings(): AccountSettingsOutputReference;
    putSettings(value: AccountSettings): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | AccountSettings | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _unit;
    get unit(): AccountUnitOutputReference;
    putUnit(value: AccountUnit): void;
    resetUnit(): void;
    get unitInput(): cdktn.IResolvable | AccountUnit | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
