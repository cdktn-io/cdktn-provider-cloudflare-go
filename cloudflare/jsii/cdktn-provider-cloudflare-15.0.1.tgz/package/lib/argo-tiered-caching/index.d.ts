/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArgoTieredCachingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Enables Tiered Caching.
    * Available values: "on", "off".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/argo_tiered_caching#value ArgoTieredCaching#value}
    */
    readonly value: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/argo_tiered_caching#zone_id ArgoTieredCaching#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/argo_tiered_caching cloudflare_argo_tiered_caching}
*/
export declare class ArgoTieredCaching extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_argo_tiered_caching";
    /**
    * Generates CDKTN code for importing a ArgoTieredCaching resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArgoTieredCaching to import
    * @param importFromId The id of the existing ArgoTieredCaching that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/argo_tiered_caching#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArgoTieredCaching to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/resources/argo_tiered_caching cloudflare_argo_tiered_caching} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArgoTieredCachingConfig
    */
    constructor(scope: Construct, id: string, config: ArgoTieredCachingConfig);
    get editable(): cdktn.IResolvable;
    get id(): string;
    get modifiedOn(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
