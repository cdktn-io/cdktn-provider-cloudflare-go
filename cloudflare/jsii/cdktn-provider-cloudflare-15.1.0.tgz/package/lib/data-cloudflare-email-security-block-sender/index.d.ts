/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSecurityBlockSenderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#account_id DataCloudflareEmailSecurityBlockSender#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#filter DataCloudflareEmailSecurityBlockSender#filter}
    */
    readonly filter?: DataCloudflareEmailSecurityBlockSenderFilter;
    /**
    * Blocked sender pattern identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#pattern_id DataCloudflareEmailSecurityBlockSender#pattern_id}
    */
    readonly patternId?: string;
}
export interface DataCloudflareEmailSecurityBlockSenderFilter {
    /**
    * The sorting direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#direction DataCloudflareEmailSecurityBlockSender#direction}
    */
    readonly direction?: string;
    /**
    * Field to sort by.
    * Available values: "pattern", "created_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#order DataCloudflareEmailSecurityBlockSender#order}
    */
    readonly order?: string;
    /**
    * Filter by pattern value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#pattern DataCloudflareEmailSecurityBlockSender#pattern}
    */
    readonly pattern?: string;
    /**
    * Filter by pattern type.
    * Available values: "EMAIL", "DOMAIN", "IP", "UNKNOWN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#pattern_type DataCloudflareEmailSecurityBlockSender#pattern_type}
    */
    readonly patternType?: string;
    /**
    * Search term for filtering records. Behavior may change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#search DataCloudflareEmailSecurityBlockSender#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareEmailSecurityBlockSenderFilterToTerraform(struct?: DataCloudflareEmailSecurityBlockSenderFilter | cdktn.IResolvable): any;
export declare function dataCloudflareEmailSecurityBlockSenderFilterToHclTerraform(struct?: DataCloudflareEmailSecurityBlockSenderFilter | cdktn.IResolvable): any;
export declare class DataCloudflareEmailSecurityBlockSenderFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityBlockSenderFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareEmailSecurityBlockSenderFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _patternType?;
    get patternType(): string;
    set patternType(value: string);
    resetPatternType(): void;
    get patternTypeInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender cloudflare_email_security_block_sender}
*/
export declare class DataCloudflareEmailSecurityBlockSender extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_security_block_sender";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSecurityBlockSender resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSecurityBlockSender to import
    * @param importFromId The id of the existing DataCloudflareEmailSecurityBlockSender that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSecurityBlockSender to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/email_security_block_sender cloudflare_email_security_block_sender} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSecurityBlockSenderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareEmailSecurityBlockSenderConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get comments(): string;
    get createdAt(): string;
    private _filter;
    get filter(): DataCloudflareEmailSecurityBlockSenderFilterOutputReference;
    putFilter(value: DataCloudflareEmailSecurityBlockSenderFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareEmailSecurityBlockSenderFilter | undefined;
    get id(): string;
    get isRegex(): cdktn.IResolvable;
    get lastModified(): string;
    get modifiedAt(): string;
    get pattern(): string;
    private _patternId?;
    get patternId(): string;
    set patternId(value: string);
    resetPatternId(): void;
    get patternIdInput(): string | undefined;
    get patternType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
