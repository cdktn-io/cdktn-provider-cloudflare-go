/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCustomSslsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to match all search requirements or at least one (any).
    * Available values: "any", "all".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/custom_ssls#match DataCloudflareCustomSsls#match}
    */
    readonly match?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/custom_ssls#max_items DataCloudflareCustomSsls#max_items}
    */
    readonly maxItems?: number;
    /**
    * Status of the zone's custom SSL.
    * Available values: "active", "expired", "deleted", "pending", "initializing".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/custom_ssls#status DataCloudflareCustomSsls#status}
    */
    readonly status?: string;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/custom_ssls#zone_id DataCloudflareCustomSsls#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareCustomSslsResultGeoRestrictions {
}
export declare function dataCloudflareCustomSslsResultGeoRestrictionsToTerraform(struct?: DataCloudflareCustomSslsResultGeoRestrictions): any;
export declare function dataCloudflareCustomSslsResultGeoRestrictionsToHclTerraform(struct?: DataCloudflareCustomSslsResultGeoRestrictions): any;
export declare class DataCloudflareCustomSslsResultGeoRestrictionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomSslsResultGeoRestrictions | undefined;
    set internalValue(value: DataCloudflareCustomSslsResultGeoRestrictions | undefined);
    get label(): string;
}
export interface DataCloudflareCustomSslsResultKeylessServerTunnel {
}
export declare function dataCloudflareCustomSslsResultKeylessServerTunnelToTerraform(struct?: DataCloudflareCustomSslsResultKeylessServerTunnel): any;
export declare function dataCloudflareCustomSslsResultKeylessServerTunnelToHclTerraform(struct?: DataCloudflareCustomSslsResultKeylessServerTunnel): any;
export declare class DataCloudflareCustomSslsResultKeylessServerTunnelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomSslsResultKeylessServerTunnel | undefined;
    set internalValue(value: DataCloudflareCustomSslsResultKeylessServerTunnel | undefined);
    get privateIp(): string;
    get vnetId(): string;
}
export interface DataCloudflareCustomSslsResultKeylessServer {
}
export declare function dataCloudflareCustomSslsResultKeylessServerToTerraform(struct?: DataCloudflareCustomSslsResultKeylessServer): any;
export declare function dataCloudflareCustomSslsResultKeylessServerToHclTerraform(struct?: DataCloudflareCustomSslsResultKeylessServer): any;
export declare class DataCloudflareCustomSslsResultKeylessServerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareCustomSslsResultKeylessServer | undefined;
    set internalValue(value: DataCloudflareCustomSslsResultKeylessServer | undefined);
    get createdOn(): string;
    get enabled(): cdktn.IResolvable;
    get host(): string;
    get id(): string;
    get modifiedOn(): string;
    get name(): string;
    get permissions(): string[];
    get port(): number;
    get status(): string;
    private _tunnel;
    get tunnel(): DataCloudflareCustomSslsResultKeylessServerTunnelOutputReference;
}
export interface DataCloudflareCustomSslsResult {
}
export declare function dataCloudflareCustomSslsResultToTerraform(struct?: DataCloudflareCustomSslsResult): any;
export declare function dataCloudflareCustomSslsResultToHclTerraform(struct?: DataCloudflareCustomSslsResult): any;
export declare class DataCloudflareCustomSslsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCustomSslsResult | undefined;
    set internalValue(value: DataCloudflareCustomSslsResult | undefined);
    get bundleMethod(): string;
    get customCsrId(): string;
    get expiresOn(): string;
    private _geoRestrictions;
    get geoRestrictions(): DataCloudflareCustomSslsResultGeoRestrictionsOutputReference;
    get hosts(): string[];
    get id(): string;
    get issuer(): string;
    private _keylessServer;
    get keylessServer(): DataCloudflareCustomSslsResultKeylessServerOutputReference;
    get modifiedOn(): string;
    get policyRestrictions(): string;
    get priority(): number;
    get signature(): string;
    get status(): string;
    get uploadedOn(): string;
    get zoneId(): string;
}
export declare class DataCloudflareCustomSslsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCustomSslsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/custom_ssls cloudflare_custom_ssls}
*/
export declare class DataCloudflareCustomSsls extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_custom_ssls";
    /**
    * Generates CDKTN code for importing a DataCloudflareCustomSsls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCustomSsls to import
    * @param importFromId The id of the existing DataCloudflareCustomSsls that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/custom_ssls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCustomSsls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/custom_ssls cloudflare_custom_ssls} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCustomSslsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareCustomSslsConfig);
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareCustomSslsResultList;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
