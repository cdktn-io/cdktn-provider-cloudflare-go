/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareByoIpPrefixConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier of a Cloudflare account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/byo_ip_prefix#account_id DataCloudflareByoIpPrefix#account_id}
    */
    readonly accountId?: string;
    /**
    * Identifier of an IP Prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/byo_ip_prefix#prefix_id DataCloudflareByoIpPrefix#prefix_id}
    */
    readonly prefixId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/byo_ip_prefix cloudflare_byo_ip_prefix}
*/
export declare class DataCloudflareByoIpPrefix extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_byo_ip_prefix";
    /**
    * Generates CDKTN code for importing a DataCloudflareByoIpPrefix resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareByoIpPrefix to import
    * @param importFromId The id of the existing DataCloudflareByoIpPrefix that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/byo_ip_prefix#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareByoIpPrefix to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/byo_ip_prefix cloudflare_byo_ip_prefix} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareByoIpPrefixConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareByoIpPrefixConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get advertised(): cdktn.IResolvable;
    get advertisedModifiedAt(): string;
    get approved(): string;
    get asn(): number;
    get cidr(): string;
    get createdAt(): string;
    get delegateLoaCreation(): cdktn.IResolvable;
    get description(): string;
    get id(): string;
    get irrValidationState(): string;
    get loaDocumentId(): string;
    get modifiedAt(): string;
    get onDemandEnabled(): cdktn.IResolvable;
    get onDemandLocked(): cdktn.IResolvable;
    get ownershipValidationState(): string;
    get ownershipValidationToken(): string;
    private _prefixId?;
    get prefixId(): string;
    set prefixId(value: string);
    get prefixIdInput(): string | undefined;
    get rpkiValidationState(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
