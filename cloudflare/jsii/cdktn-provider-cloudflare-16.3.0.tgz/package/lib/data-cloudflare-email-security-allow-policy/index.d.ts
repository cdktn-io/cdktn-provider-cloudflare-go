/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSecurityAllowPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#account_id DataCloudflareEmailSecurityAllowPolicy#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#filter DataCloudflareEmailSecurityAllowPolicy#filter}
    */
    readonly filter?: DataCloudflareEmailSecurityAllowPolicyFilter;
    /**
    * Allow policy identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#policy_id DataCloudflareEmailSecurityAllowPolicy#policy_id}
    */
    readonly policyId?: string;
}
export interface DataCloudflareEmailSecurityAllowPolicyFilter {
    /**
    * The sorting direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#direction DataCloudflareEmailSecurityAllowPolicy#direction}
    */
    readonly direction?: string;
    /**
    * Filter to show only policies where messages from the sender are exempted from Spam, Spoof, and Bulk dispositions (not Malicious or Suspicious).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#is_acceptable_sender DataCloudflareEmailSecurityAllowPolicy#is_acceptable_sender}
    */
    readonly isAcceptableSender?: boolean | cdktn.IResolvable;
    /**
    * Filter to show only policies where messages to the recipient bypass all detections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#is_exempt_recipient DataCloudflareEmailSecurityAllowPolicy#is_exempt_recipient}
    */
    readonly isExemptRecipient?: boolean | cdktn.IResolvable;
    /**
    * Filter to show only policies where messages from the sender bypass all detections and link following.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#is_trusted_sender DataCloudflareEmailSecurityAllowPolicy#is_trusted_sender}
    */
    readonly isTrustedSender?: boolean | cdktn.IResolvable;
    /**
    * Field to sort by.
    * Available values: "pattern", "created_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#order DataCloudflareEmailSecurityAllowPolicy#order}
    */
    readonly order?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#pattern DataCloudflareEmailSecurityAllowPolicy#pattern}
    */
    readonly pattern?: string;
    /**
    * Type of pattern matching.
    * - EMAIL: matches a full email address (e.g. `user@example.com`)
    * - DOMAIN: matches a domain name (e.g. `example.com`)
    * - IP: matches a plain IPv4 or IPv6 address (e.g. `1.2.3.4` or `2606:4700:4700::1111`) or CIDR block (e.g. `1.2.3.0/24` or `2606:4700:4700::/48`). The API rejects private or unique-local, loopback, link-local, unspecified, and IPv4 broadcast addresses, including their IPv4-mapped IPv6 equivalents.
    * - UNKNOWN: deprecated; you cannot use this when creating or updating policies, but it may appear on existing entries.
    * Available values: "EMAIL", "DOMAIN", "IP", "UNKNOWN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#pattern_type DataCloudflareEmailSecurityAllowPolicy#pattern_type}
    */
    readonly patternType?: string;
    /**
    * Search term for filtering records. Behavior may change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#search DataCloudflareEmailSecurityAllowPolicy#search}
    */
    readonly search?: string;
    /**
    * Filter to show only policies that enforce DMARC, SPF, or DKIM authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#verify_sender DataCloudflareEmailSecurityAllowPolicy#verify_sender}
    */
    readonly verifySender?: boolean | cdktn.IResolvable;
}
export declare function dataCloudflareEmailSecurityAllowPolicyFilterToTerraform(struct?: DataCloudflareEmailSecurityAllowPolicyFilter | cdktn.IResolvable): any;
export declare function dataCloudflareEmailSecurityAllowPolicyFilterToHclTerraform(struct?: DataCloudflareEmailSecurityAllowPolicyFilter | cdktn.IResolvable): any;
export declare class DataCloudflareEmailSecurityAllowPolicyFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityAllowPolicyFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareEmailSecurityAllowPolicyFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _isAcceptableSender?;
    get isAcceptableSender(): boolean | cdktn.IResolvable;
    set isAcceptableSender(value: boolean | cdktn.IResolvable);
    resetIsAcceptableSender(): void;
    get isAcceptableSenderInput(): boolean | cdktn.IResolvable | undefined;
    private _isExemptRecipient?;
    get isExemptRecipient(): boolean | cdktn.IResolvable;
    set isExemptRecipient(value: boolean | cdktn.IResolvable);
    resetIsExemptRecipient(): void;
    get isExemptRecipientInput(): boolean | cdktn.IResolvable | undefined;
    private _isTrustedSender?;
    get isTrustedSender(): boolean | cdktn.IResolvable;
    set isTrustedSender(value: boolean | cdktn.IResolvable);
    resetIsTrustedSender(): void;
    get isTrustedSenderInput(): boolean | cdktn.IResolvable | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    resetPattern(): void;
    get patternInput(): string | undefined;
    private _patternType?;
    get patternType(): string;
    set patternType(value: string);
    resetPatternType(): void;
    get patternTypeInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _verifySender?;
    get verifySender(): boolean | cdktn.IResolvable;
    set verifySender(value: boolean | cdktn.IResolvable);
    resetVerifySender(): void;
    get verifySenderInput(): boolean | cdktn.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy cloudflare_email_security_allow_policy}
*/
export declare class DataCloudflareEmailSecurityAllowPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_security_allow_policy";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSecurityAllowPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSecurityAllowPolicy to import
    * @param importFromId The id of the existing DataCloudflareEmailSecurityAllowPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSecurityAllowPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_allow_policy cloudflare_email_security_allow_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSecurityAllowPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareEmailSecurityAllowPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get comments(): string;
    get createdAt(): string;
    private _filter;
    get filter(): DataCloudflareEmailSecurityAllowPolicyFilterOutputReference;
    putFilter(value: DataCloudflareEmailSecurityAllowPolicyFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareEmailSecurityAllowPolicyFilter | undefined;
    get id(): string;
    get isAcceptableSender(): cdktn.IResolvable;
    get isExemptRecipient(): cdktn.IResolvable;
    get isRecipient(): cdktn.IResolvable;
    get isRegex(): cdktn.IResolvable;
    get isSender(): cdktn.IResolvable;
    get isSpoof(): cdktn.IResolvable;
    get isTrustedSender(): cdktn.IResolvable;
    get lastModified(): string;
    get modifiedAt(): string;
    get pattern(): string;
    get patternType(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    get verifySender(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
