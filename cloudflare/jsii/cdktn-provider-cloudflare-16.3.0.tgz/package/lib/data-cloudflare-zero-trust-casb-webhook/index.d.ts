/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCasbWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_webhook#account_id DataCloudflareZeroTrustCasbWebhook#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_webhook#webhook_id DataCloudflareZeroTrustCasbWebhook#webhook_id}
    */
    readonly webhookId: string;
}
export interface DataCloudflareZeroTrustCasbWebhookHeaders {
}
export declare function dataCloudflareZeroTrustCasbWebhookHeadersToTerraform(struct?: DataCloudflareZeroTrustCasbWebhookHeaders): any;
export declare function dataCloudflareZeroTrustCasbWebhookHeadersToHclTerraform(struct?: DataCloudflareZeroTrustCasbWebhookHeaders): any;
export declare class DataCloudflareZeroTrustCasbWebhookHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCasbWebhookHeaders | undefined;
    set internalValue(value: DataCloudflareZeroTrustCasbWebhookHeaders | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataCloudflareZeroTrustCasbWebhookHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCasbWebhookHeadersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_webhook cloudflare_zero_trust_casb_webhook}
*/
export declare class DataCloudflareZeroTrustCasbWebhook extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_casb_webhook";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCasbWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCasbWebhook to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCasbWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCasbWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/zero_trust_casb_webhook cloudflare_zero_trust_casb_webhook} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCasbWebhookConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCasbWebhookConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get authenticationType(): string;
    get createdAt(): string;
    get destinationUrl(): string;
    private _headers;
    get headers(): DataCloudflareZeroTrustCasbWebhookHeadersList;
    get id(): string;
    get label(): string;
    get status(): string;
    get updatedAt(): string;
    get version(): number;
    private _webhookId?;
    get webhookId(): string;
    set webhookId(value: string);
    get webhookIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
