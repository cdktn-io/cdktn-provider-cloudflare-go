/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#account_id DataCloudflareZeroTrustAccessAiControlsMcpServer#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#filter DataCloudflareZeroTrustAccessAiControlsMcpServer#filter}
    */
    readonly filter?: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter;
    /**
    * Unique identifier for the MCP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#id DataCloudflareZeroTrustAccessAiControlsMcpServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfig {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfigToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfig): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfigToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfig): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfig | undefined);
    get authorizationEndpoint(): string;
    get issuer(): string;
    get resource(): string;
    get revocationEndpoint(): string;
    get tokenEndpoint(): string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfo {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfoToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfo): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfoToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfo): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfo | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfo | undefined);
    get clientId(): string;
    get redirectUris(): string[];
    get scope(): string;
    get tokenEndpointAuthMethod(): string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummary {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummary): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummary): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummary | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummary | undefined);
    get authMode(): string;
    get clientSecretVersion(): number;
    private _config;
    get config(): DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryConfigOutputReference;
    get hasClientSecret(): cdktn.IResolvable;
    private _registrationInfo;
    get registrationInfo(): DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryRegistrationInfoOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetails {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetailsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetails): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetailsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetails): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetails | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetails | undefined);
    get cause(): string;
    get isUpstream(): cdktn.IResolvable;
    get mcpCode(): number;
    get retryable(): cdktn.IResolvable;
    get statusCode(): number;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerFilter {
    /**
    * Search by id, name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#search DataCloudflareZeroTrustAccessAiControlsMcpServer#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerFilterToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerFilterToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | cdktn.IResolvable | undefined);
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPrompts {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPromptsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPrompts): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPromptsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPrompts): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPromptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPrompts | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPrompts | undefined);
    get alias(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPromptsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPromptsOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedTools {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedToolsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedTools): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedToolsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedTools): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedTools | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedTools | undefined);
    get alias(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedToolsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedToolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server cloudflare_zero_trust_access_ai_controls_mcp_server}
*/
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_access_ai_controls_mcp_server";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustAccessAiControlsMcpServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustAccessAiControlsMcpServer to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustAccessAiControlsMcpServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustAccessAiControlsMcpServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_access_ai_controls_mcp_server cloudflare_zero_trust_access_ai_controls_mcp_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustAccessAiControlsMcpServerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustAccessAiControlsMcpServerConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _authConfigSummary;
    get authConfigSummary(): DataCloudflareZeroTrustAccessAiControlsMcpServerAuthConfigSummaryOutputReference;
    get authType(): string;
    get authenticationStatus(): string;
    get createdAt(): string;
    get createdBy(): string;
    get description(): string;
    get error(): string;
    private _errorDetails;
    get errorDetails(): DataCloudflareZeroTrustAccessAiControlsMcpServerErrorDetailsOutputReference;
    private _filter;
    get filter(): DataCloudflareZeroTrustAccessAiControlsMcpServerFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustAccessAiControlsMcpServerFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustAccessAiControlsMcpServerFilter | undefined;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isSharedOauthCallbackEnabled(): cdktn.IResolvable;
    get lastSuccessfulSync(): string;
    get lastSynced(): string;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get name(): string;
    private _prompts;
    get prompts(): cdktn.StringMapList;
    get secureWebGateway(): cdktn.IResolvable;
    get status(): string;
    private _tools;
    get tools(): cdktn.StringMapList;
    private _updatedPrompts;
    get updatedPrompts(): DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedPromptsList;
    private _updatedTools;
    get updatedTools(): DataCloudflareZeroTrustAccessAiControlsMcpServerUpdatedToolsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
