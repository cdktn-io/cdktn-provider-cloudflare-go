/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account#account_id DataCloudflareAccount#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account#filter DataCloudflareAccount#filter}
    */
    readonly filter?: DataCloudflareAccountFilter;
}
export interface DataCloudflareAccountFilter {
    /**
    * Direction to order results.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account#direction DataCloudflareAccount#direction}
    */
    readonly direction?: string;
    /**
    * Name of the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account#name DataCloudflareAccount#name}
    */
    readonly name?: string;
}
export declare function dataCloudflareAccountFilterToTerraform(struct?: DataCloudflareAccountFilter | cdktn.IResolvable): any;
export declare function dataCloudflareAccountFilterToHclTerraform(struct?: DataCloudflareAccountFilter | cdktn.IResolvable): any;
export declare class DataCloudflareAccountFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareAccountFilter | cdktn.IResolvable | undefined);
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DataCloudflareAccountManagedBy {
}
export declare function dataCloudflareAccountManagedByToTerraform(struct?: DataCloudflareAccountManagedBy): any;
export declare function dataCloudflareAccountManagedByToHclTerraform(struct?: DataCloudflareAccountManagedBy): any;
export declare class DataCloudflareAccountManagedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountManagedBy | undefined;
    set internalValue(value: DataCloudflareAccountManagedBy | undefined);
    get parentOrgId(): string;
    get parentOrgName(): string;
}
export interface DataCloudflareAccountSettings {
}
export declare function dataCloudflareAccountSettingsToTerraform(struct?: DataCloudflareAccountSettings): any;
export declare function dataCloudflareAccountSettingsToHclTerraform(struct?: DataCloudflareAccountSettings): any;
export declare class DataCloudflareAccountSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAccountSettings | undefined;
    set internalValue(value: DataCloudflareAccountSettings | undefined);
    get abuseContactEmail(): string;
    get enforceTwofactor(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account cloudflare_account}
*/
export declare class DataCloudflareAccount extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_account";
    /**
    * Generates CDKTN code for importing a DataCloudflareAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAccount to import
    * @param importFromId The id of the existing DataCloudflareAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/account cloudflare_account} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAccountConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareAccountConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get createdOn(): string;
    private _filter;
    get filter(): DataCloudflareAccountFilterOutputReference;
    putFilter(value: DataCloudflareAccountFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareAccountFilter | undefined;
    get id(): string;
    private _managedBy;
    get managedBy(): DataCloudflareAccountManagedByOutputReference;
    get name(): string;
    private _settings;
    get settings(): DataCloudflareAccountSettingsOutputReference;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
