/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareRegistrarDomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/registrar_domains#account_id DataCloudflareRegistrarDomains#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/registrar_domains#max_items DataCloudflareRegistrarDomains#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareRegistrarDomainsResultRegistrantContact {
}
export declare function dataCloudflareRegistrarDomainsResultRegistrantContactToTerraform(struct?: DataCloudflareRegistrarDomainsResultRegistrantContact): any;
export declare function dataCloudflareRegistrarDomainsResultRegistrantContactToHclTerraform(struct?: DataCloudflareRegistrarDomainsResultRegistrantContact): any;
export declare class DataCloudflareRegistrarDomainsResultRegistrantContactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRegistrarDomainsResultRegistrantContact | undefined;
    set internalValue(value: DataCloudflareRegistrarDomainsResultRegistrantContact | undefined);
    get address(): string;
    get address2(): string;
    get city(): string;
    get country(): string;
    get email(): string;
    get fax(): string;
    get firstName(): string;
    get id(): string;
    get lastName(): string;
    get organization(): string;
    get phone(): string;
    get state(): string;
    get zip(): string;
}
export interface DataCloudflareRegistrarDomainsResultTransferIn {
}
export declare function dataCloudflareRegistrarDomainsResultTransferInToTerraform(struct?: DataCloudflareRegistrarDomainsResultTransferIn): any;
export declare function dataCloudflareRegistrarDomainsResultTransferInToHclTerraform(struct?: DataCloudflareRegistrarDomainsResultTransferIn): any;
export declare class DataCloudflareRegistrarDomainsResultTransferInOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareRegistrarDomainsResultTransferIn | undefined;
    set internalValue(value: DataCloudflareRegistrarDomainsResultTransferIn | undefined);
    get acceptFoa(): string;
    get approveTransfer(): string;
    get canCancelTransfer(): cdktn.IResolvable;
    get disablePrivacy(): string;
    get enterAuthCode(): string;
    get unlockDomain(): string;
}
export interface DataCloudflareRegistrarDomainsResult {
}
export declare function dataCloudflareRegistrarDomainsResultToTerraform(struct?: DataCloudflareRegistrarDomainsResult): any;
export declare function dataCloudflareRegistrarDomainsResultToHclTerraform(struct?: DataCloudflareRegistrarDomainsResult): any;
export declare class DataCloudflareRegistrarDomainsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareRegistrarDomainsResult | undefined;
    set internalValue(value: DataCloudflareRegistrarDomainsResult | undefined);
    get available(): cdktn.IResolvable;
    get canRegister(): cdktn.IResolvable;
    get createdAt(): string;
    get currentRegistrar(): string;
    get expiresAt(): string;
    get id(): string;
    get locked(): cdktn.IResolvable;
    private _registrantContact;
    get registrantContact(): DataCloudflareRegistrarDomainsResultRegistrantContactOutputReference;
    get registryStatuses(): string;
    get supportedTld(): cdktn.IResolvable;
    private _transferIn;
    get transferIn(): DataCloudflareRegistrarDomainsResultTransferInOutputReference;
    get updatedAt(): string;
}
export declare class DataCloudflareRegistrarDomainsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareRegistrarDomainsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/registrar_domains cloudflare_registrar_domains}
*/
export declare class DataCloudflareRegistrarDomains extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_registrar_domains";
    /**
    * Generates CDKTN code for importing a DataCloudflareRegistrarDomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareRegistrarDomains to import
    * @param importFromId The id of the existing DataCloudflareRegistrarDomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/registrar_domains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareRegistrarDomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/registrar_domains cloudflare_registrar_domains} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareRegistrarDomainsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareRegistrarDomainsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareRegistrarDomainsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
