/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDeviceDefaultProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_default_profile#account_id DataCloudflareZeroTrustDeviceDefaultProfile#account_id}
    */
    readonly accountId?: string;
}
export interface DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixes {
}
export declare function dataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixesToTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixes): any;
export declare function dataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixesToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixes): any;
export declare class DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixes | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixes | undefined);
    get description(): string;
    get suffix(): string;
}
export declare class DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixesOutputReference;
}
export interface DataCloudflareZeroTrustDeviceDefaultProfileExclude {
}
export declare function dataCloudflareZeroTrustDeviceDefaultProfileExcludeToTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileExclude): any;
export declare function dataCloudflareZeroTrustDeviceDefaultProfileExcludeToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileExclude): any;
export declare class DataCloudflareZeroTrustDeviceDefaultProfileExcludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceDefaultProfileExclude | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDefaultProfileExclude | undefined);
    get address(): string;
    get description(): string;
    get host(): string;
}
export declare class DataCloudflareZeroTrustDeviceDefaultProfileExcludeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceDefaultProfileExcludeOutputReference;
}
export interface DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomains {
}
export declare function dataCloudflareZeroTrustDeviceDefaultProfileFallbackDomainsToTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomains): any;
export declare function dataCloudflareZeroTrustDeviceDefaultProfileFallbackDomainsToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomains): any;
export declare class DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomains | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomains | undefined);
    get description(): string;
    get dnsServer(): string[];
    get suffix(): string;
}
export declare class DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomainsOutputReference;
}
export interface DataCloudflareZeroTrustDeviceDefaultProfileInclude {
}
export declare function dataCloudflareZeroTrustDeviceDefaultProfileIncludeToTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileInclude): any;
export declare function dataCloudflareZeroTrustDeviceDefaultProfileIncludeToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileInclude): any;
export declare class DataCloudflareZeroTrustDeviceDefaultProfileIncludeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDeviceDefaultProfileInclude | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDefaultProfileInclude | undefined);
    get address(): string;
    get description(): string;
    get host(): string;
}
export declare class DataCloudflareZeroTrustDeviceDefaultProfileIncludeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDeviceDefaultProfileIncludeOutputReference;
}
export interface DataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2 {
}
export declare function dataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2ToTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2): any;
export declare function dataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2ToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2): any;
export declare class DataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2 | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2 | undefined);
    get mode(): string;
    get port(): number;
}
export interface DataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworks {
}
export declare function dataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworksToTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworks): any;
export declare function dataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworksToHclTerraform(struct?: DataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworks): any;
export declare class DataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworks | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworks | undefined);
    get allowed(): string[];
    get default(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_default_profile cloudflare_zero_trust_device_default_profile}
*/
export declare class DataCloudflareZeroTrustDeviceDefaultProfile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_default_profile";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDeviceDefaultProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDeviceDefaultProfile to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDeviceDefaultProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_default_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDeviceDefaultProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_device_default_profile cloudflare_zero_trust_device_default_profile} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDeviceDefaultProfileConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustDeviceDefaultProfileConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get allowModeSwitch(): cdktn.IResolvable;
    get allowUpdates(): cdktn.IResolvable;
    get allowedToLeave(): cdktn.IResolvable;
    get autoConnect(): number;
    get captivePortal(): number;
    get default(): cdktn.IResolvable;
    get disableAutoFallback(): cdktn.IResolvable;
    private _dnsSearchSuffixes;
    get dnsSearchSuffixes(): DataCloudflareZeroTrustDeviceDefaultProfileDnsSearchSuffixesList;
    get enabled(): cdktn.IResolvable;
    private _exclude;
    get exclude(): DataCloudflareZeroTrustDeviceDefaultProfileExcludeList;
    get excludeOfficeIps(): cdktn.IResolvable;
    private _fallbackDomains;
    get fallbackDomains(): DataCloudflareZeroTrustDeviceDefaultProfileFallbackDomainsList;
    get gatewayUniqueId(): string;
    get id(): string;
    private _include;
    get include(): DataCloudflareZeroTrustDeviceDefaultProfileIncludeList;
    get policyId(): string;
    get registerInterfaceIpWithDns(): cdktn.IResolvable;
    get sccmVpnBoundarySupport(): cdktn.IResolvable;
    private _serviceModeV2;
    get serviceModeV2(): DataCloudflareZeroTrustDeviceDefaultProfileServiceModeV2OutputReference;
    get supportUrl(): string;
    get switchLocked(): cdktn.IResolvable;
    get tunnelProtocol(): string;
    private _virtualNetworks;
    get virtualNetworks(): DataCloudflareZeroTrustDeviceDefaultProfileVirtualNetworksOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
