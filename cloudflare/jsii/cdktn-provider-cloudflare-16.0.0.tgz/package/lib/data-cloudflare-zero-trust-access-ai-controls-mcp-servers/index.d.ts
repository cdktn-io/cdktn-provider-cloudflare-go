/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_access_ai_controls_mcp_servers#account_id DataCloudflareZeroTrustAccessAiControlsMcpServers#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_access_ai_controls_mcp_servers#max_items DataCloudflareZeroTrustAccessAiControlsMcpServers#max_items}
    */
    readonly maxItems?: number;
    /**
    * Search by id, name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_access_ai_controls_mcp_servers#search DataCloudflareZeroTrustAccessAiControlsMcpServers#search}
    */
    readonly search?: string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfig {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfigToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfig): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfigToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfig): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfig | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfig | undefined);
    get authorizationEndpoint(): string;
    get issuer(): string;
    get resource(): string;
    get revocationEndpoint(): string;
    get tokenEndpoint(): string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfo {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfoToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfo): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfoToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfo): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfo | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfo | undefined);
    get clientId(): string;
    get redirectUris(): string[];
    get scope(): string;
    get tokenEndpointAuthMethod(): string;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummary {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummary): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummary): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummary | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummary | undefined);
    get authMode(): string;
    get clientSecretVersion(): number;
    private _config;
    get config(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryConfigOutputReference;
    get hasClientSecret(): cdktn.IResolvable;
    private _registrationInfo;
    get registrationInfo(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryRegistrationInfoOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetails {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetailsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetails): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetailsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetails): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetails | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetails | undefined);
    get cause(): string;
    get isUpstream(): cdktn.IResolvable;
    get mcpCode(): number;
    get retryable(): cdktn.IResolvable;
    get statusCode(): number;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPrompts {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPromptsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPrompts): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPromptsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPrompts): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPromptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPrompts | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPrompts | undefined);
    get alias(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPromptsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPromptsOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedTools {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedToolsToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedTools): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedToolsToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedTools): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedTools | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedTools | undefined);
    get alias(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedToolsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedToolsOutputReference;
}
export interface DataCloudflareZeroTrustAccessAiControlsMcpServersResult {
}
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultToTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResult): any;
export declare function dataCloudflareZeroTrustAccessAiControlsMcpServersResultToHclTerraform(struct?: DataCloudflareZeroTrustAccessAiControlsMcpServersResult): any;
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustAccessAiControlsMcpServersResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustAccessAiControlsMcpServersResult | undefined);
    private _authConfigSummary;
    get authConfigSummary(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultAuthConfigSummaryOutputReference;
    get authType(): string;
    get createdAt(): string;
    get createdBy(): string;
    get description(): string;
    get error(): string;
    private _errorDetails;
    get errorDetails(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultErrorDetailsOutputReference;
    get hostname(): string;
    get id(): string;
    get isSharedOauthCallbackEnabled(): cdktn.IResolvable;
    get lastSuccessfulSync(): string;
    get lastSynced(): string;
    get modifiedAt(): string;
    get modifiedBy(): string;
    get name(): string;
    private _prompts;
    get prompts(): cdktn.StringMapList;
    get secureWebGateway(): cdktn.IResolvable;
    get status(): string;
    private _tools;
    get tools(): cdktn.StringMapList;
    private _updatedPrompts;
    get updatedPrompts(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedPromptsList;
    private _updatedTools;
    get updatedTools(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultUpdatedToolsList;
}
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServersResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustAccessAiControlsMcpServersResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_access_ai_controls_mcp_servers cloudflare_zero_trust_access_ai_controls_mcp_servers}
*/
export declare class DataCloudflareZeroTrustAccessAiControlsMcpServers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_access_ai_controls_mcp_servers";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustAccessAiControlsMcpServers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustAccessAiControlsMcpServers to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustAccessAiControlsMcpServers that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_access_ai_controls_mcp_servers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustAccessAiControlsMcpServers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/zero_trust_access_ai_controls_mcp_servers cloudflare_zero_trust_access_ai_controls_mcp_servers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustAccessAiControlsMcpServersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZeroTrustAccessAiControlsMcpServersConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustAccessAiControlsMcpServersResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
