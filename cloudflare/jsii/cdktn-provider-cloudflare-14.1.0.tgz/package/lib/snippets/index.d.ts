/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SnippetsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of files belonging to the snippet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets#files Snippets#files}
    */
    readonly files: string[];
    /**
    * Metadata about the snippet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets#metadata Snippets#metadata}
    */
    readonly metadata: SnippetsMetadata;
    /**
    * The identifying name of the snippet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets#snippet_name Snippets#snippet_name}
    */
    readonly snippetName: string;
    /**
    * The unique ID of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets#zone_id Snippets#zone_id}
    */
    readonly zoneId: string;
}
export interface SnippetsMetadata {
    /**
    * Name of the file that contains the main module of the snippet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets#main_module Snippets#main_module}
    */
    readonly mainModule: string;
}
export declare function snippetsMetadataToTerraform(struct?: SnippetsMetadata | cdktn.IResolvable): any;
export declare function snippetsMetadataToHclTerraform(struct?: SnippetsMetadata | cdktn.IResolvable): any;
export declare class SnippetsMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SnippetsMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: SnippetsMetadata | cdktn.IResolvable | undefined);
    private _mainModule?;
    get mainModule(): string;
    set mainModule(value: string);
    get mainModuleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets cloudflare_snippets}
*/
export declare class Snippets extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_snippets";
    /**
    * Generates CDKTN code for importing a Snippets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Snippets to import
    * @param importFromId The id of the existing Snippets that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Snippets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/snippets cloudflare_snippets} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SnippetsConfig
    */
    constructor(scope: Construct, id: string, config: SnippetsConfig);
    get createdOn(): string;
    private _files?;
    get files(): string[];
    set files(value: string[]);
    get filesInput(): string[] | undefined;
    private _metadata;
    get metadata(): SnippetsMetadataOutputReference;
    putMetadata(value: SnippetsMetadata): void;
    get metadataInput(): cdktn.IResolvable | SnippetsMetadata | undefined;
    get modifiedOn(): string;
    private _snippetName?;
    get snippetName(): string;
    set snippetName(value: string);
    get snippetNameInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
