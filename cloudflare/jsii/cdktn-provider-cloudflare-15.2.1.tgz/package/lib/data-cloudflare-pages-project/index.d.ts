/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflarePagesProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pages_project#account_id DataCloudflarePagesProject#account_id}
    */
    readonly accountId?: string;
    /**
    * Name of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pages_project#project_name DataCloudflarePagesProject#project_name}
    */
    readonly projectName: string;
}
export interface DataCloudflarePagesProjectBuildConfig {
}
export declare function dataCloudflarePagesProjectBuildConfigToTerraform(struct?: DataCloudflarePagesProjectBuildConfig): any;
export declare function dataCloudflarePagesProjectBuildConfigToHclTerraform(struct?: DataCloudflarePagesProjectBuildConfig): any;
export declare class DataCloudflarePagesProjectBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectBuildConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentBuildConfig {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentBuildConfigToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentBuildConfig): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentBuildConfigToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentBuildConfig): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentBuildConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadata {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadataToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadata): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadataToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadata): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadata | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadata | undefined);
    get branch(): string;
    get commitDirty(): cdktn.IResolvable;
    get commitHash(): string;
    get commitMessage(): string;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentDeploymentTrigger {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentDeploymentTrigger): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentDeploymentTrigger): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentDeploymentTrigger | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentDeploymentTrigger | undefined);
    private _metadata;
    get metadata(): DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerMetadataOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentEnvVars {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentEnvVarsToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentEnvVars): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentEnvVars): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectCanonicalDeploymentEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectCanonicalDeploymentEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentLatestStage {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentLatestStageToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentLatestStage): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentLatestStageToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentLatestStage): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentLatestStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentLatestStage | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentLatestStage | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentSourceConfig {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentSourceConfigToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentSourceConfig): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentSourceConfigToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentSourceConfig): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentSourceConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentSource {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentSourceToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentSource): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentSourceToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentSource): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentSource | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentSource | undefined);
    private _config;
    get config(): DataCloudflarePagesProjectCanonicalDeploymentSourceConfigOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectCanonicalDeploymentStages {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentStagesToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentStages): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentStagesToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeploymentStages): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeploymentStages | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeploymentStages | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export declare class DataCloudflarePagesProjectCanonicalDeploymentStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePagesProjectCanonicalDeploymentStagesOutputReference;
}
export interface DataCloudflarePagesProjectCanonicalDeployment {
}
export declare function dataCloudflarePagesProjectCanonicalDeploymentToTerraform(struct?: DataCloudflarePagesProjectCanonicalDeployment): any;
export declare function dataCloudflarePagesProjectCanonicalDeploymentToHclTerraform(struct?: DataCloudflarePagesProjectCanonicalDeployment): any;
export declare class DataCloudflarePagesProjectCanonicalDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectCanonicalDeployment | undefined;
    set internalValue(value: DataCloudflarePagesProjectCanonicalDeployment | undefined);
    get aliases(): string[];
    private _buildConfig;
    get buildConfig(): DataCloudflarePagesProjectCanonicalDeploymentBuildConfigOutputReference;
    get createdOn(): string;
    private _deploymentTrigger;
    get deploymentTrigger(): DataCloudflarePagesProjectCanonicalDeploymentDeploymentTriggerOutputReference;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectCanonicalDeploymentEnvVarsMap;
    get environment(): string;
    get id(): string;
    get isSkipped(): cdktn.IResolvable;
    private _latestStage;
    get latestStage(): DataCloudflarePagesProjectCanonicalDeploymentLatestStageOutputReference;
    get modifiedOn(): string;
    get projectId(): string;
    get projectName(): string;
    get shortId(): string;
    private _source;
    get source(): DataCloudflarePagesProjectCanonicalDeploymentSourceOutputReference;
    private _stages;
    get stages(): DataCloudflarePagesProjectCanonicalDeploymentStagesList;
    get url(): string;
    get usesFunctions(): cdktn.IResolvable;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindings {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewAiBindingsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindings): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewAiBindingsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindings): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindings | undefined);
    get projectId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindingsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets | undefined);
    get dataset(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsers {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewBrowsersToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsers): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewBrowsersToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsers): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsers | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsers | undefined);
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsersOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewD1Databases {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewD1DatabasesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewD1Databases): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewD1DatabasesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewD1Databases): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewD1DatabasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewD1Databases | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewD1Databases | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewD1DatabasesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewD1DatabasesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespaces {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespacesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespaces): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespaces): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVars {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewEnvVarsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVars): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVars): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindings {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindingsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindings): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindingsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindings): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindings | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindingsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespaces {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespacesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespaces): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespaces): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewLimits {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewLimitsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewLimits): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewLimitsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewLimits): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewLimits | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewLimits | undefined);
    get cpuMs(): number;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificates {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificatesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificates): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificatesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificates): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificates | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificates | undefined);
    get certificateId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificatesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificatesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewPlacement {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewPlacementToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewPlacement): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewPlacementToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewPlacement): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewPlacement | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewPlacement | undefined);
    get mode(): string;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducers {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducersToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducers): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducersToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducers): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducers | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducers | undefined);
    get name(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducersOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewR2Buckets {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewR2BucketsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewR2Buckets): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewR2BucketsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewR2Buckets): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewR2BucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewR2Buckets | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewR2Buckets | undefined);
    get jurisdiction(): string;
    get name(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewR2BucketsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewR2BucketsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewServices {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewServicesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewServices): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewServicesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewServices): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewServices | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewServices | undefined);
    get entrypoint(): string;
    get environment(): string;
    get service(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewServicesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewServicesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindings {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindingsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindings): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindingsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindings): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindings | undefined);
    get indexName(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindingsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsPreview {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreview): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsPreviewToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsPreview): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsPreviewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsPreview | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsPreview | undefined);
    private _aiBindings;
    get aiBindings(): DataCloudflarePagesProjectDeploymentConfigsPreviewAiBindingsMap;
    get alwaysUseLatestCompatibilityDate(): cdktn.IResolvable;
    private _analyticsEngineDatasets;
    get analyticsEngineDatasets(): DataCloudflarePagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsMap;
    private _browsers;
    get browsers(): DataCloudflarePagesProjectDeploymentConfigsPreviewBrowsersMap;
    get buildImageMajorVersion(): number;
    get compatibilityDate(): string;
    get compatibilityFlags(): string[];
    private _d1Databases;
    get d1Databases(): DataCloudflarePagesProjectDeploymentConfigsPreviewD1DatabasesMap;
    private _durableObjectNamespaces;
    get durableObjectNamespaces(): DataCloudflarePagesProjectDeploymentConfigsPreviewDurableObjectNamespacesMap;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectDeploymentConfigsPreviewEnvVarsMap;
    get failOpen(): cdktn.IResolvable;
    private _hyperdriveBindings;
    get hyperdriveBindings(): DataCloudflarePagesProjectDeploymentConfigsPreviewHyperdriveBindingsMap;
    private _kvNamespaces;
    get kvNamespaces(): DataCloudflarePagesProjectDeploymentConfigsPreviewKvNamespacesMap;
    private _limits;
    get limits(): DataCloudflarePagesProjectDeploymentConfigsPreviewLimitsOutputReference;
    private _mtlsCertificates;
    get mtlsCertificates(): DataCloudflarePagesProjectDeploymentConfigsPreviewMtlsCertificatesMap;
    private _placement;
    get placement(): DataCloudflarePagesProjectDeploymentConfigsPreviewPlacementOutputReference;
    private _queueProducers;
    get queueProducers(): DataCloudflarePagesProjectDeploymentConfigsPreviewQueueProducersMap;
    private _r2Buckets;
    get r2Buckets(): DataCloudflarePagesProjectDeploymentConfigsPreviewR2BucketsMap;
    private _services;
    get services(): DataCloudflarePagesProjectDeploymentConfigsPreviewServicesMap;
    get usageModel(): string;
    private _vectorizeBindings;
    get vectorizeBindings(): DataCloudflarePagesProjectDeploymentConfigsPreviewVectorizeBindingsMap;
    get wranglerConfigHash(): string;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionAiBindings {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionAiBindingsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionAiBindings): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionAiBindingsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionAiBindings): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionAiBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionAiBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionAiBindings | undefined);
    get projectId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionAiBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionAiBindingsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets | undefined);
    get dataset(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionBrowsers {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionBrowsersToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionBrowsers): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionBrowsersToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionBrowsers): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionBrowsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionBrowsers | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionBrowsers | undefined);
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionBrowsersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionBrowsersOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionD1Databases {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionD1DatabasesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionD1Databases): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionD1DatabasesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionD1Databases): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionD1DatabasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionD1Databases | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionD1Databases | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionD1DatabasesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionD1DatabasesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespaces {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespacesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespaces): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespaces): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionEnvVars {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionEnvVarsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionEnvVars): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionEnvVars): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindings {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindingsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindings): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindingsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindings): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindings | undefined);
    get id(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindingsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespaces {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionKvNamespacesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespaces): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionKvNamespacesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespaces): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespaces | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespaces | undefined);
    get namespaceId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespacesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespacesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionLimits {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionLimitsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionLimits): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionLimitsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionLimits): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionLimits | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionLimits | undefined);
    get cpuMs(): number;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificates {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificatesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificates): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificatesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificates): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificates | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificates | undefined);
    get certificateId(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificatesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificatesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionPlacement {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionPlacementToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionPlacement): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionPlacementToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionPlacement): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionPlacement | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionPlacement | undefined);
    get mode(): string;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducers {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionQueueProducersToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducers): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionQueueProducersToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducers): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducers | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducers | undefined);
    get name(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducersMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducersOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionR2Buckets {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionR2BucketsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionR2Buckets): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionR2BucketsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionR2Buckets): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionR2BucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionR2Buckets | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionR2Buckets | undefined);
    get jurisdiction(): string;
    get name(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionR2BucketsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionR2BucketsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionServices {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionServicesToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionServices): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionServicesToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionServices): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionServices | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionServices | undefined);
    get entrypoint(): string;
    get environment(): string;
    get service(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionServicesMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionServicesOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindings {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindingsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindings): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindingsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindings): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindings | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindings | undefined);
    get indexName(): string;
}
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindingsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindingsOutputReference;
}
export interface DataCloudflarePagesProjectDeploymentConfigsProduction {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProduction): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsProductionToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigsProduction): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsProductionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigsProduction | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigsProduction | undefined);
    private _aiBindings;
    get aiBindings(): DataCloudflarePagesProjectDeploymentConfigsProductionAiBindingsMap;
    get alwaysUseLatestCompatibilityDate(): cdktn.IResolvable;
    private _analyticsEngineDatasets;
    get analyticsEngineDatasets(): DataCloudflarePagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsMap;
    private _browsers;
    get browsers(): DataCloudflarePagesProjectDeploymentConfigsProductionBrowsersMap;
    get buildImageMajorVersion(): number;
    get compatibilityDate(): string;
    get compatibilityFlags(): string[];
    private _d1Databases;
    get d1Databases(): DataCloudflarePagesProjectDeploymentConfigsProductionD1DatabasesMap;
    private _durableObjectNamespaces;
    get durableObjectNamespaces(): DataCloudflarePagesProjectDeploymentConfigsProductionDurableObjectNamespacesMap;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectDeploymentConfigsProductionEnvVarsMap;
    get failOpen(): cdktn.IResolvable;
    private _hyperdriveBindings;
    get hyperdriveBindings(): DataCloudflarePagesProjectDeploymentConfigsProductionHyperdriveBindingsMap;
    private _kvNamespaces;
    get kvNamespaces(): DataCloudflarePagesProjectDeploymentConfigsProductionKvNamespacesMap;
    private _limits;
    get limits(): DataCloudflarePagesProjectDeploymentConfigsProductionLimitsOutputReference;
    private _mtlsCertificates;
    get mtlsCertificates(): DataCloudflarePagesProjectDeploymentConfigsProductionMtlsCertificatesMap;
    private _placement;
    get placement(): DataCloudflarePagesProjectDeploymentConfigsProductionPlacementOutputReference;
    private _queueProducers;
    get queueProducers(): DataCloudflarePagesProjectDeploymentConfigsProductionQueueProducersMap;
    private _r2Buckets;
    get r2Buckets(): DataCloudflarePagesProjectDeploymentConfigsProductionR2BucketsMap;
    private _services;
    get services(): DataCloudflarePagesProjectDeploymentConfigsProductionServicesMap;
    get usageModel(): string;
    private _vectorizeBindings;
    get vectorizeBindings(): DataCloudflarePagesProjectDeploymentConfigsProductionVectorizeBindingsMap;
    get wranglerConfigHash(): string;
}
export interface DataCloudflarePagesProjectDeploymentConfigs {
}
export declare function dataCloudflarePagesProjectDeploymentConfigsToTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigs): any;
export declare function dataCloudflarePagesProjectDeploymentConfigsToHclTerraform(struct?: DataCloudflarePagesProjectDeploymentConfigs): any;
export declare class DataCloudflarePagesProjectDeploymentConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectDeploymentConfigs | undefined;
    set internalValue(value: DataCloudflarePagesProjectDeploymentConfigs | undefined);
    private _preview;
    get preview(): DataCloudflarePagesProjectDeploymentConfigsPreviewOutputReference;
    private _production;
    get production(): DataCloudflarePagesProjectDeploymentConfigsProductionOutputReference;
}
export interface DataCloudflarePagesProjectLatestDeploymentBuildConfig {
}
export declare function dataCloudflarePagesProjectLatestDeploymentBuildConfigToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentBuildConfig): any;
export declare function dataCloudflarePagesProjectLatestDeploymentBuildConfigToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentBuildConfig): any;
export declare class DataCloudflarePagesProjectLatestDeploymentBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentBuildConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadata {
}
export declare function dataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadataToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadata): any;
export declare function dataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadataToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadata): any;
export declare class DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadata | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadata | undefined);
    get branch(): string;
    get commitDirty(): cdktn.IResolvable;
    get commitHash(): string;
    get commitMessage(): string;
}
export interface DataCloudflarePagesProjectLatestDeploymentDeploymentTrigger {
}
export declare function dataCloudflarePagesProjectLatestDeploymentDeploymentTriggerToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentDeploymentTrigger): any;
export declare function dataCloudflarePagesProjectLatestDeploymentDeploymentTriggerToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentDeploymentTrigger): any;
export declare class DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentDeploymentTrigger | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentDeploymentTrigger | undefined);
    private _metadata;
    get metadata(): DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerMetadataOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectLatestDeploymentEnvVars {
}
export declare function dataCloudflarePagesProjectLatestDeploymentEnvVarsToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentEnvVars): any;
export declare function dataCloudflarePagesProjectLatestDeploymentEnvVarsToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentEnvVars): any;
export declare class DataCloudflarePagesProjectLatestDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentEnvVars | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class DataCloudflarePagesProjectLatestDeploymentEnvVarsMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflarePagesProjectLatestDeploymentEnvVarsOutputReference;
}
export interface DataCloudflarePagesProjectLatestDeploymentLatestStage {
}
export declare function dataCloudflarePagesProjectLatestDeploymentLatestStageToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentLatestStage): any;
export declare function dataCloudflarePagesProjectLatestDeploymentLatestStageToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentLatestStage): any;
export declare class DataCloudflarePagesProjectLatestDeploymentLatestStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentLatestStage | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentLatestStage | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export interface DataCloudflarePagesProjectLatestDeploymentSourceConfig {
}
export declare function dataCloudflarePagesProjectLatestDeploymentSourceConfigToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentSourceConfig): any;
export declare function dataCloudflarePagesProjectLatestDeploymentSourceConfigToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentSourceConfig): any;
export declare class DataCloudflarePagesProjectLatestDeploymentSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentSourceConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface DataCloudflarePagesProjectLatestDeploymentSource {
}
export declare function dataCloudflarePagesProjectLatestDeploymentSourceToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentSource): any;
export declare function dataCloudflarePagesProjectLatestDeploymentSourceToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentSource): any;
export declare class DataCloudflarePagesProjectLatestDeploymentSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentSource | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentSource | undefined);
    private _config;
    get config(): DataCloudflarePagesProjectLatestDeploymentSourceConfigOutputReference;
    get type(): string;
}
export interface DataCloudflarePagesProjectLatestDeploymentStages {
}
export declare function dataCloudflarePagesProjectLatestDeploymentStagesToTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentStages): any;
export declare function dataCloudflarePagesProjectLatestDeploymentStagesToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeploymentStages): any;
export declare class DataCloudflarePagesProjectLatestDeploymentStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePagesProjectLatestDeploymentStages | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeploymentStages | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export declare class DataCloudflarePagesProjectLatestDeploymentStagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePagesProjectLatestDeploymentStagesOutputReference;
}
export interface DataCloudflarePagesProjectLatestDeployment {
}
export declare function dataCloudflarePagesProjectLatestDeploymentToTerraform(struct?: DataCloudflarePagesProjectLatestDeployment): any;
export declare function dataCloudflarePagesProjectLatestDeploymentToHclTerraform(struct?: DataCloudflarePagesProjectLatestDeployment): any;
export declare class DataCloudflarePagesProjectLatestDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectLatestDeployment | undefined;
    set internalValue(value: DataCloudflarePagesProjectLatestDeployment | undefined);
    get aliases(): string[];
    private _buildConfig;
    get buildConfig(): DataCloudflarePagesProjectLatestDeploymentBuildConfigOutputReference;
    get createdOn(): string;
    private _deploymentTrigger;
    get deploymentTrigger(): DataCloudflarePagesProjectLatestDeploymentDeploymentTriggerOutputReference;
    private _envVars;
    get envVars(): DataCloudflarePagesProjectLatestDeploymentEnvVarsMap;
    get environment(): string;
    get id(): string;
    get isSkipped(): cdktn.IResolvable;
    private _latestStage;
    get latestStage(): DataCloudflarePagesProjectLatestDeploymentLatestStageOutputReference;
    get modifiedOn(): string;
    get projectId(): string;
    get projectName(): string;
    get shortId(): string;
    private _source;
    get source(): DataCloudflarePagesProjectLatestDeploymentSourceOutputReference;
    private _stages;
    get stages(): DataCloudflarePagesProjectLatestDeploymentStagesList;
    get url(): string;
    get usesFunctions(): cdktn.IResolvable;
}
export interface DataCloudflarePagesProjectSourceConfig {
}
export declare function dataCloudflarePagesProjectSourceConfigToTerraform(struct?: DataCloudflarePagesProjectSourceConfig): any;
export declare function dataCloudflarePagesProjectSourceConfigToHclTerraform(struct?: DataCloudflarePagesProjectSourceConfig): any;
export declare class DataCloudflarePagesProjectSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectSourceConfig | undefined;
    set internalValue(value: DataCloudflarePagesProjectSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface DataCloudflarePagesProjectSource {
}
export declare function dataCloudflarePagesProjectSourceToTerraform(struct?: DataCloudflarePagesProjectSource): any;
export declare function dataCloudflarePagesProjectSourceToHclTerraform(struct?: DataCloudflarePagesProjectSource): any;
export declare class DataCloudflarePagesProjectSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePagesProjectSource | undefined;
    set internalValue(value: DataCloudflarePagesProjectSource | undefined);
    private _config;
    get config(): DataCloudflarePagesProjectSourceConfigOutputReference;
    get type(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pages_project cloudflare_pages_project}
*/
export declare class DataCloudflarePagesProject extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_pages_project";
    /**
    * Generates CDKTN code for importing a DataCloudflarePagesProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflarePagesProject to import
    * @param importFromId The id of the existing DataCloudflarePagesProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pages_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflarePagesProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pages_project cloudflare_pages_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflarePagesProjectConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflarePagesProjectConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _buildConfig;
    get buildConfig(): DataCloudflarePagesProjectBuildConfigOutputReference;
    private _canonicalDeployment;
    get canonicalDeployment(): DataCloudflarePagesProjectCanonicalDeploymentOutputReference;
    get createdOn(): string;
    private _deploymentConfigs;
    get deploymentConfigs(): DataCloudflarePagesProjectDeploymentConfigsOutputReference;
    get domains(): string[];
    get framework(): string;
    get frameworkVersion(): string;
    get id(): string;
    private _latestDeployment;
    get latestDeployment(): DataCloudflarePagesProjectLatestDeploymentOutputReference;
    get name(): string;
    get previewScriptName(): string;
    get productionBranch(): string;
    get productionScriptName(): string;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _source;
    get source(): DataCloudflarePagesProjectSourceOutputReference;
    get subdomain(): string;
    get usesFunctions(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
