/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpProximityValidatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validator#account_id DataCloudflareZeroTrustDlpProximityValidator#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validator#validator_id DataCloudflareZeroTrustDlpProximityValidator#validator_id}
    */
    readonly validatorId: string;
}
export interface DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntries {
}
export declare function dataCloudflareZeroTrustDlpProximityValidatorReferencedByEntriesToTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntries): any;
export declare function dataCloudflareZeroTrustDlpProximityValidatorReferencedByEntriesToHclTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntries): any;
export declare class DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntries | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntries | undefined);
    get id(): string;
    get name(): string;
    get type(): string;
}
export declare class DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntriesOutputReference;
}
export interface DataCloudflareZeroTrustDlpProximityValidatorReferencedBy {
}
export declare function dataCloudflareZeroTrustDlpProximityValidatorReferencedByToTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorReferencedBy): any;
export declare function dataCloudflareZeroTrustDlpProximityValidatorReferencedByToHclTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorReferencedBy): any;
export declare class DataCloudflareZeroTrustDlpProximityValidatorReferencedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpProximityValidatorReferencedBy | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpProximityValidatorReferencedBy | undefined);
    private _entries;
    get entries(): DataCloudflareZeroTrustDlpProximityValidatorReferencedByEntriesList;
    get entryCount(): number;
}
export interface DataCloudflareZeroTrustDlpProximityValidatorWords {
}
export declare function dataCloudflareZeroTrustDlpProximityValidatorWordsToTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorWords): any;
export declare function dataCloudflareZeroTrustDlpProximityValidatorWordsToHclTerraform(struct?: DataCloudflareZeroTrustDlpProximityValidatorWords): any;
export declare class DataCloudflareZeroTrustDlpProximityValidatorWordsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpProximityValidatorWords | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpProximityValidatorWords | undefined);
    get weight(): string;
    get word(): string;
}
export declare class DataCloudflareZeroTrustDlpProximityValidatorWordsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpProximityValidatorWordsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validator cloudflare_zero_trust_dlp_proximity_validator}
*/
export declare class DataCloudflareZeroTrustDlpProximityValidator extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_proximity_validator";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpProximityValidator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpProximityValidator to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpProximityValidator that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpProximityValidator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_dlp_proximity_validator cloudflare_zero_trust_dlp_proximity_validator} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpProximityValidatorConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpProximityValidatorConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    get id(): string;
    get name(): string;
    private _referencedBy;
    get referencedBy(): DataCloudflareZeroTrustDlpProximityValidatorReferencedByOutputReference;
    get updatedAt(): string;
    private _validatorId?;
    get validatorId(): string;
    set validatorId(value: string);
    get validatorIdInput(): string | undefined;
    private _words;
    get words(): DataCloudflareZeroTrustDlpProximityValidatorWordsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
