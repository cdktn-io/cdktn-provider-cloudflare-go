/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustResourceLibraryCategoriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_resource_library_categories#account_id DataCloudflareZeroTrustResourceLibraryCategories#account_id}
    */
    readonly accountId: string;
    /**
    * Limit of number of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_resource_library_categories#limit DataCloudflareZeroTrustResourceLibraryCategories#limit}
    */
    readonly limit?: number;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_resource_library_categories#max_items DataCloudflareZeroTrustResourceLibraryCategories#max_items}
    */
    readonly maxItems?: number;
    /**
    * Offset of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_resource_library_categories#offset DataCloudflareZeroTrustResourceLibraryCategories#offset}
    */
    readonly offset?: number;
}
export interface DataCloudflareZeroTrustResourceLibraryCategoriesResult {
}
export declare function dataCloudflareZeroTrustResourceLibraryCategoriesResultToTerraform(struct?: DataCloudflareZeroTrustResourceLibraryCategoriesResult): any;
export declare function dataCloudflareZeroTrustResourceLibraryCategoriesResultToHclTerraform(struct?: DataCloudflareZeroTrustResourceLibraryCategoriesResult): any;
export declare class DataCloudflareZeroTrustResourceLibraryCategoriesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustResourceLibraryCategoriesResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustResourceLibraryCategoriesResult | undefined);
    get createdAt(): string;
    get description(): string;
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZeroTrustResourceLibraryCategoriesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustResourceLibraryCategoriesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_resource_library_categories cloudflare_zero_trust_resource_library_categories}
*/
export declare class DataCloudflareZeroTrustResourceLibraryCategories extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_resource_library_categories";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustResourceLibraryCategories resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustResourceLibraryCategories to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustResourceLibraryCategories that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_resource_library_categories#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustResourceLibraryCategories to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zero_trust_resource_library_categories cloudflare_zero_trust_resource_library_categories} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustResourceLibraryCategoriesConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustResourceLibraryCategoriesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _offset?;
    get offset(): number;
    set offset(value: number);
    resetOffset(): void;
    get offsetInput(): number | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustResourceLibraryCategoriesResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
