/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareNelSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/nel_setting#zone_id DataCloudflareNelSetting#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflareNelSettingValue {
}
export declare function dataCloudflareNelSettingValueToTerraform(struct?: DataCloudflareNelSettingValue): any;
export declare function dataCloudflareNelSettingValueToHclTerraform(struct?: DataCloudflareNelSettingValue): any;
export declare class DataCloudflareNelSettingValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareNelSettingValue | undefined;
    set internalValue(value: DataCloudflareNelSettingValue | undefined);
    get enabled(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/nel_setting cloudflare_nel_setting}
*/
export declare class DataCloudflareNelSetting extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_nel_setting";
    /**
    * Generates CDKTN code for importing a DataCloudflareNelSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareNelSetting to import
    * @param importFromId The id of the existing DataCloudflareNelSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/nel_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareNelSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.25.0/docs/data-sources/nel_setting cloudflare_nel_setting} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareNelSettingConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareNelSettingConfig);
    get editable(): cdktn.IResolvable;
    get id(): string;
    get modifiedOn(): string;
    private _value;
    get value(): DataCloudflareNelSettingValueOutputReference;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
