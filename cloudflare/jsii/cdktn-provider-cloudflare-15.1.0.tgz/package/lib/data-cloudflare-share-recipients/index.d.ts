/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareShareRecipientsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share_recipients#account_id DataCloudflareShareRecipients#account_id}
    */
    readonly accountId: string;
    /**
    * Include resources in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share_recipients#include_resources DataCloudflareShareRecipients#include_resources}
    */
    readonly includeResources?: boolean | cdktn.IResolvable;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share_recipients#max_items DataCloudflareShareRecipients#max_items}
    */
    readonly maxItems?: number;
    /**
    * Share identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share_recipients#share_id DataCloudflareShareRecipients#share_id}
    */
    readonly shareId: string;
}
export interface DataCloudflareShareRecipientsResultResources {
}
export declare function dataCloudflareShareRecipientsResultResourcesToTerraform(struct?: DataCloudflareShareRecipientsResultResources): any;
export declare function dataCloudflareShareRecipientsResultResourcesToHclTerraform(struct?: DataCloudflareShareRecipientsResultResources): any;
export declare class DataCloudflareShareRecipientsResultResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareShareRecipientsResultResources | undefined;
    set internalValue(value: DataCloudflareShareRecipientsResultResources | undefined);
    get error(): string;
    get resourceId(): string;
    get resourceVersion(): number;
    get terminal(): cdktn.IResolvable;
}
export declare class DataCloudflareShareRecipientsResultResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareShareRecipientsResultResourcesOutputReference;
}
export interface DataCloudflareShareRecipientsResult {
}
export declare function dataCloudflareShareRecipientsResultToTerraform(struct?: DataCloudflareShareRecipientsResult): any;
export declare function dataCloudflareShareRecipientsResultToHclTerraform(struct?: DataCloudflareShareRecipientsResult): any;
export declare class DataCloudflareShareRecipientsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareShareRecipientsResult | undefined;
    set internalValue(value: DataCloudflareShareRecipientsResult | undefined);
    get accountId(): string;
    get associationStatus(): string;
    get created(): string;
    get id(): string;
    get modified(): string;
    private _resources;
    get resources(): DataCloudflareShareRecipientsResultResourcesList;
}
export declare class DataCloudflareShareRecipientsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareShareRecipientsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share_recipients cloudflare_share_recipients}
*/
export declare class DataCloudflareShareRecipients extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_share_recipients";
    /**
    * Generates CDKTN code for importing a DataCloudflareShareRecipients resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareShareRecipients to import
    * @param importFromId The id of the existing DataCloudflareShareRecipients that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share_recipients#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareShareRecipients to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/share_recipients cloudflare_share_recipients} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareShareRecipientsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareShareRecipientsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _includeResources?;
    get includeResources(): boolean | cdktn.IResolvable;
    set includeResources(value: boolean | cdktn.IResolvable);
    resetIncludeResources(): void;
    get includeResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareShareRecipientsResultList;
    private _shareId?;
    get shareId(): string;
    set shareId(value: string);
    get shareIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
