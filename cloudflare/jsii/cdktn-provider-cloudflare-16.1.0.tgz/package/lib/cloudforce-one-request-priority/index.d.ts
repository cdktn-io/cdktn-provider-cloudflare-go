/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudforceOneRequestPriorityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority#account_id CloudforceOneRequestPriority#account_id}
    */
    readonly accountId: string;
    /**
    * List of labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority#labels CloudforceOneRequestPriority#labels}
    */
    readonly labels: string[];
    /**
    * Priority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority#priority CloudforceOneRequestPriority#priority}
    */
    readonly priority: number;
    /**
    * Requirement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority#requirement CloudforceOneRequestPriority#requirement}
    */
    readonly requirement: string;
    /**
    * The CISA defined Traffic Light Protocol (TLP).
    * Available values: "clear", "amber", "amber-strict", "green", "red".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority#tlp CloudforceOneRequestPriority#tlp}
    */
    readonly tlp: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority cloudflare_cloudforce_one_request_priority}
*/
export declare class CloudforceOneRequestPriority extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_cloudforce_one_request_priority";
    /**
    * Generates CDKTN code for importing a CloudforceOneRequestPriority resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudforceOneRequestPriority to import
    * @param importFromId The id of the existing CloudforceOneRequestPriority that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudforceOneRequestPriority to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/cloudforce_one_request_priority cloudflare_cloudforce_one_request_priority} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudforceOneRequestPriorityConfig
    */
    constructor(scope: Construct, id: string, config: CloudforceOneRequestPriorityConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get completed(): string;
    get content(): string;
    get created(): string;
    get id(): string;
    private _labels?;
    get labels(): string[];
    set labels(value: string[]);
    get labelsInput(): string[] | undefined;
    get messageTokens(): number;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    get readableId(): string;
    get request(): string;
    private _requirement?;
    get requirement(): string;
    set requirement(value: string);
    get requirementInput(): string | undefined;
    get status(): string;
    get summary(): string;
    private _tlp?;
    get tlp(): string;
    set tlp(value: string);
    get tlpInput(): string | undefined;
    get tokens(): number;
    get updated(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
