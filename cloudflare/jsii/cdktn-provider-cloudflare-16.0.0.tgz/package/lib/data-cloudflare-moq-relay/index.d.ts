/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareMoqRelayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#account_id DataCloudflareMoqRelay#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#filter DataCloudflareMoqRelay#filter}
    */
    readonly filter?: DataCloudflareMoqRelayFilter;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#relay_id DataCloudflareMoqRelay#relay_id}
    */
    readonly relayId?: string;
}
export interface DataCloudflareMoqRelayConfigLingeringSubscribe {
}
export declare function dataCloudflareMoqRelayConfigLingeringSubscribeToTerraform(struct?: DataCloudflareMoqRelayConfigLingeringSubscribe): any;
export declare function dataCloudflareMoqRelayConfigLingeringSubscribeToHclTerraform(struct?: DataCloudflareMoqRelayConfigLingeringSubscribe): any;
export declare class DataCloudflareMoqRelayConfigLingeringSubscribeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMoqRelayConfigLingeringSubscribe | undefined;
    set internalValue(value: DataCloudflareMoqRelayConfigLingeringSubscribe | undefined);
    get enabled(): cdktn.IResolvable;
    get maxTimeoutMs(): number;
}
export interface DataCloudflareMoqRelayConfigUpstreamsUpstreams {
}
export declare function dataCloudflareMoqRelayConfigUpstreamsUpstreamsToTerraform(struct?: DataCloudflareMoqRelayConfigUpstreamsUpstreams): any;
export declare function dataCloudflareMoqRelayConfigUpstreamsUpstreamsToHclTerraform(struct?: DataCloudflareMoqRelayConfigUpstreamsUpstreams): any;
export declare class DataCloudflareMoqRelayConfigUpstreamsUpstreamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareMoqRelayConfigUpstreamsUpstreams | undefined;
    set internalValue(value: DataCloudflareMoqRelayConfigUpstreamsUpstreams | undefined);
    get url(): string;
}
export declare class DataCloudflareMoqRelayConfigUpstreamsUpstreamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareMoqRelayConfigUpstreamsUpstreamsOutputReference;
}
export interface DataCloudflareMoqRelayConfigUpstreams {
}
export declare function dataCloudflareMoqRelayConfigUpstreamsToTerraform(struct?: DataCloudflareMoqRelayConfigUpstreams): any;
export declare function dataCloudflareMoqRelayConfigUpstreamsToHclTerraform(struct?: DataCloudflareMoqRelayConfigUpstreams): any;
export declare class DataCloudflareMoqRelayConfigUpstreamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMoqRelayConfigUpstreams | undefined;
    set internalValue(value: DataCloudflareMoqRelayConfigUpstreams | undefined);
    get enabled(): cdktn.IResolvable;
    private _upstreams;
    get upstreams(): DataCloudflareMoqRelayConfigUpstreamsUpstreamsList;
}
export interface DataCloudflareMoqRelayConfigA {
}
export declare function dataCloudflareMoqRelayConfigAToTerraform(struct?: DataCloudflareMoqRelayConfigA): any;
export declare function dataCloudflareMoqRelayConfigAToHclTerraform(struct?: DataCloudflareMoqRelayConfigA): any;
export declare class DataCloudflareMoqRelayConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMoqRelayConfigA | undefined;
    set internalValue(value: DataCloudflareMoqRelayConfigA | undefined);
    private _lingeringSubscribe;
    get lingeringSubscribe(): DataCloudflareMoqRelayConfigLingeringSubscribeOutputReference;
    private _upstreams;
    get upstreams(): DataCloudflareMoqRelayConfigUpstreamsOutputReference;
}
export interface DataCloudflareMoqRelayFilter {
    /**
    * Sort order by `created`. When true, results are returned oldest-first
    * (ascending); otherwise newest-first (descending, the default).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#asc DataCloudflareMoqRelay#asc}
    */
    readonly asc?: boolean | cdktn.IResolvable;
    /**
    * Cursor for pagination. Returns relays created strictly after this
    * RFC 3339 timestamp (typically the `created` value of the last item
    * on the current page, to fetch the next page).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#created_after DataCloudflareMoqRelay#created_after}
    */
    readonly createdAfter?: string;
    /**
    * Cursor for pagination. Returns relays created strictly before this
    * RFC 3339 timestamp (typically the `created` value of the first item
    * on the current page, to fetch the previous page).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#created_before DataCloudflareMoqRelay#created_before}
    */
    readonly createdBefore?: string;
    /**
    * Maximum number of relays to return per page.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#per_page DataCloudflareMoqRelay#per_page}
    */
    readonly perPage?: number;
}
export declare function dataCloudflareMoqRelayFilterToTerraform(struct?: DataCloudflareMoqRelayFilter | cdktn.IResolvable): any;
export declare function dataCloudflareMoqRelayFilterToHclTerraform(struct?: DataCloudflareMoqRelayFilter | cdktn.IResolvable): any;
export declare class DataCloudflareMoqRelayFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareMoqRelayFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareMoqRelayFilter | cdktn.IResolvable | undefined);
    private _asc?;
    get asc(): boolean | cdktn.IResolvable;
    set asc(value: boolean | cdktn.IResolvable);
    resetAsc(): void;
    get ascInput(): boolean | cdktn.IResolvable | undefined;
    private _createdAfter?;
    get createdAfter(): string;
    set createdAfter(value: string);
    resetCreatedAfter(): void;
    get createdAfterInput(): string | undefined;
    private _createdBefore?;
    get createdBefore(): string;
    set createdBefore(value: string);
    resetCreatedBefore(): void;
    get createdBeforeInput(): string | undefined;
    private _perPage?;
    get perPage(): number;
    set perPage(value: number);
    resetPerPage(): void;
    get perPageInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay cloudflare_moq_relay}
*/
export declare class DataCloudflareMoqRelay extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_moq_relay";
    /**
    * Generates CDKTN code for importing a DataCloudflareMoqRelay resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareMoqRelay to import
    * @param importFromId The id of the existing DataCloudflareMoqRelay that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareMoqRelay to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/moq_relay cloudflare_moq_relay} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareMoqRelayConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareMoqRelayConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _config;
    get config(): DataCloudflareMoqRelayConfigAOutputReference;
    get created(): string;
    private _filter;
    get filter(): DataCloudflareMoqRelayFilterOutputReference;
    putFilter(value: DataCloudflareMoqRelayFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareMoqRelayFilter | undefined;
    get id(): string;
    get modified(): string;
    get name(): string;
    private _relayId?;
    get relayId(): string;
    set relayId(value: string);
    resetRelayId(): void;
    get relayIdInput(): string | undefined;
    get status(): string;
    get uid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
