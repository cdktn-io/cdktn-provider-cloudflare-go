/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWaitingRoomsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/waiting_rooms#account_id DataCloudflareWaitingRooms#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/waiting_rooms#max_items DataCloudflareWaitingRooms#max_items}
    */
    readonly maxItems?: number;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/waiting_rooms#zone_id DataCloudflareWaitingRooms#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareWaitingRoomsResultAdditionalRoutes {
}
export declare function dataCloudflareWaitingRoomsResultAdditionalRoutesToTerraform(struct?: DataCloudflareWaitingRoomsResultAdditionalRoutes): any;
export declare function dataCloudflareWaitingRoomsResultAdditionalRoutesToHclTerraform(struct?: DataCloudflareWaitingRoomsResultAdditionalRoutes): any;
export declare class DataCloudflareWaitingRoomsResultAdditionalRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWaitingRoomsResultAdditionalRoutes | undefined;
    set internalValue(value: DataCloudflareWaitingRoomsResultAdditionalRoutes | undefined);
    get host(): string;
    get path(): string;
}
export declare class DataCloudflareWaitingRoomsResultAdditionalRoutesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWaitingRoomsResultAdditionalRoutesOutputReference;
}
export interface DataCloudflareWaitingRoomsResultCookieAttributes {
}
export declare function dataCloudflareWaitingRoomsResultCookieAttributesToTerraform(struct?: DataCloudflareWaitingRoomsResultCookieAttributes): any;
export declare function dataCloudflareWaitingRoomsResultCookieAttributesToHclTerraform(struct?: DataCloudflareWaitingRoomsResultCookieAttributes): any;
export declare class DataCloudflareWaitingRoomsResultCookieAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWaitingRoomsResultCookieAttributes | undefined;
    set internalValue(value: DataCloudflareWaitingRoomsResultCookieAttributes | undefined);
    get samesite(): string;
    get secure(): string;
}
export interface DataCloudflareWaitingRoomsResult {
}
export declare function dataCloudflareWaitingRoomsResultToTerraform(struct?: DataCloudflareWaitingRoomsResult): any;
export declare function dataCloudflareWaitingRoomsResultToHclTerraform(struct?: DataCloudflareWaitingRoomsResult): any;
export declare class DataCloudflareWaitingRoomsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWaitingRoomsResult | undefined;
    set internalValue(value: DataCloudflareWaitingRoomsResult | undefined);
    private _additionalRoutes;
    get additionalRoutes(): DataCloudflareWaitingRoomsResultAdditionalRoutesList;
    private _cookieAttributes;
    get cookieAttributes(): DataCloudflareWaitingRoomsResultCookieAttributesOutputReference;
    get cookieSuffix(): string;
    get createdOn(): string;
    get customPageHtml(): string;
    get defaultTemplateLanguage(): string;
    get description(): string;
    get disableSessionRenewal(): cdktn.IResolvable;
    get enabledOriginCommands(): string[];
    get host(): string;
    get id(): string;
    get jsonResponseEnabled(): cdktn.IResolvable;
    get modifiedOn(): string;
    get name(): string;
    get newUsersPerMinute(): number;
    get nextEventPrequeueStartTime(): string;
    get nextEventStartTime(): string;
    get path(): string;
    get queueAll(): cdktn.IResolvable;
    get queueingMethod(): string;
    get queueingStatusCode(): number;
    get sessionDuration(): number;
    get suspended(): cdktn.IResolvable;
    get totalActiveUsers(): number;
    get turnstileAction(): string;
    get turnstileMode(): string;
}
export declare class DataCloudflareWaitingRoomsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWaitingRoomsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/waiting_rooms cloudflare_waiting_rooms}
*/
export declare class DataCloudflareWaitingRooms extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_waiting_rooms";
    /**
    * Generates CDKTN code for importing a DataCloudflareWaitingRooms resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWaitingRooms to import
    * @param importFromId The id of the existing DataCloudflareWaitingRooms that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/waiting_rooms#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWaitingRooms to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/waiting_rooms cloudflare_waiting_rooms} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWaitingRoomsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareWaitingRoomsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareWaitingRoomsResultList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
