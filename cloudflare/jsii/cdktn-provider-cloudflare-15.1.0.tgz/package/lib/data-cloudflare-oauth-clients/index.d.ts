/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareOauthClientsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/oauth_clients#account_id DataCloudflareOauthClients#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/oauth_clients#max_items DataCloudflareOauthClients#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareOauthClientsResultClientUriVerification {
}
export declare function dataCloudflareOauthClientsResultClientUriVerificationToTerraform(struct?: DataCloudflareOauthClientsResultClientUriVerification): any;
export declare function dataCloudflareOauthClientsResultClientUriVerificationToHclTerraform(struct?: DataCloudflareOauthClientsResultClientUriVerification): any;
export declare class DataCloudflareOauthClientsResultClientUriVerificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareOauthClientsResultClientUriVerification | undefined;
    set internalValue(value: DataCloudflareOauthClientsResultClientUriVerification | undefined);
    get status(): string;
    get text(): string;
}
export interface DataCloudflareOauthClientsResult {
}
export declare function dataCloudflareOauthClientsResultToTerraform(struct?: DataCloudflareOauthClientsResult): any;
export declare function dataCloudflareOauthClientsResultToHclTerraform(struct?: DataCloudflareOauthClientsResult): any;
export declare class DataCloudflareOauthClientsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareOauthClientsResult | undefined;
    set internalValue(value: DataCloudflareOauthClientsResult | undefined);
    get allowedCorsOrigins(): string[];
    get clientId(): string;
    get clientName(): string;
    get clientUri(): string;
    private _clientUriVerification;
    get clientUriVerification(): DataCloudflareOauthClientsResultClientUriVerificationOutputReference;
    get createdAt(): string;
    get grantTypes(): string[];
    get hasRotatedSecret(): cdktn.IResolvable;
    get logoUri(): string;
    get policyUri(): string;
    get postLogoutRedirectUris(): string[];
    get promotedAt(): string;
    get redirectUris(): string[];
    get responseTypes(): string[];
    get scopes(): string[];
    get tokenEndpointAuthMethod(): string;
    get tosUri(): string;
    get updatedAt(): string;
    get visibility(): string;
}
export declare class DataCloudflareOauthClientsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareOauthClientsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/oauth_clients cloudflare_oauth_clients}
*/
export declare class DataCloudflareOauthClients extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_oauth_clients";
    /**
    * Generates CDKTN code for importing a DataCloudflareOauthClients resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareOauthClients to import
    * @param importFromId The id of the existing DataCloudflareOauthClients that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/oauth_clients#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareOauthClients to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/oauth_clients cloudflare_oauth_clients} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareOauthClientsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareOauthClientsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareOauthClientsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
