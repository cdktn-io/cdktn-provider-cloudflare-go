/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSendingSubdomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/email_sending_subdomains#max_items DataCloudflareEmailSendingSubdomains#max_items}
    */
    readonly maxItems?: number;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/email_sending_subdomains#zone_id DataCloudflareEmailSendingSubdomains#zone_id}
    */
    readonly zoneId: string;
}
export interface DataCloudflareEmailSendingSubdomainsResult {
}
export declare function dataCloudflareEmailSendingSubdomainsResultToTerraform(struct?: DataCloudflareEmailSendingSubdomainsResult): any;
export declare function dataCloudflareEmailSendingSubdomainsResultToHclTerraform(struct?: DataCloudflareEmailSendingSubdomainsResult): any;
export declare class DataCloudflareEmailSendingSubdomainsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareEmailSendingSubdomainsResult | undefined;
    set internalValue(value: DataCloudflareEmailSendingSubdomainsResult | undefined);
    get created(): string;
    get dkimSelector(): string;
    get dropSuppressedRecipients(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get modified(): string;
    get name(): string;
    get previewEnabled(): cdktn.IResolvable;
    get returnPathDomain(): string;
    get tag(): string;
}
export declare class DataCloudflareEmailSendingSubdomainsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareEmailSendingSubdomainsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/email_sending_subdomains cloudflare_email_sending_subdomains}
*/
export declare class DataCloudflareEmailSendingSubdomains extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_sending_subdomains";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSendingSubdomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSendingSubdomains to import
    * @param importFromId The id of the existing DataCloudflareEmailSendingSubdomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/email_sending_subdomains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSendingSubdomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/email_sending_subdomains cloudflare_email_sending_subdomains} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSendingSubdomainsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareEmailSendingSubdomainsConfig);
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareEmailSendingSubdomainsResultList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
