/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustCwsDeploymentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID (32-character hexadecimal string)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments#account_id DataCloudflareZeroTrustCwsDeployments#account_id}
    */
    readonly accountId: string;
    /**
    * Sort direction (default: asc)
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments#direction DataCloudflareZeroTrustCwsDeployments#direction}
    */
    readonly direction?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments#max_items DataCloudflareZeroTrustCwsDeployments#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter by deployment name (case-insensitive substring match)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments#name DataCloudflareZeroTrustCwsDeployments#name}
    */
    readonly name?: string;
    /**
    * Field to order results by (default: created_at)
    * Available values: "name", "created_at", "updated_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments#order DataCloudflareZeroTrustCwsDeployments#order}
    */
    readonly order?: string;
}
export interface DataCloudflareZeroTrustCwsDeploymentsResult {
}
export declare function dataCloudflareZeroTrustCwsDeploymentsResultToTerraform(struct?: DataCloudflareZeroTrustCwsDeploymentsResult): any;
export declare function dataCloudflareZeroTrustCwsDeploymentsResultToHclTerraform(struct?: DataCloudflareZeroTrustCwsDeploymentsResult): any;
export declare class DataCloudflareZeroTrustCwsDeploymentsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustCwsDeploymentsResult | undefined;
    set internalValue(value: DataCloudflareZeroTrustCwsDeploymentsResult | undefined);
    get basicAuthCredentialIds(): string[];
    get createdAt(): string;
    get defaultMode(): string;
    get description(): string;
    get domainAclId(): string;
    get id(): string;
    get name(): string;
    get onErrorAction(): string;
    get policySetIds(): string[];
    get regoRaiseError(): cdktn.IResolvable;
    private _tags;
    get tags(): cdktn.StringMap;
    get updatedAt(): string;
}
export declare class DataCloudflareZeroTrustCwsDeploymentsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustCwsDeploymentsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments cloudflare_zero_trust_cws_deployments}
*/
export declare class DataCloudflareZeroTrustCwsDeployments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_cws_deployments";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustCwsDeployments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustCwsDeployments to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustCwsDeployments that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustCwsDeployments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.29.0/docs/data-sources/zero_trust_cws_deployments cloudflare_zero_trust_cws_deployments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustCwsDeploymentsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustCwsDeploymentsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _result;
    get result(): DataCloudflareZeroTrustCwsDeploymentsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
