/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PagesProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#account_id PagesProject#account_id}
    */
    readonly accountId: string;
    /**
    * Configs for the project build process.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#build_config PagesProject#build_config}
    */
    readonly buildConfig?: PagesProjectBuildConfig;
    /**
    * Configs for deployments in a project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#deployment_configs PagesProject#deployment_configs}
    */
    readonly deploymentConfigs?: PagesProjectDeploymentConfigs;
    /**
    * Name of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
    /**
    * Production branch of the project. Used to identify production deployments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#production_branch PagesProject#production_branch}
    */
    readonly productionBranch: string;
    /**
    * Configs for the project source control.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#source PagesProject#source}
    */
    readonly source?: PagesProjectSource;
}
export interface PagesProjectBuildConfig {
    /**
    * Enable build caching for the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#build_caching PagesProject#build_caching}
    */
    readonly buildCaching?: boolean | cdktn.IResolvable;
    /**
    * Command used to build project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#build_command PagesProject#build_command}
    */
    readonly buildCommand?: string;
    /**
    * Output directory of the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#destination_dir PagesProject#destination_dir}
    */
    readonly destinationDir?: string;
    /**
    * Directory to run the command.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#root_dir PagesProject#root_dir}
    */
    readonly rootDir?: string;
    /**
    * The classifying tag for analytics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#web_analytics_tag PagesProject#web_analytics_tag}
    */
    readonly webAnalyticsTag?: string;
    /**
    * The auth token for analytics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#web_analytics_token PagesProject#web_analytics_token}
    */
    readonly webAnalyticsToken?: string;
}
export declare function pagesProjectBuildConfigToTerraform(struct?: PagesProjectBuildConfig | cdktn.IResolvable): any;
export declare function pagesProjectBuildConfigToHclTerraform(struct?: PagesProjectBuildConfig | cdktn.IResolvable): any;
export declare class PagesProjectBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectBuildConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectBuildConfig | cdktn.IResolvable | undefined);
    private _buildCaching?;
    get buildCaching(): boolean | cdktn.IResolvable;
    set buildCaching(value: boolean | cdktn.IResolvable);
    resetBuildCaching(): void;
    get buildCachingInput(): boolean | cdktn.IResolvable | undefined;
    private _buildCommand?;
    get buildCommand(): string;
    set buildCommand(value: string);
    resetBuildCommand(): void;
    get buildCommandInput(): string | undefined;
    private _destinationDir?;
    get destinationDir(): string;
    set destinationDir(value: string);
    resetDestinationDir(): void;
    get destinationDirInput(): string | undefined;
    private _rootDir?;
    get rootDir(): string;
    set rootDir(value: string);
    resetRootDir(): void;
    get rootDirInput(): string | undefined;
    private _webAnalyticsTag?;
    get webAnalyticsTag(): string;
    set webAnalyticsTag(value: string);
    resetWebAnalyticsTag(): void;
    get webAnalyticsTagInput(): string | undefined;
    private _webAnalyticsToken?;
    get webAnalyticsToken(): string;
    set webAnalyticsToken(value: string);
    resetWebAnalyticsToken(): void;
    get webAnalyticsTokenInput(): string | undefined;
}
export interface PagesProjectCanonicalDeploymentBuildConfig {
}
export declare function pagesProjectCanonicalDeploymentBuildConfigToTerraform(struct?: PagesProjectCanonicalDeploymentBuildConfig): any;
export declare function pagesProjectCanonicalDeploymentBuildConfigToHclTerraform(struct?: PagesProjectCanonicalDeploymentBuildConfig): any;
export declare class PagesProjectCanonicalDeploymentBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectCanonicalDeploymentBuildConfig | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface PagesProjectCanonicalDeploymentDeploymentTriggerMetadata {
}
export declare function pagesProjectCanonicalDeploymentDeploymentTriggerMetadataToTerraform(struct?: PagesProjectCanonicalDeploymentDeploymentTriggerMetadata): any;
export declare function pagesProjectCanonicalDeploymentDeploymentTriggerMetadataToHclTerraform(struct?: PagesProjectCanonicalDeploymentDeploymentTriggerMetadata): any;
export declare class PagesProjectCanonicalDeploymentDeploymentTriggerMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectCanonicalDeploymentDeploymentTriggerMetadata | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentDeploymentTriggerMetadata | undefined);
    get branch(): string;
    get commitDirty(): cdktn.IResolvable;
    get commitHash(): string;
    get commitMessage(): string;
}
export interface PagesProjectCanonicalDeploymentDeploymentTrigger {
}
export declare function pagesProjectCanonicalDeploymentDeploymentTriggerToTerraform(struct?: PagesProjectCanonicalDeploymentDeploymentTrigger): any;
export declare function pagesProjectCanonicalDeploymentDeploymentTriggerToHclTerraform(struct?: PagesProjectCanonicalDeploymentDeploymentTrigger): any;
export declare class PagesProjectCanonicalDeploymentDeploymentTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectCanonicalDeploymentDeploymentTrigger | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentDeploymentTrigger | undefined);
    private _metadata;
    get metadata(): PagesProjectCanonicalDeploymentDeploymentTriggerMetadataOutputReference;
    get type(): string;
}
export interface PagesProjectCanonicalDeploymentEnvVars {
}
export declare function pagesProjectCanonicalDeploymentEnvVarsToTerraform(struct?: PagesProjectCanonicalDeploymentEnvVars): any;
export declare function pagesProjectCanonicalDeploymentEnvVarsToHclTerraform(struct?: PagesProjectCanonicalDeploymentEnvVars): any;
export declare class PagesProjectCanonicalDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectCanonicalDeploymentEnvVars | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class PagesProjectCanonicalDeploymentEnvVarsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectCanonicalDeploymentEnvVarsOutputReference;
}
export interface PagesProjectCanonicalDeploymentLatestStage {
}
export declare function pagesProjectCanonicalDeploymentLatestStageToTerraform(struct?: PagesProjectCanonicalDeploymentLatestStage): any;
export declare function pagesProjectCanonicalDeploymentLatestStageToHclTerraform(struct?: PagesProjectCanonicalDeploymentLatestStage): any;
export declare class PagesProjectCanonicalDeploymentLatestStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectCanonicalDeploymentLatestStage | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentLatestStage | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export interface PagesProjectCanonicalDeploymentSourceConfig {
}
export declare function pagesProjectCanonicalDeploymentSourceConfigToTerraform(struct?: PagesProjectCanonicalDeploymentSourceConfig): any;
export declare function pagesProjectCanonicalDeploymentSourceConfigToHclTerraform(struct?: PagesProjectCanonicalDeploymentSourceConfig): any;
export declare class PagesProjectCanonicalDeploymentSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectCanonicalDeploymentSourceConfig | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface PagesProjectCanonicalDeploymentSource {
}
export declare function pagesProjectCanonicalDeploymentSourceToTerraform(struct?: PagesProjectCanonicalDeploymentSource): any;
export declare function pagesProjectCanonicalDeploymentSourceToHclTerraform(struct?: PagesProjectCanonicalDeploymentSource): any;
export declare class PagesProjectCanonicalDeploymentSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectCanonicalDeploymentSource | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentSource | undefined);
    private _config;
    get config(): PagesProjectCanonicalDeploymentSourceConfigOutputReference;
    get type(): string;
}
export interface PagesProjectCanonicalDeploymentStages {
}
export declare function pagesProjectCanonicalDeploymentStagesToTerraform(struct?: PagesProjectCanonicalDeploymentStages): any;
export declare function pagesProjectCanonicalDeploymentStagesToHclTerraform(struct?: PagesProjectCanonicalDeploymentStages): any;
export declare class PagesProjectCanonicalDeploymentStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PagesProjectCanonicalDeploymentStages | undefined;
    set internalValue(value: PagesProjectCanonicalDeploymentStages | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export declare class PagesProjectCanonicalDeploymentStagesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PagesProjectCanonicalDeploymentStagesOutputReference;
}
export interface PagesProjectCanonicalDeployment {
}
export declare function pagesProjectCanonicalDeploymentToTerraform(struct?: PagesProjectCanonicalDeployment): any;
export declare function pagesProjectCanonicalDeploymentToHclTerraform(struct?: PagesProjectCanonicalDeployment): any;
export declare class PagesProjectCanonicalDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectCanonicalDeployment | undefined;
    set internalValue(value: PagesProjectCanonicalDeployment | undefined);
    get aliases(): string[];
    private _buildConfig;
    get buildConfig(): PagesProjectCanonicalDeploymentBuildConfigOutputReference;
    get createdOn(): string;
    private _deploymentTrigger;
    get deploymentTrigger(): PagesProjectCanonicalDeploymentDeploymentTriggerOutputReference;
    private _envVars;
    get envVars(): PagesProjectCanonicalDeploymentEnvVarsMap;
    get environment(): string;
    get id(): string;
    get isSkipped(): cdktn.IResolvable;
    private _latestStage;
    get latestStage(): PagesProjectCanonicalDeploymentLatestStageOutputReference;
    get modifiedOn(): string;
    get projectId(): string;
    get projectName(): string;
    get shortId(): string;
    private _source;
    get source(): PagesProjectCanonicalDeploymentSourceOutputReference;
    private _stages;
    get stages(): PagesProjectCanonicalDeploymentStagesList;
    get url(): string;
    get usesFunctions(): cdktn.IResolvable;
}
export interface PagesProjectDeploymentConfigsPreviewAiBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#project_id PagesProject#project_id}
    */
    readonly projectId: string;
}
export declare function pagesProjectDeploymentConfigsPreviewAiBindingsToTerraform(struct?: PagesProjectDeploymentConfigsPreviewAiBindings | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewAiBindingsToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewAiBindings | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewAiBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewAiBindings | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewAiBindings | cdktn.IResolvable | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewAiBindingsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewAiBindings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewAiBindingsOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets {
    /**
    * Name of the dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#dataset PagesProject#dataset}
    */
    readonly dataset: string;
}
export declare function pagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsToTerraform(struct?: PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets | cdktn.IResolvable | undefined);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewBrowsers {
}
export declare function pagesProjectDeploymentConfigsPreviewBrowsersToTerraform(struct?: PagesProjectDeploymentConfigsPreviewBrowsers | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewBrowsersToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewBrowsers | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewBrowsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewBrowsers | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewBrowsers | cdktn.IResolvable | undefined);
}
export declare class PagesProjectDeploymentConfigsPreviewBrowsersMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewBrowsers;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewBrowsersOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewD1Databases {
    /**
    * UUID of the D1 database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#id PagesProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function pagesProjectDeploymentConfigsPreviewD1DatabasesToTerraform(struct?: PagesProjectDeploymentConfigsPreviewD1Databases | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewD1DatabasesToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewD1Databases | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewD1DatabasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewD1Databases | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewD1Databases | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewD1DatabasesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewD1Databases;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewD1DatabasesOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces {
    /**
    * ID of the Durable Object namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#namespace_id PagesProject#namespace_id}
    */
    readonly namespaceId: string;
}
export declare function pagesProjectDeploymentConfigsPreviewDurableObjectNamespacesToTerraform(struct?: PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewDurableObjectNamespacesToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewDurableObjectNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces | cdktn.IResolvable | undefined);
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewDurableObjectNamespacesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewDurableObjectNamespacesOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewEnvVars {
    /**
    * Available values: "plain_text", "secret_text".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#type PagesProject#type}
    */
    readonly type: string;
    /**
    * Environment variable value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#value PagesProject#value}
    */
    readonly value: string;
}
export declare function pagesProjectDeploymentConfigsPreviewEnvVarsToTerraform(struct?: PagesProjectDeploymentConfigsPreviewEnvVars | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewEnvVarsToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewEnvVars | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewEnvVars | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewEnvVarsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewEnvVars;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewEnvVarsOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewHyperdriveBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#id PagesProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function pagesProjectDeploymentConfigsPreviewHyperdriveBindingsToTerraform(struct?: PagesProjectDeploymentConfigsPreviewHyperdriveBindings | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewHyperdriveBindingsToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewHyperdriveBindings | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewHyperdriveBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewHyperdriveBindings | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewHyperdriveBindings | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewHyperdriveBindingsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewHyperdriveBindings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewHyperdriveBindingsOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewKvNamespaces {
    /**
    * ID of the KV namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#namespace_id PagesProject#namespace_id}
    */
    readonly namespaceId: string;
}
export declare function pagesProjectDeploymentConfigsPreviewKvNamespacesToTerraform(struct?: PagesProjectDeploymentConfigsPreviewKvNamespaces | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewKvNamespacesToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewKvNamespaces | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewKvNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewKvNamespaces | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewKvNamespaces | cdktn.IResolvable | undefined);
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewKvNamespacesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewKvNamespaces;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewKvNamespacesOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewLimits {
    /**
    * CPU time limit in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#cpu_ms PagesProject#cpu_ms}
    */
    readonly cpuMs: number;
}
export declare function pagesProjectDeploymentConfigsPreviewLimitsToTerraform(struct?: PagesProjectDeploymentConfigsPreviewLimits | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewLimitsToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewLimits | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewLimits | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewLimits | cdktn.IResolvable | undefined);
    private _cpuMs?;
    get cpuMs(): number;
    set cpuMs(value: number);
    get cpuMsInput(): number | undefined;
}
export interface PagesProjectDeploymentConfigsPreviewMtlsCertificates {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#certificate_id PagesProject#certificate_id}
    */
    readonly certificateId: string;
}
export declare function pagesProjectDeploymentConfigsPreviewMtlsCertificatesToTerraform(struct?: PagesProjectDeploymentConfigsPreviewMtlsCertificates | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewMtlsCertificatesToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewMtlsCertificates | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewMtlsCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewMtlsCertificates | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewMtlsCertificates | cdktn.IResolvable | undefined);
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    get certificateIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewMtlsCertificatesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewMtlsCertificates;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewMtlsCertificatesOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewPlacement {
    /**
    * Placement mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#mode PagesProject#mode}
    */
    readonly mode?: string;
}
export declare function pagesProjectDeploymentConfigsPreviewPlacementToTerraform(struct?: PagesProjectDeploymentConfigsPreviewPlacement | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewPlacementToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewPlacement | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewPlacement | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewPlacement | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface PagesProjectDeploymentConfigsPreviewQueueProducers {
    /**
    * Name of the Queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
}
export declare function pagesProjectDeploymentConfigsPreviewQueueProducersToTerraform(struct?: PagesProjectDeploymentConfigsPreviewQueueProducers | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewQueueProducersToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewQueueProducers | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewQueueProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewQueueProducers | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewQueueProducers | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewQueueProducersMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewQueueProducers;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewQueueProducersOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewR2Buckets {
    /**
    * Jurisdiction of the R2 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#jurisdiction PagesProject#jurisdiction}
    */
    readonly jurisdiction?: string;
    /**
    * Name of the R2 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
}
export declare function pagesProjectDeploymentConfigsPreviewR2BucketsToTerraform(struct?: PagesProjectDeploymentConfigsPreviewR2Buckets | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewR2BucketsToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewR2Buckets | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewR2BucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewR2Buckets | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewR2Buckets | cdktn.IResolvable | undefined);
    private _jurisdiction?;
    get jurisdiction(): string;
    set jurisdiction(value: string);
    resetJurisdiction(): void;
    get jurisdictionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewR2BucketsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewR2Buckets;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewR2BucketsOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewServices {
    /**
    * The entrypoint to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#entrypoint PagesProject#entrypoint}
    */
    readonly entrypoint?: string;
    /**
    * The Service environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#environment PagesProject#environment}
    */
    readonly environment?: string;
    /**
    * The Service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#service PagesProject#service}
    */
    readonly service: string;
}
export declare function pagesProjectDeploymentConfigsPreviewServicesToTerraform(struct?: PagesProjectDeploymentConfigsPreviewServices | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewServicesToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewServices | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewServices | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewServices | cdktn.IResolvable | undefined);
    private _entrypoint?;
    get entrypoint(): string;
    set entrypoint(value: string);
    resetEntrypoint(): void;
    get entrypointInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewServicesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewServices;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewServicesOutputReference;
}
export interface PagesProjectDeploymentConfigsPreviewVectorizeBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#index_name PagesProject#index_name}
    */
    readonly indexName: string;
}
export declare function pagesProjectDeploymentConfigsPreviewVectorizeBindingsToTerraform(struct?: PagesProjectDeploymentConfigsPreviewVectorizeBindings | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewVectorizeBindingsToHclTerraform(struct?: PagesProjectDeploymentConfigsPreviewVectorizeBindings | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewVectorizeBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsPreviewVectorizeBindings | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreviewVectorizeBindings | cdktn.IResolvable | undefined);
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsPreviewVectorizeBindingsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewVectorizeBindings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsPreviewVectorizeBindingsOutputReference;
}
export interface PagesProjectDeploymentConfigsPreview {
    /**
    * Constellation bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#ai_bindings PagesProject#ai_bindings}
    */
    readonly aiBindings?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewAiBindings;
    } | cdktn.IResolvable;
    /**
    * Whether to always use the latest compatibility date for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#always_use_latest_compatibility_date PagesProject#always_use_latest_compatibility_date}
    */
    readonly alwaysUseLatestCompatibilityDate?: boolean | cdktn.IResolvable;
    /**
    * Analytics Engine bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#analytics_engine_datasets PagesProject#analytics_engine_datasets}
    */
    readonly analyticsEngineDatasets?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets;
    } | cdktn.IResolvable;
    /**
    * Browser bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#browsers PagesProject#browsers}
    */
    readonly browsers?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewBrowsers;
    } | cdktn.IResolvable;
    /**
    * The major version of the build image to use for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#build_image_major_version PagesProject#build_image_major_version}
    */
    readonly buildImageMajorVersion?: number;
    /**
    * Compatibility date used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#compatibility_date PagesProject#compatibility_date}
    */
    readonly compatibilityDate?: string;
    /**
    * Compatibility flags used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#compatibility_flags PagesProject#compatibility_flags}
    */
    readonly compatibilityFlags?: string[];
    /**
    * D1 databases used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#d1_databases PagesProject#d1_databases}
    */
    readonly d1Databases?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewD1Databases;
    } | cdktn.IResolvable;
    /**
    * Durable Object namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#durable_object_namespaces PagesProject#durable_object_namespaces}
    */
    readonly durableObjectNamespaces?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces;
    } | cdktn.IResolvable;
    /**
    * Environment variables used for builds and Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#env_vars PagesProject#env_vars}
    */
    readonly envVars?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewEnvVars;
    } | cdktn.IResolvable;
    /**
    * Whether to fail open when the deployment config cannot be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#fail_open PagesProject#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * Hyperdrive bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#hyperdrive_bindings PagesProject#hyperdrive_bindings}
    */
    readonly hyperdriveBindings?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewHyperdriveBindings;
    } | cdktn.IResolvable;
    /**
    * KV namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#kv_namespaces PagesProject#kv_namespaces}
    */
    readonly kvNamespaces?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewKvNamespaces;
    } | cdktn.IResolvable;
    /**
    * Limits for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#limits PagesProject#limits}
    */
    readonly limits?: PagesProjectDeploymentConfigsPreviewLimits;
    /**
    * mTLS bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#mtls_certificates PagesProject#mtls_certificates}
    */
    readonly mtlsCertificates?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewMtlsCertificates;
    } | cdktn.IResolvable;
    /**
    * Placement setting used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#placement PagesProject#placement}
    */
    readonly placement?: PagesProjectDeploymentConfigsPreviewPlacement;
    /**
    * Queue Producer bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#queue_producers PagesProject#queue_producers}
    */
    readonly queueProducers?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewQueueProducers;
    } | cdktn.IResolvable;
    /**
    * R2 buckets used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#r2_buckets PagesProject#r2_buckets}
    */
    readonly r2Buckets?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewR2Buckets;
    } | cdktn.IResolvable;
    /**
    * Services used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#services PagesProject#services}
    */
    readonly services?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewServices;
    } | cdktn.IResolvable;
    /**
    * The usage model for Pages Functions.
    * Available values: "standard", "bundled", "unbound".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#usage_model PagesProject#usage_model}
    */
    readonly usageModel?: string;
    /**
    * Vectorize bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#vectorize_bindings PagesProject#vectorize_bindings}
    */
    readonly vectorizeBindings?: {
        [key: string]: PagesProjectDeploymentConfigsPreviewVectorizeBindings;
    } | cdktn.IResolvable;
    /**
    * Hash of the Wrangler configuration used for the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#wrangler_config_hash PagesProject#wrangler_config_hash}
    */
    readonly wranglerConfigHash?: string;
}
export declare function pagesProjectDeploymentConfigsPreviewToTerraform(struct?: PagesProjectDeploymentConfigsPreview | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsPreviewToHclTerraform(struct?: PagesProjectDeploymentConfigsPreview | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsPreviewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsPreview | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsPreview | cdktn.IResolvable | undefined);
    private _aiBindings;
    get aiBindings(): PagesProjectDeploymentConfigsPreviewAiBindingsMap;
    putAiBindings(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewAiBindings;
    } | cdktn.IResolvable): void;
    resetAiBindings(): void;
    get aiBindingsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewAiBindings;
    } | undefined;
    private _alwaysUseLatestCompatibilityDate?;
    get alwaysUseLatestCompatibilityDate(): boolean | cdktn.IResolvable;
    set alwaysUseLatestCompatibilityDate(value: boolean | cdktn.IResolvable);
    resetAlwaysUseLatestCompatibilityDate(): void;
    get alwaysUseLatestCompatibilityDateInput(): boolean | cdktn.IResolvable | undefined;
    private _analyticsEngineDatasets;
    get analyticsEngineDatasets(): PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasetsMap;
    putAnalyticsEngineDatasets(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets;
    } | cdktn.IResolvable): void;
    resetAnalyticsEngineDatasets(): void;
    get analyticsEngineDatasetsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewAnalyticsEngineDatasets;
    } | undefined;
    private _browsers;
    get browsers(): PagesProjectDeploymentConfigsPreviewBrowsersMap;
    putBrowsers(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewBrowsers;
    } | cdktn.IResolvable): void;
    resetBrowsers(): void;
    get browsersInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewBrowsers;
    } | undefined;
    private _buildImageMajorVersion?;
    get buildImageMajorVersion(): number;
    set buildImageMajorVersion(value: number);
    resetBuildImageMajorVersion(): void;
    get buildImageMajorVersionInput(): number | undefined;
    private _compatibilityDate?;
    get compatibilityDate(): string;
    set compatibilityDate(value: string);
    resetCompatibilityDate(): void;
    get compatibilityDateInput(): string | undefined;
    private _compatibilityFlags?;
    get compatibilityFlags(): string[];
    set compatibilityFlags(value: string[]);
    resetCompatibilityFlags(): void;
    get compatibilityFlagsInput(): string[] | undefined;
    private _d1Databases;
    get d1Databases(): PagesProjectDeploymentConfigsPreviewD1DatabasesMap;
    putD1Databases(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewD1Databases;
    } | cdktn.IResolvable): void;
    resetD1Databases(): void;
    get d1DatabasesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewD1Databases;
    } | undefined;
    private _durableObjectNamespaces;
    get durableObjectNamespaces(): PagesProjectDeploymentConfigsPreviewDurableObjectNamespacesMap;
    putDurableObjectNamespaces(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces;
    } | cdktn.IResolvable): void;
    resetDurableObjectNamespaces(): void;
    get durableObjectNamespacesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewDurableObjectNamespaces;
    } | undefined;
    private _envVars;
    get envVars(): PagesProjectDeploymentConfigsPreviewEnvVarsMap;
    putEnvVars(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewEnvVars;
    } | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewEnvVars;
    } | undefined;
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _hyperdriveBindings;
    get hyperdriveBindings(): PagesProjectDeploymentConfigsPreviewHyperdriveBindingsMap;
    putHyperdriveBindings(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewHyperdriveBindings;
    } | cdktn.IResolvable): void;
    resetHyperdriveBindings(): void;
    get hyperdriveBindingsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewHyperdriveBindings;
    } | undefined;
    private _kvNamespaces;
    get kvNamespaces(): PagesProjectDeploymentConfigsPreviewKvNamespacesMap;
    putKvNamespaces(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewKvNamespaces;
    } | cdktn.IResolvable): void;
    resetKvNamespaces(): void;
    get kvNamespacesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewKvNamespaces;
    } | undefined;
    private _limits;
    get limits(): PagesProjectDeploymentConfigsPreviewLimitsOutputReference;
    putLimits(value: PagesProjectDeploymentConfigsPreviewLimits): void;
    resetLimits(): void;
    get limitsInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsPreviewLimits | undefined;
    private _mtlsCertificates;
    get mtlsCertificates(): PagesProjectDeploymentConfigsPreviewMtlsCertificatesMap;
    putMtlsCertificates(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewMtlsCertificates;
    } | cdktn.IResolvable): void;
    resetMtlsCertificates(): void;
    get mtlsCertificatesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewMtlsCertificates;
    } | undefined;
    private _placement;
    get placement(): PagesProjectDeploymentConfigsPreviewPlacementOutputReference;
    putPlacement(value: PagesProjectDeploymentConfigsPreviewPlacement): void;
    resetPlacement(): void;
    get placementInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsPreviewPlacement | undefined;
    private _queueProducers;
    get queueProducers(): PagesProjectDeploymentConfigsPreviewQueueProducersMap;
    putQueueProducers(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewQueueProducers;
    } | cdktn.IResolvable): void;
    resetQueueProducers(): void;
    get queueProducersInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewQueueProducers;
    } | undefined;
    private _r2Buckets;
    get r2Buckets(): PagesProjectDeploymentConfigsPreviewR2BucketsMap;
    putR2Buckets(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewR2Buckets;
    } | cdktn.IResolvable): void;
    resetR2Buckets(): void;
    get r2BucketsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewR2Buckets;
    } | undefined;
    private _services;
    get services(): PagesProjectDeploymentConfigsPreviewServicesMap;
    putServices(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewServices;
    } | cdktn.IResolvable): void;
    resetServices(): void;
    get servicesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewServices;
    } | undefined;
    private _usageModel?;
    get usageModel(): string;
    set usageModel(value: string);
    resetUsageModel(): void;
    get usageModelInput(): string | undefined;
    private _vectorizeBindings;
    get vectorizeBindings(): PagesProjectDeploymentConfigsPreviewVectorizeBindingsMap;
    putVectorizeBindings(value: {
        [key: string]: PagesProjectDeploymentConfigsPreviewVectorizeBindings;
    } | cdktn.IResolvable): void;
    resetVectorizeBindings(): void;
    get vectorizeBindingsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsPreviewVectorizeBindings;
    } | undefined;
    private _wranglerConfigHash?;
    get wranglerConfigHash(): string;
    set wranglerConfigHash(value: string);
    resetWranglerConfigHash(): void;
    get wranglerConfigHashInput(): string | undefined;
}
export interface PagesProjectDeploymentConfigsProductionAiBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#project_id PagesProject#project_id}
    */
    readonly projectId: string;
}
export declare function pagesProjectDeploymentConfigsProductionAiBindingsToTerraform(struct?: PagesProjectDeploymentConfigsProductionAiBindings | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionAiBindingsToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionAiBindings | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionAiBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionAiBindings | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionAiBindings | cdktn.IResolvable | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionAiBindingsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionAiBindings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionAiBindingsOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets {
    /**
    * Name of the dataset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#dataset PagesProject#dataset}
    */
    readonly dataset: string;
}
export declare function pagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsToTerraform(struct?: PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets | cdktn.IResolvable | undefined);
    private _dataset?;
    get dataset(): string;
    set dataset(value: string);
    get datasetInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionBrowsers {
}
export declare function pagesProjectDeploymentConfigsProductionBrowsersToTerraform(struct?: PagesProjectDeploymentConfigsProductionBrowsers | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionBrowsersToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionBrowsers | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionBrowsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionBrowsers | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionBrowsers | cdktn.IResolvable | undefined);
}
export declare class PagesProjectDeploymentConfigsProductionBrowsersMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionBrowsers;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionBrowsersOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionD1Databases {
    /**
    * UUID of the D1 database.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#id PagesProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function pagesProjectDeploymentConfigsProductionD1DatabasesToTerraform(struct?: PagesProjectDeploymentConfigsProductionD1Databases | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionD1DatabasesToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionD1Databases | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionD1DatabasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionD1Databases | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionD1Databases | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionD1DatabasesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionD1Databases;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionD1DatabasesOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionDurableObjectNamespaces {
    /**
    * ID of the Durable Object namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#namespace_id PagesProject#namespace_id}
    */
    readonly namespaceId: string;
}
export declare function pagesProjectDeploymentConfigsProductionDurableObjectNamespacesToTerraform(struct?: PagesProjectDeploymentConfigsProductionDurableObjectNamespaces | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionDurableObjectNamespacesToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionDurableObjectNamespaces | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionDurableObjectNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionDurableObjectNamespaces | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionDurableObjectNamespaces | cdktn.IResolvable | undefined);
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionDurableObjectNamespacesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionDurableObjectNamespaces;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionDurableObjectNamespacesOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionEnvVars {
    /**
    * Available values: "plain_text", "secret_text".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#type PagesProject#type}
    */
    readonly type: string;
    /**
    * Environment variable value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#value PagesProject#value}
    */
    readonly value: string;
}
export declare function pagesProjectDeploymentConfigsProductionEnvVarsToTerraform(struct?: PagesProjectDeploymentConfigsProductionEnvVars | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionEnvVarsToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionEnvVars | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionEnvVars | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionEnvVarsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionEnvVars;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionEnvVarsOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionHyperdriveBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#id PagesProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function pagesProjectDeploymentConfigsProductionHyperdriveBindingsToTerraform(struct?: PagesProjectDeploymentConfigsProductionHyperdriveBindings | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionHyperdriveBindingsToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionHyperdriveBindings | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionHyperdriveBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionHyperdriveBindings | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionHyperdriveBindings | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionHyperdriveBindingsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionHyperdriveBindings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionHyperdriveBindingsOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionKvNamespaces {
    /**
    * ID of the KV namespace.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#namespace_id PagesProject#namespace_id}
    */
    readonly namespaceId: string;
}
export declare function pagesProjectDeploymentConfigsProductionKvNamespacesToTerraform(struct?: PagesProjectDeploymentConfigsProductionKvNamespaces | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionKvNamespacesToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionKvNamespaces | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionKvNamespacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionKvNamespaces | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionKvNamespaces | cdktn.IResolvable | undefined);
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionKvNamespacesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionKvNamespaces;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionKvNamespacesOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionLimits {
    /**
    * CPU time limit in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#cpu_ms PagesProject#cpu_ms}
    */
    readonly cpuMs: number;
}
export declare function pagesProjectDeploymentConfigsProductionLimitsToTerraform(struct?: PagesProjectDeploymentConfigsProductionLimits | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionLimitsToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionLimits | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionLimits | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionLimits | cdktn.IResolvable | undefined);
    private _cpuMs?;
    get cpuMs(): number;
    set cpuMs(value: number);
    get cpuMsInput(): number | undefined;
}
export interface PagesProjectDeploymentConfigsProductionMtlsCertificates {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#certificate_id PagesProject#certificate_id}
    */
    readonly certificateId: string;
}
export declare function pagesProjectDeploymentConfigsProductionMtlsCertificatesToTerraform(struct?: PagesProjectDeploymentConfigsProductionMtlsCertificates | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionMtlsCertificatesToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionMtlsCertificates | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionMtlsCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionMtlsCertificates | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionMtlsCertificates | cdktn.IResolvable | undefined);
    private _certificateId?;
    get certificateId(): string;
    set certificateId(value: string);
    get certificateIdInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionMtlsCertificatesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionMtlsCertificates;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionMtlsCertificatesOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionPlacement {
    /**
    * Placement mode.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#mode PagesProject#mode}
    */
    readonly mode?: string;
}
export declare function pagesProjectDeploymentConfigsProductionPlacementToTerraform(struct?: PagesProjectDeploymentConfigsProductionPlacement | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionPlacementToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionPlacement | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionPlacement | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionPlacement | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface PagesProjectDeploymentConfigsProductionQueueProducers {
    /**
    * Name of the Queue.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
}
export declare function pagesProjectDeploymentConfigsProductionQueueProducersToTerraform(struct?: PagesProjectDeploymentConfigsProductionQueueProducers | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionQueueProducersToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionQueueProducers | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionQueueProducersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionQueueProducers | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionQueueProducers | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionQueueProducersMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionQueueProducers;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionQueueProducersOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionR2Buckets {
    /**
    * Jurisdiction of the R2 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#jurisdiction PagesProject#jurisdiction}
    */
    readonly jurisdiction?: string;
    /**
    * Name of the R2 bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#name PagesProject#name}
    */
    readonly name: string;
}
export declare function pagesProjectDeploymentConfigsProductionR2BucketsToTerraform(struct?: PagesProjectDeploymentConfigsProductionR2Buckets | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionR2BucketsToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionR2Buckets | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionR2BucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionR2Buckets | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionR2Buckets | cdktn.IResolvable | undefined);
    private _jurisdiction?;
    get jurisdiction(): string;
    set jurisdiction(value: string);
    resetJurisdiction(): void;
    get jurisdictionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionR2BucketsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionR2Buckets;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionR2BucketsOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionServices {
    /**
    * The entrypoint to bind to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#entrypoint PagesProject#entrypoint}
    */
    readonly entrypoint?: string;
    /**
    * The Service environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#environment PagesProject#environment}
    */
    readonly environment?: string;
    /**
    * The Service name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#service PagesProject#service}
    */
    readonly service: string;
}
export declare function pagesProjectDeploymentConfigsProductionServicesToTerraform(struct?: PagesProjectDeploymentConfigsProductionServices | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionServicesToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionServices | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionServices | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionServices | cdktn.IResolvable | undefined);
    private _entrypoint?;
    get entrypoint(): string;
    set entrypoint(value: string);
    resetEntrypoint(): void;
    get entrypointInput(): string | undefined;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionServicesMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionServices;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionServicesOutputReference;
}
export interface PagesProjectDeploymentConfigsProductionVectorizeBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#index_name PagesProject#index_name}
    */
    readonly indexName: string;
}
export declare function pagesProjectDeploymentConfigsProductionVectorizeBindingsToTerraform(struct?: PagesProjectDeploymentConfigsProductionVectorizeBindings | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionVectorizeBindingsToHclTerraform(struct?: PagesProjectDeploymentConfigsProductionVectorizeBindings | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionVectorizeBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectDeploymentConfigsProductionVectorizeBindings | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProductionVectorizeBindings | cdktn.IResolvable | undefined);
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
}
export declare class PagesProjectDeploymentConfigsProductionVectorizeBindingsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: PagesProjectDeploymentConfigsProductionVectorizeBindings;
    } | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectDeploymentConfigsProductionVectorizeBindingsOutputReference;
}
export interface PagesProjectDeploymentConfigsProduction {
    /**
    * Constellation bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#ai_bindings PagesProject#ai_bindings}
    */
    readonly aiBindings?: {
        [key: string]: PagesProjectDeploymentConfigsProductionAiBindings;
    } | cdktn.IResolvable;
    /**
    * Whether to always use the latest compatibility date for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#always_use_latest_compatibility_date PagesProject#always_use_latest_compatibility_date}
    */
    readonly alwaysUseLatestCompatibilityDate?: boolean | cdktn.IResolvable;
    /**
    * Analytics Engine bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#analytics_engine_datasets PagesProject#analytics_engine_datasets}
    */
    readonly analyticsEngineDatasets?: {
        [key: string]: PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets;
    } | cdktn.IResolvable;
    /**
    * Browser bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#browsers PagesProject#browsers}
    */
    readonly browsers?: {
        [key: string]: PagesProjectDeploymentConfigsProductionBrowsers;
    } | cdktn.IResolvable;
    /**
    * The major version of the build image to use for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#build_image_major_version PagesProject#build_image_major_version}
    */
    readonly buildImageMajorVersion?: number;
    /**
    * Compatibility date used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#compatibility_date PagesProject#compatibility_date}
    */
    readonly compatibilityDate?: string;
    /**
    * Compatibility flags used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#compatibility_flags PagesProject#compatibility_flags}
    */
    readonly compatibilityFlags?: string[];
    /**
    * D1 databases used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#d1_databases PagesProject#d1_databases}
    */
    readonly d1Databases?: {
        [key: string]: PagesProjectDeploymentConfigsProductionD1Databases;
    } | cdktn.IResolvable;
    /**
    * Durable Object namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#durable_object_namespaces PagesProject#durable_object_namespaces}
    */
    readonly durableObjectNamespaces?: {
        [key: string]: PagesProjectDeploymentConfigsProductionDurableObjectNamespaces;
    } | cdktn.IResolvable;
    /**
    * Environment variables used for builds and Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#env_vars PagesProject#env_vars}
    */
    readonly envVars?: {
        [key: string]: PagesProjectDeploymentConfigsProductionEnvVars;
    } | cdktn.IResolvable;
    /**
    * Whether to fail open when the deployment config cannot be applied.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#fail_open PagesProject#fail_open}
    */
    readonly failOpen?: boolean | cdktn.IResolvable;
    /**
    * Hyperdrive bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#hyperdrive_bindings PagesProject#hyperdrive_bindings}
    */
    readonly hyperdriveBindings?: {
        [key: string]: PagesProjectDeploymentConfigsProductionHyperdriveBindings;
    } | cdktn.IResolvable;
    /**
    * KV namespaces used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#kv_namespaces PagesProject#kv_namespaces}
    */
    readonly kvNamespaces?: {
        [key: string]: PagesProjectDeploymentConfigsProductionKvNamespaces;
    } | cdktn.IResolvable;
    /**
    * Limits for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#limits PagesProject#limits}
    */
    readonly limits?: PagesProjectDeploymentConfigsProductionLimits;
    /**
    * mTLS bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#mtls_certificates PagesProject#mtls_certificates}
    */
    readonly mtlsCertificates?: {
        [key: string]: PagesProjectDeploymentConfigsProductionMtlsCertificates;
    } | cdktn.IResolvable;
    /**
    * Placement setting used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#placement PagesProject#placement}
    */
    readonly placement?: PagesProjectDeploymentConfigsProductionPlacement;
    /**
    * Queue Producer bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#queue_producers PagesProject#queue_producers}
    */
    readonly queueProducers?: {
        [key: string]: PagesProjectDeploymentConfigsProductionQueueProducers;
    } | cdktn.IResolvable;
    /**
    * R2 buckets used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#r2_buckets PagesProject#r2_buckets}
    */
    readonly r2Buckets?: {
        [key: string]: PagesProjectDeploymentConfigsProductionR2Buckets;
    } | cdktn.IResolvable;
    /**
    * Services used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#services PagesProject#services}
    */
    readonly services?: {
        [key: string]: PagesProjectDeploymentConfigsProductionServices;
    } | cdktn.IResolvable;
    /**
    * The usage model for Pages Functions.
    * Available values: "standard", "bundled", "unbound".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#usage_model PagesProject#usage_model}
    */
    readonly usageModel?: string;
    /**
    * Vectorize bindings used for Pages Functions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#vectorize_bindings PagesProject#vectorize_bindings}
    */
    readonly vectorizeBindings?: {
        [key: string]: PagesProjectDeploymentConfigsProductionVectorizeBindings;
    } | cdktn.IResolvable;
    /**
    * Hash of the Wrangler configuration used for the deployment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#wrangler_config_hash PagesProject#wrangler_config_hash}
    */
    readonly wranglerConfigHash?: string;
}
export declare function pagesProjectDeploymentConfigsProductionToTerraform(struct?: PagesProjectDeploymentConfigsProduction | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsProductionToHclTerraform(struct?: PagesProjectDeploymentConfigsProduction | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsProductionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigsProduction | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigsProduction | cdktn.IResolvable | undefined);
    private _aiBindings;
    get aiBindings(): PagesProjectDeploymentConfigsProductionAiBindingsMap;
    putAiBindings(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionAiBindings;
    } | cdktn.IResolvable): void;
    resetAiBindings(): void;
    get aiBindingsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionAiBindings;
    } | undefined;
    private _alwaysUseLatestCompatibilityDate?;
    get alwaysUseLatestCompatibilityDate(): boolean | cdktn.IResolvable;
    set alwaysUseLatestCompatibilityDate(value: boolean | cdktn.IResolvable);
    resetAlwaysUseLatestCompatibilityDate(): void;
    get alwaysUseLatestCompatibilityDateInput(): boolean | cdktn.IResolvable | undefined;
    private _analyticsEngineDatasets;
    get analyticsEngineDatasets(): PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasetsMap;
    putAnalyticsEngineDatasets(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets;
    } | cdktn.IResolvable): void;
    resetAnalyticsEngineDatasets(): void;
    get analyticsEngineDatasetsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionAnalyticsEngineDatasets;
    } | undefined;
    private _browsers;
    get browsers(): PagesProjectDeploymentConfigsProductionBrowsersMap;
    putBrowsers(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionBrowsers;
    } | cdktn.IResolvable): void;
    resetBrowsers(): void;
    get browsersInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionBrowsers;
    } | undefined;
    private _buildImageMajorVersion?;
    get buildImageMajorVersion(): number;
    set buildImageMajorVersion(value: number);
    resetBuildImageMajorVersion(): void;
    get buildImageMajorVersionInput(): number | undefined;
    private _compatibilityDate?;
    get compatibilityDate(): string;
    set compatibilityDate(value: string);
    resetCompatibilityDate(): void;
    get compatibilityDateInput(): string | undefined;
    private _compatibilityFlags?;
    get compatibilityFlags(): string[];
    set compatibilityFlags(value: string[]);
    resetCompatibilityFlags(): void;
    get compatibilityFlagsInput(): string[] | undefined;
    private _d1Databases;
    get d1Databases(): PagesProjectDeploymentConfigsProductionD1DatabasesMap;
    putD1Databases(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionD1Databases;
    } | cdktn.IResolvable): void;
    resetD1Databases(): void;
    get d1DatabasesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionD1Databases;
    } | undefined;
    private _durableObjectNamespaces;
    get durableObjectNamespaces(): PagesProjectDeploymentConfigsProductionDurableObjectNamespacesMap;
    putDurableObjectNamespaces(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionDurableObjectNamespaces;
    } | cdktn.IResolvable): void;
    resetDurableObjectNamespaces(): void;
    get durableObjectNamespacesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionDurableObjectNamespaces;
    } | undefined;
    private _envVars;
    get envVars(): PagesProjectDeploymentConfigsProductionEnvVarsMap;
    putEnvVars(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionEnvVars;
    } | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionEnvVars;
    } | undefined;
    private _failOpen?;
    get failOpen(): boolean | cdktn.IResolvable;
    set failOpen(value: boolean | cdktn.IResolvable);
    resetFailOpen(): void;
    get failOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _hyperdriveBindings;
    get hyperdriveBindings(): PagesProjectDeploymentConfigsProductionHyperdriveBindingsMap;
    putHyperdriveBindings(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionHyperdriveBindings;
    } | cdktn.IResolvable): void;
    resetHyperdriveBindings(): void;
    get hyperdriveBindingsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionHyperdriveBindings;
    } | undefined;
    private _kvNamespaces;
    get kvNamespaces(): PagesProjectDeploymentConfigsProductionKvNamespacesMap;
    putKvNamespaces(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionKvNamespaces;
    } | cdktn.IResolvable): void;
    resetKvNamespaces(): void;
    get kvNamespacesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionKvNamespaces;
    } | undefined;
    private _limits;
    get limits(): PagesProjectDeploymentConfigsProductionLimitsOutputReference;
    putLimits(value: PagesProjectDeploymentConfigsProductionLimits): void;
    resetLimits(): void;
    get limitsInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsProductionLimits | undefined;
    private _mtlsCertificates;
    get mtlsCertificates(): PagesProjectDeploymentConfigsProductionMtlsCertificatesMap;
    putMtlsCertificates(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionMtlsCertificates;
    } | cdktn.IResolvable): void;
    resetMtlsCertificates(): void;
    get mtlsCertificatesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionMtlsCertificates;
    } | undefined;
    private _placement;
    get placement(): PagesProjectDeploymentConfigsProductionPlacementOutputReference;
    putPlacement(value: PagesProjectDeploymentConfigsProductionPlacement): void;
    resetPlacement(): void;
    get placementInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsProductionPlacement | undefined;
    private _queueProducers;
    get queueProducers(): PagesProjectDeploymentConfigsProductionQueueProducersMap;
    putQueueProducers(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionQueueProducers;
    } | cdktn.IResolvable): void;
    resetQueueProducers(): void;
    get queueProducersInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionQueueProducers;
    } | undefined;
    private _r2Buckets;
    get r2Buckets(): PagesProjectDeploymentConfigsProductionR2BucketsMap;
    putR2Buckets(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionR2Buckets;
    } | cdktn.IResolvable): void;
    resetR2Buckets(): void;
    get r2BucketsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionR2Buckets;
    } | undefined;
    private _services;
    get services(): PagesProjectDeploymentConfigsProductionServicesMap;
    putServices(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionServices;
    } | cdktn.IResolvable): void;
    resetServices(): void;
    get servicesInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionServices;
    } | undefined;
    private _usageModel?;
    get usageModel(): string;
    set usageModel(value: string);
    resetUsageModel(): void;
    get usageModelInput(): string | undefined;
    private _vectorizeBindings;
    get vectorizeBindings(): PagesProjectDeploymentConfigsProductionVectorizeBindingsMap;
    putVectorizeBindings(value: {
        [key: string]: PagesProjectDeploymentConfigsProductionVectorizeBindings;
    } | cdktn.IResolvable): void;
    resetVectorizeBindings(): void;
    get vectorizeBindingsInput(): cdktn.IResolvable | {
        [key: string]: PagesProjectDeploymentConfigsProductionVectorizeBindings;
    } | undefined;
    private _wranglerConfigHash?;
    get wranglerConfigHash(): string;
    set wranglerConfigHash(value: string);
    resetWranglerConfigHash(): void;
    get wranglerConfigHashInput(): string | undefined;
}
export interface PagesProjectDeploymentConfigs {
    /**
    * Configs for preview deploys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#preview PagesProject#preview}
    */
    readonly preview?: PagesProjectDeploymentConfigsPreview;
    /**
    * Configs for production deploys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#production PagesProject#production}
    */
    readonly production?: PagesProjectDeploymentConfigsProduction;
}
export declare function pagesProjectDeploymentConfigsToTerraform(struct?: PagesProjectDeploymentConfigs | cdktn.IResolvable): any;
export declare function pagesProjectDeploymentConfigsToHclTerraform(struct?: PagesProjectDeploymentConfigs | cdktn.IResolvable): any;
export declare class PagesProjectDeploymentConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectDeploymentConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectDeploymentConfigs | cdktn.IResolvable | undefined);
    private _preview;
    get preview(): PagesProjectDeploymentConfigsPreviewOutputReference;
    putPreview(value: PagesProjectDeploymentConfigsPreview): void;
    resetPreview(): void;
    get previewInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsPreview | undefined;
    private _production;
    get production(): PagesProjectDeploymentConfigsProductionOutputReference;
    putProduction(value: PagesProjectDeploymentConfigsProduction): void;
    resetProduction(): void;
    get productionInput(): cdktn.IResolvable | PagesProjectDeploymentConfigsProduction | undefined;
}
export interface PagesProjectLatestDeploymentBuildConfig {
}
export declare function pagesProjectLatestDeploymentBuildConfigToTerraform(struct?: PagesProjectLatestDeploymentBuildConfig): any;
export declare function pagesProjectLatestDeploymentBuildConfigToHclTerraform(struct?: PagesProjectLatestDeploymentBuildConfig): any;
export declare class PagesProjectLatestDeploymentBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectLatestDeploymentBuildConfig | undefined;
    set internalValue(value: PagesProjectLatestDeploymentBuildConfig | undefined);
    get buildCaching(): cdktn.IResolvable;
    get buildCommand(): string;
    get destinationDir(): string;
    get rootDir(): string;
    get webAnalyticsTag(): string;
    get webAnalyticsToken(): string;
}
export interface PagesProjectLatestDeploymentDeploymentTriggerMetadata {
}
export declare function pagesProjectLatestDeploymentDeploymentTriggerMetadataToTerraform(struct?: PagesProjectLatestDeploymentDeploymentTriggerMetadata): any;
export declare function pagesProjectLatestDeploymentDeploymentTriggerMetadataToHclTerraform(struct?: PagesProjectLatestDeploymentDeploymentTriggerMetadata): any;
export declare class PagesProjectLatestDeploymentDeploymentTriggerMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectLatestDeploymentDeploymentTriggerMetadata | undefined;
    set internalValue(value: PagesProjectLatestDeploymentDeploymentTriggerMetadata | undefined);
    get branch(): string;
    get commitDirty(): cdktn.IResolvable;
    get commitHash(): string;
    get commitMessage(): string;
}
export interface PagesProjectLatestDeploymentDeploymentTrigger {
}
export declare function pagesProjectLatestDeploymentDeploymentTriggerToTerraform(struct?: PagesProjectLatestDeploymentDeploymentTrigger): any;
export declare function pagesProjectLatestDeploymentDeploymentTriggerToHclTerraform(struct?: PagesProjectLatestDeploymentDeploymentTrigger): any;
export declare class PagesProjectLatestDeploymentDeploymentTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectLatestDeploymentDeploymentTrigger | undefined;
    set internalValue(value: PagesProjectLatestDeploymentDeploymentTrigger | undefined);
    private _metadata;
    get metadata(): PagesProjectLatestDeploymentDeploymentTriggerMetadataOutputReference;
    get type(): string;
}
export interface PagesProjectLatestDeploymentEnvVars {
}
export declare function pagesProjectLatestDeploymentEnvVarsToTerraform(struct?: PagesProjectLatestDeploymentEnvVars): any;
export declare function pagesProjectLatestDeploymentEnvVarsToHclTerraform(struct?: PagesProjectLatestDeploymentEnvVars): any;
export declare class PagesProjectLatestDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): PagesProjectLatestDeploymentEnvVars | undefined;
    set internalValue(value: PagesProjectLatestDeploymentEnvVars | undefined);
    get type(): string;
    get value(): string;
}
export declare class PagesProjectLatestDeploymentEnvVarsMap extends cdktn.ComplexMap {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): PagesProjectLatestDeploymentEnvVarsOutputReference;
}
export interface PagesProjectLatestDeploymentLatestStage {
}
export declare function pagesProjectLatestDeploymentLatestStageToTerraform(struct?: PagesProjectLatestDeploymentLatestStage): any;
export declare function pagesProjectLatestDeploymentLatestStageToHclTerraform(struct?: PagesProjectLatestDeploymentLatestStage): any;
export declare class PagesProjectLatestDeploymentLatestStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectLatestDeploymentLatestStage | undefined;
    set internalValue(value: PagesProjectLatestDeploymentLatestStage | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export interface PagesProjectLatestDeploymentSourceConfig {
}
export declare function pagesProjectLatestDeploymentSourceConfigToTerraform(struct?: PagesProjectLatestDeploymentSourceConfig): any;
export declare function pagesProjectLatestDeploymentSourceConfigToHclTerraform(struct?: PagesProjectLatestDeploymentSourceConfig): any;
export declare class PagesProjectLatestDeploymentSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectLatestDeploymentSourceConfig | undefined;
    set internalValue(value: PagesProjectLatestDeploymentSourceConfig | undefined);
    get deploymentsEnabled(): cdktn.IResolvable;
    get owner(): string;
    get ownerId(): string;
    get pathExcludes(): string[];
    get pathIncludes(): string[];
    get prCommentsEnabled(): cdktn.IResolvable;
    get previewBranchExcludes(): string[];
    get previewBranchIncludes(): string[];
    get previewDeploymentSetting(): string;
    get productionBranch(): string;
    get productionDeploymentsEnabled(): cdktn.IResolvable;
    get repoId(): string;
    get repoName(): string;
}
export interface PagesProjectLatestDeploymentSource {
}
export declare function pagesProjectLatestDeploymentSourceToTerraform(struct?: PagesProjectLatestDeploymentSource): any;
export declare function pagesProjectLatestDeploymentSourceToHclTerraform(struct?: PagesProjectLatestDeploymentSource): any;
export declare class PagesProjectLatestDeploymentSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectLatestDeploymentSource | undefined;
    set internalValue(value: PagesProjectLatestDeploymentSource | undefined);
    private _config;
    get config(): PagesProjectLatestDeploymentSourceConfigOutputReference;
    get type(): string;
}
export interface PagesProjectLatestDeploymentStages {
}
export declare function pagesProjectLatestDeploymentStagesToTerraform(struct?: PagesProjectLatestDeploymentStages): any;
export declare function pagesProjectLatestDeploymentStagesToHclTerraform(struct?: PagesProjectLatestDeploymentStages): any;
export declare class PagesProjectLatestDeploymentStagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PagesProjectLatestDeploymentStages | undefined;
    set internalValue(value: PagesProjectLatestDeploymentStages | undefined);
    get endedOn(): string;
    get name(): string;
    get startedOn(): string;
    get status(): string;
}
export declare class PagesProjectLatestDeploymentStagesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PagesProjectLatestDeploymentStagesOutputReference;
}
export interface PagesProjectLatestDeployment {
}
export declare function pagesProjectLatestDeploymentToTerraform(struct?: PagesProjectLatestDeployment): any;
export declare function pagesProjectLatestDeploymentToHclTerraform(struct?: PagesProjectLatestDeployment): any;
export declare class PagesProjectLatestDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectLatestDeployment | undefined;
    set internalValue(value: PagesProjectLatestDeployment | undefined);
    get aliases(): string[];
    private _buildConfig;
    get buildConfig(): PagesProjectLatestDeploymentBuildConfigOutputReference;
    get createdOn(): string;
    private _deploymentTrigger;
    get deploymentTrigger(): PagesProjectLatestDeploymentDeploymentTriggerOutputReference;
    private _envVars;
    get envVars(): PagesProjectLatestDeploymentEnvVarsMap;
    get environment(): string;
    get id(): string;
    get isSkipped(): cdktn.IResolvable;
    private _latestStage;
    get latestStage(): PagesProjectLatestDeploymentLatestStageOutputReference;
    get modifiedOn(): string;
    get projectId(): string;
    get projectName(): string;
    get shortId(): string;
    private _source;
    get source(): PagesProjectLatestDeploymentSourceOutputReference;
    private _stages;
    get stages(): PagesProjectLatestDeploymentStagesList;
    get url(): string;
    get usesFunctions(): cdktn.IResolvable;
}
export interface PagesProjectSourceConfig {
    /**
    * Whether to enable automatic deployments when pushing to the source repository.
    * When disabled, no deployments (production or preview) will be triggered automatically.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#deployments_enabled PagesProject#deployments_enabled}
    */
    readonly deploymentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The owner of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#owner PagesProject#owner}
    */
    readonly owner?: string;
    /**
    * The owner ID of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#owner_id PagesProject#owner_id}
    */
    readonly ownerId?: string;
    /**
    * A list of paths that should be excluded from triggering a preview deployment. Wildcard syntax (`*`) is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#path_excludes PagesProject#path_excludes}
    */
    readonly pathExcludes?: string[];
    /**
    * A list of paths that should be watched to trigger a preview deployment. Wildcard syntax (`*`) is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#path_includes PagesProject#path_includes}
    */
    readonly pathIncludes?: string[];
    /**
    * Whether to enable PR comments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#pr_comments_enabled PagesProject#pr_comments_enabled}
    */
    readonly prCommentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * A list of branches that should not trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#preview_branch_excludes PagesProject#preview_branch_excludes}
    */
    readonly previewBranchExcludes?: string[];
    /**
    * A list of branches that should trigger a preview deployment. Wildcard syntax (`*`) is supported. Must be used with `preview_deployment_setting` set to `custom`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#preview_branch_includes PagesProject#preview_branch_includes}
    */
    readonly previewBranchIncludes?: string[];
    /**
    * Controls whether commits to preview branches trigger a preview deployment.
    * Available values: "all", "none", "custom".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#preview_deployment_setting PagesProject#preview_deployment_setting}
    */
    readonly previewDeploymentSetting?: string;
    /**
    * The production branch of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#production_branch PagesProject#production_branch}
    */
    readonly productionBranch?: string;
    /**
    * Whether to trigger a production deployment on commits to the production branch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#production_deployments_enabled PagesProject#production_deployments_enabled}
    */
    readonly productionDeploymentsEnabled?: boolean | cdktn.IResolvable;
    /**
    * The ID of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#repo_id PagesProject#repo_id}
    */
    readonly repoId?: string;
    /**
    * The name of the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#repo_name PagesProject#repo_name}
    */
    readonly repoName?: string;
}
export declare function pagesProjectSourceConfigToTerraform(struct?: PagesProjectSourceConfig | cdktn.IResolvable): any;
export declare function pagesProjectSourceConfigToHclTerraform(struct?: PagesProjectSourceConfig | cdktn.IResolvable): any;
export declare class PagesProjectSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectSourceConfig | cdktn.IResolvable | undefined);
    private _deploymentsEnabled?;
    get deploymentsEnabled(): boolean | cdktn.IResolvable;
    set deploymentsEnabled(value: boolean | cdktn.IResolvable);
    resetDeploymentsEnabled(): void;
    get deploymentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _ownerId?;
    get ownerId(): string;
    set ownerId(value: string);
    resetOwnerId(): void;
    get ownerIdInput(): string | undefined;
    private _pathExcludes?;
    get pathExcludes(): string[];
    set pathExcludes(value: string[]);
    resetPathExcludes(): void;
    get pathExcludesInput(): string[] | undefined;
    private _pathIncludes?;
    get pathIncludes(): string[];
    set pathIncludes(value: string[]);
    resetPathIncludes(): void;
    get pathIncludesInput(): string[] | undefined;
    private _prCommentsEnabled?;
    get prCommentsEnabled(): boolean | cdktn.IResolvable;
    set prCommentsEnabled(value: boolean | cdktn.IResolvable);
    resetPrCommentsEnabled(): void;
    get prCommentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _previewBranchExcludes?;
    get previewBranchExcludes(): string[];
    set previewBranchExcludes(value: string[]);
    resetPreviewBranchExcludes(): void;
    get previewBranchExcludesInput(): string[] | undefined;
    private _previewBranchIncludes?;
    get previewBranchIncludes(): string[];
    set previewBranchIncludes(value: string[]);
    resetPreviewBranchIncludes(): void;
    get previewBranchIncludesInput(): string[] | undefined;
    private _previewDeploymentSetting?;
    get previewDeploymentSetting(): string;
    set previewDeploymentSetting(value: string);
    resetPreviewDeploymentSetting(): void;
    get previewDeploymentSettingInput(): string | undefined;
    private _productionBranch?;
    get productionBranch(): string;
    set productionBranch(value: string);
    resetProductionBranch(): void;
    get productionBranchInput(): string | undefined;
    private _productionDeploymentsEnabled?;
    get productionDeploymentsEnabled(): boolean | cdktn.IResolvable;
    set productionDeploymentsEnabled(value: boolean | cdktn.IResolvable);
    resetProductionDeploymentsEnabled(): void;
    get productionDeploymentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _repoId?;
    get repoId(): string;
    set repoId(value: string);
    resetRepoId(): void;
    get repoIdInput(): string | undefined;
    private _repoName?;
    get repoName(): string;
    set repoName(value: string);
    resetRepoName(): void;
    get repoNameInput(): string | undefined;
}
export interface PagesProjectSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#config PagesProject#config}
    */
    readonly config: PagesProjectSourceConfig;
    /**
    * The source control management provider.
    * Available values: "github", "gitlab".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#type PagesProject#type}
    */
    readonly type: string;
}
export declare function pagesProjectSourceToTerraform(struct?: PagesProjectSource | cdktn.IResolvable): any;
export declare function pagesProjectSourceToHclTerraform(struct?: PagesProjectSource | cdktn.IResolvable): any;
export declare class PagesProjectSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PagesProjectSource | cdktn.IResolvable | undefined;
    set internalValue(value: PagesProjectSource | cdktn.IResolvable | undefined);
    private _config;
    get config(): PagesProjectSourceConfigOutputReference;
    putConfig(value: PagesProjectSourceConfig): void;
    get configInput(): cdktn.IResolvable | PagesProjectSourceConfig | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project cloudflare_pages_project}
*/
export declare class PagesProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_pages_project";
    /**
    * Generates CDKTN code for importing a PagesProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PagesProject to import
    * @param importFromId The id of the existing PagesProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PagesProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/pages_project cloudflare_pages_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PagesProjectConfig
    */
    constructor(scope: Construct, id: string, config: PagesProjectConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _buildConfig;
    get buildConfig(): PagesProjectBuildConfigOutputReference;
    putBuildConfig(value: PagesProjectBuildConfig): void;
    resetBuildConfig(): void;
    get buildConfigInput(): cdktn.IResolvable | PagesProjectBuildConfig | undefined;
    private _canonicalDeployment;
    get canonicalDeployment(): PagesProjectCanonicalDeploymentOutputReference;
    get createdOn(): string;
    private _deploymentConfigs;
    get deploymentConfigs(): PagesProjectDeploymentConfigsOutputReference;
    putDeploymentConfigs(value: PagesProjectDeploymentConfigs): void;
    resetDeploymentConfigs(): void;
    get deploymentConfigsInput(): cdktn.IResolvable | PagesProjectDeploymentConfigs | undefined;
    get domains(): string[];
    get framework(): string;
    get frameworkVersion(): string;
    get id(): string;
    private _latestDeployment;
    get latestDeployment(): PagesProjectLatestDeploymentOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get previewScriptName(): string;
    private _productionBranch?;
    get productionBranch(): string;
    set productionBranch(value: string);
    get productionBranchInput(): string | undefined;
    get productionScriptName(): string;
    private _source;
    get source(): PagesProjectSourceOutputReference;
    putSource(value: PagesProjectSource): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | PagesProjectSource | undefined;
    get subdomain(): string;
    get usesFunctions(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
