/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareEmailSecurityDomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#account_id DataCloudflareEmailSecurityDomains#account_id}
    */
    readonly accountId: string;
    /**
    * Currently active delivery mode to filter by.
    * Available values: "DIRECT", "BCC", "JOURNAL", "API", "RETRO_SCAN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#active_delivery_mode DataCloudflareEmailSecurityDomains#active_delivery_mode}
    */
    readonly activeDeliveryMode?: string;
    /**
    * Delivery mode to filter by.
    * Available values: "DIRECT", "BCC", "JOURNAL", "API", "RETRO_SCAN".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#allowed_delivery_mode DataCloudflareEmailSecurityDomains#allowed_delivery_mode}
    */
    readonly allowedDeliveryMode?: string;
    /**
    * The sorting direction.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#direction DataCloudflareEmailSecurityDomains#direction}
    */
    readonly direction?: string;
    /**
    * Domain names to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#domain DataCloudflareEmailSecurityDomains#domain}
    */
    readonly domain?: string[];
    /**
    * Integration ID to filter by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#integration_id DataCloudflareEmailSecurityDomains#integration_id}
    */
    readonly integrationId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#max_items DataCloudflareEmailSecurityDomains#max_items}
    */
    readonly maxItems?: number;
    /**
    * Field to sort by.
    * Available values: "domain", "created_at".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#order DataCloudflareEmailSecurityDomains#order}
    */
    readonly order?: string;
    /**
    * Search term for filtering records. Behavior may change.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#search DataCloudflareEmailSecurityDomains#search}
    */
    readonly search?: string;
    /**
    * Filters response to domains with the provided status.
    * Available values: "PENDING", "ACTIVE", "FAILED", "TIMEOUT".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#status DataCloudflareEmailSecurityDomains#status}
    */
    readonly status?: string;
}
export interface DataCloudflareEmailSecurityDomainsResultAuthorization {
}
export declare function dataCloudflareEmailSecurityDomainsResultAuthorizationToTerraform(struct?: DataCloudflareEmailSecurityDomainsResultAuthorization): any;
export declare function dataCloudflareEmailSecurityDomainsResultAuthorizationToHclTerraform(struct?: DataCloudflareEmailSecurityDomainsResultAuthorization): any;
export declare class DataCloudflareEmailSecurityDomainsResultAuthorizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityDomainsResultAuthorization | undefined;
    set internalValue(value: DataCloudflareEmailSecurityDomainsResultAuthorization | undefined);
    get authorized(): cdktn.IResolvable;
    get statusMessage(): string;
    get timestamp(): string;
}
export interface DataCloudflareEmailSecurityDomainsResultEmailsProcessed {
}
export declare function dataCloudflareEmailSecurityDomainsResultEmailsProcessedToTerraform(struct?: DataCloudflareEmailSecurityDomainsResultEmailsProcessed): any;
export declare function dataCloudflareEmailSecurityDomainsResultEmailsProcessedToHclTerraform(struct?: DataCloudflareEmailSecurityDomainsResultEmailsProcessed): any;
export declare class DataCloudflareEmailSecurityDomainsResultEmailsProcessedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareEmailSecurityDomainsResultEmailsProcessed | undefined;
    set internalValue(value: DataCloudflareEmailSecurityDomainsResultEmailsProcessed | undefined);
    get timestamp(): string;
    get totalEmailsProcessed(): number;
    get totalEmailsProcessedPrevious(): number;
}
export interface DataCloudflareEmailSecurityDomainsResult {
}
export declare function dataCloudflareEmailSecurityDomainsResultToTerraform(struct?: DataCloudflareEmailSecurityDomainsResult): any;
export declare function dataCloudflareEmailSecurityDomainsResultToHclTerraform(struct?: DataCloudflareEmailSecurityDomainsResult): any;
export declare class DataCloudflareEmailSecurityDomainsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareEmailSecurityDomainsResult | undefined;
    set internalValue(value: DataCloudflareEmailSecurityDomainsResult | undefined);
    get allowedDeliveryModes(): string[];
    private _authorization;
    get authorization(): DataCloudflareEmailSecurityDomainsResultAuthorizationOutputReference;
    get createdAt(): string;
    get dmarcStatus(): string;
    get domain(): string;
    get dropDispositions(): string[];
    private _emailsProcessed;
    get emailsProcessed(): DataCloudflareEmailSecurityDomainsResultEmailsProcessedOutputReference;
    get folder(): string;
    get id(): string;
    get inboxProvider(): string;
    get integrationId(): string;
    get ipRestrictions(): string[];
    get lastModified(): string;
    get lookbackHops(): number;
    get modifiedAt(): string;
    get o365TenantId(): string;
    get regions(): string[];
    get requireTlsInbound(): cdktn.IResolvable;
    get requireTlsOutbound(): cdktn.IResolvable;
    get spfStatus(): string;
    get status(): string;
    get transport(): string;
}
export declare class DataCloudflareEmailSecurityDomainsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareEmailSecurityDomainsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains cloudflare_email_security_domains}
*/
export declare class DataCloudflareEmailSecurityDomains extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_email_security_domains";
    /**
    * Generates CDKTN code for importing a DataCloudflareEmailSecurityDomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareEmailSecurityDomains to import
    * @param importFromId The id of the existing DataCloudflareEmailSecurityDomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareEmailSecurityDomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.26.0/docs/data-sources/email_security_domains cloudflare_email_security_domains} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareEmailSecurityDomainsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareEmailSecurityDomainsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _activeDeliveryMode?;
    get activeDeliveryMode(): string;
    set activeDeliveryMode(value: string);
    resetActiveDeliveryMode(): void;
    get activeDeliveryModeInput(): string | undefined;
    private _allowedDeliveryMode?;
    get allowedDeliveryMode(): string;
    set allowedDeliveryMode(value: string);
    resetAllowedDeliveryMode(): void;
    get allowedDeliveryModeInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _domain?;
    get domain(): string[];
    set domain(value: string[]);
    resetDomain(): void;
    get domainInput(): string[] | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    resetIntegrationId(): void;
    get integrationIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _result;
    get result(): DataCloudflareEmailSecurityDomainsResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
