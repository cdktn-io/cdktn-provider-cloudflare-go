/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustResourceLibraryApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#account_id DataCloudflareZeroTrustResourceLibraryApplication#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#filter DataCloudflareZeroTrustResourceLibraryApplication#filter}
    */
    readonly filter?: DataCloudflareZeroTrustResourceLibraryApplicationFilter;
    /**
    * Returns the application ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#id DataCloudflareZeroTrustResourceLibraryApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: number;
}
export interface DataCloudflareZeroTrustResourceLibraryApplicationFilter {
    /**
    * Return only the listed properties on each application, as a comma-separated list.
    * Use this to keep responses small when you only need part of each application — for
    * example populating a picker with `fields=id,name` instead of downloading every
    * hostname and IP subnet.
    *
    * Omit this parameter to receive the full application object.
    *
    * `id` is always returned.
    *
    * Selectable properties: `id`, `name`, `human_id`, `version`, `hostnames`,
    * `support_domains`, `ip_subnets`, `port_protocols`, `supported`, `gen_ai_score`,
    * `application_confidence_score`, `created_at`, `updated_at`, `review_status`.
    *
    * Unknown or empty property names return `400`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#fields DataCloudflareZeroTrustResourceLibraryApplication#fields}
    */
    readonly fields?: string;
    /**
    * Filter applications using key:value format. Supported filter keys:
    * - name: Filter by application name (e.g., name:HR)
    * - id: Filter by application ID (e.g., id:498)
    * - human_id: Filter by human-readable ID (e.g., human_id:HR)
    * - hostname: Filter by hostname or support domain (e.g., hostname:portal.example.com)
    * - source: Filter by application source name (e.g., source:cloudflare)
    * - ip_subnet: Filter by IP subnet using CIDR containment — returns applications where any stored subnet contains the search value (e.g., ip_subnet:10.0.1.5/32 matches apps with 10.0.0.0/16)
    * - category_id: Filter by category ID (e.g., category_id:12).
    * - category_name: Filter by category name (e.g., category_name:HR).
    * - supported: Filter by supported Cloudflare product (e.g., supported:ACCESS). Values: GATEWAY, ACCESS, CASB.
    * - review_status: Filter by the account's Gateway review status. Values: approved, unapproved, in_review, unreviewed.
    * .
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#filter DataCloudflareZeroTrustResourceLibraryApplication#filter}
    */
    readonly filter?: string;
    /**
    * Limit of number of results to return (max 250).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#limit DataCloudflareZeroTrustResourceLibraryApplication#limit}
    */
    readonly limit?: number;
    /**
    * Offset of results to return.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#offset DataCloudflareZeroTrustResourceLibraryApplication#offset}
    */
    readonly offset?: number;
    /**
    * Order results using field:direction format. Supported fields are name, id, human_id,
    * category_id, application_type, application_confidence_score, and gen_ai_score.
    * Supported directions are asc and desc. Ignored when search is provided; results are
    * ranked by relevance instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#order_by DataCloudflareZeroTrustResourceLibraryApplication#order_by}
    */
    readonly orderBy?: string;
    /**
    * Fuzzy search across application name and hostnames. Results are ranked by relevance. Must be between 2 and 200 characters. Can be combined with filter parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#search DataCloudflareZeroTrustResourceLibraryApplication#search}
    */
    readonly search?: string;
}
export declare function dataCloudflareZeroTrustResourceLibraryApplicationFilterToTerraform(struct?: DataCloudflareZeroTrustResourceLibraryApplicationFilter | cdktn.IResolvable): any;
export declare function dataCloudflareZeroTrustResourceLibraryApplicationFilterToHclTerraform(struct?: DataCloudflareZeroTrustResourceLibraryApplicationFilter | cdktn.IResolvable): any;
export declare class DataCloudflareZeroTrustResourceLibraryApplicationFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustResourceLibraryApplicationFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareZeroTrustResourceLibraryApplicationFilter | cdktn.IResolvable | undefined);
    private _fields?;
    get fields(): string;
    set fields(value: string);
    resetFields(): void;
    get fieldsInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _limit?;
    get limit(): number;
    set limit(value: number);
    resetLimit(): void;
    get limitInput(): number | undefined;
    private _offset?;
    get offset(): number;
    set offset(value: number);
    resetOffset(): void;
    get offsetInput(): number | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application cloudflare_zero_trust_resource_library_application}
*/
export declare class DataCloudflareZeroTrustResourceLibraryApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_resource_library_application";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustResourceLibraryApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustResourceLibraryApplication to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustResourceLibraryApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustResourceLibraryApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.27.0/docs/data-sources/zero_trust_resource_library_application cloudflare_zero_trust_resource_library_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustResourceLibraryApplicationConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustResourceLibraryApplicationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get applicationConfidenceScore(): number;
    get applicationScoreComposition(): string;
    get applicationSource(): string;
    get applicationType(): string;
    get applicationTypeDescription(): string;
    get categoryId(): number;
    get createdAt(): string;
    private _filter;
    get filter(): DataCloudflareZeroTrustResourceLibraryApplicationFilterOutputReference;
    putFilter(value: DataCloudflareZeroTrustResourceLibraryApplicationFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareZeroTrustResourceLibraryApplicationFilter | undefined;
    get genAiScore(): number;
    get hostnames(): string[];
    get humanId(): string;
    private _id?;
    get id(): number;
    set id(value: number);
    resetId(): void;
    get idInput(): number | undefined;
    get ipSubnets(): string[];
    get name(): string;
    get portProtocols(): string[];
    get supportDomains(): string[];
    get supported(): string[];
    get updatedAt(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
