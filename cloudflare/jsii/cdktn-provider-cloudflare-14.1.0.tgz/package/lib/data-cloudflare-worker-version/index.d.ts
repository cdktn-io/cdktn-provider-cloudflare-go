/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareWorkerVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/worker_version#account_id DataCloudflareWorkerVersion#account_id}
    */
    readonly accountId: string;
    /**
    * Whether to include the `modules` property of the version in the response, which contains code and sourcemap content and may add several megabytes to the response size.
    * Available values: "modules".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/worker_version#include DataCloudflareWorkerVersion#include}
    */
    readonly include?: string;
    /**
    * Identifier for the version, which can be ID or the literal "latest" to operate on the most recently created version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/worker_version#version_id DataCloudflareWorkerVersion#version_id}
    */
    readonly versionId: string;
    /**
    * Identifier for the Worker, which can be ID or name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/worker_version#worker_id DataCloudflareWorkerVersion#worker_id}
    */
    readonly workerId: string;
}
export interface DataCloudflareWorkerVersionAnnotations {
}
export declare function dataCloudflareWorkerVersionAnnotationsToTerraform(struct?: DataCloudflareWorkerVersionAnnotations): any;
export declare function dataCloudflareWorkerVersionAnnotationsToHclTerraform(struct?: DataCloudflareWorkerVersionAnnotations): any;
export declare class DataCloudflareWorkerVersionAnnotationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionAnnotations | undefined;
    set internalValue(value: DataCloudflareWorkerVersionAnnotations | undefined);
    get workersMessage(): string;
    get workersTag(): string;
    get workersTriggeredBy(): string;
}
export interface DataCloudflareWorkerVersionAssetsConfig {
}
export declare function dataCloudflareWorkerVersionAssetsConfigToTerraform(struct?: DataCloudflareWorkerVersionAssetsConfig): any;
export declare function dataCloudflareWorkerVersionAssetsConfigToHclTerraform(struct?: DataCloudflareWorkerVersionAssetsConfig): any;
export declare class DataCloudflareWorkerVersionAssetsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionAssetsConfig | undefined;
    set internalValue(value: DataCloudflareWorkerVersionAssetsConfig | undefined);
    get htmlHandling(): string;
    get notFoundHandling(): string;
    get runWorkerFirst(): string[];
}
export interface DataCloudflareWorkerVersionAssets {
}
export declare function dataCloudflareWorkerVersionAssetsToTerraform(struct?: DataCloudflareWorkerVersionAssets): any;
export declare function dataCloudflareWorkerVersionAssetsToHclTerraform(struct?: DataCloudflareWorkerVersionAssets): any;
export declare class DataCloudflareWorkerVersionAssetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionAssets | undefined;
    set internalValue(value: DataCloudflareWorkerVersionAssets | undefined);
    private _config;
    get config(): DataCloudflareWorkerVersionAssetsConfigOutputReference;
    get jwt(): string;
}
export interface DataCloudflareWorkerVersionBindingsOutboundParams {
}
export declare function dataCloudflareWorkerVersionBindingsOutboundParamsToTerraform(struct?: DataCloudflareWorkerVersionBindingsOutboundParams): any;
export declare function dataCloudflareWorkerVersionBindingsOutboundParamsToHclTerraform(struct?: DataCloudflareWorkerVersionBindingsOutboundParams): any;
export declare class DataCloudflareWorkerVersionBindingsOutboundParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionBindingsOutboundParams | undefined;
    set internalValue(value: DataCloudflareWorkerVersionBindingsOutboundParams | undefined);
    get name(): string;
}
export declare class DataCloudflareWorkerVersionBindingsOutboundParamsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionBindingsOutboundParamsOutputReference;
}
export interface DataCloudflareWorkerVersionBindingsOutboundWorker {
}
export declare function dataCloudflareWorkerVersionBindingsOutboundWorkerToTerraform(struct?: DataCloudflareWorkerVersionBindingsOutboundWorker): any;
export declare function dataCloudflareWorkerVersionBindingsOutboundWorkerToHclTerraform(struct?: DataCloudflareWorkerVersionBindingsOutboundWorker): any;
export declare class DataCloudflareWorkerVersionBindingsOutboundWorkerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionBindingsOutboundWorker | undefined;
    set internalValue(value: DataCloudflareWorkerVersionBindingsOutboundWorker | undefined);
    get entrypoint(): string;
    get environment(): string;
    get service(): string;
}
export interface DataCloudflareWorkerVersionBindingsOutbound {
}
export declare function dataCloudflareWorkerVersionBindingsOutboundToTerraform(struct?: DataCloudflareWorkerVersionBindingsOutbound): any;
export declare function dataCloudflareWorkerVersionBindingsOutboundToHclTerraform(struct?: DataCloudflareWorkerVersionBindingsOutbound): any;
export declare class DataCloudflareWorkerVersionBindingsOutboundOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionBindingsOutbound | undefined;
    set internalValue(value: DataCloudflareWorkerVersionBindingsOutbound | undefined);
    private _params;
    get params(): DataCloudflareWorkerVersionBindingsOutboundParamsList;
    private _worker;
    get worker(): DataCloudflareWorkerVersionBindingsOutboundWorkerOutputReference;
}
export interface DataCloudflareWorkerVersionBindingsSimple {
}
export declare function dataCloudflareWorkerVersionBindingsSimpleToTerraform(struct?: DataCloudflareWorkerVersionBindingsSimple): any;
export declare function dataCloudflareWorkerVersionBindingsSimpleToHclTerraform(struct?: DataCloudflareWorkerVersionBindingsSimple): any;
export declare class DataCloudflareWorkerVersionBindingsSimpleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionBindingsSimple | undefined;
    set internalValue(value: DataCloudflareWorkerVersionBindingsSimple | undefined);
    get limit(): number;
    get period(): number;
}
export interface DataCloudflareWorkerVersionBindings {
}
export declare function dataCloudflareWorkerVersionBindingsToTerraform(struct?: DataCloudflareWorkerVersionBindings): any;
export declare function dataCloudflareWorkerVersionBindingsToHclTerraform(struct?: DataCloudflareWorkerVersionBindings): any;
export declare class DataCloudflareWorkerVersionBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionBindings | undefined;
    set internalValue(value: DataCloudflareWorkerVersionBindings | undefined);
    get algorithm(): string;
    get allowedDestinationAddresses(): string[];
    get allowedSenderAddresses(): string[];
    get bucketName(): string;
    get certificateId(): string;
    get className(): string;
    get dataset(): string;
    get destinationAddress(): string;
    get environment(): string;
    get format(): string;
    get id(): string;
    get indexName(): string;
    get json(): string;
    get jurisdiction(): string;
    get keyBase64(): string;
    get keyJwk(): string;
    get name(): string;
    get namespace(): string;
    get namespaceId(): string;
    get oldName(): string;
    private _outbound;
    get outbound(): DataCloudflareWorkerVersionBindingsOutboundOutputReference;
    get part(): string;
    get pipeline(): string;
    get queueName(): string;
    get scriptName(): string;
    get secretName(): string;
    get service(): string;
    private _simple;
    get simple(): DataCloudflareWorkerVersionBindingsSimpleOutputReference;
    get storeId(): string;
    get text(): string;
    get type(): string;
    get usages(): string[];
    get versionId(): string;
    get workflowName(): string;
}
export declare class DataCloudflareWorkerVersionBindingsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionBindingsOutputReference;
}
export interface DataCloudflareWorkerVersionLimits {
}
export declare function dataCloudflareWorkerVersionLimitsToTerraform(struct?: DataCloudflareWorkerVersionLimits): any;
export declare function dataCloudflareWorkerVersionLimitsToHclTerraform(struct?: DataCloudflareWorkerVersionLimits): any;
export declare class DataCloudflareWorkerVersionLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionLimits | undefined;
    set internalValue(value: DataCloudflareWorkerVersionLimits | undefined);
    get cpuMs(): number;
}
export interface DataCloudflareWorkerVersionMigrationsRenamedClasses {
}
export declare function dataCloudflareWorkerVersionMigrationsRenamedClassesToTerraform(struct?: DataCloudflareWorkerVersionMigrationsRenamedClasses): any;
export declare function dataCloudflareWorkerVersionMigrationsRenamedClassesToHclTerraform(struct?: DataCloudflareWorkerVersionMigrationsRenamedClasses): any;
export declare class DataCloudflareWorkerVersionMigrationsRenamedClassesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionMigrationsRenamedClasses | undefined;
    set internalValue(value: DataCloudflareWorkerVersionMigrationsRenamedClasses | undefined);
    get from(): string;
    get to(): string;
}
export declare class DataCloudflareWorkerVersionMigrationsRenamedClassesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionMigrationsRenamedClassesOutputReference;
}
export interface DataCloudflareWorkerVersionMigrationsStepsRenamedClasses {
}
export declare function dataCloudflareWorkerVersionMigrationsStepsRenamedClassesToTerraform(struct?: DataCloudflareWorkerVersionMigrationsStepsRenamedClasses): any;
export declare function dataCloudflareWorkerVersionMigrationsStepsRenamedClassesToHclTerraform(struct?: DataCloudflareWorkerVersionMigrationsStepsRenamedClasses): any;
export declare class DataCloudflareWorkerVersionMigrationsStepsRenamedClassesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionMigrationsStepsRenamedClasses | undefined;
    set internalValue(value: DataCloudflareWorkerVersionMigrationsStepsRenamedClasses | undefined);
    get from(): string;
    get to(): string;
}
export declare class DataCloudflareWorkerVersionMigrationsStepsRenamedClassesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionMigrationsStepsRenamedClassesOutputReference;
}
export interface DataCloudflareWorkerVersionMigrationsStepsTransferredClasses {
}
export declare function dataCloudflareWorkerVersionMigrationsStepsTransferredClassesToTerraform(struct?: DataCloudflareWorkerVersionMigrationsStepsTransferredClasses): any;
export declare function dataCloudflareWorkerVersionMigrationsStepsTransferredClassesToHclTerraform(struct?: DataCloudflareWorkerVersionMigrationsStepsTransferredClasses): any;
export declare class DataCloudflareWorkerVersionMigrationsStepsTransferredClassesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionMigrationsStepsTransferredClasses | undefined;
    set internalValue(value: DataCloudflareWorkerVersionMigrationsStepsTransferredClasses | undefined);
    get from(): string;
    get fromScript(): string;
    get to(): string;
}
export declare class DataCloudflareWorkerVersionMigrationsStepsTransferredClassesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionMigrationsStepsTransferredClassesOutputReference;
}
export interface DataCloudflareWorkerVersionMigrationsSteps {
}
export declare function dataCloudflareWorkerVersionMigrationsStepsToTerraform(struct?: DataCloudflareWorkerVersionMigrationsSteps): any;
export declare function dataCloudflareWorkerVersionMigrationsStepsToHclTerraform(struct?: DataCloudflareWorkerVersionMigrationsSteps): any;
export declare class DataCloudflareWorkerVersionMigrationsStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionMigrationsSteps | undefined;
    set internalValue(value: DataCloudflareWorkerVersionMigrationsSteps | undefined);
    get deletedClasses(): string[];
    get newClasses(): string[];
    get newSqliteClasses(): string[];
    private _renamedClasses;
    get renamedClasses(): DataCloudflareWorkerVersionMigrationsStepsRenamedClassesList;
    private _transferredClasses;
    get transferredClasses(): DataCloudflareWorkerVersionMigrationsStepsTransferredClassesList;
}
export declare class DataCloudflareWorkerVersionMigrationsStepsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionMigrationsStepsOutputReference;
}
export interface DataCloudflareWorkerVersionMigrationsTransferredClasses {
}
export declare function dataCloudflareWorkerVersionMigrationsTransferredClassesToTerraform(struct?: DataCloudflareWorkerVersionMigrationsTransferredClasses): any;
export declare function dataCloudflareWorkerVersionMigrationsTransferredClassesToHclTerraform(struct?: DataCloudflareWorkerVersionMigrationsTransferredClasses): any;
export declare class DataCloudflareWorkerVersionMigrationsTransferredClassesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionMigrationsTransferredClasses | undefined;
    set internalValue(value: DataCloudflareWorkerVersionMigrationsTransferredClasses | undefined);
    get from(): string;
    get fromScript(): string;
    get to(): string;
}
export declare class DataCloudflareWorkerVersionMigrationsTransferredClassesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionMigrationsTransferredClassesOutputReference;
}
export interface DataCloudflareWorkerVersionMigrations {
}
export declare function dataCloudflareWorkerVersionMigrationsToTerraform(struct?: DataCloudflareWorkerVersionMigrations): any;
export declare function dataCloudflareWorkerVersionMigrationsToHclTerraform(struct?: DataCloudflareWorkerVersionMigrations): any;
export declare class DataCloudflareWorkerVersionMigrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionMigrations | undefined;
    set internalValue(value: DataCloudflareWorkerVersionMigrations | undefined);
    get deletedClasses(): string[];
    get newClasses(): string[];
    get newSqliteClasses(): string[];
    get newTag(): string;
    get oldTag(): string;
    private _renamedClasses;
    get renamedClasses(): DataCloudflareWorkerVersionMigrationsRenamedClassesList;
    private _steps;
    get steps(): DataCloudflareWorkerVersionMigrationsStepsList;
    private _transferredClasses;
    get transferredClasses(): DataCloudflareWorkerVersionMigrationsTransferredClassesList;
}
export interface DataCloudflareWorkerVersionModules {
}
export declare function dataCloudflareWorkerVersionModulesToTerraform(struct?: DataCloudflareWorkerVersionModules): any;
export declare function dataCloudflareWorkerVersionModulesToHclTerraform(struct?: DataCloudflareWorkerVersionModules): any;
export declare class DataCloudflareWorkerVersionModulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionModules | undefined;
    set internalValue(value: DataCloudflareWorkerVersionModules | undefined);
    get contentBase64(): string;
    get contentType(): string;
    get name(): string;
}
export declare class DataCloudflareWorkerVersionModulesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionModulesOutputReference;
}
export interface DataCloudflareWorkerVersionPlacementTarget {
}
export declare function dataCloudflareWorkerVersionPlacementTargetToTerraform(struct?: DataCloudflareWorkerVersionPlacementTarget): any;
export declare function dataCloudflareWorkerVersionPlacementTargetToHclTerraform(struct?: DataCloudflareWorkerVersionPlacementTarget): any;
export declare class DataCloudflareWorkerVersionPlacementTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareWorkerVersionPlacementTarget | undefined;
    set internalValue(value: DataCloudflareWorkerVersionPlacementTarget | undefined);
    get host(): string;
    get hostname(): string;
    get region(): string;
}
export declare class DataCloudflareWorkerVersionPlacementTargetList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareWorkerVersionPlacementTargetOutputReference;
}
export interface DataCloudflareWorkerVersionPlacement {
}
export declare function dataCloudflareWorkerVersionPlacementToTerraform(struct?: DataCloudflareWorkerVersionPlacement): any;
export declare function dataCloudflareWorkerVersionPlacementToHclTerraform(struct?: DataCloudflareWorkerVersionPlacement): any;
export declare class DataCloudflareWorkerVersionPlacementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareWorkerVersionPlacement | undefined;
    set internalValue(value: DataCloudflareWorkerVersionPlacement | undefined);
    get host(): string;
    get hostname(): string;
    get mode(): string;
    get region(): string;
    private _target;
    get target(): DataCloudflareWorkerVersionPlacementTargetList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/worker_version cloudflare_worker_version}
*/
export declare class DataCloudflareWorkerVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_worker_version";
    /**
    * Generates CDKTN code for importing a DataCloudflareWorkerVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareWorkerVersion to import
    * @param importFromId The id of the existing DataCloudflareWorkerVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/worker_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareWorkerVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/data-sources/worker_version cloudflare_worker_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareWorkerVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareWorkerVersionConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _annotations;
    get annotations(): DataCloudflareWorkerVersionAnnotationsOutputReference;
    private _assets;
    get assets(): DataCloudflareWorkerVersionAssetsOutputReference;
    private _bindings;
    get bindings(): DataCloudflareWorkerVersionBindingsList;
    get compatibilityDate(): string;
    get compatibilityFlags(): string[];
    get createdOn(): string;
    get id(): string;
    private _include?;
    get include(): string;
    set include(value: string);
    resetInclude(): void;
    get includeInput(): string | undefined;
    private _limits;
    get limits(): DataCloudflareWorkerVersionLimitsOutputReference;
    get mainModule(): string;
    get mainScriptBase64(): string;
    private _migrations;
    get migrations(): DataCloudflareWorkerVersionMigrationsOutputReference;
    private _modules;
    get modules(): DataCloudflareWorkerVersionModulesList;
    get number(): number;
    private _placement;
    get placement(): DataCloudflareWorkerVersionPlacementOutputReference;
    get source(): string;
    get startupTimeMs(): number;
    get usageModel(): string;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    get versionIdInput(): string | undefined;
    private _workerId?;
    get workerId(): string;
    set workerId(value: string);
    get workerIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
