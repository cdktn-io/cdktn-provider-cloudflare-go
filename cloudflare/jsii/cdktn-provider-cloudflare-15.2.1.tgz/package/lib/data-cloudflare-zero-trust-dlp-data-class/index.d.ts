/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpDataClassConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_data_class#account_id DataCloudflareZeroTrustDlpDataClass#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_data_class#data_class_id DataCloudflareZeroTrustDlpDataClass#data_class_id}
    */
    readonly dataClassId: string;
}
export interface DataCloudflareZeroTrustDlpDataClassSensitivityLevels {
}
export declare function dataCloudflareZeroTrustDlpDataClassSensitivityLevelsToTerraform(struct?: DataCloudflareZeroTrustDlpDataClassSensitivityLevels): any;
export declare function dataCloudflareZeroTrustDlpDataClassSensitivityLevelsToHclTerraform(struct?: DataCloudflareZeroTrustDlpDataClassSensitivityLevels): any;
export declare class DataCloudflareZeroTrustDlpDataClassSensitivityLevelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpDataClassSensitivityLevels | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpDataClassSensitivityLevels | undefined);
    get groupId(): string;
    get levelId(): string;
}
export declare class DataCloudflareZeroTrustDlpDataClassSensitivityLevelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpDataClassSensitivityLevelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_data_class cloudflare_zero_trust_dlp_data_class}
*/
export declare class DataCloudflareZeroTrustDlpDataClass extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_data_class";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpDataClass resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpDataClass to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpDataClass that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_data_class#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpDataClass to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/zero_trust_dlp_data_class cloudflare_zero_trust_dlp_data_class} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpDataClassConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpDataClassConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get createdAt(): string;
    private _dataClassId?;
    get dataClassId(): string;
    set dataClassId(value: string);
    get dataClassIdInput(): string | undefined;
    get dataTags(): string[];
    get description(): string;
    get expression(): string;
    get id(): string;
    get name(): string;
    private _sensitivityLevels;
    get sensitivityLevels(): DataCloudflareZeroTrustDlpDataClassSensitivityLevelsList;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
