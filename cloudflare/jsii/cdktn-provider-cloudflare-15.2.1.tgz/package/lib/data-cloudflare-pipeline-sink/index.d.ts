/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflarePipelineSinkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies the public ID of the account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink#account_id DataCloudflarePipelineSink#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink#filter DataCloudflarePipelineSink#filter}
    */
    readonly filter?: DataCloudflarePipelineSinkFilter;
    /**
    * Specifies the publid ID of the sink.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink#sink_id DataCloudflarePipelineSink#sink_id}
    */
    readonly sinkId?: string;
}
export interface DataCloudflarePipelineSinkConfigFileNaming {
}
export declare function dataCloudflarePipelineSinkConfigFileNamingToTerraform(struct?: DataCloudflarePipelineSinkConfigFileNaming): any;
export declare function dataCloudflarePipelineSinkConfigFileNamingToHclTerraform(struct?: DataCloudflarePipelineSinkConfigFileNaming): any;
export declare class DataCloudflarePipelineSinkConfigFileNamingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkConfigFileNaming | undefined;
    set internalValue(value: DataCloudflarePipelineSinkConfigFileNaming | undefined);
    get prefix(): string;
    get strategy(): string;
    get suffix(): string;
}
export interface DataCloudflarePipelineSinkConfigPartitioning {
}
export declare function dataCloudflarePipelineSinkConfigPartitioningToTerraform(struct?: DataCloudflarePipelineSinkConfigPartitioning): any;
export declare function dataCloudflarePipelineSinkConfigPartitioningToHclTerraform(struct?: DataCloudflarePipelineSinkConfigPartitioning): any;
export declare class DataCloudflarePipelineSinkConfigPartitioningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkConfigPartitioning | undefined;
    set internalValue(value: DataCloudflarePipelineSinkConfigPartitioning | undefined);
    get timePattern(): string;
}
export interface DataCloudflarePipelineSinkConfigRollingPolicy {
}
export declare function dataCloudflarePipelineSinkConfigRollingPolicyToTerraform(struct?: DataCloudflarePipelineSinkConfigRollingPolicy): any;
export declare function dataCloudflarePipelineSinkConfigRollingPolicyToHclTerraform(struct?: DataCloudflarePipelineSinkConfigRollingPolicy): any;
export declare class DataCloudflarePipelineSinkConfigRollingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkConfigRollingPolicy | undefined;
    set internalValue(value: DataCloudflarePipelineSinkConfigRollingPolicy | undefined);
    get fileSizeBytes(): number;
    get inactivitySeconds(): number;
    get intervalSeconds(): number;
}
export interface DataCloudflarePipelineSinkConfigA {
}
export declare function dataCloudflarePipelineSinkConfigAToTerraform(struct?: DataCloudflarePipelineSinkConfigA): any;
export declare function dataCloudflarePipelineSinkConfigAToHclTerraform(struct?: DataCloudflarePipelineSinkConfigA): any;
export declare class DataCloudflarePipelineSinkConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkConfigA | undefined;
    set internalValue(value: DataCloudflarePipelineSinkConfigA | undefined);
    get accountId(): string;
    get bucket(): string;
    private _fileNaming;
    get fileNaming(): DataCloudflarePipelineSinkConfigFileNamingOutputReference;
    get jurisdiction(): string;
    get namespace(): string;
    private _partitioning;
    get partitioning(): DataCloudflarePipelineSinkConfigPartitioningOutputReference;
    get path(): string;
    private _rollingPolicy;
    get rollingPolicy(): DataCloudflarePipelineSinkConfigRollingPolicyOutputReference;
    get tableName(): string;
}
export interface DataCloudflarePipelineSinkFilter {
    /**
    * Filters sinks by name (case-insensitive substring).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink#name DataCloudflarePipelineSink#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink#pipeline_id DataCloudflarePipelineSink#pipeline_id}
    */
    readonly pipelineId?: string;
}
export declare function dataCloudflarePipelineSinkFilterToTerraform(struct?: DataCloudflarePipelineSinkFilter | cdktn.IResolvable): any;
export declare function dataCloudflarePipelineSinkFilterToHclTerraform(struct?: DataCloudflarePipelineSinkFilter | cdktn.IResolvable): any;
export declare class DataCloudflarePipelineSinkFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflarePipelineSinkFilter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    resetPipelineId(): void;
    get pipelineIdInput(): string | undefined;
}
export interface DataCloudflarePipelineSinkFormat {
}
export declare function dataCloudflarePipelineSinkFormatToTerraform(struct?: DataCloudflarePipelineSinkFormat): any;
export declare function dataCloudflarePipelineSinkFormatToHclTerraform(struct?: DataCloudflarePipelineSinkFormat): any;
export declare class DataCloudflarePipelineSinkFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkFormat | undefined;
    set internalValue(value: DataCloudflarePipelineSinkFormat | undefined);
    get compression(): string;
    get decimalEncoding(): string;
    get rowGroupBytes(): number;
    get timestampFormat(): string;
    get type(): string;
    get unstructured(): cdktn.IResolvable;
}
export interface DataCloudflarePipelineSinkSchemaFields {
}
export declare function dataCloudflarePipelineSinkSchemaFieldsToTerraform(struct?: DataCloudflarePipelineSinkSchemaFields): any;
export declare function dataCloudflarePipelineSinkSchemaFieldsToHclTerraform(struct?: DataCloudflarePipelineSinkSchemaFields): any;
export declare class DataCloudflarePipelineSinkSchemaFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePipelineSinkSchemaFields | undefined;
    set internalValue(value: DataCloudflarePipelineSinkSchemaFields | undefined);
    get metadataKey(): string;
    get name(): string;
    get required(): cdktn.IResolvable;
    get sqlName(): string;
    get type(): string;
    get unit(): string;
}
export declare class DataCloudflarePipelineSinkSchemaFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePipelineSinkSchemaFieldsOutputReference;
}
export interface DataCloudflarePipelineSinkSchemaFormat {
}
export declare function dataCloudflarePipelineSinkSchemaFormatToTerraform(struct?: DataCloudflarePipelineSinkSchemaFormat): any;
export declare function dataCloudflarePipelineSinkSchemaFormatToHclTerraform(struct?: DataCloudflarePipelineSinkSchemaFormat): any;
export declare class DataCloudflarePipelineSinkSchemaFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkSchemaFormat | undefined;
    set internalValue(value: DataCloudflarePipelineSinkSchemaFormat | undefined);
    get compression(): string;
    get decimalEncoding(): string;
    get rowGroupBytes(): number;
    get timestampFormat(): string;
    get type(): string;
    get unstructured(): cdktn.IResolvable;
}
export interface DataCloudflarePipelineSinkSchema {
}
export declare function dataCloudflarePipelineSinkSchemaToTerraform(struct?: DataCloudflarePipelineSinkSchema): any;
export declare function dataCloudflarePipelineSinkSchemaToHclTerraform(struct?: DataCloudflarePipelineSinkSchema): any;
export declare class DataCloudflarePipelineSinkSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflarePipelineSinkSchema | undefined;
    set internalValue(value: DataCloudflarePipelineSinkSchema | undefined);
    private _fields;
    get fields(): DataCloudflarePipelineSinkSchemaFieldsList;
    private _format;
    get format(): DataCloudflarePipelineSinkSchemaFormatOutputReference;
    get inferred(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink cloudflare_pipeline_sink}
*/
export declare class DataCloudflarePipelineSink extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_pipeline_sink";
    /**
    * Generates CDKTN code for importing a DataCloudflarePipelineSink resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflarePipelineSink to import
    * @param importFromId The id of the existing DataCloudflarePipelineSink that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflarePipelineSink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/pipeline_sink cloudflare_pipeline_sink} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflarePipelineSinkConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflarePipelineSinkConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _config;
    get config(): DataCloudflarePipelineSinkConfigAOutputReference;
    get createdAt(): string;
    private _filter;
    get filter(): DataCloudflarePipelineSinkFilterOutputReference;
    putFilter(value: DataCloudflarePipelineSinkFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflarePipelineSinkFilter | undefined;
    private _format;
    get format(): DataCloudflarePipelineSinkFormatOutputReference;
    get id(): string;
    get modifiedAt(): string;
    get name(): string;
    private _schema;
    get schema(): DataCloudflarePipelineSinkSchemaOutputReference;
    private _sinkId?;
    get sinkId(): string;
    set sinkId(value: string);
    resetSinkId(): void;
    get sinkIdInput(): string | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
