/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomCsrConfig extends cdktn.TerraformMetaArguments {
    /**
    * The Account ID to use for this endpoint. Mutually exclusive with the Zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#account_id CustomCsr#account_id}
    */
    readonly accountId?: string;
    /**
    * The common name (domain) for the CSR. Must be at most 64 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#common_name CustomCsr#common_name}
    */
    readonly commonName: string;
    /**
    * Two-letter ISO 3166-1 alpha-2 country code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#country CustomCsr#country}
    */
    readonly country: string;
    /**
    * Optional description for the CSR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#description CustomCsr#description}
    */
    readonly description?: string;
    /**
    * Key algorithm to use for the CSR. Defaults to rsa2048 if not specified.
    * Available values: "rsa2048", "p256v1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#key_type CustomCsr#key_type}
    */
    readonly keyType?: string;
    /**
    * City or locality name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#locality CustomCsr#locality}
    */
    readonly locality: string;
    /**
    * Human-readable name for the CSR.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#name CustomCsr#name}
    */
    readonly name?: string;
    /**
    * Organization name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#organization CustomCsr#organization}
    */
    readonly organization: string;
    /**
    * Organizational unit name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#organizational_unit CustomCsr#organizational_unit}
    */
    readonly organizationalUnit?: string;
    /**
    * Subject Alternative Names for the CSR. At least one SAN is required.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#sans CustomCsr#sans}
    */
    readonly sans: string[];
    /**
    * State or province name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#state CustomCsr#state}
    */
    readonly state: string;
    /**
    * The Zone ID to use for this endpoint. Mutually exclusive with the Account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#zone_id CustomCsr#zone_id}
    */
    readonly zoneId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr cloudflare_custom_csr}
*/
export declare class CustomCsr extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_custom_csr";
    /**
    * Generates CDKTN code for importing a CustomCsr resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomCsr to import
    * @param importFromId The id of the existing CustomCsr that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomCsr to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/resources/custom_csr cloudflare_custom_csr} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomCsrConfig
    */
    constructor(scope: Construct, id: string, config: CustomCsrConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get accountTag(): string;
    private _commonName?;
    get commonName(): string;
    set commonName(value: string);
    get commonNameInput(): string | undefined;
    private _country?;
    get country(): string;
    set country(value: string);
    get countryInput(): string | undefined;
    get createdAt(): string;
    get csr(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _keyType?;
    get keyType(): string;
    set keyType(value: string);
    resetKeyType(): void;
    get keyTypeInput(): string | undefined;
    private _locality?;
    get locality(): string;
    set locality(value: string);
    get localityInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _organizationalUnit?;
    get organizationalUnit(): string;
    set organizationalUnit(value: string);
    resetOrganizationalUnit(): void;
    get organizationalUnitInput(): string | undefined;
    private _sans?;
    get sans(): string[];
    set sans(value: string[]);
    get sansInput(): string[] | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
