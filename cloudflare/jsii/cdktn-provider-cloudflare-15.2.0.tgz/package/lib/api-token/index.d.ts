/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#condition ApiToken#condition}
    */
    readonly condition?: ApiTokenCondition;
    /**
    * The expiration time on or after which the JWT MUST NOT be accepted for processing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#expires_on ApiToken#expires_on}
    */
    readonly expiresOn?: string;
    /**
    * Token name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#name ApiToken#name}
    */
    readonly name: string;
    /**
    * The time before which the token MUST NOT be accepted for processing.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#not_before ApiToken#not_before}
    */
    readonly notBefore?: string;
    /**
    * Set of access policies assigned to the token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#policies ApiToken#policies}
    */
    readonly policies: ApiTokenPolicies[] | cdktn.IResolvable;
    /**
    * Status of the token.
    * Available values: "active", "disabled", "expired".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#status ApiToken#status}
    */
    readonly status?: string;
}
export interface ApiTokenConditionRequestIp {
    /**
    * List of IPv4/IPv6 CIDR addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#in ApiToken#in}
    */
    readonly in?: string[];
    /**
    * List of IPv4/IPv6 CIDR addresses.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#not_in ApiToken#not_in}
    */
    readonly notIn?: string[];
}
export declare function apiTokenConditionRequestIpToTerraform(struct?: ApiTokenConditionRequestIp | cdktn.IResolvable): any;
export declare function apiTokenConditionRequestIpToHclTerraform(struct?: ApiTokenConditionRequestIp | cdktn.IResolvable): any;
export declare class ApiTokenConditionRequestIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiTokenConditionRequestIp | cdktn.IResolvable | undefined;
    set internalValue(value: ApiTokenConditionRequestIp | cdktn.IResolvable | undefined);
    private _in?;
    get in(): string[];
    set in(value: string[]);
    resetIn(): void;
    get inInput(): string[] | undefined;
    private _notIn?;
    get notIn(): string[];
    set notIn(value: string[]);
    resetNotIn(): void;
    get notInInput(): string[] | undefined;
}
export interface ApiTokenCondition {
    /**
    * Client IP restrictions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#request_ip ApiToken#request_ip}
    */
    readonly requestIp?: ApiTokenConditionRequestIp;
}
export declare function apiTokenConditionToTerraform(struct?: ApiTokenCondition | cdktn.IResolvable): any;
export declare function apiTokenConditionToHclTerraform(struct?: ApiTokenCondition | cdktn.IResolvable): any;
export declare class ApiTokenConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiTokenCondition | cdktn.IResolvable | undefined;
    set internalValue(value: ApiTokenCondition | cdktn.IResolvable | undefined);
    private _requestIp;
    get requestIp(): ApiTokenConditionRequestIpOutputReference;
    putRequestIp(value: ApiTokenConditionRequestIp): void;
    resetRequestIp(): void;
    get requestIpInput(): cdktn.IResolvable | ApiTokenConditionRequestIp | undefined;
}
export interface ApiTokenPoliciesPermissionGroups {
    /**
    * Identifier of the permission group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#id ApiToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function apiTokenPoliciesPermissionGroupsToTerraform(struct?: ApiTokenPoliciesPermissionGroups | cdktn.IResolvable): any;
export declare function apiTokenPoliciesPermissionGroupsToHclTerraform(struct?: ApiTokenPoliciesPermissionGroups | cdktn.IResolvable): any;
export declare class ApiTokenPoliciesPermissionGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiTokenPoliciesPermissionGroups | cdktn.IResolvable | undefined;
    set internalValue(value: ApiTokenPoliciesPermissionGroups | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class ApiTokenPoliciesPermissionGroupsList extends cdktn.ComplexList {
    internalValue?: ApiTokenPoliciesPermissionGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiTokenPoliciesPermissionGroupsOutputReference;
}
export interface ApiTokenPolicies {
    /**
    * Allow or deny operations against the resources.
    * Available values: "allow", "deny".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#effect ApiToken#effect}
    */
    readonly effect: string;
    /**
    * A set of permission groups that are specified to the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#permission_groups ApiToken#permission_groups}
    */
    readonly permissionGroups: ApiTokenPoliciesPermissionGroups[] | cdktn.IResolvable;
    /**
    * A json object representing the resources that are specified to the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#resources ApiToken#resources}
    */
    readonly resources: string;
}
export declare function apiTokenPoliciesToTerraform(struct?: ApiTokenPolicies | cdktn.IResolvable): any;
export declare function apiTokenPoliciesToHclTerraform(struct?: ApiTokenPolicies | cdktn.IResolvable): any;
export declare class ApiTokenPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiTokenPolicies | cdktn.IResolvable | undefined;
    set internalValue(value: ApiTokenPolicies | cdktn.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    get effectInput(): string | undefined;
    private _permissionGroups;
    get permissionGroups(): ApiTokenPoliciesPermissionGroupsList;
    putPermissionGroups(value: ApiTokenPoliciesPermissionGroups[] | cdktn.IResolvable): void;
    get permissionGroupsInput(): cdktn.IResolvable | ApiTokenPoliciesPermissionGroups[] | undefined;
    private _resources?;
    get resources(): string;
    set resources(value: string);
    get resourcesInput(): string | undefined;
}
export declare class ApiTokenPoliciesList extends cdktn.ComplexList {
    internalValue?: ApiTokenPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiTokenPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token cloudflare_api_token}
*/
export declare class ApiToken extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_api_token";
    /**
    * Generates CDKTN code for importing a ApiToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiToken to import
    * @param importFromId The id of the existing ApiToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/resources/api_token cloudflare_api_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiTokenConfig
    */
    constructor(scope: Construct, id: string, config: ApiTokenConfig);
    private _condition;
    get condition(): ApiTokenConditionOutputReference;
    putCondition(value: ApiTokenCondition): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | ApiTokenCondition | undefined;
    private _expiresOn?;
    get expiresOn(): string;
    set expiresOn(value: string);
    resetExpiresOn(): void;
    get expiresOnInput(): string | undefined;
    get id(): string;
    get issuedOn(): string;
    get lastUsedOn(): string;
    get modifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notBefore?;
    get notBefore(): string;
    set notBefore(value: string);
    resetNotBefore(): void;
    get notBeforeInput(): string | undefined;
    private _policies;
    get policies(): ApiTokenPoliciesList;
    putPolicies(value: ApiTokenPolicies[] | cdktn.IResolvable): void;
    get policiesInput(): cdktn.IResolvable | ApiTokenPolicies[] | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get value(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
