/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareCallsSfuAppsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/calls_sfu_apps#account_id DataCloudflareCallsSfuApps#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/calls_sfu_apps#max_items DataCloudflareCallsSfuApps#max_items}
    */
    readonly maxItems?: number;
}
export interface DataCloudflareCallsSfuAppsResult {
}
export declare function dataCloudflareCallsSfuAppsResultToTerraform(struct?: DataCloudflareCallsSfuAppsResult): any;
export declare function dataCloudflareCallsSfuAppsResultToHclTerraform(struct?: DataCloudflareCallsSfuAppsResult): any;
export declare class DataCloudflareCallsSfuAppsResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareCallsSfuAppsResult | undefined;
    set internalValue(value: DataCloudflareCallsSfuAppsResult | undefined);
    get created(): string;
    get modified(): string;
    get name(): string;
    get uid(): string;
}
export declare class DataCloudflareCallsSfuAppsResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareCallsSfuAppsResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/calls_sfu_apps cloudflare_calls_sfu_apps}
*/
export declare class DataCloudflareCallsSfuApps extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_calls_sfu_apps";
    /**
    * Generates CDKTN code for importing a DataCloudflareCallsSfuApps resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareCallsSfuApps to import
    * @param importFromId The id of the existing DataCloudflareCallsSfuApps that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/calls_sfu_apps#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareCallsSfuApps to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/calls_sfu_apps cloudflare_calls_sfu_apps} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareCallsSfuAppsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareCallsSfuAppsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareCallsSfuAppsResultList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
