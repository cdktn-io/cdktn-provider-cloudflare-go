/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDeviceSubnetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_device_subnet#account_id DataCloudflareZeroTrustDeviceSubnet#account_id}
    */
    readonly accountId?: string;
    /**
    * The UUID of the subnet.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_device_subnet#subnet_id DataCloudflareZeroTrustDeviceSubnet#subnet_id}
    */
    readonly subnetId: string;
}
export interface DataCloudflareZeroTrustDeviceSubnetCapacity {
}
export declare function dataCloudflareZeroTrustDeviceSubnetCapacityToTerraform(struct?: DataCloudflareZeroTrustDeviceSubnetCapacity): any;
export declare function dataCloudflareZeroTrustDeviceSubnetCapacityToHclTerraform(struct?: DataCloudflareZeroTrustDeviceSubnetCapacity): any;
export declare class DataCloudflareZeroTrustDeviceSubnetCapacityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDeviceSubnetCapacity | undefined;
    set internalValue(value: DataCloudflareZeroTrustDeviceSubnetCapacity | undefined);
    get total(): number;
    get used(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_device_subnet cloudflare_zero_trust_device_subnet}
*/
export declare class DataCloudflareZeroTrustDeviceSubnet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_device_subnet";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDeviceSubnet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDeviceSubnet to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDeviceSubnet that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_device_subnet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDeviceSubnet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.24.0/docs/data-sources/zero_trust_device_subnet cloudflare_zero_trust_device_subnet} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDeviceSubnetConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDeviceSubnetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _capacity;
    get capacity(): DataCloudflareZeroTrustDeviceSubnetCapacityOutputReference;
    get comment(): string;
    get createdAt(): string;
    get deletedAt(): string;
    get id(): string;
    get isDefaultNetwork(): cdktn.IResolvable;
    get name(): string;
    get network(): string;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    get subnetType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
