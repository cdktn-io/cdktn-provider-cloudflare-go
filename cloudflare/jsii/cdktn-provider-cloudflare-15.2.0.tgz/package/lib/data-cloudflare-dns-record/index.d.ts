/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareDnsRecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#dns_record_id DataCloudflareDnsRecord#dns_record_id}
    */
    readonly dnsRecordId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#filter DataCloudflareDnsRecord#filter}
    */
    readonly filter?: DataCloudflareDnsRecordFilter;
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#zone_id DataCloudflareDnsRecord#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareDnsRecordData {
}
export declare function dataCloudflareDnsRecordDataToTerraform(struct?: DataCloudflareDnsRecordData): any;
export declare function dataCloudflareDnsRecordDataToHclTerraform(struct?: DataCloudflareDnsRecordData): any;
export declare class DataCloudflareDnsRecordDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsRecordData | undefined;
    set internalValue(value: DataCloudflareDnsRecordData | undefined);
    get algorithm(): number;
    get altitude(): number;
    get certificate(): string;
    get digest(): string;
    get digestType(): number;
    get fingerprint(): string;
    private _flags;
    get flags(): cdktn.AnyMap;
    get keyTag(): number;
    get latDegrees(): number;
    get latDirection(): string;
    get latMinutes(): number;
    get latSeconds(): number;
    get longDegrees(): number;
    get longDirection(): string;
    get longMinutes(): number;
    get longSeconds(): number;
    get matchingType(): number;
    get order(): number;
    get port(): number;
    get precisionHorz(): number;
    get precisionVert(): number;
    get preference(): number;
    get priority(): number;
    get protocol(): number;
    get publicKey(): string;
    get regex(): string;
    get replacement(): string;
    get selector(): number;
    get service(): string;
    get size(): number;
    get tag(): string;
    get target(): string;
    get type(): number;
    get usage(): number;
    get value(): string;
    get weight(): number;
}
export interface DataCloudflareDnsRecordFilterComment {
    /**
    * If this parameter is present, only records *without* a comment are returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#absent DataCloudflareDnsRecord#absent}
    */
    readonly absent?: string;
    /**
    * Substring of the DNS record comment. Comment filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#contains DataCloudflareDnsRecord#contains}
    */
    readonly contains?: string;
    /**
    * Suffix of the DNS record comment. Comment filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#endswith DataCloudflareDnsRecord#endswith}
    */
    readonly endswith?: string;
    /**
    * Exact value of the DNS record comment. Comment filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#exact DataCloudflareDnsRecord#exact}
    */
    readonly exact?: string;
    /**
    * If this parameter is present, only records *with* a comment are returned.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#present DataCloudflareDnsRecord#present}
    */
    readonly present?: string;
    /**
    * Prefix of the DNS record comment. Comment filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#startswith DataCloudflareDnsRecord#startswith}
    */
    readonly startswith?: string;
}
export declare function dataCloudflareDnsRecordFilterCommentToTerraform(struct?: DataCloudflareDnsRecordFilterComment | cdktn.IResolvable): any;
export declare function dataCloudflareDnsRecordFilterCommentToHclTerraform(struct?: DataCloudflareDnsRecordFilterComment | cdktn.IResolvable): any;
export declare class DataCloudflareDnsRecordFilterCommentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsRecordFilterComment | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareDnsRecordFilterComment | cdktn.IResolvable | undefined);
    private _absent?;
    get absent(): string;
    set absent(value: string);
    resetAbsent(): void;
    get absentInput(): string | undefined;
    private _contains?;
    get contains(): string;
    set contains(value: string);
    resetContains(): void;
    get containsInput(): string | undefined;
    private _endswith?;
    get endswith(): string;
    set endswith(value: string);
    resetEndswith(): void;
    get endswithInput(): string | undefined;
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _present?;
    get present(): string;
    set present(value: string);
    resetPresent(): void;
    get presentInput(): string | undefined;
    private _startswith?;
    get startswith(): string;
    set startswith(value: string);
    resetStartswith(): void;
    get startswithInput(): string | undefined;
}
export interface DataCloudflareDnsRecordFilterContent {
    /**
    * Substring of the DNS record content. Content filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#contains DataCloudflareDnsRecord#contains}
    */
    readonly contains?: string;
    /**
    * Suffix of the DNS record content. Content filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#endswith DataCloudflareDnsRecord#endswith}
    */
    readonly endswith?: string;
    /**
    * Exact value of the DNS record content. Content filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#exact DataCloudflareDnsRecord#exact}
    */
    readonly exact?: string;
    /**
    * Prefix of the DNS record content. Content filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#startswith DataCloudflareDnsRecord#startswith}
    */
    readonly startswith?: string;
}
export declare function dataCloudflareDnsRecordFilterContentToTerraform(struct?: DataCloudflareDnsRecordFilterContent | cdktn.IResolvable): any;
export declare function dataCloudflareDnsRecordFilterContentToHclTerraform(struct?: DataCloudflareDnsRecordFilterContent | cdktn.IResolvable): any;
export declare class DataCloudflareDnsRecordFilterContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsRecordFilterContent | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareDnsRecordFilterContent | cdktn.IResolvable | undefined);
    private _contains?;
    get contains(): string;
    set contains(value: string);
    resetContains(): void;
    get containsInput(): string | undefined;
    private _endswith?;
    get endswith(): string;
    set endswith(value: string);
    resetEndswith(): void;
    get endswithInput(): string | undefined;
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _startswith?;
    get startswith(): string;
    set startswith(value: string);
    resetStartswith(): void;
    get startswithInput(): string | undefined;
}
export interface DataCloudflareDnsRecordFilterName {
    /**
    * Substring of the DNS record name. Name filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#contains DataCloudflareDnsRecord#contains}
    */
    readonly contains?: string;
    /**
    * Suffix of the DNS record name. Name filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#endswith DataCloudflareDnsRecord#endswith}
    */
    readonly endswith?: string;
    /**
    * Exact value of the DNS record name. Name filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#exact DataCloudflareDnsRecord#exact}
    */
    readonly exact?: string;
    /**
    * Prefix of the DNS record name. Name filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#startswith DataCloudflareDnsRecord#startswith}
    */
    readonly startswith?: string;
}
export declare function dataCloudflareDnsRecordFilterNameToTerraform(struct?: DataCloudflareDnsRecordFilterName | cdktn.IResolvable): any;
export declare function dataCloudflareDnsRecordFilterNameToHclTerraform(struct?: DataCloudflareDnsRecordFilterName | cdktn.IResolvable): any;
export declare class DataCloudflareDnsRecordFilterNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsRecordFilterName | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareDnsRecordFilterName | cdktn.IResolvable | undefined);
    private _contains?;
    get contains(): string;
    set contains(value: string);
    resetContains(): void;
    get containsInput(): string | undefined;
    private _endswith?;
    get endswith(): string;
    set endswith(value: string);
    resetEndswith(): void;
    get endswithInput(): string | undefined;
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _startswith?;
    get startswith(): string;
    set startswith(value: string);
    resetStartswith(): void;
    get startswithInput(): string | undefined;
}
export interface DataCloudflareDnsRecordFilterTag {
    /**
    * Name of a tag which must *not* be present on the DNS record. Tag filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#absent DataCloudflareDnsRecord#absent}
    */
    readonly absent?: string;
    /**
    * A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value contains `<tag-value>`. Tag filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#contains DataCloudflareDnsRecord#contains}
    */
    readonly contains?: string;
    /**
    * A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value ends with `<tag-value>`. Tag filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#endswith DataCloudflareDnsRecord#endswith}
    */
    readonly endswith?: string;
    /**
    * A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value is `<tag-value>`. Tag filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#exact DataCloudflareDnsRecord#exact}
    */
    readonly exact?: string;
    /**
    * Name of a tag which must be present on the DNS record. Tag filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#present DataCloudflareDnsRecord#present}
    */
    readonly present?: string;
    /**
    * A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value starts with `<tag-value>`. Tag filters are case-insensitive.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#startswith DataCloudflareDnsRecord#startswith}
    */
    readonly startswith?: string;
}
export declare function dataCloudflareDnsRecordFilterTagToTerraform(struct?: DataCloudflareDnsRecordFilterTag | cdktn.IResolvable): any;
export declare function dataCloudflareDnsRecordFilterTagToHclTerraform(struct?: DataCloudflareDnsRecordFilterTag | cdktn.IResolvable): any;
export declare class DataCloudflareDnsRecordFilterTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsRecordFilterTag | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareDnsRecordFilterTag | cdktn.IResolvable | undefined);
    private _absent?;
    get absent(): string;
    set absent(value: string);
    resetAbsent(): void;
    get absentInput(): string | undefined;
    private _contains?;
    get contains(): string;
    set contains(value: string);
    resetContains(): void;
    get containsInput(): string | undefined;
    private _endswith?;
    get endswith(): string;
    set endswith(value: string);
    resetEndswith(): void;
    get endswithInput(): string | undefined;
    private _exact?;
    get exact(): string;
    set exact(value: string);
    resetExact(): void;
    get exactInput(): string | undefined;
    private _present?;
    get present(): string;
    set present(value: string);
    resetPresent(): void;
    get presentInput(): string | undefined;
    private _startswith?;
    get startswith(): string;
    set startswith(value: string);
    resetStartswith(): void;
    get startswithInput(): string | undefined;
}
export interface DataCloudflareDnsRecordFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#comment DataCloudflareDnsRecord#comment}
    */
    readonly comment?: DataCloudflareDnsRecordFilterComment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#content DataCloudflareDnsRecord#content}
    */
    readonly content?: DataCloudflareDnsRecordFilterContent;
    /**
    * Direction to order DNS records in.
    * Available values: "asc", "desc".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#direction DataCloudflareDnsRecord#direction}
    */
    readonly direction?: string;
    /**
    * Whether to match all search requirements or at least one (any). If set to `all`, acts like a logical AND between filters. If set to `any`, acts like a logical OR instead. Note that the interaction between tag filters is controlled by the `tag-match` parameter instead.
    * Available values: "any", "all".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#match DataCloudflareDnsRecord#match}
    */
    readonly match?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#name DataCloudflareDnsRecord#name}
    */
    readonly name?: DataCloudflareDnsRecordFilterName;
    /**
    * Field to order DNS records by.
    * Available values: "type", "name", "content", "ttl", "proxied".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#order DataCloudflareDnsRecord#order}
    */
    readonly order?: string;
    /**
    * Whether the record is receiving the performance and security benefits of Cloudflare.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#proxied DataCloudflareDnsRecord#proxied}
    */
    readonly proxied?: boolean | cdktn.IResolvable;
    /**
    * Allows searching in multiple properties of a DNS record simultaneously. This parameter is intended for human users, not automation. Its exact behavior is intentionally left unspecified and is subject to change in the future. This parameter works independently of the `match` setting. For automated searches, please use the other available parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#search DataCloudflareDnsRecord#search}
    */
    readonly search?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#tag DataCloudflareDnsRecord#tag}
    */
    readonly tag?: DataCloudflareDnsRecordFilterTag;
    /**
    * Whether to match all tag search requirements or at least one (any). If set to `all`, acts like a logical AND between tag filters. If set to `any`, acts like a logical OR instead. Note that the regular `match` parameter is still used to combine the resulting condition with other filters that aren't related to tags.
    * Available values: "any", "all".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#tag_match DataCloudflareDnsRecord#tag_match}
    */
    readonly tagMatch?: string;
    /**
    * Record type.
    * Available values: "A", "AAAA", "CAA", "CERT", "CNAME", "DNSKEY", "DS", "HTTPS", "LOC", "MX", "NAPTR", "NS", "OPENPGPKEY", "PTR", "SMIMEA", "SRV", "SSHFP", "SVCB", "TLSA", "TXT", "URI".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#type DataCloudflareDnsRecord#type}
    */
    readonly type?: string;
}
export declare function dataCloudflareDnsRecordFilterToTerraform(struct?: DataCloudflareDnsRecordFilter | cdktn.IResolvable): any;
export declare function dataCloudflareDnsRecordFilterToHclTerraform(struct?: DataCloudflareDnsRecordFilter | cdktn.IResolvable): any;
export declare class DataCloudflareDnsRecordFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsRecordFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataCloudflareDnsRecordFilter | cdktn.IResolvable | undefined);
    private _comment;
    get comment(): DataCloudflareDnsRecordFilterCommentOutputReference;
    putComment(value: DataCloudflareDnsRecordFilterComment): void;
    resetComment(): void;
    get commentInput(): cdktn.IResolvable | DataCloudflareDnsRecordFilterComment | undefined;
    private _content;
    get content(): DataCloudflareDnsRecordFilterContentOutputReference;
    putContent(value: DataCloudflareDnsRecordFilterContent): void;
    resetContent(): void;
    get contentInput(): cdktn.IResolvable | DataCloudflareDnsRecordFilterContent | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    resetDirection(): void;
    get directionInput(): string | undefined;
    private _match?;
    get match(): string;
    set match(value: string);
    resetMatch(): void;
    get matchInput(): string | undefined;
    private _name;
    get name(): DataCloudflareDnsRecordFilterNameOutputReference;
    putName(value: DataCloudflareDnsRecordFilterName): void;
    resetName(): void;
    get nameInput(): cdktn.IResolvable | DataCloudflareDnsRecordFilterName | undefined;
    private _order?;
    get order(): string;
    set order(value: string);
    resetOrder(): void;
    get orderInput(): string | undefined;
    private _proxied?;
    get proxied(): boolean | cdktn.IResolvable;
    set proxied(value: boolean | cdktn.IResolvable);
    resetProxied(): void;
    get proxiedInput(): boolean | cdktn.IResolvable | undefined;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    private _tag;
    get tag(): DataCloudflareDnsRecordFilterTagOutputReference;
    putTag(value: DataCloudflareDnsRecordFilterTag): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | DataCloudflareDnsRecordFilterTag | undefined;
    private _tagMatch?;
    get tagMatch(): string;
    set tagMatch(value: string);
    resetTagMatch(): void;
    get tagMatchInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DataCloudflareDnsRecordSettings {
}
export declare function dataCloudflareDnsRecordSettingsToTerraform(struct?: DataCloudflareDnsRecordSettings): any;
export declare function dataCloudflareDnsRecordSettingsToHclTerraform(struct?: DataCloudflareDnsRecordSettings): any;
export declare class DataCloudflareDnsRecordSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareDnsRecordSettings | undefined;
    set internalValue(value: DataCloudflareDnsRecordSettings | undefined);
    get flattenCname(): cdktn.IResolvable;
    get ipv4Only(): cdktn.IResolvable;
    get ipv6Only(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record cloudflare_dns_record}
*/
export declare class DataCloudflareDnsRecord extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_dns_record";
    /**
    * Generates CDKTN code for importing a DataCloudflareDnsRecord resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareDnsRecord to import
    * @param importFromId The id of the existing DataCloudflareDnsRecord that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareDnsRecord to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.0/docs/data-sources/dns_record cloudflare_dns_record} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareDnsRecordConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareDnsRecordConfig);
    get comment(): string;
    get commentModifiedOn(): string;
    get content(): string;
    get createdOn(): string;
    private _data;
    get data(): DataCloudflareDnsRecordDataOutputReference;
    private _dnsRecordId?;
    get dnsRecordId(): string;
    set dnsRecordId(value: string);
    resetDnsRecordId(): void;
    get dnsRecordIdInput(): string | undefined;
    private _filter;
    get filter(): DataCloudflareDnsRecordFilterOutputReference;
    putFilter(value: DataCloudflareDnsRecordFilter): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataCloudflareDnsRecordFilter | undefined;
    get id(): string;
    get meta(): string;
    get modifiedOn(): string;
    get name(): string;
    get priority(): number;
    get privateRouting(): cdktn.IResolvable;
    get proxiable(): cdktn.IResolvable;
    get proxied(): cdktn.IResolvable;
    private _settings;
    get settings(): DataCloudflareDnsRecordSettingsOutputReference;
    get tags(): string[];
    get tagsModifiedOn(): string;
    get ttl(): number;
    get type(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
