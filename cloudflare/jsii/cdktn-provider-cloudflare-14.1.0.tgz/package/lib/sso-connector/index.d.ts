/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SsoConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector#account_id SsoConnector#account_id}
    */
    readonly accountId: string;
    /**
    * Begin the verification process after creation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector#begin_verification SsoConnector#begin_verification}
    */
    readonly beginVerification?: boolean | cdktn.IResolvable;
    /**
    * Email domain of the new SSO connector
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector#email_domain SsoConnector#email_domain}
    */
    readonly emailDomain: string;
    /**
    * SSO Connector enabled state
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector#enabled SsoConnector#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Controls the display of FedRAMP language to the user during SSO login
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector#use_fedramp_language SsoConnector#use_fedramp_language}
    */
    readonly useFedrampLanguage?: boolean | cdktn.IResolvable;
}
export interface SsoConnectorVerification {
}
export declare function ssoConnectorVerificationToTerraform(struct?: SsoConnectorVerification): any;
export declare function ssoConnectorVerificationToHclTerraform(struct?: SsoConnectorVerification): any;
export declare class SsoConnectorVerificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SsoConnectorVerification | undefined;
    set internalValue(value: SsoConnectorVerification | undefined);
    get code(): string;
    get status(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector cloudflare_sso_connector}
*/
export declare class SsoConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudflare_sso_connector";
    /**
    * Generates CDKTN code for importing a SsoConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SsoConnector to import
    * @param importFromId The id of the existing SsoConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SsoConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.18.0/docs/resources/sso_connector cloudflare_sso_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SsoConnectorConfig
    */
    constructor(scope: Construct, id: string, config: SsoConnectorConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _beginVerification?;
    get beginVerification(): boolean | cdktn.IResolvable;
    set beginVerification(value: boolean | cdktn.IResolvable);
    resetBeginVerification(): void;
    get beginVerificationInput(): boolean | cdktn.IResolvable | undefined;
    get createdOn(): string;
    private _emailDomain?;
    get emailDomain(): string;
    set emailDomain(value: string);
    get emailDomainInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get updatedOn(): string;
    private _useFedrampLanguage?;
    get useFedrampLanguage(): boolean | cdktn.IResolvable;
    set useFedrampLanguage(value: boolean | cdktn.IResolvable);
    resetUseFedrampLanguage(): void;
    get useFedrampLanguageInput(): boolean | cdktn.IResolvable | undefined;
    private _verification;
    get verification(): SsoConnectorVerificationOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
