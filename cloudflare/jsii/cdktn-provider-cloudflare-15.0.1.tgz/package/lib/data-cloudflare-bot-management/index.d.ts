/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareBotManagementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/bot_management#zone_id DataCloudflareBotManagement#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareBotManagementStaleZoneConfiguration {
}
export declare function dataCloudflareBotManagementStaleZoneConfigurationToTerraform(struct?: DataCloudflareBotManagementStaleZoneConfiguration): any;
export declare function dataCloudflareBotManagementStaleZoneConfigurationToHclTerraform(struct?: DataCloudflareBotManagementStaleZoneConfiguration): any;
export declare class DataCloudflareBotManagementStaleZoneConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareBotManagementStaleZoneConfiguration | undefined;
    set internalValue(value: DataCloudflareBotManagementStaleZoneConfiguration | undefined);
    get fightMode(): cdktn.IResolvable;
    get optimizeWordpress(): cdktn.IResolvable;
    get sbfmDefinitelyAutomated(): string;
    get sbfmLikelyAutomated(): string;
    get sbfmStaticResourceProtection(): string;
    get sbfmVerifiedBots(): string;
    get suppressSessionScore(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/bot_management cloudflare_bot_management}
*/
export declare class DataCloudflareBotManagement extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_bot_management";
    /**
    * Generates CDKTN code for importing a DataCloudflareBotManagement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareBotManagement to import
    * @param importFromId The id of the existing DataCloudflareBotManagement that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/bot_management#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareBotManagement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/bot_management cloudflare_bot_management} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareBotManagementConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareBotManagementConfig);
    get aiBotsProtection(): string;
    get autoUpdateModel(): cdktn.IResolvable;
    get bmCookieEnabled(): cdktn.IResolvable;
    get cfRobotsVariant(): string;
    get contentBotsProtection(): string;
    get crawlerProtection(): string;
    get enableJs(): cdktn.IResolvable;
    get fightMode(): cdktn.IResolvable;
    get id(): string;
    get isRobotsTxtManaged(): cdktn.IResolvable;
    get optimizeWordpress(): cdktn.IResolvable;
    get sbfmDefinitelyAutomated(): string;
    get sbfmLikelyAutomated(): string;
    get sbfmStaticResourceProtection(): cdktn.IResolvable;
    get sbfmVerifiedBots(): string;
    private _staleZoneConfiguration;
    get staleZoneConfiguration(): DataCloudflareBotManagementStaleZoneConfigurationOutputReference;
    get suppressSessionScore(): cdktn.IResolvable;
    get usingLatestModel(): cdktn.IResolvable;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
