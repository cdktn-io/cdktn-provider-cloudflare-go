/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflarePageShieldScriptsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/page_shield_scripts#script_id DataCloudflarePageShieldScripts#script_id}
    */
    readonly scriptId: string;
    /**
    * Identifier
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/page_shield_scripts#zone_id DataCloudflarePageShieldScripts#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflarePageShieldScriptsVersions {
}
export declare function dataCloudflarePageShieldScriptsVersionsToTerraform(struct?: DataCloudflarePageShieldScriptsVersions): any;
export declare function dataCloudflarePageShieldScriptsVersionsToHclTerraform(struct?: DataCloudflarePageShieldScriptsVersions): any;
export declare class DataCloudflarePageShieldScriptsVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflarePageShieldScriptsVersions | undefined;
    set internalValue(value: DataCloudflarePageShieldScriptsVersions | undefined);
    get cryptominingScore(): number;
    get dataflowScore(): number;
    get fetchedAt(): string;
    get hash(): string;
    get jsIntegrityScore(): number;
    get magecartScore(): number;
    get malwareScore(): number;
    get obfuscationScore(): number;
}
export declare class DataCloudflarePageShieldScriptsVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflarePageShieldScriptsVersionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/page_shield_scripts cloudflare_page_shield_scripts}
*/
export declare class DataCloudflarePageShieldScripts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_page_shield_scripts";
    /**
    * Generates CDKTN code for importing a DataCloudflarePageShieldScripts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflarePageShieldScripts to import
    * @param importFromId The id of the existing DataCloudflarePageShieldScripts that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/page_shield_scripts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflarePageShieldScripts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/page_shield_scripts cloudflare_page_shield_scripts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflarePageShieldScriptsConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflarePageShieldScriptsConfig);
    get addedAt(): string;
    get cryptominingScore(): number;
    get dataflowScore(): number;
    get domainReportedMalicious(): cdktn.IResolvable;
    get fetchedAt(): string;
    get firstPageUrl(): string;
    get firstSeenAt(): string;
    get hash(): string;
    get host(): string;
    get id(): string;
    get jsIntegrityScore(): number;
    get lastSeenAt(): string;
    get magecartScore(): number;
    get maliciousDomainCategories(): string[];
    get maliciousUrlCategories(): string[];
    get malwareScore(): number;
    get obfuscationScore(): number;
    get pageUrls(): string[];
    private _scriptId?;
    get scriptId(): string;
    set scriptId(value: string);
    get scriptIdInput(): string | undefined;
    get url(): string;
    get urlContainsCdnCgiPath(): cdktn.IResolvable;
    get urlReportedMalicious(): cdktn.IResolvable;
    private _versions;
    get versions(): DataCloudflarePageShieldScriptsVersionsList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
