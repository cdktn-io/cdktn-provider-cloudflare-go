/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareQueueConsumerConfig extends cdktn.TerraformMetaArguments {
    /**
    * A Resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/queue_consumer#account_id DataCloudflareQueueConsumer#account_id}
    */
    readonly accountId: string;
    /**
    * A Resource identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/queue_consumer#queue_id DataCloudflareQueueConsumer#queue_id}
    */
    readonly queueId: string;
}
export interface DataCloudflareQueueConsumerSettings {
}
export declare function dataCloudflareQueueConsumerSettingsToTerraform(struct?: DataCloudflareQueueConsumerSettings): any;
export declare function dataCloudflareQueueConsumerSettingsToHclTerraform(struct?: DataCloudflareQueueConsumerSettings): any;
export declare class DataCloudflareQueueConsumerSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareQueueConsumerSettings | undefined;
    set internalValue(value: DataCloudflareQueueConsumerSettings | undefined);
    get batchSize(): number;
    get maxConcurrency(): number;
    get maxRetries(): number;
    get maxWaitTimeMs(): number;
    get retryDelay(): number;
    get visibilityTimeoutMs(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/queue_consumer cloudflare_queue_consumer}
*/
export declare class DataCloudflareQueueConsumer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_queue_consumer";
    /**
    * Generates CDKTN code for importing a DataCloudflareQueueConsumer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareQueueConsumer to import
    * @param importFromId The id of the existing DataCloudflareQueueConsumer that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/queue_consumer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareQueueConsumer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/queue_consumer cloudflare_queue_consumer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareQueueConsumerConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareQueueConsumerConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get consumerId(): string;
    get createdOn(): string;
    get deadLetterQueue(): string;
    private _queueId?;
    get queueId(): string;
    set queueId(value: string);
    get queueIdInput(): string | undefined;
    get queueName(): string;
    get scriptName(): string;
    private _settings;
    get settings(): DataCloudflareQueueConsumerSettingsOutputReference;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
