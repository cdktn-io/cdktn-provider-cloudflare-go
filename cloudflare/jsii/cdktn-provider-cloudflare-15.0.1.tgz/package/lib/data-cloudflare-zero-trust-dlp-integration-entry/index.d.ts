/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZeroTrustDlpIntegrationEntryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dlp_integration_entry#account_id DataCloudflareZeroTrustDlpIntegrationEntry#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dlp_integration_entry#entry_id DataCloudflareZeroTrustDlpIntegrationEntry#entry_id}
    */
    readonly entryId: string;
}
export interface DataCloudflareZeroTrustDlpIntegrationEntryConfidence {
}
export declare function dataCloudflareZeroTrustDlpIntegrationEntryConfidenceToTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryConfidence): any;
export declare function dataCloudflareZeroTrustDlpIntegrationEntryConfidenceToHclTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryConfidence): any;
export declare class DataCloudflareZeroTrustDlpIntegrationEntryConfidenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpIntegrationEntryConfidence | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpIntegrationEntryConfidence | undefined);
    get aiContextAvailable(): cdktn.IResolvable;
    get available(): cdktn.IResolvable;
}
export interface DataCloudflareZeroTrustDlpIntegrationEntryPattern {
}
export declare function dataCloudflareZeroTrustDlpIntegrationEntryPatternToTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryPattern): any;
export declare function dataCloudflareZeroTrustDlpIntegrationEntryPatternToHclTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryPattern): any;
export declare class DataCloudflareZeroTrustDlpIntegrationEntryPatternOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpIntegrationEntryPattern | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpIntegrationEntryPattern | undefined);
    get regex(): string;
    get validation(): string;
}
export interface DataCloudflareZeroTrustDlpIntegrationEntryProfiles {
}
export declare function dataCloudflareZeroTrustDlpIntegrationEntryProfilesToTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryProfiles): any;
export declare function dataCloudflareZeroTrustDlpIntegrationEntryProfilesToHclTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryProfiles): any;
export declare class DataCloudflareZeroTrustDlpIntegrationEntryProfilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareZeroTrustDlpIntegrationEntryProfiles | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpIntegrationEntryProfiles | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataCloudflareZeroTrustDlpIntegrationEntryProfilesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareZeroTrustDlpIntegrationEntryProfilesOutputReference;
}
export interface DataCloudflareZeroTrustDlpIntegrationEntryVariant {
}
export declare function dataCloudflareZeroTrustDlpIntegrationEntryVariantToTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryVariant): any;
export declare function dataCloudflareZeroTrustDlpIntegrationEntryVariantToHclTerraform(struct?: DataCloudflareZeroTrustDlpIntegrationEntryVariant): any;
export declare class DataCloudflareZeroTrustDlpIntegrationEntryVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZeroTrustDlpIntegrationEntryVariant | undefined;
    set internalValue(value: DataCloudflareZeroTrustDlpIntegrationEntryVariant | undefined);
    get description(): string;
    get topicType(): string;
    get type(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dlp_integration_entry cloudflare_zero_trust_dlp_integration_entry}
*/
export declare class DataCloudflareZeroTrustDlpIntegrationEntry extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zero_trust_dlp_integration_entry";
    /**
    * Generates CDKTN code for importing a DataCloudflareZeroTrustDlpIntegrationEntry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZeroTrustDlpIntegrationEntry to import
    * @param importFromId The id of the existing DataCloudflareZeroTrustDlpIntegrationEntry that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dlp_integration_entry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZeroTrustDlpIntegrationEntry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.19.1/docs/data-sources/zero_trust_dlp_integration_entry cloudflare_zero_trust_dlp_integration_entry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZeroTrustDlpIntegrationEntryConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareZeroTrustDlpIntegrationEntryConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get caseSensitive(): cdktn.IResolvable;
    private _confidence;
    get confidence(): DataCloudflareZeroTrustDlpIntegrationEntryConfidenceOutputReference;
    get createdAt(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _entryId?;
    get entryId(): string;
    set entryId(value: string);
    get entryIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _pattern;
    get pattern(): DataCloudflareZeroTrustDlpIntegrationEntryPatternOutputReference;
    get profileId(): string;
    private _profiles;
    get profiles(): DataCloudflareZeroTrustDlpIntegrationEntryProfilesList;
    get secret(): cdktn.IResolvable;
    get type(): string;
    get updatedAt(): string;
    get uploadStatus(): string;
    private _variant;
    get variant(): DataCloudflareZeroTrustDlpIntegrationEntryVariantOutputReference;
    get wordList(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
