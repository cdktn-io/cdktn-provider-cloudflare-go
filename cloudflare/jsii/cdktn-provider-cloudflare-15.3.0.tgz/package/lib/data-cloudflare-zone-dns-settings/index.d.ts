/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareZoneDnsSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zone_dns_settings#zone_id DataCloudflareZoneDnsSettings#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataCloudflareZoneDnsSettingsInternalDns {
}
export declare function dataCloudflareZoneDnsSettingsInternalDnsToTerraform(struct?: DataCloudflareZoneDnsSettingsInternalDns): any;
export declare function dataCloudflareZoneDnsSettingsInternalDnsToHclTerraform(struct?: DataCloudflareZoneDnsSettingsInternalDns): any;
export declare class DataCloudflareZoneDnsSettingsInternalDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneDnsSettingsInternalDns | undefined;
    set internalValue(value: DataCloudflareZoneDnsSettingsInternalDns | undefined);
    get referenceZoneId(): string;
}
export interface DataCloudflareZoneDnsSettingsNameservers {
}
export declare function dataCloudflareZoneDnsSettingsNameserversToTerraform(struct?: DataCloudflareZoneDnsSettingsNameservers): any;
export declare function dataCloudflareZoneDnsSettingsNameserversToHclTerraform(struct?: DataCloudflareZoneDnsSettingsNameservers): any;
export declare class DataCloudflareZoneDnsSettingsNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneDnsSettingsNameservers | undefined;
    set internalValue(value: DataCloudflareZoneDnsSettingsNameservers | undefined);
    get nsSet(): number;
    get type(): string;
}
export interface DataCloudflareZoneDnsSettingsSoa {
}
export declare function dataCloudflareZoneDnsSettingsSoaToTerraform(struct?: DataCloudflareZoneDnsSettingsSoa): any;
export declare function dataCloudflareZoneDnsSettingsSoaToHclTerraform(struct?: DataCloudflareZoneDnsSettingsSoa): any;
export declare class DataCloudflareZoneDnsSettingsSoaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareZoneDnsSettingsSoa | undefined;
    set internalValue(value: DataCloudflareZoneDnsSettingsSoa | undefined);
    get expire(): number;
    get minTtl(): number;
    get mname(): string;
    get refresh(): number;
    get retry(): number;
    get rname(): string;
    get ttl(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zone_dns_settings cloudflare_zone_dns_settings}
*/
export declare class DataCloudflareZoneDnsSettings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_zone_dns_settings";
    /**
    * Generates CDKTN code for importing a DataCloudflareZoneDnsSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareZoneDnsSettings to import
    * @param importFromId The id of the existing DataCloudflareZoneDnsSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zone_dns_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareZoneDnsSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.22.0/docs/data-sources/zone_dns_settings cloudflare_zone_dns_settings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareZoneDnsSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareZoneDnsSettingsConfig);
    get flattenAllCnames(): cdktn.IResolvable;
    get foundationDns(): cdktn.IResolvable;
    private _internalDns;
    get internalDns(): DataCloudflareZoneDnsSettingsInternalDnsOutputReference;
    get multiProvider(): cdktn.IResolvable;
    private _nameservers;
    get nameservers(): DataCloudflareZoneDnsSettingsNameserversOutputReference;
    get nsTtl(): number;
    get secondaryOverrides(): cdktn.IResolvable;
    private _soa;
    get soa(): DataCloudflareZoneDnsSettingsSoaOutputReference;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    get zoneMode(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
