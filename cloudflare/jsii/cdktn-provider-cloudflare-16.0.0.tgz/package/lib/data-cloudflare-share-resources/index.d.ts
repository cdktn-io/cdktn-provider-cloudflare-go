/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareShareResourcesAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Account identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources#account_id DataCloudflareShareResourcesA#account_id}
    */
    readonly accountId: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources#max_items DataCloudflareShareResourcesA#max_items}
    */
    readonly maxItems?: number;
    /**
    * Filter share resources by resource_type.
    * Available values: "custom-ruleset", "gateway-policy", "gateway-destination-ip", "gateway-block-page-settings", "gateway-extended-email-matching", "idp-federation-grant".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources#resource_type DataCloudflareShareResourcesA#resource_type}
    */
    readonly resourceType?: string;
    /**
    * Share identifier tag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources#share_id DataCloudflareShareResourcesA#share_id}
    */
    readonly shareId: string;
    /**
    * Filter share resources by status.
    * Available values: "active", "deleting", "deleted".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources#status DataCloudflareShareResourcesA#status}
    */
    readonly status?: string;
}
export interface DataCloudflareShareResourcesResult {
}
export declare function dataCloudflareShareResourcesResultToTerraform(struct?: DataCloudflareShareResourcesResult): any;
export declare function dataCloudflareShareResourcesResultToHclTerraform(struct?: DataCloudflareShareResourcesResult): any;
export declare class DataCloudflareShareResourcesResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareShareResourcesResult | undefined;
    set internalValue(value: DataCloudflareShareResourcesResult | undefined);
    get created(): string;
    get id(): string;
    get meta(): string;
    get modified(): string;
    get resourceAccountId(): string;
    get resourceId(): string;
    get resourceType(): string;
    get resourceVersion(): number;
    get status(): string;
}
export declare class DataCloudflareShareResourcesResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareShareResourcesResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources cloudflare_share_resources}
*/
export declare class DataCloudflareShareResourcesA extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_share_resources";
    /**
    * Generates CDKTN code for importing a DataCloudflareShareResourcesA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareShareResourcesA to import
    * @param importFromId The id of the existing DataCloudflareShareResourcesA that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareShareResourcesA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.23.0/docs/data-sources/share_resources cloudflare_share_resources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareShareResourcesAConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareShareResourcesAConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _result;
    get result(): DataCloudflareShareResourcesResultList;
    private _shareId?;
    get shareId(): string;
    set shareId(value: string);
    get shareIdInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
