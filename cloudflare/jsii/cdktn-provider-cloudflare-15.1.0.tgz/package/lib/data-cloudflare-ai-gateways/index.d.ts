/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareAiGatewaysConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/ai_gateways#account_id DataCloudflareAiGateways#account_id}
    */
    readonly accountId?: string;
    /**
    * Max items to fetch, default: 1000
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/ai_gateways#max_items DataCloudflareAiGateways#max_items}
    */
    readonly maxItems?: number;
    /**
    * Search by id
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/ai_gateways#search DataCloudflareAiGateways#search}
    */
    readonly search?: string;
}
export interface DataCloudflareAiGatewaysResultDlpPolicies {
}
export declare function dataCloudflareAiGatewaysResultDlpPoliciesToTerraform(struct?: DataCloudflareAiGatewaysResultDlpPolicies): any;
export declare function dataCloudflareAiGatewaysResultDlpPoliciesToHclTerraform(struct?: DataCloudflareAiGatewaysResultDlpPolicies): any;
export declare class DataCloudflareAiGatewaysResultDlpPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewaysResultDlpPolicies | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultDlpPolicies | undefined);
    get action(): string;
    get check(): string[];
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get profiles(): string[];
}
export declare class DataCloudflareAiGatewaysResultDlpPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewaysResultDlpPoliciesOutputReference;
}
export interface DataCloudflareAiGatewaysResultDlp {
}
export declare function dataCloudflareAiGatewaysResultDlpToTerraform(struct?: DataCloudflareAiGatewaysResultDlp): any;
export declare function dataCloudflareAiGatewaysResultDlpToHclTerraform(struct?: DataCloudflareAiGatewaysResultDlp): any;
export declare class DataCloudflareAiGatewaysResultDlpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultDlp | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultDlp | undefined);
    get action(): string;
    get enabled(): cdktn.IResolvable;
    private _policies;
    get policies(): DataCloudflareAiGatewaysResultDlpPoliciesList;
    get profiles(): string[];
}
export interface DataCloudflareAiGatewaysResultGuardrailsPrompt {
}
export declare function dataCloudflareAiGatewaysResultGuardrailsPromptToTerraform(struct?: DataCloudflareAiGatewaysResultGuardrailsPrompt): any;
export declare function dataCloudflareAiGatewaysResultGuardrailsPromptToHclTerraform(struct?: DataCloudflareAiGatewaysResultGuardrailsPrompt): any;
export declare class DataCloudflareAiGatewaysResultGuardrailsPromptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultGuardrailsPrompt | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultGuardrailsPrompt | undefined);
    get p1(): string;
    get s1(): string;
    get s10(): string;
    get s11(): string;
    get s12(): string;
    get s13(): string;
    get s2(): string;
    get s3(): string;
    get s4(): string;
    get s5(): string;
    get s6(): string;
    get s7(): string;
    get s8(): string;
    get s9(): string;
}
export interface DataCloudflareAiGatewaysResultGuardrailsResponse {
}
export declare function dataCloudflareAiGatewaysResultGuardrailsResponseToTerraform(struct?: DataCloudflareAiGatewaysResultGuardrailsResponse): any;
export declare function dataCloudflareAiGatewaysResultGuardrailsResponseToHclTerraform(struct?: DataCloudflareAiGatewaysResultGuardrailsResponse): any;
export declare class DataCloudflareAiGatewaysResultGuardrailsResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultGuardrailsResponse | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultGuardrailsResponse | undefined);
    get p1(): string;
    get s1(): string;
    get s10(): string;
    get s11(): string;
    get s12(): string;
    get s13(): string;
    get s2(): string;
    get s3(): string;
    get s4(): string;
    get s5(): string;
    get s6(): string;
    get s7(): string;
    get s8(): string;
    get s9(): string;
}
export interface DataCloudflareAiGatewaysResultGuardrails {
}
export declare function dataCloudflareAiGatewaysResultGuardrailsToTerraform(struct?: DataCloudflareAiGatewaysResultGuardrails): any;
export declare function dataCloudflareAiGatewaysResultGuardrailsToHclTerraform(struct?: DataCloudflareAiGatewaysResultGuardrails): any;
export declare class DataCloudflareAiGatewaysResultGuardrailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultGuardrails | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultGuardrails | undefined);
    private _prompt;
    get prompt(): DataCloudflareAiGatewaysResultGuardrailsPromptOutputReference;
    private _response;
    get response(): DataCloudflareAiGatewaysResultGuardrailsResponseOutputReference;
}
export interface DataCloudflareAiGatewaysResultOtel {
}
export declare function dataCloudflareAiGatewaysResultOtelToTerraform(struct?: DataCloudflareAiGatewaysResultOtel): any;
export declare function dataCloudflareAiGatewaysResultOtelToHclTerraform(struct?: DataCloudflareAiGatewaysResultOtel): any;
export declare class DataCloudflareAiGatewaysResultOtelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewaysResultOtel | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultOtel | undefined);
    get authorization(): string;
    get contentType(): string;
    private _headers;
    get headers(): cdktn.StringMap;
    get url(): string;
}
export declare class DataCloudflareAiGatewaysResultOtelList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewaysResultOtelOutputReference;
}
export interface DataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProvider {
}
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProviderToTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProvider): any;
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProviderToHclTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProvider): any;
export declare class DataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProvider | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProvider | undefined);
    get mode(): string;
    get values(): string[];
}
export interface DataCloudflareAiGatewaysResultSpendLimitsRulesMetadata {
}
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesMetadataToTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRulesMetadata): any;
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesMetadataToHclTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRulesMetadata): any;
export declare class DataCloudflareAiGatewaysResultSpendLimitsRulesMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataCloudflareAiGatewaysResultSpendLimitsRulesMetadata | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultSpendLimitsRulesMetadata | undefined);
    get mode(): string;
    get values(): string[];
}
export declare class DataCloudflareAiGatewaysResultSpendLimitsRulesMetadataMap extends cdktn.ComplexMap {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataCloudflareAiGatewaysResultSpendLimitsRulesMetadataOutputReference;
}
export interface DataCloudflareAiGatewaysResultSpendLimitsRulesModel {
}
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesModelToTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRulesModel): any;
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesModelToHclTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRulesModel): any;
export declare class DataCloudflareAiGatewaysResultSpendLimitsRulesModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultSpendLimitsRulesModel | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultSpendLimitsRulesModel | undefined);
    get mode(): string;
    get values(): string[];
}
export interface DataCloudflareAiGatewaysResultSpendLimitsRules {
}
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesToTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRules): any;
export declare function dataCloudflareAiGatewaysResultSpendLimitsRulesToHclTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimitsRules): any;
export declare class DataCloudflareAiGatewaysResultSpendLimitsRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewaysResultSpendLimitsRules | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultSpendLimitsRules | undefined);
    private _aiGatewayProvider;
    get aiGatewayProvider(): DataCloudflareAiGatewaysResultSpendLimitsRulesAiGatewayProviderOutputReference;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get limit(): number;
    get limitType(): string;
    private _metadata;
    get metadata(): DataCloudflareAiGatewaysResultSpendLimitsRulesMetadataMap;
    private _model;
    get model(): DataCloudflareAiGatewaysResultSpendLimitsRulesModelOutputReference;
    get technique(): string;
    get window(): number;
}
export declare class DataCloudflareAiGatewaysResultSpendLimitsRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewaysResultSpendLimitsRulesOutputReference;
}
export interface DataCloudflareAiGatewaysResultSpendLimits {
}
export declare function dataCloudflareAiGatewaysResultSpendLimitsToTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimits): any;
export declare function dataCloudflareAiGatewaysResultSpendLimitsToHclTerraform(struct?: DataCloudflareAiGatewaysResultSpendLimits): any;
export declare class DataCloudflareAiGatewaysResultSpendLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultSpendLimits | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultSpendLimits | undefined);
    get enabled(): cdktn.IResolvable;
    private _rules;
    get rules(): DataCloudflareAiGatewaysResultSpendLimitsRulesList;
}
export interface DataCloudflareAiGatewaysResultStripeUsageEvents {
}
export declare function dataCloudflareAiGatewaysResultStripeUsageEventsToTerraform(struct?: DataCloudflareAiGatewaysResultStripeUsageEvents): any;
export declare function dataCloudflareAiGatewaysResultStripeUsageEventsToHclTerraform(struct?: DataCloudflareAiGatewaysResultStripeUsageEvents): any;
export declare class DataCloudflareAiGatewaysResultStripeUsageEventsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewaysResultStripeUsageEvents | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultStripeUsageEvents | undefined);
    get payload(): string;
}
export declare class DataCloudflareAiGatewaysResultStripeUsageEventsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewaysResultStripeUsageEventsOutputReference;
}
export interface DataCloudflareAiGatewaysResultStripe {
}
export declare function dataCloudflareAiGatewaysResultStripeToTerraform(struct?: DataCloudflareAiGatewaysResultStripe): any;
export declare function dataCloudflareAiGatewaysResultStripeToHclTerraform(struct?: DataCloudflareAiGatewaysResultStripe): any;
export declare class DataCloudflareAiGatewaysResultStripeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareAiGatewaysResultStripe | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResultStripe | undefined);
    get authorization(): string;
    private _usageEvents;
    get usageEvents(): DataCloudflareAiGatewaysResultStripeUsageEventsList;
}
export interface DataCloudflareAiGatewaysResult {
}
export declare function dataCloudflareAiGatewaysResultToTerraform(struct?: DataCloudflareAiGatewaysResult): any;
export declare function dataCloudflareAiGatewaysResultToHclTerraform(struct?: DataCloudflareAiGatewaysResult): any;
export declare class DataCloudflareAiGatewaysResultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareAiGatewaysResult | undefined;
    set internalValue(value: DataCloudflareAiGatewaysResult | undefined);
    get authentication(): cdktn.IResolvable;
    get cacheInvalidateOnUpdate(): cdktn.IResolvable;
    get cacheTtl(): number;
    get collectLogs(): cdktn.IResolvable;
    get createdAt(): string;
    private _dlp;
    get dlp(): DataCloudflareAiGatewaysResultDlpOutputReference;
    private _guardrails;
    get guardrails(): DataCloudflareAiGatewaysResultGuardrailsOutputReference;
    get id(): string;
    get isDefault(): cdktn.IResolvable;
    get logManagement(): number;
    get logManagementStrategy(): string;
    get logpush(): cdktn.IResolvable;
    get logpushPublicKey(): string;
    get modifiedAt(): string;
    private _otel;
    get otel(): DataCloudflareAiGatewaysResultOtelList;
    get rateLimitingInterval(): number;
    get rateLimitingLimit(): number;
    get rateLimitingTechnique(): string;
    get retryBackoff(): string;
    get retryDelay(): number;
    get retryMaxAttempts(): number;
    private _spendLimits;
    get spendLimits(): DataCloudflareAiGatewaysResultSpendLimitsOutputReference;
    get storeId(): string;
    private _stripe;
    get stripe(): DataCloudflareAiGatewaysResultStripeOutputReference;
    get workersAiBillingMode(): string;
    get zdr(): cdktn.IResolvable;
}
export declare class DataCloudflareAiGatewaysResultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareAiGatewaysResultOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/ai_gateways cloudflare_ai_gateways}
*/
export declare class DataCloudflareAiGateways extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_ai_gateways";
    /**
    * Generates CDKTN code for importing a DataCloudflareAiGateways resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareAiGateways to import
    * @param importFromId The id of the existing DataCloudflareAiGateways that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/ai_gateways#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareAiGateways to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.20.0/docs/data-sources/ai_gateways cloudflare_ai_gateways} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareAiGatewaysConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataCloudflareAiGatewaysConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
    private _result;
    get result(): DataCloudflareAiGatewaysResultList;
    private _search?;
    get search(): string;
    set search(value: string);
    resetSearch(): void;
    get searchInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
