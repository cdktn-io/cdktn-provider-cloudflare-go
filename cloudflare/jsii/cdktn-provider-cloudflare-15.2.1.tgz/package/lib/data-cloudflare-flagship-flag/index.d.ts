/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataCloudflareFlagshipFlagConfig extends cdktn.TerraformMetaArguments {
    /**
    * Cloudflare account ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/flagship_flag#account_id DataCloudflareFlagshipFlag#account_id}
    */
    readonly accountId: string;
    /**
    * App identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/flagship_flag#app_id DataCloudflareFlagshipFlag#app_id}
    */
    readonly appId: string;
    /**
    * Flag key (slug).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/flagship_flag#flag_key DataCloudflareFlagshipFlag#flag_key}
    */
    readonly flagKey: string;
}
export interface DataCloudflareFlagshipFlagRulesConditionsClauses {
}
export declare function dataCloudflareFlagshipFlagRulesConditionsClausesToTerraform(struct?: DataCloudflareFlagshipFlagRulesConditionsClauses): any;
export declare function dataCloudflareFlagshipFlagRulesConditionsClausesToHclTerraform(struct?: DataCloudflareFlagshipFlagRulesConditionsClauses): any;
export declare class DataCloudflareFlagshipFlagRulesConditionsClausesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipFlagRulesConditionsClauses | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagRulesConditionsClauses | undefined);
    get attribute(): string;
    private _clauses;
    get clauses(): DataCloudflareFlagshipFlagRulesConditionsClausesList;
    get logicalOperator(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataCloudflareFlagshipFlagRulesConditionsClausesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipFlagRulesConditionsClausesOutputReference;
}
export interface DataCloudflareFlagshipFlagRulesConditions {
}
export declare function dataCloudflareFlagshipFlagRulesConditionsToTerraform(struct?: DataCloudflareFlagshipFlagRulesConditions): any;
export declare function dataCloudflareFlagshipFlagRulesConditionsToHclTerraform(struct?: DataCloudflareFlagshipFlagRulesConditions): any;
export declare class DataCloudflareFlagshipFlagRulesConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipFlagRulesConditions | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagRulesConditions | undefined);
    get attribute(): string;
    private _clauses;
    get clauses(): DataCloudflareFlagshipFlagRulesConditionsClausesList;
    get logicalOperator(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataCloudflareFlagshipFlagRulesConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipFlagRulesConditionsOutputReference;
}
export interface DataCloudflareFlagshipFlagRulesRollout {
}
export declare function dataCloudflareFlagshipFlagRulesRolloutToTerraform(struct?: DataCloudflareFlagshipFlagRulesRollout): any;
export declare function dataCloudflareFlagshipFlagRulesRolloutToHclTerraform(struct?: DataCloudflareFlagshipFlagRulesRollout): any;
export declare class DataCloudflareFlagshipFlagRulesRolloutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataCloudflareFlagshipFlagRulesRollout | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagRulesRollout | undefined);
    get attribute(): string;
    get percentage(): number;
}
export interface DataCloudflareFlagshipFlagRules {
}
export declare function dataCloudflareFlagshipFlagRulesToTerraform(struct?: DataCloudflareFlagshipFlagRules): any;
export declare function dataCloudflareFlagshipFlagRulesToHclTerraform(struct?: DataCloudflareFlagshipFlagRules): any;
export declare class DataCloudflareFlagshipFlagRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataCloudflareFlagshipFlagRules | undefined;
    set internalValue(value: DataCloudflareFlagshipFlagRules | undefined);
    private _conditions;
    get conditions(): DataCloudflareFlagshipFlagRulesConditionsList;
    get priority(): number;
    private _rollout;
    get rollout(): DataCloudflareFlagshipFlagRulesRolloutOutputReference;
    get serveVariation(): string;
}
export declare class DataCloudflareFlagshipFlagRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataCloudflareFlagshipFlagRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/flagship_flag cloudflare_flagship_flag}
*/
export declare class DataCloudflareFlagshipFlag extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "cloudflare_flagship_flag";
    /**
    * Generates CDKTN code for importing a DataCloudflareFlagshipFlag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataCloudflareFlagshipFlag to import
    * @param importFromId The id of the existing DataCloudflareFlagshipFlag that should be imported. Refer to the {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/flagship_flag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataCloudflareFlagshipFlag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/cloudflare/cloudflare/5.21.1/docs/data-sources/flagship_flag cloudflare_flagship_flag} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataCloudflareFlagshipFlagConfig
    */
    constructor(scope: Construct, id: string, config: DataCloudflareFlagshipFlagConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get defaultVariation(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _flagKey?;
    get flagKey(): string;
    set flagKey(value: string);
    get flagKeyInput(): string | undefined;
    get key(): string;
    private _rules;
    get rules(): DataCloudflareFlagshipFlagRulesList;
    get type(): string;
    get updatedAt(): string;
    get updatedBy(): string;
    private _variations;
    get variations(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
